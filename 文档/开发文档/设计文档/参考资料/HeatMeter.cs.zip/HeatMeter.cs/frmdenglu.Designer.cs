// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]public partial class frmdenglu
	{
#region Windows 窗体设计器生成的代码
		[System.Diagnostics.DebuggerNonUserCode()]public frmdenglu()
		{
			//此调用是 Windows 窗体设计器所必需的。
			InitializeComponent();
		}
		//窗体重写释放，以清理组件列表。
		[System.Diagnostics.DebuggerNonUserCode()]protected override void Dispose(bool Disposing)
		{
			if (Disposing)
			{
				if (!(components == null))
				{
					components.Dispose();
				}
			}
			base.Dispose(Disposing);
		}
		//Windows 窗体设计器所必需的
		private System.ComponentModel.Container components = null;
		public System.Windows.Forms.ToolTip ToolTip1;
		public System.Windows.Forms.ComboBox Combo1;
		public System.Windows.Forms.Timer Timer1;
		public System.Windows.Forms.TextBox Text2;
		public System.Windows.Forms.Button Command1;
		public System.Windows.Forms.Button Command2;
		public System.Windows.Forms.Label Label1;
		public System.Windows.Forms.Label Label2;
		//注意: 以下过程是 Windows 窗体设计器所必需的
		//可以使用 Windows 窗体设计器来修改它。
		//不要使用代码编辑器修改它。
		[System.Diagnostics.DebuggerStepThrough()]private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmdenglu));
			this.components = new System.ComponentModel.Container();
			base.Load += frmdenglu_Load;
			this.ToolTip1 = new System.Windows.Forms.ToolTip(components);
			this.Combo1 = new System.Windows.Forms.ComboBox();
			this.Combo1.KeyPress += this.combo1_KeyPress;
			this.Timer1 = new System.Windows.Forms.Timer(components);
			this.Timer1.Tick += this.Timer1_Tick;
			this.Text2 = new System.Windows.Forms.TextBox();
			this.Text2.KeyPress += this.Text2_KeyPress;
			this.Command1 = new System.Windows.Forms.Button();
			this.Command1.Click += this.Command1_Click;
			this.Command2 = new System.Windows.Forms.Button();
			this.Command2.Click += this.Command2_Click;
			this.Label1 = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			this.ToolTip1.Active = true;
			this.Text = "系统登录";
			this.ClientSize = new System.Drawing.Size(390, 163);
			this.Location = new System.Drawing.Point(4, 23);
			this.Icon = (System.Drawing.Icon) (resources.GetObject("frmdenglu.Icon"));
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
			this.ControlBox = true;
			this.Enabled = true;
			this.KeyPreview = false;
			this.MaximizeBox = true;
			this.MinimizeBox = true;
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.ShowInTaskbar = true;
			this.HelpButton = false;
			this.WindowState = System.Windows.Forms.FormWindowState.Normal;
			this.Name = "frmdenglu";
			this.Combo1.Font = new System.Drawing.Font("宋体", (float) (14.25F), System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Combo1.Size = new System.Drawing.Size(145, 27);
			this.Combo1.Location = new System.Drawing.Point(136, 16);
			this.Combo1.TabIndex = 5;
			this.Combo1.BackColor = System.Drawing.SystemColors.Window;
			this.Combo1.CausesValidation = true;
			this.Combo1.Enabled = true;
			this.Combo1.ForeColor = System.Drawing.SystemColors.WindowText;
			this.Combo1.IntegralHeight = true;
			this.Combo1.Cursor = System.Windows.Forms.Cursors.Default;
			this.Combo1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Combo1.Sorted = false;
			this.Combo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
			this.Combo1.TabStop = true;
			this.Combo1.Visible = true;
			this.Combo1.Name = "Combo1";
			this.Timer1.Interval = 100;
			this.Timer1.Enabled = true;
			this.Text2.AutoSize = false;
			this.Text2.Font = new System.Drawing.Font("宋体", (float) (14.25F), System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Text2.Size = new System.Drawing.Size(141, 27);
			this.Text2.Location = new System.Drawing.Point(136, 54);
			this.Text2.MaxLength = 4;
			this.Text2.TabIndex = 1;
			this.Text2.AcceptsReturn = true;
			this.Text2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.Text2.BackColor = System.Drawing.SystemColors.Window;
			this.Text2.CausesValidation = true;
			this.Text2.Enabled = true;
			this.Text2.ForeColor = System.Drawing.SystemColors.WindowText;
			this.Text2.HideSelection = true;
			this.Text2.ReadOnly = false;
			this.Text2.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.Text2.Multiline = false;
			this.Text2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Text2.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.Text2.TabStop = true;
			this.Text2.Visible = true;
			this.Text2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.Text2.Name = "Text2";
			this.Command1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.Command1.Text = "确定";
			this.Command1.Font = new System.Drawing.Font("宋体", (float) (10.5F), System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Command1.Size = new System.Drawing.Size(67, 31);
			this.Command1.Location = new System.Drawing.Point(120, 104);
			this.Command1.TabIndex = 4;
			this.Command1.BackColor = System.Drawing.SystemColors.Control;
			this.Command1.CausesValidation = true;
			this.Command1.Enabled = true;
			this.Command1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Command1.Cursor = System.Windows.Forms.Cursors.Default;
			this.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Command1.TabStop = true;
			this.Command1.Name = "Command1";
			this.Command2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.Command2.Text = "退出";
			this.Command2.Font = new System.Drawing.Font("宋体", (float) (10.5F), System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Command2.Size = new System.Drawing.Size(67, 31);
			this.Command2.Location = new System.Drawing.Point(216, 104);
			this.Command2.TabIndex = 0;
			this.Command2.BackColor = System.Drawing.SystemColors.Control;
			this.Command2.CausesValidation = true;
			this.Command2.Enabled = true;
			this.Command2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Command2.Cursor = System.Windows.Forms.Cursors.Default;
			this.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Command2.TabStop = true;
			this.Command2.Name = "Command2";
			this.Label1.Text = "名    称：";
			this.Label1.Font = new System.Drawing.Font("宋体", (float) (10.5F), System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Label1.Size = new System.Drawing.Size(70, 14);
			this.Label1.Location = new System.Drawing.Point(64, 22);
			this.Label1.TabIndex = 3;
			this.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.Label1.BackColor = System.Drawing.SystemColors.Control;
			this.Label1.Enabled = true;
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Label1.Cursor = System.Windows.Forms.Cursors.Default;
			this.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Label1.UseMnemonic = true;
			this.Label1.Visible = true;
			this.Label1.AutoSize = true;
			this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.Label1.Name = "Label1";
			this.Label2.Text = "密    码：";
			this.Label2.Font = new System.Drawing.Font("宋体", (float) (10.5F), System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Label2.Size = new System.Drawing.Size(70, 14);
			this.Label2.Location = new System.Drawing.Point(64, 60);
			this.Label2.TabIndex = 2;
			this.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this.Label2.BackColor = System.Drawing.SystemColors.Control;
			this.Label2.Enabled = true;
			this.Label2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Label2.Cursor = System.Windows.Forms.Cursors.Default;
			this.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Label2.UseMnemonic = true;
			this.Label2.Visible = true;
			this.Label2.AutoSize = true;
			this.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.Label2.Name = "Label2";
			this.Controls.Add(Combo1);
			this.Controls.Add(Text2);
			this.Controls.Add(Command1);
			this.Controls.Add(Command2);
			this.Controls.Add(Label1);
			this.Controls.Add(Label2);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
#endregion
	}
}
