// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]public partial class comm
	{
#region Windows 窗体设计器生成的代码
		[System.Diagnostics.DebuggerNonUserCode()]public comm()
		{
			//此调用是 Windows 窗体设计器所必需的。
			InitializeComponent();
		}
		//窗体重写释放，以清理组件列表。
		[System.Diagnostics.DebuggerNonUserCode()]protected override void Dispose(bool Disposing)
		{
			if (Disposing)
			{
				if (!(components == null))
				{
					components.Dispose();
				}
			}
			base.Dispose(Disposing);
		}
		//Windows 窗体设计器所必需的
		private System.ComponentModel.Container components = null;
		public System.Windows.Forms.ToolTip ToolTip1;
		public AxMSCommLib.AxMSComm MSComm3;
		public AxMSCommLib.AxMSComm MSComm2;
		public AxMSCommLib.AxMSComm MSComm4;
		public System.Windows.Forms.Timer Timer1;
		public AxMSCommLib.AxMSComm MSComm1;
		//注意: 以下过程是 Windows 窗体设计器所必需的
		//可以使用 Windows 窗体设计器来修改它。
		//不要使用代码编辑器修改它。
		[System.Diagnostics.DebuggerStepThrough()]private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(comm));
			this.components = new System.ComponentModel.Container();
			base.Load += comm_Load;
			this.ToolTip1 = new System.Windows.Forms.ToolTip(components);
			this.MSComm3 = new AxMSCommLib.AxMSComm();
			this.MSComm2 = new AxMSCommLib.AxMSComm();
			this.MSComm4 = new AxMSCommLib.AxMSComm();
			this.Timer1 = new System.Windows.Forms.Timer(components);
			this.MSComm1 = new AxMSCommLib.AxMSComm();
			this.SuspendLayout();
			this.ToolTip1.Active = true;
			((System.ComponentModel.ISupportInitialize) this.MSComm3).BeginInit();
			((System.ComponentModel.ISupportInitialize) this.MSComm2).BeginInit();
			((System.ComponentModel.ISupportInitialize) this.MSComm4).BeginInit();
			((System.ComponentModel.ISupportInitialize) this.MSComm1).BeginInit();
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "通讯";
			this.ClientSize = new System.Drawing.Size(332, 111);
			this.Location = new System.Drawing.Point(163, 274);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
			this.ControlBox = true;
			this.Enabled = true;
			this.KeyPreview = false;
			this.MaximizeBox = true;
			this.MinimizeBox = true;
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.ShowInTaskbar = true;
			this.HelpButton = false;
			this.WindowState = System.Windows.Forms.FormWindowState.Normal;
			this.Name = "comm";
			MSComm3.OcxState = (System.Windows.Forms.AxHost.State) (resources.GetObject("MSComm3.OcxState"));
			this.MSComm3.Location = new System.Drawing.Point(251, 49);
			this.MSComm3.Name = "MSComm3";
			MSComm2.OcxState = (System.Windows.Forms.AxHost.State) (resources.GetObject("MSComm2.OcxState"));
			this.MSComm2.Location = new System.Drawing.Point(138, 65);
			this.MSComm2.Name = "MSComm2";
			MSComm4.OcxState = (System.Windows.Forms.AxHost.State) (resources.GetObject("MSComm4.OcxState"));
			this.MSComm4.Location = new System.Drawing.Point(73, 17);
			this.MSComm4.Name = "MSComm4";
			this.Timer1.Interval = 50;
			this.Timer1.Enabled = true;
			MSComm1.OcxState = (System.Windows.Forms.AxHost.State) (resources.GetObject("MSComm1.OcxState"));
			this.MSComm1.Location = new System.Drawing.Point(170, 0);
			this.MSComm1.Name = "MSComm1";
			this.Controls.Add(MSComm3);
			this.Controls.Add(MSComm2);
			this.Controls.Add(MSComm4);
			this.Controls.Add(MSComm1);
			((System.ComponentModel.ISupportInitialize) this.MSComm1).EndInit();
			((System.ComponentModel.ISupportInitialize) this.MSComm4).EndInit();
			((System.ComponentModel.ISupportInitialize) this.MSComm2).EndInit();
			((System.ComponentModel.ISupportInitialize) this.MSComm3).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
#endregion
	}
}
