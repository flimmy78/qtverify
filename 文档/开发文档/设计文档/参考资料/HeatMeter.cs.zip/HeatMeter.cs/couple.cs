// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using Microsoft.VisualBasic.CompilerServices;

namespace 热量表
{
	partial class mainForm : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static mainForm defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static mainForm Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new mainForm();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		object t;
		object b8;
		object Rtp;
		object deltaW;
		object wt;
		object wrt;
		object a8;
		object r;
		object a;
		double b;
		
		public object t1;
		public object t2;
		public float t3;
		float[] pt1000 = new float[101];
		short msg;
		ADODB.Recordset Namefind;
		
		short[] WuCha = new short[21];
		float[] mi = new float[9];
		float[] mi1 = new float[9];
		short Pt_XH;
		object sj2;
		object sj5;
		object sj6;
		object sc2;
		object sc5;
		object sc6;
		private void about_Click()
		{
			object aboutForm = null;
			//UPGRADE_WARNING: 未能解析对象 aboutForm.Show 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			());
		}
		public float standom_t(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[2] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[3] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[1];
			returnValue = (float) (System.Math.Round(System.Convert.ToDouble((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa)), 4));
			return returnValue;
		}
		public float standom_t1(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[5] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[6] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[4];
			returnValue = (float) (System.Math.Round(System.Convert.ToDouble((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa)), 4));
			return returnValue;
		}
		
		private void pt_centgrade()
		{
			//以下是铂电阻计算程序：
			double[] d = new double[10];
			double wt = 0;
			double deltaW = 0;
			double wrt = 0;
			double pt;
			double r = 0;
			double t = 0;
			double a;
			double b;
			double a8 = 0;
			double b8 = 0;
			double rpt = 0;
			
			float t1;
			float t2;
			float t3;
			
			float[] pt1000 = new float[101];
			short i = 0;
			
			d[0] = 439.932854;
			d[1] = 472.41802;
			d[2] = 37.684494;
			d[3] = 7.472018;
			d[4] = 2.920828;
			d[5] = 0.005184;
			d[6] = -0.963864;
			d[7] = -0.188732;
			d[8] = 0.191203;
			d[9] = 0.049025;
			
			//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			r = System.Convert.ToDouble(sub_Renamed.pt_om);
			//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			a8 = System.Convert.ToDouble(sub_Renamed.pt_a8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b8 = System.Convert.ToDouble(sub_Renamed.pt_b8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			rpt = System.Convert.ToDouble(sub_Renamed.pt_Rpt);
			
			wt = r / rpt;
			deltaW = a8 * (wt - 1) + b8 * Math.Pow((wt - 1), 2);
			wrt = wt - deltaW;
			t = 0;
			for (i = 0; i <= 9; i++)
			{
				t = t + d[i] * Math.Pow(((wrt - 2.64) / 1.64), i); //t=d0*sum[di(Wr(t)-2.64)/1.64]^I;I:1 to 9
			}
			t1 = (float) t;
			sub_Renamed.centgrade = System.Math.Round(t, 4);
			
		}
		
		private void exitCommand_Click()
		{
			this.Close();
		}
		
		
		private void cmdDaYin_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			msg = (short) (Interaction.MsgBox("请您确认是否打印？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "打印提示"));
			switch (msg)
			{
				case (short) MsgBoxResult.Yes:
					Module1.PrintCouple();
					break;
				case (short) MsgBoxResult.No:
					return;
			}
		}
		
		
		private void cmdpause_Click()
		{
			
		}
		
		public void cmdQuit_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmbdzcssz.Default.Show();
			
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Kk1;
			object Wendu_js1;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			MSComm6.PortOpen = true;
			Timer9.Enabled = false;
			Timer10.Enabled = false;
			Timer5.Enabled = false;
			Timer3.Enabled = false;
			Timer4.Enabled = false;
			Timer7.Enabled = false;
			if (Pt_XH == 2)
			{
				MSComm6.Settings = "9600,n,8,1";
				MSComm6.InputLen = (short) 0; //串口清空
				Timer1.Enabled = true;
				Timer2.Enabled = true;
			}
			else if (Pt_XH == 3)
			{
				MSComm6.Settings = "4800,n,8,1";
				MSComm6.InputLen = (short) 0;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = 0;
				Timer6.Enabled = true;
				//Timer22.Enabled = True
			}
			else if (Pt_XH == 1)
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
			}
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Pt_XH == 2)
			{
				Timer1.Enabled = false;
				Timer2.Enabled = false;
				Text10[1].Text = "";
				//Text31(1).Text = ""
				Text26[1].Text = "";
				//Text27(1).Text = ""
				Text10[1].Visible = true;
				Text26[1].Visible = true;
			}
			else if (Pt_XH == 3)
			{
				Text10[1].Text = "";
				//Text31(1).Text = ""
				Text26[1].Text = "";
				//Text27(1).Text = ""
				Timer6.Enabled = false;
				//Timer22.Enabled = False
			}
			else if (Pt_XH == 1)
			{
				
			}
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Kk1;
			object Wendu_js1;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			MSComm6.PortOpen = true;
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer6.Enabled = false;
			Timer9.Enabled = false;
			Timer10.Enabled = false;
			Timer5.Enabled = false;
			if (Pt_XH == 2)
			{
				MSComm6.Settings = "9600,n,8,1";
				MSComm6.InputLen = (short) 0; //串口清空
				Timer3.Enabled = true;
				Timer4.Enabled = true;
			}
			else if (Pt_XH == 3)
			{
				MSComm6.Settings = "4800,n,8,1";
				MSComm6.InputLen = (short) 0;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = 0;
				Timer7.Enabled = true;
				//Timer22.Enabled = True
			}
			else if (Pt_XH == 1)
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
			}
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Pt_XH == 2)
			{
				Timer3.Enabled = false;
				Timer4.Enabled = false;
				Text10[2].Text = "";
				//Text31(2).Text = ""
				Text26[2].Text = "";
				//Text27(2).Text = ""
				Text10[2].Visible = true;
				Text26[2].Visible = true;
			}
			else if (Pt_XH == 3)
			{
				Text10[2].Text = "";
				//Text31(2).Text = ""
				Text26[2].Text = "";
				//Text27(2).Text = ""
				Timer7.Enabled = false;
				//Timer22.Enabled = False
			}
			else if (Pt_XH == 1)
			{
				
			}
		}
		
		public void Command7_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Kk1;
			object Wendu_js1;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			MSComm6.PortOpen = true;
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer6.Enabled = false;
			Timer3.Enabled = false;
			Timer4.Enabled = false;
			Timer7.Enabled = false;
			
			if (Pt_XH == 2)
			{
				MSComm6.Settings = "9600,n,8,1";
				MSComm6.InputLen = (short) 0; //串口清空
				Timer9.Enabled = true;
				Timer10.Enabled = true;
			}
			else if (Pt_XH == 3)
			{
				MSComm6.Settings = "4800,n,8,1";
				MSComm6.InputLen = (short) 0;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = 0;
				Timer5.Enabled = true;
				//Timer22.Enabled = True
			}
			else if (Pt_XH == 1)
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
			}
		}
		
		public void Command8_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Pt_XH == 2)
			{
				Timer9.Enabled = false;
				Timer10.Enabled = false;
				Text10[0].Text = "";
				//Text31(0).Text = ""
				Text26[0].Text = "";
				//Text27(0).Text = ""
				Text10[0].Visible = true;
				Text26[0].Visible = true;
			}
			else if (Pt_XH == 3)
			{
				Text10[0].Text = "";
				//Text31(0).Text = ""
				Text26[0].Text = "";
				//Text27(0).Text = ""
				Timer5.Enabled = false;
				//Timer22.Enabled = False
			}
			else if (Pt_XH == 1)
			{
				
			}
		}
		
		public void mainForm_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Index = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//读被检铂电阻参数：
			short n = 0;
			
			short int1;
			//  Text34(0).Text = "误差(%)"
			//     Text32(0).Text = "误差(%)"
			//      Text33(0).Text = "误差(%)"
			
			if (sub_Renamed.Chinese == true)
			{
				this.Text = "铂电阻数值比较法检测";
				Label12[4].Text = "检测数据输入";
				Label12[1].Text = "检测数据计算";
				Frame1[0].Text = "第一温差点";
				Frame1[7].Text = "第二温差点";
				Frame1[8].Text = "第三温差点";
				Frame2[0].Text = "第一温差点";
				Frame6.Text = "第二温差点";
				Frame5.Text = "第三温差点";
				Label1[0].Text = "标准温度";
				Label1[1].Text = "标准温度";
				Label1[2].Text = "标准温度";
				
				Label21[0].Text = "电阻值(Ω)";
				Label21[1].Text = "电阻值(Ω)";
				Label21[2].Text = "电阻值(Ω)";
				Label24[0].Text = "温度值(℃)";
				Label24[1].Text = "温度值(℃)";
				Label24[2].Text = "温度值(℃)";
				Label7[0].Text = "被检温度传感器";
				Label7[1].Text = "被检温度传感器";
				Label7[2].Text = "被检温度传感器";
				Label12[0].Text = "(以下输入铂电阻值Ω)";
				Label12[2].Text = "(以下输入铂电阻值Ω)";
				Label12[3].Text = "(以下输入铂电阻值Ω)";
				
				Text28.Text = "编号";
				Text45[0].Text = "进口";
				Text70[2].Text = "进口";
				Text70[4].Text = "进口";
				Text45[1].Text = "进口";
				Text70[7].Text = "进口";
				Text70[9].Text = "进口";
				
				
				Text6[6].Text = "进口";
				Text6[8].Text = "进口";
				Text6[10].Text = "进口";
				Text6[7].Text = "出口";
				Text6[9].Text = "出口";
				Text6[11].Text = "出口";
				Text6[3].Text = "温差";
				Text6[4].Text = "温差";
				Text6[5].Text = "温差";
				Text70[1].Text = "出口";
				Text70[3].Text = "出口";
				Text70[5].Text = "出口";
				Text70[0].Text = "出口";
				Text70[6].Text = "出口";
				Text70[8].Text = "出口";
				
				
				
				wcx[0].Text = "误差限(℃/%)";
				wcx[1].Text = "误差限(℃/%)";
				wcx[2].Text = "误差限(℃/%)";
				Text7.Text = "进口温度 (℃)";
				Text8.Text = "出口温度 (℃)";
				Text34[0].Text = "误差 (%)";
				Text30.Text = "进口温度 (℃)";
				Text29.Text = "出口温度 (℃)";
				Text34[1].Text = "误差 (%)";
				
				Text14.Text = "进口温度 (℃)";
				Text9.Text = "出口温度 (℃)";
				Text34[2].Text = "误差 (%)";
				
				Command1.Text = "参    数";
				SSCommand2.Text = "生成表格";
				SSCommand1.Text = "保存记录";
				cmdquit.Text = "退出系统";
				Labt.Text = "操作步骤：1、请首先进行参数设置；2、输入检定数据；3、生成表格；4、保存数据；5、退出。";
			}
			else
			{
				this.Text = "Temperature sensors-Value comparison";
				Label12[4].Text = "Value input";
				Label12[1].Text = "Value comparison";
				Frame1[0].Text = "Diff.temp.1";
				Frame1[7].Text = "Diff.temp.2";
				Frame1[8].Text = "Diff.temp.3";
				Frame2[0].Text = "Diff.temp.1";
				Frame6.Text = "Diff.temp.2";
				Frame5.Text = "Diff.temp.3";
				Label1[0].Text = "Stand.temp.";
				Label1[1].Text = "Stand.temp.";
				Label1[2].Text = "Stand.temp.";
				
				Label21[0].Text = "Resis.Ω)";
				Label21[1].Text = "Resis.(Ω)";
				Label21[2].Text = "Resis.(Ω)";
				Label24[0].Text = "Temp.(℃)";
				Label24[1].Text = "Temp.(℃)";
				Label24[2].Text = "Temp.(℃)";
				Label7[0].Text = "Temp.Sensor";
				Label7[1].Text = "Temp.Sensor";
				Label7[2].Text = "Temp.Sensor";
				Label12[0].Text = "(Input resistance value Ω)";
				Label12[2].Text = "(Input resistance value Ω)";
				Label12[3].Text = "(Input resistance value Ω)";
				
				Text28.Text = "No.";
				Text45[0].Text = "Flow";
				Text70[2].Text = "Flow";
				Text70[4].Text = "Flow";
				Text45[1].Text = "Flow";
				Text70[7].Text = "Flow";
				Text70[9].Text = "Flow";
				Text6[6].Text = "Flow";
				Text6[8].Text = "Flow";
				Text6[10].Text = "Flow";
				Text6[7].Text = "Return";
				Text6[9].Text = "Return";
				Text6[11].Text = "Return";
				Text6[3].Text = "Δθ";
				Text6[4].Text = "Δθ";
				Text6[5].Text = "Δθ";
				Text70[1].Text = "Return";
				Text70[3].Text = "Return";
				Text70[5].Text = "Return";
				Text70[0].Text = "Return";
				Text70[6].Text = "Return";
				Text70[8].Text = "Return";
				wcx[0].Text = "MPE (℃/%)";
				wcx[1].Text = "MPE (℃/%)";
				wcx[2].Text = "MPE (℃/%)";
				Text7.Text = "Fl.(℃)";
				Text8.Text = "Re.(℃)";
				Text34[0].Text = "Δθ(%)";
				Text30.Text = "Fl.(℃)";
				Text29.Text = "Re.(℃)";
				Text34[1].Text = "Δθ(%)";
				
				Text14.Text = "Fl.(℃)";
				Text9.Text = "Re.(℃)";
				Text34[2].Text = "Δθ(%)";
				
				Command1.Text = "Setup";
				SSCommand2.Text = "Report";
				SSCommand1.Text = "Save";
				cmdquit.Text = "Exit";
				Labt.Text = "Step：1、Setup 2、Data input 3、Report 4、Save 5、Exit";
			}
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer3.Enabled = false;
			Timer4.Enabled = false;
			Timer5.Enabled = false;
			Timer6.Enabled = false;
			Timer7.Enabled = false;
			Timer9.Enabled = false;
			Timer10.Enabled = false;
			
			
			//MSComm3.CommPort = Com4 '标温进口
			//MSComm3.RThreshold = 80
			MSComm6.CommPort = sub_Renamed.Com4; //标准出口
			MSComm6.RThreshold = (short) 80;
			
			//If MSComm3.PortOpen = True Then MSComm3.PortOpen = False
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			
			FileSystem.FileClose(1);
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\bjpt_canshu.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			
			
			FileSystem.Input(1, ref mi1[1]);
			FileSystem.Input(1, ref mi1[2]);
			FileSystem.Input(1, ref mi1[3]);
			Frame2[1].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2055)));
			
			
			//
			//'frmbdzcssz.Twcd.Text = m0
			//Text3(0).Text = mi(1)
			//Text4(0).Text = mi(2)
			//Text5(0).Text = mi(3)
			//'Text30.Text = m4
			Text11[0].Text = (mi1[1]).ToString();
			Text12[0].Text = (mi1[2]).ToString();
			Text13[0].Text = (mi1[3]).ToString();
			
			FileSystem.FileClose(1);
			
			FileSystem.FileClose(23);
			Module1.sFileCanShu = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\pt_canshu.dll";
			FileSystem.FileOpen(23, Module1.sFileCanShu, OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			for (n = 1; n <= 7; n++)
			{
				FileSystem.Input(23, ref mi[n]);
			}
			FileSystem.FileClose(23);
			
			FileSystem.FileClose(11);
			FileSystem.FileOpen(11, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(11, ref Pt_XH);
			FileSystem.FileClose(11);
			
			
			//Dim i As Integer
			for ( = ;0; i <= 15); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 Index 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Index = sub_Renamed.i;
				Text44[Index].Text = "";
				Text55[Index].Text = "";
				Text56[Index].Text = "";
				Text57[Index].Text = "";
				Text58[Index].Text = "";
				Text59[Index].Text = "";
				Text60[Index].Text = "";
				text17[Index].Text = "";
				Text18[Index].Text = "";
				Text19[Index].Text = "";
				Text20[Index].Text = "";
				Text21[Index].Text = "";
				Text22[Index].Text = "";
				Text23[Index].Text = "";
				Text24[Index].Text = "";
				Text25[Index].Text = "";
				
				Text1[Index].Text = "";
				Text2[Index].Text = "";
				
				text17[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text18[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text19[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text20[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text21[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text22[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text23[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text24[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text25[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				//
				//    Text80(Index).BackColor = &HC0E0FF
				//    Text81(Index).BackColor = &HC0E0FF
				//    Text82(Index).BackColor = &HC0E0FF
				//
				
				//    Text17(Index).Locked = True
				//    Text18(Index).Locked = True
				//    Text19(Index).Locked = True
				//    Text20(Index).Locked = True
				//    Text21(Index).Locked = True
				//    Text22(Index).Locked = True
				//    Text23(Index).Locked = True
				//    Text24(Index).Locked = True
				//    Text25(Index).Locked = True
				
				//    Text80(Index).Locked = True
				//    Text81(Index).Locked = True
				//    Text82(Index).Locked = True
				//
				
				
				text17[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text18[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text19[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text20[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text21[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text22[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text23[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text24[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text25[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				
				//    Text80(Index).Alignment = 1
				//    Text81(Index).Alignment = 1
				//    Text82(Index).Alignment = 1
			}
			Text10[0].Text = "";
			Text10[1].Text = "";
			Text10[2].Text = "";
			Text31[0].Text = "";
			Text31[1].Text = "";
			Text31[2].Text = "";
			Text26[0].Text = "";
			Text26[1].Text = "";
			Text26[2].Text = "";
			Text27[0].Text = "";
			Text27[1].Text = "";
			Text27[2].Text = "";
			
			Text38[0].Text = ""; //铂电阻计算输入框
			Text39[1].Text = "";
			Text39[2].Text = "";
			Text40[1].Text = "";
			Text40[2].Text = "";
			Text41[1].Text = "";
			Text41[2].Text = "";
			
			Frame4.Visible = false;
			//    Label6.Visible = False
			
			//    For i = 0 To 15
			//        Text80(i).Visible = False
			//        Text81(i).Visible = False
			//        Text82(i).Visible = False
			//    Next i
			//
			
			
			//shuju(5).Text = Worke
			//shuju(6).Text = Worke
			
			
			
		}
		
		
		
		
		private void ptin_Click()
		{
			
		}
		
		public void mainForm_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer3.Enabled = false;
			Timer4.Enabled = false;
			Timer5.Enabled = false;
			Timer6.Enabled = false;
			Timer7.Enabled = false;
			Timer9.Enabled = false;
			Timer10.Enabled = false;
			//If MSComm3.PortOpen = True Then MSComm3.PortOpen = False
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
		}
		
		//UPGRADE_ISSUE: Frame 事件 Frame3.DblClick 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="ABD9AF39-7E24-4AFF-AD8D-3675C1AA3054"”
		// VBConversions Note: Former VB static variables moved to class level because they aren't supported in C#.
		private bool Frame3_DblClick_sw = default(bool);
		
		private void Frame3_DblClick(short Index)
		{
			// static bool sw = default(bool); VBConversions Note: Static variable moved to class level and renamed Frame3_DblClick_sw. Local static variables are not supported in C#.
			Frame3_DblClick_sw = !Frame3_DblClick_sw;
			if (Frame3_DblClick_sw == true)
			{
				Frame4.Visible = true;
				Label5.Text = "(双击关闭)";
				Text39[1].Focus();
			}
			else
			{
				Frame4.Visible = false;
				Label5.Text = "(双击数据输入)";
			}
		}
		
		
		
		//UPGRADE_ISSUE: Frame 事件 Frame4.DblClick 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="ABD9AF39-7E24-4AFF-AD8D-3675C1AA3054"”
		private void Frame4_DblClick()
		{
			Frame4.Visible = false;
			
		}
		
		private void myfile_Click()
		{
			
		}
		
		private void Option1_Click()
		{
			
		}
		
		//Private Sub Option3_Click()
		//    Frame2(0).Caption = "配对计算结果"
		//    Text26(0).Visible = True
		//    Text26(1).Visible = True
		//    Text26(2).Visible = True
		//    Text27(0).Visible = True
		//    Text27(1).Visible = True
		//    Text27(2).Visible = True
		//    Label7.Visible = True
		//
		//    Text34(0).Text = "误差(%)"
		//     Text32(0).Text = "误差(%)"
		//      Text33(0).Text = "误差(%)"
		//        Text34(1).Visible = False
		//     Text32(1).Visible = False
		//      Text33(1).Visible = False
		///    Frame2(1).Caption = "配对计算结果(温差值)"
		//
		//
		//'    Label6.Visible = False
		//    For i = 0 To 15
		//        Text80(i).Visible = False
		//        Text81(i).Visible = False
		//        Text82(i).Visible = False
		//    Next i
		//'     Frame2(1).Width = 2055
		//
		//
		//End Sub
		
		//Private Sub Option4_Click()
		//    Frame2(0).Caption = "单支计算结果"
		//'    Frame2(1).Caption = "单支计算结果(绝对温度差值)"
		//    Text26(0).Visible = False
		//    Text26(1).Visible = False
		//    Text26(2).Visible = False
		//    Text27(0).Visible = False
		//    Text27(1).Visible = False
		//    Text27(2).Visible = False
		//    Label7.Visible = False
		//    Label1(0).Caption = "标准温度（进口）"
		//'
		//'    Text45(0).Text = "(1)"
		//'    Text70(1).Text = "(2)"
		//'    Text70(2).Text = "(1)"
		//'    Text70(3).Text = "(2)"
		//'    Text70(4).Text = "(1)"
		//'    Text70(5).Text = "(2)"
		//'
		//'    Text7.Text = "(1)"
		//'    Text8.Text = "(2)"
		//'    Text9.Text = "(1)"
		//'    Text14.Text = "(2)"
		//'    Text15.Text = "(1)"
		//'    Text16.Text = "(2)"
		//
		//'    Label6.Visible = True
		//    Text34(0).Text = "进口误差(K)"
		//     Text32(0).Text = "进口误差(K)"
		//      Text33(0).Text = "进口误差(K)"
		//        Text34(1).Visible = True
		//     Text32(1).Visible = True
		//      Text33(1).Visible = True
		//       Text34(1).Text = "出口误差(K)"
		//     Text32(1).Text = "出口误差(K)"
		//      Text33(1).Text = "出口误差(K)"
		//    For i = 0 To 15
		//        Text80(i).Visible = True
		//        Text81(i).Visible = True
		//        Text82(i).Visible = True
		//    Next i
		//'    Frame2(1).Width = 4095
		//End Sub
		
		private void reports_Click()
		{
			
		}
		
		private void savekey_Click()
		{
			//On Error Resume Next
			//Close #1
			//Dim m0, m4 As String, m1, m2, m3, m5, m6, m7 As Single
			//Open App.Path + "\pt_canshu.dll" For Output As #1
			//
			//m0 = frmbdzcssz.Twcd.Text
			//m1 = Val(Text3(0).Text)
			//m2 = Val(Text4(0).Text)
			//m3 = Val(Text5(0).Text)
			//m4 = Text30.Text
			//m5 = Val(Text3(1).Text)
			//m6 = Val(Text4(1).Text)
			//m7 = Val(Text5(1).Text)
			//
			//Write #1, m0
			//Write #1, m1
			//Write #1, m2
			//Write #1, m3
			//Write #1, m4
			//Write #1, m5
			//Write #1, m6
			//Write #1, m7
			//
			//Close #1
			
		}
		
		public void SSCommand1_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			string StrSql = "";
			short jd = 0;
			
			sub_Renamed.yibiao_No = int.Parse("");
			sub_Renamed.yibiao_No = (int) (sub_Renamed.yibiao_No + double.Parse(Conversion.Str(Mdlguanfa.yibiaoNo)));
			sub_Renamed.save_execel();
			sub_Renamed.XlApp.Workbooks[1].SaveAs((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\report\\" + (sub_Renamed.yibiao_No).ToString().Trim() + ".xls", null, null, null, null, null, (Microsoft.Office.Interop.Excel.XlSaveAsAccessMode) 1, null, null, null, null, null);
			
			if (sub_Renamed.Chinese == true)
			{
				sub_Renamed.Title = "保存数据";
				msg = (short) (Interaction.MsgBox("请您确认输入项是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示"));
			}
			else
			{
				sub_Renamed.Title = "保存数据";
				msg = (short) (Interaction.MsgBox("Please confirm the saved data are correct？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "Note"));
			}
			switch (msg)
			{
				case (short) MsgBoxResult.Yes:
					StrSql = "select * from bdzpd ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					for (jd = 0; jd <= 15; jd++)
					{
						if (Strings.Len(this.Text44[jd].Text) == 0)
						{
							break;
						}
						sub_Renamed.RsZbs.AddNew(null, null);
						sub_Renamed.RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
						sub_Renamed.RsZbs.Fields[1].Value = this.Text44[jd].Text;
						sub_Renamed.RsZbs.Fields[2].Value = DateAndTime.Today;
						sub_Renamed.RsZbs.Fields[3].Value = frmbdzcssz.Default.shuju[8].Text;
						sub_Renamed.RsZbs.Update(null, null);
					}
					sub_Renamed.RsZbs.Close();
					
					//            MsgBox "保存完毕！保存路径\lib\jiliang.mdb jcjg", vbInformation, "保存完毕"
					//            MsgBox App.Path & "\report\" & Trim(yibiao_No) & ".xls"
					return;
				case (short) MsgBoxResult.No:
					
					return;
			}
		}
		
		public void SSCommand2_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.gain_fileNO();
			
			
			Module1.PrintCoupleBJ();
		}
		
		public void Text10_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text10.GetIndex(eventSender); //电阻_温度值转换（上一行）
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				//           If Val(Text10(Index).Text) <= 99 Or Val(Text10(Index).Text) > 140 Then
				//            MsgBox ("进口二等标准铂电阻输入电阻值超出范围！")
				//              Text10(Index).Text = ""
				//              Text31(Index).Text = ""
				//              Text10(Index).SetFocus
				//              Exit Sub
				//            End If
				//
				//
				//           r = Val(Text10(Index).Text)
				//           Call standom_t
				//           Text31(Index).Text = standom_t(Val(r))
				Text26[Index].Focus();
				//           Index = Index + 1
				//           If Index = 3 Then Index = 0
				//           Text10(Index).SetFocus
				
				
				
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text10.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text10_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text10.GetIndex(eventSender);
			
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (mi[7] == 1)
			{
				//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_Rpt = mi[1];
				//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_a8 = mi[2];
				//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_b8 = mi[3];
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text10[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 20 & sub_Renamed.pt_om <= 40)
				{
					pt_centgrade();
					Text31[Index].Text = Text31(sub_Renamed.centgrade, "0.000");
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text10[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 99 & sub_Renamed.pt_om <= 140)
				{
					Text31[Index].Text = Text31(standom_t((float) (Conversion.Val(Text10[Index].Text))), "0.000");
				}
			}
		}
		public void Text13_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text13.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text17_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = text17.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				if (Text31[0].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					text17[Index].Text = "";
					Text10[0].Focus();
					goto EventExitSub;
				}
				//                Text26(Index) = Round(Abs(Val(Text17(Index).Text) - Text31(0).Text), 2)
				if (System.Math.Abs((System.Convert.ToDouble(text17[Index].Text)) - Conversion.Val(Text31[0].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[0].Text)) //误差判断，超过误差显示为红色
				{
					text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
				Text18[Index].Focus();
				
				
				
			}
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text18_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text18.GetIndex(eventSender);
			object deltaCa2 = null;
			object deltaCa1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				if (Text27[0].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text18[Index].Text = "";
					Text26[0].Focus();
					goto EventExitSub;
				}
				
				if (text17[Index].Text == "")
				{
					MessageBox.Show("请先输入进口温度!");
					Text18[Index].Text = "";
					text17[Index].Focus();
					goto EventExitSub;
				}
				//                Text26(Index + 16) = Round(Abs(Val(Text18(Index).Text) - Text31(0).Text), 2)
				if (System.Math.Abs((System.Convert.ToDouble(Text18[Index].Text)) - Conversion.Val(Text27[0].Text)) > 0.3 + 0.005 * Conversion.Val(Text27[0].Text)) //误差判断，超过误差显示为红色
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
				
				//温差示值-温差标准值：
				//UPGRADE_WARNING: 未能解析对象 deltaCa1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				deltaCa1 = Conversion.Val((System.Convert.ToDouble(text17[Index].Text)) - Conversion.Val(Text18[Index].Text).ToString()); //示值差
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				deltaCa2 = Conversion.Val((System.Convert.ToDouble(Text31[0].Text)) - Conversion.Val(Text27[0].Text).ToString()); //标准差
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 deltaCa1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = System.Convert.ToDouble(System.Convert.ToInt32(System.Convert.ToDouble(deltaCa1) - System.Convert.ToDouble(deltaCa2)) / System.Convert.ToDouble(deltaCa2)) * 100; //绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text23[Index].Text = Text23(t, "0.0");
				
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(t) > (0.5 + 3 * (Conversion.Val(frmbdzcssz.Default.Twcd.Text)) / deltaCa2))
				{
					Text23[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[7] = (short) 1;
				}
				else
				{
					Text23[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[7] = (short) 0;
				}
				
				Index++;
				
				text17[Index].Focus();
				
			}
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text19_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text19.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				if (Text31[1].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text19[Index].Text = "";
					Text10[1].Focus();
					goto EventExitSub;
				}
				
				//                Text26(Index + 32) = Round(Abs(Val(Text19(Index).Text) - Text31(1).Text), 2)
				if (System.Math.Abs((System.Convert.ToDouble(Text19[Index].Text)) - Conversion.Val(Text31[1].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[1].Text)) //误差判断，超过误差显示为红色
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text20_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text20.GetIndex(eventSender);
			object deltaCa2 = null;
			object deltaCa1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				if (Text27[1].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text20[Index].Text = "";
					Text26[1].Focus();
					goto EventExitSub;
				}
				
				if (Text19[Index].Text == "")
				{
					MessageBox.Show("请先输入进口温度!");
					Text20[Index].Text = "";
					Text19[Index].Focus();
					goto EventExitSub;
				}
				//                Text26(Index + 48) = Round(Abs(Val(Text20(Index).Text) - Text31(1).Text), 2)
				if (System.Math.Abs((System.Convert.ToDouble(Text20[Index].Text)) - Conversion.Val(Text27[1].Text)) > 0.3 + 0.005 * Conversion.Val(Text27[1].Text)) //误差判断，超过误差显示为红色
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
				
				//温差示值-温差标准值：
				//UPGRADE_WARNING: 未能解析对象 deltaCa1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				deltaCa1 = Conversion.Val((System.Convert.ToDouble(Text19[Index].Text)) - Conversion.Val(Text20[Index].Text).ToString()); //示值差
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				deltaCa2 = Conversion.Val((System.Convert.ToDouble(Text31[1].Text)) - Conversion.Val(Text27[1].Text).ToString()); //标准差
				//                t = deltaCa1 - deltaCa2 '绝对误差
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 deltaCa1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = System.Convert.ToDouble(System.Convert.ToInt32(System.Convert.ToDouble(deltaCa1) - System.Convert.ToDouble(deltaCa2)) / System.Convert.ToDouble(deltaCa2)) * 100; //绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text24[Index].Text = Text24(t, "0.0");
				//                                Text6(Index + 1).Text = Format(0.5 + 3 * Val(frmbdzcssz.Twcd.Text) / (Val(Text31(Index + 1).Text) - Val(Text27(Index + 1).Text)), "0.00")
				//
				//
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(t) > (0.5 + 3 * (Conversion.Val(frmbdzcssz.Default.Twcd.Text)) / deltaCa2))
				{
					Text24[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[8] = (short) 1;
				}
				else
				{
					Text24[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[8] = (short) 0;
				}
				
				
			}
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text21_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text21.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				if (Text31[2].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text21[Index].Text = "";
					Text10[2].Focus();
					goto EventExitSub;
				}
				
				//                 Text26(Index + 64) = Round(Abs(Val(Text21(Index).Text) - Text31(2).Text), 2)
				if (System.Math.Abs((System.Convert.ToDouble(Text21[Index].Text)) - Conversion.Val(Text31[2].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[2].Text)) //误差判断，超过误差显示为红色
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text22_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text22.GetIndex(eventSender);
			object deltaCa2 = null;
			object deltaCa1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				
				if (Text27[2].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text22[Index].Text = "";
					Text26[2].Focus();
					goto EventExitSub;
				}
				
				if (Text21[Index].Text == "")
				{
					MessageBox.Show("请先输入进口温度!");
					Text22[Index].Text = "";
					Text21[Index].Focus();
					goto EventExitSub;
				}
				
				//                Text26(Index + 80) = Round(Abs(Val(Text22(Index).Text) - Text31(2).Text), 2)
				if (System.Math.Abs((System.Convert.ToDouble(Text22[Index].Text)) - Conversion.Val(Text27[2].Text)) > 0.3 + 0.005 * Conversion.Val(Text27[2].Text)) //误差判断，超过误差显示为红色
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
				
				//温差示值-温差标准值：
				//UPGRADE_WARNING: 未能解析对象 deltaCa1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				deltaCa1 = Conversion.Val((System.Convert.ToDouble(Text21[Index].Text)) - Conversion.Val(Text22[Index].Text).ToString()); //示值差
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				deltaCa2 = Conversion.Val((System.Convert.ToDouble(Text31[2].Text)) - Conversion.Val(Text27[2].Text).ToString()); //标准差
				//            t = deltaCa1 - deltaCa2 '绝对误差
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 deltaCa1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = System.Convert.ToDouble(System.Convert.ToInt32(System.Convert.ToDouble(deltaCa1) - System.Convert.ToDouble(deltaCa2)) / System.Convert.ToDouble(deltaCa2)) * 100; //绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text25[Index].Text = Text25(t, "0.0");
				//                    Text6(Index + 2).Text = Format(0.5 + 3 * Val(frmbdzcssz.Twcd.Text) / (Val(Text31(Index + 2).Text) - Val(Text27(Index + 2).Text)), "0.00")
				
				//UPGRADE_WARNING: 未能解析对象 deltaCa2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(t) > (0.5 + 3 * (Conversion.Val(frmbdzcssz.Default.Twcd.Text)) / deltaCa2))
				{
					Text25[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[9] = (short) 1;
				}
				else
				{
					Text25[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[9] = (short) 0;
				}
				
			}
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text23_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text23.GetIndex(eventSender);
			KeyAscii = (short) 0;
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text24_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text24.GetIndex(eventSender);
			KeyAscii = (short) 0;
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text25_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text25.GetIndex(eventSender);
			KeyAscii = (short) 0;
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text26_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text26.GetIndex(eventSender); //电阻_温度值转换（下一行）
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				//            If Val(Text26(Index).Text) <= 99 Or Val(Text26(Index).Text) > 140 Then
				//            MsgBox ("出口二等标准铂电阻输入电阻值超出范围！")
				//              Text26(Index).Text = ""
				//              Text27(Index).Text = ""
				//              Text26(Index).SetFocus
				//              Exit Sub
				//            End If
				//
				//           r = Val(Text26(Index).Text)
				//'           Call standom_t
				//           Text27(Index).Text = standom_t1(Val(r))
				Text44[Index].Focus();
				//           Index = Index + 1
				//           If Index = 3 Then Index = 0
				//           Text26(Index).SetFocus
				
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text26.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text26_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text26.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (mi[7] == 1)
			{
				//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_Rpt = mi[4];
				//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_a8 = mi[5];
				//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_b8 = mi[6];
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text26[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 20 & sub_Renamed.pt_om <= 40)
				{
					pt_centgrade();
					Text27[Index].Text = Text27(sub_Renamed.centgrade, "0.000");
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text26[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 99 & sub_Renamed.pt_om <= 140)
				{
					Text27[Index].Text = Text27(standom_t1((float) (Conversion.Val(Text26[Index].Text))), "0.000");
				}
			}
		}
		
		public void Text11_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text11.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			//    If KeyAscii = 13 Then Text12(Index).SetFocus
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text12_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text12.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			//    If KeyAscii = 13 Then Text13(Index).SetFocus
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text27.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text27_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text27.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Conversion.Val(Text27[Index].Text) > 0)
			{
				if (Index == 0)
				{
					Text2[0].Text = Text2(0.3 + 0.005 * Conversion.Val(Text27[0].Text), "0.00");
				}
				else if (Index == 1)
				{
					Text2[1].Text = Text2(0.3 + 0.005 * Conversion.Val(Text27[1].Text), "0.00");
				}
				else if (Index == 2)
				{
					Text2[2].Text = Text2(0.3 + 0.005 * Conversion.Val(Text27[2].Text), "0.00");
				}
				
				if (Text31[Index].Text == "")
				{
					MessageBox.Show("请先输入进口温度！");
					
					Text27[Index].Text = "";
					Text31[Index].Focus();
					return;
				}
				if ((Conversion.Val(Text31[Index].Text) - Conversion.Val(Text27[Index].Text)) < Conversion.Val(frmbdzcssz.Default.Twcd.Text))
				{
					MessageBox.Show("进出口温差不得小于最小温差！");
					return;
					
				}
				else
				{
					Text6[Index].Text = Text6(0.5 + 3 * Conversion.Val(frmbdzcssz.Default.Twcd.Text) / (Conversion.Val(Text31[Index].Text) - Conversion.Val(Text27[Index].Text)), "0.00");
				}
			}
			
		}
		
		public void Text29_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text3_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text3.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text30_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text31.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text31_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text31.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Conversion.Val(Text31[Index].Text) > 0)
			{
				if (Index == 0)
				{
					
					Text1[0].Text = Text1(0.3 + 0.005 * Conversion.Val(Text31[0].Text), "0.00");
				}
				else if (Index == 1)
				{
					Text1[1].Text = Text1(0.3 + 0.005 * Conversion.Val(Text31[1].Text), "0.00");
					
					
				}
				else if (Index == 2)
				{
					Text1[2].Text = Text1(0.3 + 0.005 * Conversion.Val(Text31[2].Text), "0.00");
				}
			}
			
		}
		
		public void Text39_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text39.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Index++;
				if (Index >= 3)
				{
					Index = (short) 1;
					Text40[1].Focus();
				}
				else
				{
					Text39[Index].Focus();
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text4_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text4.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text40_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text40.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Index++;
				if (Index >= 3)
				{
					Index = (short) 1;
					Text41[Index].Focus();
				}
				else
				{
					Text40[Index].Focus();
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text41_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text41.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Index++;
				if (Index >= 3)
				{
					Index = (short) 1;
					Text39[Index].Focus();
				}
				else
				{
					Text41[Index].Focus();
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text44_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text44.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			if (KeyAscii == 13)
			{
				Text55[Index].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text5_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text5.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text55_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text55.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			double t = 0;
			if (KeyAscii == 13)
			{
				
				if (Conversion.Val(Text55[Index].Text) <= 995 || Conversion.Val(Text55[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text55[Index].Text = "";
					text17[Index].Text = "";
					Text55[Index].Focus();
					goto EventExitSub;
				}
				
				if (Text31[0].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text55[Index].Text = "";
					Text10[0].Focus();
					goto EventExitSub;
				}
				
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) (Conversion.Val(Text55[Index].Text) / Conversion.Val(Text11[0].Text));
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				text17[Index].Text = (System.Math.Round(t, 2)).ToString();
				
				if (System.Math.Abs(t - Conversion.Val(Text31[0].Text)) > (0.3 + 0.005 * Conversion.Val(Text31[0].Text))) //误差判断，超过误差显示为红色
				{
					text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
				
				
				//               If Option4.value = True Then     '单支测量显示绝对误差
				//                Text23(Index).Text = Round(Val(Text17(Index).Text) - Val(Text31(0).Text), 4)
				//               End If
				Text56[Index].Focus();
				Index++;
				
				
				if (Index >= 16)
				{
					Index = (short) 0;
					Text44[Index].Focus();
				}
			}
			
			
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text56_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text56.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			double deltaCa1 = 0;
			double deltaCa2 = 0;
			if (KeyAscii == 13)
			{
				
				if (Conversion.Val(Text56[Index].Text) <= 995 || Conversion.Val(Text56[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text56[Index].Text = "";
					Text18[Index].Text = "";
					Text56[Index].Focus();
					goto EventExitSub;
				}
				
				if (Text27[0].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text56[Index].Text = "";
					Text26[0].Focus();
					goto EventExitSub;
				}
				
				//        If Option3 = True Then  '配对
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text56[Index].Text)) / Conversion.Val(Text11[0].Text));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text18[Index].Text = (System.Math.Round(System.Convert.ToDouble(t), 2)).ToString();
				
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(System.Convert.ToDouble(t) - Conversion.Val(Text27[0].Text)) > (0.3 + 0.005 * Conversion.Val(Text27[0].Text))) //误差判断，超过误差显示为红色
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[2] = (short) 1;
				}
				else
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[2] = (short) 0;
				}
				//温差示值-温差标准值：
				deltaCa1 = Conversion.Val((System.Convert.ToDouble(text17[Index].Text)) - Conversion.Val(Text18[Index].Text).ToString()); //示值差
				deltaCa2 = Conversion.Val((System.Convert.ToDouble(Text31[0].Text)) - Conversion.Val(Text27[0].Text).ToString()); //标准差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (deltaCa1 - deltaCa2) / deltaCa2 * 100; //绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text23[Index].Text = Text23(t, "0.0");
				
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(t) > (0.5 + 3 * (Conversion.Val(frmbdzcssz.Default.Twcd.Text)) / deltaCa2))
				{
					Text23[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[7] = (short) 1;
				}
				else
				{
					Text23[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[7] = (short) 0;
				}
				
				Index++;
				//                If Index >= 16 Then
				//                    Index = 0
				Text44[Index].Focus();
				//                Else
				//                    Text56(Index).SetFocus
				//                End If
				//        End If
				
				
				//        If Option4 = True Then  '单支
				//
				//                On Error GoTo x_eorro
				//                Xb = Val(Text12(0).Text) / 10 ^ 3    '铂电阻的一次项
				//                Xa = Val(Text13(0).Text) / 10 ^ 7    '铂电阻的二次顶
				//                Xc = Text56(Index).Text / Val(Text11(0).Text)
				//                t = (-1 * Xb + Sqr(Xb ^ 2 - 4 * Xa * (1 - Xc))) / (2 * Xa)
				//                Text18(Index).Text = Round(t, 2)
				//
				//                If Abs(t - Val(Text31(0).Text)) > (0.3 + 0.005 * Val(Text31(0).Text)) Then '误差判断，超过误差显示为红色
				//                    Text18(Index).ForeColor = &HFF&
				//                    WuCha(2) = 1
				//                Else
				//                    Text18(Index).ForeColor = &H80000008
				//                    WuCha(2) = 0
				//                End If
				//                Text80(Index).Text = Round(Text18(Index).Text - Text31(0).Text, 2)
				//                Index = Index + 1
				//                If Index >= 16 Then
				//                    Index = 0
				//                    Text57(Index).SetFocus
				//                Else
				//                    Text56(Index).SetFocus
				//                End If
				//        End If
				
			}
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text57_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text57.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			double t = 0;
			if (KeyAscii == 13)
			{
				
				if (Conversion.Val(Text57[Index].Text) <= 995 || Conversion.Val(Text57[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text57[Index].Text = "";
					Text19[Index].Text = "";
					Text57[Index].Focus();
					goto EventExitSub;
				}
				
				if (Text31[1].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text57[Index].Text = "";
					Text10[1].Focus();
					goto EventExitSub;
				}
				
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text57[Index].Text)) / Conversion.Val(Text11[0].Text));
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				Text19[Index].Text = (System.Math.Round(t, 2)).ToString();
				
				if (System.Math.Abs(t - Conversion.Val(Text31[1].Text)) > (0.3 + 0.005 * Conversion.Val(Text31[0].Text))) //误差判断，超过误差显示为红色
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[3] = (short) 1;
				}
				else
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[3] = (short) 0;
				}
				
				//    If Option4.value = True Then     '单支测量显示绝对误差
				//     Text24(Index).Text = Round(Text19(Index).Text - Text31(1).Text, 2)
				//    End If
				Text58[Index].Focus();
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text44[Index].Focus();
				}
			}
			
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text58_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text58.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
			}
			else
			{
				KeyAscii = (short) 0;
			}
			double deltaCa1 = 0;
			double deltaCa2 = 0;
			if (KeyAscii == 13)
			{
				
				if (Conversion.Val(Text58[Index].Text) <= 995 || Conversion.Val(Text58[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text58[Index].Text = "";
					Text20[Index].Text = "";
					Text58[Index].Focus();
					goto EventExitSub;
				}
				
				if (Text27[1].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text58[Index].Text = "";
					Text26[1].Focus();
					goto EventExitSub;
				}
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text58[Index].Text)) / Conversion.Val(Text11[0].Text));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text20[Index].Text = (System.Math.Round(System.Convert.ToDouble(t), 2)).ToString();
				
				//        If Option3 = True Then
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(System.Convert.ToDouble(t) - Conversion.Val(Text27[1].Text)) > (0.3 + 0.005 * Conversion.Val(Text27[1].Text))) //误差判断，超过误差显示为红色
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[4] = (short) 1;
				}
				else
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[4] = (short) 0;
				}
				//温差示值-温差标准值：
				deltaCa1 = Conversion.Val((System.Convert.ToDouble(Text19[Index].Text)) - Conversion.Val(Text20[Index].Text).ToString()); //示值差
				deltaCa2 = Conversion.Val((System.Convert.ToDouble(Text31[1].Text)) - Conversion.Val(Text27[1].Text).ToString()); //标准差
				//                t = deltaCa1 - deltaCa2 '绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (deltaCa1 - deltaCa2) / deltaCa2 * 100; //绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text24[Index].Text = Text24(t, "0.0");
				//                                Text6(Index + 1).Text = Format(0.5 + 3 * Val(frmbdzcssz.Twcd.Text) / (Val(Text31(Index + 1).Text) - Val(Text27(Index + 1).Text)), "0.00")
				//
				//
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(t) > (0.5 + 3 * (Conversion.Val(frmbdzcssz.Default.Twcd.Text)) / deltaCa2))
				{
					Text24[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[8] = (short) 1;
				}
				else
				{
					Text24[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[8] = (short) 0;
				}
				
				//        End If
				
				//        If Option4 = True Then
				//              If Abs(t - Val(Text31(1).Text)) > (0.3 + 0.005 * Val(Text31(1).Text)) Then '误差判断，超过误差显示为红色
				//                    Text20(Index).ForeColor = &HFF&
				//                    WuCha(4) = 1
				//                Else
				//                    Text20(Index).ForeColor = &H80000008
				//                    WuCha(4) = 0
				//                End If
				//
				//        End If
				//            Text81(Index).Text = Round(Text20(Index).Text - Text31(1).Text, 2)
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text59[Index].Focus();
				}
				else
				{
					Text58[Index].Focus();
				}
				
			}
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text59_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text59.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			double t = 0;
			if (KeyAscii == 13)
			{
				
				if (Conversion.Val(Text59[Index].Text) <= 995 || Conversion.Val(Text59[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text59[Index].Text = "";
					Text21[Index].Text = "";
					Text59[Index].Focus();
					goto EventExitSub;
				}
				
				if (Text31[2].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text59[Index].Text = "";
					Text10[2].Focus();
					goto EventExitSub;
				}
				
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text59[Index].Text)) / Conversion.Val(Text11[0].Text));
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				Text21[Index].Text = (System.Math.Round(t, 2)).ToString();
				
				if (System.Math.Abs(t - Conversion.Val(Text31[2].Text)) > (0.3 + 0.005 * Conversion.Val(Text31[2].Text))) //误差判断，超过误差显示为红色
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[5] = (short) 1;
				}
				else
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[5] = (short) 0;
				}
				
				
				//    If Option4.value = True Then     '单支测量显示绝对误差
				//     Text25(Index).Text = Round(Text21(Index).Text - Text31(2).Text, 2)
				//    End If
				Text60[Index].Focus();
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					
					Text44[Index].Focus();
				}
				
			}
			
			
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text60_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text60.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			double deltaCa1 = 0;
			double deltaCa2 = 0;
			if (KeyAscii == 13)
			{
				
				if (Conversion.Val(Text60[Index].Text) <= 995 || Conversion.Val(Text60[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text60[Index].Text = "";
					Text22[Index].Text = "";
					Text60[Index].Focus();
					goto EventExitSub;
				}
				
				if (Text27[2].Text == "")
				{
					MessageBox.Show("请先输入相应标准温度!");
					Text60[Index].Text = "";
					Text26[2].Focus();
					goto EventExitSub;
				}
				
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text60[Index].Text)) / Conversion.Val(Text11[0].Text));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text22[Index].Text = (System.Math.Round(System.Convert.ToDouble(t), 2)).ToString();
				
				//        If Option3 = True Then
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(System.Convert.ToDouble(t) - Conversion.Val(Text27[2].Text)) > (0.3 + 0.005 * Conversion.Val(Text27[2].Text))) //误差判断，超过误差显示为红色
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[6] = (short) 1;
				}
				else
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[6] = (short) 0;
				}
				//温差示值-温差标准值：
				deltaCa1 = Conversion.Val((System.Convert.ToDouble(Text21[Index].Text)) - Conversion.Val(Text22[Index].Text).ToString()); //示值差
				deltaCa2 = Conversion.Val((System.Convert.ToDouble(Text31[2].Text)) - Conversion.Val(Text27[2].Text).ToString()); //标准差
				//            t = deltaCa1 - deltaCa2 '绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (deltaCa1 - deltaCa2) / deltaCa2 * 100; //绝对误差
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text25[Index].Text = Text25(t, "0.0");
				//                    Text6(Index + 2).Text = Format(0.5 + 3 * Val(frmbdzcssz.Twcd.Text) / (Val(Text31(Index + 2).Text) - Val(Text27(Index + 2).Text)), "0.00")
				
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(t) > (0.5 + 3 * (Conversion.Val(frmbdzcssz.Default.Twcd.Text)) / deltaCa2))
				{
					Text25[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[9] = (short) 1;
				}
				else
				{
					Text25[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[9] = (short) 0;
				}
				//        End If
				
				//        If Option4 = True Then
				//            If Abs(t - Val(Text31(2).Text)) > (0.3 + 0.005 * Val(Text31(2).Text)) Then '误差判断，超过误差显示为红色
				//                Text22(Index).ForeColor = &HFF&
				//                WuCha(6) = 1
				//            Else
				//                Text22(Index).ForeColor = &H80000008
				//                WuCha(6) = 0
				//            End If
				//Text82(Index).Text = Round(Text22(Index).Text - Text31(2).Text, 2)
				//        End If
				
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text44[Index].Focus();
				}
				else
				{
					Text60[Index].Focus();
				}
				
			}
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		private void user_Click()
		{
			object userForm = null;
			//UPGRADE_WARNING: 未能解析对象 userForm.Show 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			userForm.show();
		}
		
		private void Textbh_KeyPress(short KeyAscii)
		{
			object Textbh = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Qingling();
			string Strsql1 = "";
			if (KeyAscii == 13)
			{
				sub_Renamed.RsZbs = new ADODB.Recordset();
				//UPGRADE_WARNING: 未能解析对象 Textbh.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Strsql1 = "select * from dianzu where dianzu.bianhao=\'" + Strings.Trim(System.Convert.ToString(Textbh.text)) + "\' order by bianhao";
				sub_Renamed.RsZbs.Open(Strsql1, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				if (sub_Renamed.RsZbs.RecordCount != 0)
				{
					
					Text44[0].Text = () (sub_Renamed.RsZbs.Fields[0].Value));
					Text55[0].Text = () (sub_Renamed.RsZbs.Fields[1].Value));
					Text56[0].Text = () (sub_Renamed.RsZbs.Fields[2].Value));
					Text57[0].Text = () (sub_Renamed.RsZbs.Fields[3].Value));
					Text58[0].Text = () (sub_Renamed.RsZbs.Fields[4].Value));
					Text59[0].Text = () (sub_Renamed.RsZbs.Fields[5].Value));
					Text60[0].Text = () (sub_Renamed.RsZbs.Fields[6].Value));
					text17[0].Text = () (sub_Renamed.RsZbs.Fields[7].Value));
					Text18[0].Text = () (sub_Renamed.RsZbs.Fields[8].Value));
					Text19[0].Text = () (sub_Renamed.RsZbs.Fields[9].Value));
					Text20[0].Text = () (sub_Renamed.RsZbs.Fields[10].Value));
					Text21[0].Text = () (sub_Renamed.RsZbs.Fields[11].Value));
					Text22[0].Text = () (sub_Renamed.RsZbs.Fields[12].Value));
					Text23[0].Text = () (sub_Renamed.RsZbs.Fields[13].Value));
					Text24[0].Text = () (sub_Renamed.RsZbs.Fields[14].Value));
					Text25[0].Text = () (sub_Renamed.RsZbs.Fields[15].Value));
					
				}
				sub_Renamed.RsZbs.Close();
				
			}
			
		}
		
		public void Qingling()
		{
			for ( = ;0; i <= 15); i++;);
			{
				
				Text44[sub_Renamed.i].Text = "";
				Text55[sub_Renamed.i].Text = "";
				Text56[sub_Renamed.i].Text = "";
				Text57[sub_Renamed.i].Text = "";
				Text58[sub_Renamed.i].Text = "";
				Text59[sub_Renamed.i].Text = "";
				Text60[sub_Renamed.i].Text = "";
				text17[sub_Renamed.i].Text = "";
				Text18[sub_Renamed.i].Text = "";
				Text19[sub_Renamed.i].Text = "";
				Text20[sub_Renamed.i].Text = "";
				Text21[sub_Renamed.i].Text = "";
				Text22[sub_Renamed.i].Text = "";
				Text23[sub_Renamed.i].Text = "";
				Text24[sub_Renamed.i].Text = "";
				Text25[sub_Renamed.i].Text = "";
			}
		}
		
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text10[1].Visible = false;
			MSComm6.Output = "FETC? (@2)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text10[1].Text = () );MSComm6.Input;
			if (Text10[1].Text == "")
			{
				Text31[1].Text = Text31[1].Text;
			}
			else
			{
				Text31[1].Text = Text31(Conversion.Val(Text10[1].Text), "0.000");
			}
		}
		
		public void Timer10_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text26[0].Visible = false;
			MSComm6.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text26[0].Text = () );MSComm6.Input;
			if (Text26[0].Text == "")
			{
				Text27[0].Text = Text27[0].Text;
			}
			else
			{
				Text27[0].Text = Text27(Conversion.Val(Text26[0].Text), "0.000");
			}
		}
		
		public void Timer2_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text26[1].Visible = false;
			MSComm6.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text26[1].Text = () );MSComm6.Input;
			if (Text26[1].Text == "")
			{
				Text27[1].Text = Text27[1].Text;
			}
			else
			{
				Text27[1].Text = Text27(Conversion.Val(Text26[1].Text), "0.000");
			}
		}
		
		public void Timer3_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text10[2].Visible = false;
			MSComm6.Output = "FETC? (@2)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text10[2].Text = () );MSComm6.Input;
			if (Text10[2].Text == "")
			{
				Text31[2].Text = Text31[2].Text;
			}
			else
			{
				Text31[2].Text = Text31(Conversion.Val(Text10[2].Text), "0.000");
			}
		}
		
		public void Timer4_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text26[2].Visible = false;
			MSComm6.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text26[2].Text = () );MSComm6.Input;
			if (Text26[2].Text == "")
			{
				Text27[2].Text = Text27[2].Text;
			}
			else
			{
				Text27[2].Text = Text27(Conversion.Val(Text26[2].Text), "0.000");
			}
		}
		
		public void Timer5_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Wendu_js1 = null;
			object Data_in1 = null;
			object Kk1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = System.Convert.ToInt32(Kk1) + 1;
				sub_Renamed.delay_times(1);
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 2));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = MSComm6.Input;
			//
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text10[0].Text = () );Data_in1;
			
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Wendu_js1 = System.Convert.ToInt32(Wendu_js1) + 1;
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Wendu_js1 < 15)
			{
				//   Text5.Text = Data_in1
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 >= 15 & Wendu_js1 <= 30)
			{
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Wendu_js1 == 15)
				{
					MessageBox.Show("请在十秒钟内将出口铂电阻接入测试仪！");
				}
				//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text26[0].Text = () );Data_in1;
				
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 > 30)
			{
				Timer5.Enabled = false;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
			}
		}
		
		public void Timer6_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Wendu_js1 = null;
			object Data_in1 = null;
			object Kk1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = System.Convert.ToInt32(Kk1) + 1;
				sub_Renamed.delay_times(1);
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 2));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = MSComm6.Input;
			//
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text10[1].Text = () );Data_in1;
			
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Wendu_js1 = System.Convert.ToInt32(Wendu_js1) + 1;
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Wendu_js1 < 15)
			{
				//   Text5.Text = Data_in1
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 >= 15 & Wendu_js1 <= 30)
			{
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Wendu_js1 == 15)
				{
					MessageBox.Show("请在十秒钟内将出口铂电阻接入测试仪！");
				}
				//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text26[1].Text = () );Data_in1;
				
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 > 30)
			{
				Timer6.Enabled = false;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
			}
		}
		
		public void Timer7_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Wendu_js1 = null;
			object Data_in1 = null;
			object Kk1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = System.Convert.ToInt32(Kk1) + 1;
				sub_Renamed.delay_times(1);
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 2));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = MSComm6.Input;
			//
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text10[2].Text = () );Data_in1;
			
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Wendu_js1 = System.Convert.ToInt32(Wendu_js1) + 1;
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Wendu_js1 < 15)
			{
				//   Text5.Text = Data_in1
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 >= 15 & Wendu_js1 <= 30)
			{
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Wendu_js1 == 15)
				{
					MessageBox.Show("请在十秒钟内将出口铂电阻接入测试仪！");
				}
				//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text26[2].Text = () );Data_in1;
				
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 > 30)
			{
				Timer7.Enabled = false;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
			}
		}
		
		public void Timer9_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text10[0].Visible = false;
			MSComm6.Output = "FETC? (@2)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text10[0].Text = () );MSComm6.Input;
			if (Text10[0].Text == "")
			{
				Text31[0].Text = Text31[0].Text;
			}
			else
			{
				Text31[0].Text = Text31(Conversion.Val(Text10[0].Text), "0.000");
			}
		}
	}
}
