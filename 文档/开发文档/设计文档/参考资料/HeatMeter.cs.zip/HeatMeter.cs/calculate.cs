// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace 热量表
{
	partial class calculator : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static calculator defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static calculator Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new calculator();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		short msg;
		float[] mi = new float[9];
		ADODB.Recordset Namefind;
		ADODB.Recordset RsZbs;
		string StrSql;
		short Wendu_js1;
		string Data_in1;
		
		int Kk1;
		short txt_idx;
		object pt_a8;
		object pt_om;
		object pt_Rpt;
		object pt_b8;
		double centgrade; //用于标准铂电阻_温度值转换计算
		Microsoft.Office.Interop.Excel.Application objExcel; //表格
		float EnthalpieV;
		float EnthalpieR;
		private void pt_centgrade()
		{
			//以下是铂电阻计算程序：
			double[] d = new double[10];
			double wt = 0;
			double deltaW = 0;
			double wrt = 0;
			double pt;
			double r = 0;
			double t = 0;
			double a;
			double b;
			double a8 = 0;
			double b8 = 0;
			double rpt = 0;
			
			float t1;
			float t2;
			float t3;
			
			float[] pt1000 = new float[101];
			short i = 0;
			
			d[0] = 439.932854;
			d[1] = 472.41802;
			d[2] = 37.684494;
			d[3] = 7.472018;
			d[4] = 2.920828;
			d[5] = 0.005184;
			d[6] = -0.963864;
			d[7] = -0.188732;
			d[8] = 0.191203;
			d[9] = 0.049025;
			
			//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			r = System.Convert.ToDouble(pt_om);
			//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			a8 = System.Convert.ToDouble(pt_a8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b8 = System.Convert.ToDouble(pt_b8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			rpt = System.Convert.ToDouble(pt_Rpt);
			
			wt = r / rpt;
			deltaW = a8 * (wt - 1) + b8 * Math.Pow((wt - 1), 2);
			wrt = wt - deltaW;
			t = 0;
			for (i = 0; i <= 9; i++)
			{
				t = t + d[i] * Math.Pow(((wrt - 2.64) / 1.64), i); //t=d0*sum[di(Wr(t)-2.64)/1.64]^I;I:1 to 9
			}
			t1 = (float) t;
			centgrade = System.Math.Round(t, 4);
			
		}
		private void Findsongjian()
		{
			//On Error Resume Next
			//shuju(8).Clear
			//Set Namefind = New ADODB.Recordset
			//   sqlStr = "SELECT DISTINCT Sname from songjiank order by Sname"
			//   Namefind.Open sqlStr, db, adOpenStatic, adLockOptimistic
			//   If Namefind.RecordCount <> 0 Then
			//            Namefind.MoveFirst
			//            Do Until Namefind.EOF
			//                  shuju(8).AddItem Namefind.Fields("Sname")
			//                  Namefind.MoveNext
			//             Loop
			//   End If
			//   Namefind.Close
			//   'shuju(8).ListIndex = 0
			
		}
		private void Findzhizao()
		{
			//On Error Resume Next
			//shuju(7).Clear
			//Set Namefind = New ADODB.Recordset
			//   sqlStr = "SELECT DISTINCT Zname from zhizaok order by Zname"
			//   Namefind.Open sqlStr, db, adOpenStatic, adLockOptimistic
			//   If Namefind.RecordCount <> 0 Then
			//            Namefind.MoveFirst
			//            Do Until Namefind.EOF
			//                  shuju(7).AddItem Namefind.Fields("Zname")
			//                  Namefind.MoveNext
			//             Loop
			//   End If
			//   Namefind.Close
			//   'shuju(7).ListIndex = 0
			
		}
		
		private void Cjin_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Wendu_js1 = (short) 0;
			//timer1.Enabled = True
			//Wendu_js1 = 0
		}
		
		public void cmdDaYin_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next
			//
			//Call gain_fileNO
			//Set objExcel = New Excel.Application
			//objExcel.SheetsInNewWorkbook = 1
			//objExcel.Workbooks.add
			//'formm_condition = False 'FORM1状态标志
			//objExcel.Sheets.Application.DisplayFullScreen = True
			//objExcel.Application.WindowState = xlMinimized
			//objExcel.Application.Visible = True
			//'Call give_ini
			//' list
			//
			//     Set objExcel = XlApp.Workbooks.Open(App.Path & "\tab\Temp.xlt")
			//     objExcel.ActiveSheet.Cells(6, 3) = 22
			sub_Renamed.gain_fileNO();
			
			
			Module1.PrintCalCular();
		}
		
		private void cmdpause_Click()
		{
			
		}
		
		public void cmdQuit_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		private void cmdxsbx_Click()
		{
			
		}
		
		
		
		
		
		private void ducanshu_Click()
		{
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmjsqcs.Default.Show();
		}
		
		private void Command2_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Wendu_js1 = (short) 0;
			//timer2.Enabled = True
			
		}
		
		public void calculator_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short int1;
			//timer1.Enabled = False
			//timer2.Enabled = False
			
			FileSystem.FileClose(13);
			Module1.sFileCanShu = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\bjpt_canshu.dll";
			FileSystem.FileOpen(13, Module1.sFileCanShu, OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			//    Input #13, gsgs
			FileSystem.Input(13, ref mi[1]);
			FileSystem.Input(13, ref mi[2]);
			FileSystem.Input(13, ref mi[3]);
			//
			
			FileSystem.FileClose(13);
			//Text1.Text = 4
			//Text2.Text = 3
			Qingling();
			//Findguige
			//Findsongjian
			//FindXinghao
			//Findzhizao
			//读标准铂电阻参数：
			short n;
			
			//Dim gsgs As String
			//Dim gsgs1 As String
			
			
		}
		private void stb()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			short st;
			short pp = 0;
			double cl = 0;
			double tt = 0;
			double t = 0;
			object p5 = null;
			double v1;
			double ab = 0;
			double h1 = 0;
			double volume;
			double w3 = 0;
			double w1 = 0;
			double Gf = 0;
			double z = 0;
			double y = 0;
			double o = 0;
			double b = 0;
			double y1 = 0;
			double gg = 0;
			double w = 0;
			double w2 = 0;
			double v = 0;
			double AAA = 0;
			double h6 = 0;
			double aa = 0;
			double h2 = 0;
			double kr = 0;
			double vr = 0;
			double tf = 0;
			double hf = 0;
			double g7;
			double g5 = 0;
			double g3 = 0;
			double g1 = 0;
			double g2 = 0;
			double g4 = 0;
			double g6 = 0;
			double h = 0;
			double vf = 0;
			double hr = 0;
			double tR = 0;
			double kf = 0;
			st = (short) 0;
			if (st == 0)
			{
				tt = Conversion.Val(Text11[txt_idx].Text); //进口温度输入
			}
AAAA:
			if (st == 1)
			{
				tt = Conversion.Val(Text12[txt_idx].Text); //出口温度输入
			}
			cl = tt;
			t = tt + 273.15;
			//If Option7.value = True Then
			pp = (short) 6;
			//    Else
			//    pp = 10
			//End If
			//pp = Val(Text10.Text)
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			p5 = pp * 100000;
			o = t / Module1.tc;
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b = System.Convert.ToDouble(System.Convert.ToDouble(p5) / Module1.pc);
			y = 1 - Module1.d1 * Math.Pow(o, 2) - Module1.d2 * Math.Pow(o, -6);
			y1 = -2 * Module1.d1 * o + 6 * Module1.d2 * Math.Pow(o, -7);
			z = y + System.Math.Sqrt(System.Math.Abs(Module1.d3 * Math.Pow(y, 2) - 2 * Module1.d4 * o + 2 * Module1.d5 * b));
			gg = Module1.d6 - o;
			if (System.Math.Abs(gg) < 0.000158)
			{
				gg = 0;
			}
			Gf = Module1.d6 - o;
			if (System.Math.Abs(Gf) < 0.0000596)
			{
				Gf = 0;
			}
			w = Module1.B1 * Module1.d5 * Math.Pow(z, (-5 / 17));
			w1 = w + (Module1.B2 + Module1.B3 * o + Module1.b4 * Math.Pow(o, 2) + Module1.b5 * Math.Pow(gg, 10) + Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -1)) - Math.Pow((Module1.d8 + Math.Pow(o, 11)), -1) * (Module1.b7 + 2 * Module1.b8 * b + 3 * Module1.b9 * Math.Pow(b, 2));
			w2 = w1 - Module1.c0 * Math.Pow(o, 18) * (Module1.d9 + Math.Pow(o, 2)) * (-3 * Math.Pow((Module1.e0 + b), -4) + Module1.e1);
			w3 = w2 + 3 * Module1.c1 * (Module1.e2 - o) * Math.Pow(b, 2) + 4 * Module1.c2 * Math.Pow(o, -20) * Math.Pow(b, 3);
			v = 1000 * w3 * Module1.vc;
			volume = 1 / v;
			
			//If st = 0 Then
			//    If volume# < 1 Then             'text7进水处比容
			//       Text7.Text = CStr(cl#) + "℃," + Chr(13) + CStr(pp) + "bar时：" + "0" + Left$(CStr(volume#), 6)
			//    Else: Text7.Text = CStr(cl#) + "℃," + Chr(13) + CStr(pp) + "bar时：" + Left$(CStr(volume#), 6)
			//    End If
			//End If
			
			//If st = 1 Then                      'text1出水处比容
			//    If volume# < 1 Then
			//      Text1.Text = CStr(cl#) + "℃," + Chr(16) + CStr(pp) + "(bar)时：" + "0" + Left$(CStr(volume#), 6)
			//      Else: Text1.Text = CStr(cl#) + "℃," + Chr(16) + CStr(pp) + "(bar)时：" + Left$(CStr(volume#), 6)
			//    End If
			//End If
			
			AAA = Module1.a1 + Module1.a2 * o + Module1.a3 * Math.Pow(o, 2) + Module1.a4 * Math.Pow(o, 3) + Module1.a5 * Math.Pow(o, 4) + Module1.a6 * Math.Pow(o, 5) + Module1.a7 * Math.Pow(o, 6) + Module1.a8 * Math.Pow(o, 7) + Module1.a9 * Math.Pow(o, 8) + Module1.b0 * Math.Pow(o, 9);
			h1 = Module1.a0 * o * (1 - System.Math.Log(o)) + AAA + Module1.B1 * ((17 / 29) * z - (17 / 12) * y) * Math.Pow(z, (12 / 17)) + (Module1.B2 + Module1.B3 * o + Module1.b4 * Math.Pow(o, 2) + Module1.b5 * Math.Pow(gg, 10) + Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -1)) * b;
			h2 = h1 - Math.Pow((Module1.d8 + Math.Pow(o, 11)), -1) * (Module1.b7 * b + Module1.b8 * Math.Pow(b, 2) + Module1.b9 * Math.Pow(b, 3)) - Module1.c0 * Math.Pow(o, 18) * (Module1.d9 + Math.Pow(o, 2)) * (Math.Pow((Module1.e0 + b), -3) + Module1.e1 * b);
			h6 = h2 + Module1.c1 * (Module1.e2 - o) * Math.Pow(b, 3) + Module1.c2 * Math.Pow(o, -20) * Math.Pow(b, 4);
			//Text2.Text = Left$(CStr(h6#), 6)
			ab = Module1.a2 + 2 * Module1.a3 * o;
			aa = ab + 3 * Module1.a4 * Math.Pow(o, 2) + 4 * Module1.a5 * Math.Pow(o, 3) + 5 * Module1.a6 * Math.Pow(o, 4) + 6 * Module1.a7 * Math.Pow(o, 5) + 7 * Module1.a8 * Math.Pow(o, 6) + 8 * Module1.a9 * Math.Pow(o, 7) + 9 * Module1.b0 * Math.Pow(o, 8);
			g1 = Module1.a0 * System.Math.Log(o) - aa + Module1.B1 * ((((5 * z) / 12) - (Module1.d3 - 1) * y) * y1 + Module1.d4) * Math.Pow(z, (-5 / 17));
			g2 = (- Module1.B3 - 2 * Module1.b4 * o + 10 * Module1.b5 * Math.Pow(Gf, 9) + 19 * Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -2) * Math.Pow(o, 18)) * b;
			g3 = 11 * Math.Pow((Module1.d8 + Math.Pow(o, 11)), -2) * Math.Pow(o, 10) * (Module1.b7 * b + Module1.b8 * Math.Pow(b, 2) + Module1.b9 * Math.Pow(b, 3));
			g4 = Module1.c0 * Math.Pow(o, 17) * (18 * Module1.d9 + 20 * Math.Pow(o, 2)) * (Math.Pow((Module1.e0 + b), -3) + Module1.e1 * b);
			g5 = Module1.c1 * Math.Pow(b, 3) + 20 * Module1.c2 * Math.Pow(o, -21) * Math.Pow(b, 4);
			g6 = g1 + g2 - g3 + g4 + g5;
			//Text3.Text = Left$(CStr(g6#), 6)
			h = (Module1.pc * Module1.vc) * (o * g6 + h6);
			h = h / 1000;
			
			if (st == 0)
			{
				EnthalpieV = float.Parse(VB.Strings.Left((h).ToString(), 6));
			}
			if (st == 1)
			{
				EnthalpieR = float.Parse(VB.Strings.Left((h).ToString(), 6));
			}
			
			
			if (st == 1)
			{
				goto XXX;
			}
			hf = h;
			vf = v;
			tf = cl;
			st = (short) 1;
			goto AAAA;
			
XXX:
			
			
			if (Option5.Checked == true)
			{
				hr = h;
				vr = v;
				tR = cl;
				
				kr = (hf - hr) / ((tf - tR) * vr);
				kf = (hf - hr) / ((tf - tR) * vf);
				
				if (Option1.Checked == true)
				{
					if (Option3.Checked == true)
					{
						Text14[txt_idx].Text = VB.Strings.Left((kf).ToString(), 6); //进口K系数 MJ
					}
					else
					{
						Text14[txt_idx].Text = VB.Strings.Left((kf / 3.6).ToString(), 6); //进口K系数 kWh
					}
				}
				else
				{
					if (Option3.Checked == true)
					{
						Text14[txt_idx].Text = VB.Strings.Left((kr).ToString(), 6); //出口K系数 MJ
					}
					else
					{
						Text14[txt_idx].Text = VB.Strings.Left((kr / 3.6).ToString(), 6); //出口K系数 kWh
					}
				}
				//
				
				Text21[txt_idx].Text = Text21(0.5 + System.Math.Abs(Conversion.Val(Twcd.Text) / ((System.Convert.ToDouble(Text11[txt_idx].Text)) - System.Convert.ToDouble(Text12[txt_idx].Text))), "0.0"); //示值误差技术要求
				
				Text44[txt_idx].Text = (Conversion.Int(3000 / (Conversion.Val(Text21[txt_idx].Text) * ((System.Convert.ToDouble(Text11[txt_idx].Text)) - System.Convert.ToDouble(Text12[txt_idx].Text)) * System.Convert.ToDouble(Text14[txt_idx].Text)) / 10) * 10).ToString();
				
			}
			else
			{
				
				Text14[txt_idx].Text = (EnthalpieV - EnthalpieR).ToString(); //焓差
				//
				
				Text21[txt_idx].Text = Text21(0.5 + System.Math.Abs(Conversion.Val(Twcd.Text) / ((System.Convert.ToDouble(Text11[txt_idx].Text)) - System.Convert.ToDouble(Text12[txt_idx].Text))), "0.0"); //示值误差技术要求
				if (Option1.Checked == true)
				{
					//UPGRADE_WARNING: 未能解析对象 MiDu(Val(Text11(txt_idx).Text)) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text44[txt_idx].Text = (System.Convert.ToInt32(Conversion.Int(System.Convert.ToDouble(System.Convert.ToInt32(3000 / System.Convert.ToInt32(System.Convert.ToDouble(Conversion.Val(Text21[txt_idx].Text) * mdlyingpanxuliehao.MiDu((Conversion.Val(Text11[txt_idx].Text)).ToString())) * System.Convert.ToDouble(Text14[txt_idx].Text))) * 3.6) / 10)) * 10).ToString();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 MiDu(Val(Text12(txt_idx).Text)) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text44[txt_idx].Text = (System.Convert.ToInt32(Conversion.Int(System.Convert.ToDouble(System.Convert.ToInt32(3000 / System.Convert.ToInt32(System.Convert.ToDouble(Conversion.Val(Text21[txt_idx].Text) * mdlyingpanxuliehao.MiDu((Conversion.Val(Text12[txt_idx].Text)).ToString())) * System.Convert.ToDouble(Text14[txt_idx].Text))) * 3.6) / 10)) * 10).ToString();
					
				}
			}
			
		}
		
		
		public void Option3_Enter(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (Option5.Checked == true)
			{
				Text14[0].Text = "k系数" + "\r" + "\n" + "(MJ/m3℃)";
			}
			Text15[0].Text = "理论热量E(MJ)";
			Text19[0].Text = "热量示值(MJ)";
			Text45[0].Text = "E0(MJ)";
			Text46[0].Text = "E1(MJ)";
			
		}
		
		public void Option4_Enter(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (Option5.Checked == true)
			{
				Text14[0].Text = "k系数" + "\r" + "\n" + "(kWh/m3℃)";
			}
			Text15[0].Text = "理论热量(kWh)";
			Text19[0].Text = "热量示值(kWh)";
			Text45[0].Text = "E0(kWh)";
			Text46[0].Text = "E1(kWh)";
			
		}
		
		//
		private void save_Click()
		{
			//要保存的内容:0.生产厂家 1.型号 2.编号 3.安装位置 4.热量单位 5.进口标准铂电阻编号，6出口标准铂电阻编号
			//7.温度点 （1-10个测量点） 8.检定时间 9.检定员
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option5.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option5_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option4.Checked == true)
				{
					Text14[0].Text = "K系数(kWh/m3℃)";
				}
				else
				{
					Text14[0].Text = "K系数(MJ/m3℃)";
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option6.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option6_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				Text14[0].Text = "焓差值(kJ/kg)";
			}
		}
		
		public void SSCommand1_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			string StrSql = "";
			short jd;
			sub_Renamed.Title = "保存数据";
			msg = (short) (Interaction.MsgBox("请你确认输入项是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示"));
			switch (msg)
			{
				case (short) MsgBoxResult.Yes:
					StrSql = "select * from jsqjc ";
					RsZbs = new ADODB.Recordset();
					RsZbs.Open(StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					
					RsZbs.AddNew(null, null);
					RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
					RsZbs.Fields[1].Value = frmjsqcs.Default.Text1.Text;
					RsZbs.Fields[2].Value = DateAndTime.Today;
					RsZbs.Fields[3].Value = sub_Renamed.SongjianDanwei;
					RsZbs.Update(null, null);
					
					RsZbs.Close();
					
					//            MsgBox "保存完毕！保存路径\lib\jiliang.mdb jcjg", vbInformation, "保存完毕"
					//            MsgBox App.Path & "\report\" & Trim(yibiao_No) & ".xls"
					return;
				case (short) MsgBoxResult.No:
					
					return;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text10.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text10_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text10.GetIndex(eventSender);
			//On Error Resume Next
			//
			//Text12(Index).Text = standom_t1(Val(Text10(Index).Text))
		}
		
		public void Text10_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text10.GetIndex(eventSender);
			//On Error Resume Next
			//
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
			//Dim abc
			//If KeyAscii = 13 Then
			//            Text13(Index).SetFocus
			//
			//            pt_rpt = mi(1)
			//            pt_a8 = mi(2)
			//            pt_b8 = mi(3)
			//            pt_om = Val(Text10(Index).Text)
			//
			//'            If pt_rpt = 0 Or pt_a8 = 0 Or pt_b8 = 0 Or pt_om <= 20 Or pt_om > 40 Then
			//'
			//'              abc = MsgBox("标准铂电阻参数错或电阻值超过可能的范围！", vbOKOnly)
			//'              Text10(Index).SetFocus
			//'              Exit Sub
			//'            End If
			//
			//            Call pt_centgrade
			//            Text12(Index).Text = centgrade
			//            txt_idx = Index
			//            Call stb
			//     End If
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			double t = 0;
			if (KeyAscii == 13)
			{
				
				//     On Error GoTo x_eorro
				
				Mdlguanfa.Xb = (float) (mi[2] / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (mi[3] / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) (Conversion.Val(Text10[Index].Text) / mi[1]);
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				Text12[Index].Text = (System.Math.Round(t, 3)).ToString();
				txt_idx = Index;
				stb();
				Text13[Index].Focus();
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text11_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text11.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
				
			}
			else
			{
				KeyAscii = (short) 0;
			}
			if (KeyAscii == 13)
			{
				Text12[Index].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text12_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text12.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
			}
			else
			{
				KeyAscii = (short) 0;
			}
			if (KeyAscii == 13)
			{
				Text13[Index].Focus();
			}
			txt_idx = Index;
			stb();
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text13_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text13.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			object imputdata;
			float mvolume;
			if (KeyAscii == 13)
			{
				Text45[Index].Focus();
				txt_idx = Index;
				mvolume = (float) (Conversion.Val(Text11[Index].Text));
				if (mvolume == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("进口温度不能为零的数字！！", MsgBoxStyle.OkOnly, null);
					Text11[Index].Focus();
					goto EventExitSub;
				}
				mvolume = (float) (Conversion.Val(Text13[Index].Text));
				if (mvolume == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("模拟流量只能是不为零的数字！", MsgBoxStyle.OkOnly, null);
					Text13[Index].Focus();
					goto EventExitSub;
				}
				
				if (Conversion.Val(Text11[Index].Text) - Conversion.Val(Text12[Index].Text) == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("进出口温度不能相同！", MsgBoxStyle.OkOnly, null);
					
					//                If Option5.value = True Then
					//                     text9(Index).SetFocus
					//                     Else
					Text45[Index].Focus();
					//                End If
					
					goto EventExitSub;
				}
				if (Option5.Checked == true) //K系数
				{
					Text15[txt_idx].Text = (System.Math.Round(((System.Convert.ToDouble(Text11[txt_idx].Text)) - System.Convert.ToDouble(Text12[txt_idx].Text)) * (System.Convert.ToDouble(Text13[txt_idx].Text)) * (System.Convert.ToDouble(Text14[txt_idx].Text)) / 1000, 3)).ToString(); //理论热量
				}
				else //焓差法
				{
					if (Option3.Checked == true) //MJ
					{
						if (Option1.Checked == true) //进口
						{
							//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text15[txt_idx].Text = (System.Math.Round(System.Convert.ToDouble(System.Convert.ToDouble(System.Convert.ToInt32(mdlyingpanxuliehao.MiDu((Conversion.Val(Text11[txt_idx].Text)).ToString())) * (System.Convert.ToDouble(Text13[txt_idx].Text)) * (System.Convert.ToDouble(Text14[txt_idx].Text))) / 1000), 3)).ToString(); //理论热量
						}
						else //出口
						{
							//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text15[txt_idx].Text = (System.Math.Round(System.Convert.ToDouble(System.Convert.ToDouble(System.Convert.ToInt32(mdlyingpanxuliehao.MiDu((Conversion.Val(Text12[txt_idx].Text)).ToString())) * (System.Convert.ToDouble(Text13[txt_idx].Text)) * (System.Convert.ToDouble(Text14[txt_idx].Text))) / 1000), 3)).ToString(); //理论热量
						}
					}
					else //kWh
					{
						if (Option1.Checked == true) //进口
						{
							//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text15[txt_idx].Text = (System.Math.Round(System.Convert.ToDouble(System.Convert.ToDouble(System.Convert.ToInt32(mdlyingpanxuliehao.MiDu((Conversion.Val(Text11[txt_idx].Text)).ToString())) * (System.Convert.ToDouble(Text13[txt_idx].Text)) * (System.Convert.ToDouble(Text14[txt_idx].Text))) / 1000 / 3.6), 3)).ToString(); //理论热量
						}
						else //出口
						{
							//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text15[txt_idx].Text = (System.Math.Round(System.Convert.ToDouble(System.Convert.ToDouble(System.Convert.ToInt32(mdlyingpanxuliehao.MiDu((Conversion.Val(Text12[txt_idx].Text)).ToString())) * (System.Convert.ToDouble(Text13[txt_idx].Text)) * (System.Convert.ToDouble(Text14[txt_idx].Text))) / 1000 / 3.6), 3)).ToString(); //理论热量
						}
					}
				}
			}
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text14_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text14.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
				
			}
			else
			{
				KeyAscii = (short) 0;
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void text15_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text15.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
				
			}
			else
			{
				KeyAscii = (short) 0;
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		
		
		
		public void Text19_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text19.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
				
			}
			else
			{
				KeyAscii = (short) 0;
			}
			object imputdata;
			double menergy;
			if (KeyAscii == 13)
			{
				text9[Index].Focus();
				menergy = Conversion.Val(Text19[Index].Text);
				if (menergy == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("请输入热能示值", MsgBoxStyle.OkOnly, null);
					
					Text19[Index].Focus();
					goto EventExitSub;
				}
				
				//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				imputdata = Conversion.Val(Text15[Index].Text);
				if (menergy == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("理论热能不能为零！", MsgBoxStyle.OkOnly, null);
					
					Text13[Index].Focus();
					goto EventExitSub;
				}
				Text20[Index].Text = (System.Math.Round(((System.Convert.ToDouble(Text19[Index].Text)) - System.Convert.ToDouble(Text15[Index].Text)) / (System.Convert.ToDouble(Text15[Index].Text)) * 100, 2)).ToString(); //示值误差
				if (System.Math.Abs(Conversion.Val(Text20[Index].Text)) > Conversion.Val(Text21[Index].Text))
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					
				}
				else
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					
				}
			}
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		private void Text2_KeyPress(short KeyAscii)
		{
			//On Error Resume Next
			//
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
			//    If KeyAscii = 13 Then
			//        Text3.SetFocus
			//    End If
		}
		
		
		
		private void Text26_KeyPress(ref short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
				
			}
			else
			{
				KeyAscii = (short) 0;
			}
		}
		
		private void Text37_KeyPress(short KeyAscii)
		{
			//On Error Resume Next
			//
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
		}
		
		
		
		private void Text38_KeyPress(short KeyAscii)
		{
			//On Error Resume Next
			//
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
		}
		
		
		
		private void Text39_keypress(short KeyAscii)
		{
			//On Error Resume Next
			//
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
		}
		
		
		private void Text40_keypress(short KeyAscii)
		{
			//On Error Resume Next
			//
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
		}
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text20.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text20_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text20.GetIndex(eventSender);
			if (System.Math.Abs(Conversion.Val(Text20[Index].Text)) > Conversion.Val(Text21[Index].Text))
			{
				Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
				
			}
			else
			{
				Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
				
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text21.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text21_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text21.GetIndex(eventSender);
			if (System.Math.Abs(Conversion.Val(Text20[Index].Text)) > Conversion.Val(Text21[Index].Text))
			{
				Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
				
			}
			else
			{
				Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
				
			}
		}
		
		public void Text45_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text45.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
			if (KeyAscii == 13)
			{
				
				Text46[Index].Focus();
			}
			
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text46_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text46.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
			object imputdata;
			object menergy = null;
			double menergy1;
			float q_energy = 0;
			if (KeyAscii == 13)
			{
				
				//UPGRADE_WARNING: 未能解析对象 menergy 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				menergy = Conversion.Val(Text45[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 menergy 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text45[Index].Text = () );menergy;
				
				
				//UPGRADE_WARNING: 未能解析对象 menergy 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				menergy = Conversion.Val(Text46[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 menergy 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) menergy == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("请输入热能示值", MsgBoxStyle.OkOnly, null);
					
					Text46[Index].Focus();
					goto EventExitSub;
				}
				
				q_energy = (float) (Conversion.Val((System.Convert.ToDouble(Text46[Index].Text)) - System.Convert.ToDouble(Text45[Index].Text).ToString())); //热量示值
				Text19[Index].Text = (q_energy).ToString();
				
				//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				imputdata = Conversion.Val(Text15[Index].Text);
				
				//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) imputdata == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("理论热能不能为0", MsgBoxStyle.OkOnly, null);
					
					Text13[Index].Focus();
					goto EventExitSub;
				}
				
				
				Text20[Index].Text = (System.Math.Round((q_energy - System.Convert.ToDouble(Text15[Index].Text)) / (System.Convert.ToDouble(Text15[Index].Text)) * 100, 2)).ToString(); //示值误差
				if (System.Math.Abs(Conversion.Val(Text20[Index].Text)) > Conversion.Val(Text21[Index].Text))
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					
				}
				else
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					
				}
				Index++;
				if (Index > 10)
				{
					Index = (short) 1;
				}
				text9[Index].Focus();
				
			}
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		
		private void Text5_KeyPress(ref short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if ((StringType.StrLike(Strings.Chr(KeyAscii), "[0-9]", CompareMethod.Binary)) || (StringType.StrLike(Strings.Chr(KeyAscii), "[.]", CompareMethod.Binary)) || (KeyAscii == 13))
			{
				
			}
			else
			{
				KeyAscii = (short) 0;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 text9.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void text9_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = text9.GetIndex(eventSender);
			//On Error Resume Next
			//
			//Text11(Index).Text = standom_t(Val(text9(Index).Text))
		}
		
		public void text9_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = text9.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			double t = 0;
			if (KeyAscii == 13)
			{
				
				//     On Error GoTo x_eorro
				
				Mdlguanfa.Xb = (float) (mi[2] / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (mi[3] / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) (Conversion.Val(text9[Index].Text) / mi[1]);
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				Text11[Index].Text = (System.Math.Round(t, 3)).ToString();
				Text10[Index].Focus();
			}
			
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Qingling()
		{
			short i = 0;
			short j;
			for (i = 1; i <= 10; i++)
			{
				text9[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text10[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text11[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text12[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text13[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text14[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text15[i].Text = "";
			}
			//For i = 1 To 10: Text16(i).Text = "": Next i
			//For i = 1 To 10: Text17(i).Text = "": Next i
			//For i = 1 To 10: Text18(i).Text = "": Next i
			for (i = 1; i <= 10; i++)
			{
				Text19[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text20[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text21[i].Text = "";
			}
			
			for (i = 1; i <= 10; i++)
			{
				Text45[i].Text = "";
			}
			for (i = 1; i <= 10; i++)
			{
				Text46[i].Text = "";
			}
			
		}
		
		
		//Function standom_t(Fenzi As Single) As Single        '由标准电阻值计算 标准温度
		//On Error Resume Next
		//'        t1 = T
		//'        T = Round(T, 4)
		//
		// Xb = mi(2) / 10 ^ 3    '铂电阻的一次项
		//            Xa = mi(3) / 10 ^ 7    '铂电阻的二次顶
		//            Xc = Fenzi / mi(1)
		//            standom_t = Round((-1 * Xb + Sqr(Xb ^ 2 - 4 * Xa * (1 - Xc))) / (2 * Xa), 4)
		//End Function
		//Function standom_t1(Fenzi As Single) As Single        '由标准电阻值计算 标准温度
		//On Error Resume Next
		//'        t1 = T
		//'        T = Round(T, 4)
		//
		//Xb = mi(5) / 10 ^ 3    '铂电阻的一次项
		//            Xa = mi(6) / 10 ^ 7    '铂电阻的二次顶
		//            Xc = Fenzi / mi(4)
		//            standom_t1 = Round((-1 * Xb + Sqr(Xb ^ 2 - 4 * Xa * (1 - Xc))) / (2 * Xa), 4)
		//End Function
	}
}
