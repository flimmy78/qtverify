// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using System.Runtime.InteropServices;

namespace 热量表
{
	sealed class mdlyingpanxuliehao
	{
		//获得硬盘序列号
		[DllImport("kernel32.dll",EntryPoint="GetVolumeInformationA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		private static extern int GetVolumeInformation(string lpRootPathName, string lpVolumeNameBuffer, short nVolumeNameSize, ref int lpVolumeSerialNumber, ref int lpMaximumComponentLength, ref int lpFileSystemFlags, string lpFileSystemNameBuffer, int nFileSystemNameSize);
		
		static public int GetSerialNumber(string strDrive)
		{
			int returnValue = 0;
			int SerialNum = 0;
			int Res;
			string Temp1 = "";
			string Temp2 = "";
			Temp1 = new string('\0', 255);
			Temp2 = new string('\0', 255);
			System.Int32 temp_lpMaximumComponentLength = 0;
			System.Int32 temp_lpFileSystemFlags = 0;
			Res = System.Convert.ToInt32(GetVolumeInformation(strDrive, Temp1, (short) Temp1.Length, ref SerialNum, ref temp_lpMaximumComponentLength, ref temp_lpFileSystemFlags, Temp2, Temp2.Length));
			returnValue = SerialNum;
			return returnValue;
		}
		
		static public object MiDu(string Chuzhi)
		{
			object returnValue = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			double jieguo = 0;
			
			short st;
			short pp = 0;
			double cl;
			double t = 0;
			double tt = 0;
			object p5 = null;
			double v1;
			double ab;
			double h1;
			double volume = 0;
			double w3 = 0;
			double w1 = 0;
			double Gf = 0;
			double z = 0;
			double y = 0;
			double o = 0;
			double b = 0;
			double y1;
			double gg = 0;
			double w = 0;
			double w2 = 0;
			double v = 0;
			double AAA;
			double h6;
			double aa;
			double h2;
			double kr;
			double vr;
			double tf;
			double hf;
			double g7;
			double g5;
			double g3;
			double g1;
			double g2;
			double g4;
			double g6;
			double h;
			double vf;
			double hr;
			double tR;
			double kf;
			tt = Conversion.Val(Chuzhi);
			cl = tt;
			t = tt + 273.15;
			pp = (short) 1;
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			p5 = pp * 100000;
			o = t / Module1.tc;
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b = System.Convert.ToDouble(System.Convert.ToDouble(p5) / Module1.pc);
			y = 1 - Module1.d1 * Math.Pow(o, 2) - Module1.d2 * Math.Pow(o, -6);
			y1 = -2 * Module1.d1 * o + 6 * Module1.d2 * Math.Pow(o, -7);
			z = y + System.Math.Sqrt(System.Math.Abs(Module1.d3 * Math.Pow(y, 2) - 2 * Module1.d4 * o + 2 * Module1.d5 * b));
			gg = Module1.d6 - o;
			if (System.Math.Abs(gg) < 0.000158)
			{
				gg = 0;
			}
			Gf = Module1.d6 - o;
			if (System.Math.Abs(Gf) < 0.0000596)
			{
				Gf = 0;
			}
			w = Module1.B1 * Module1.d5 * Math.Pow(z, (-5 / 17));
			w1 = w + (Module1.B2 + Module1.B3 * o + Module1.b4 * Math.Pow(o, 2) + Module1.b5 * Math.Pow(gg, 10) + Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -1)) - Math.Pow((Module1.d8 + Math.Pow(o, 11)), -1) * (Module1.b7 + 2 * Module1.b8 * b + 3 * Module1.b9 * Math.Pow(b, 2));
			w2 = w1 - Module1.c0 * Math.Pow(o, 18) * (Module1.d9 + Math.Pow(o, 2)) * (-3 * Math.Pow((Module1.e0 + b), -4) + Module1.e1);
			w3 = w2 + 3 * Module1.c1 * (Module1.e2 - o) * Math.Pow(b, 2) + 4 * Module1.c2 * Math.Pow(o, -20) * Math.Pow(b, 3);
			v = 1000 * w3 * Module1.vc;
			volume = 1 / v;
			
			if (volume < 1)
			{
				jieguo = double.Parse((volume).ToString().Substring(0, 7));
			}
			else
			{
				jieguo = double.Parse((volume).ToString().Substring(0, 7));
			}
			//  v = 1000! * w3 * vc
			//UPGRADE_WARNING: 未能解析对象 MiDu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			returnValue = jieguo;
			return returnValue;
		}
	}
}
