// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports



namespace 热量表
{
	sealed class DataEnvironment_DataEnvironment1_Module
	{
		internal static DataEnvironment_DataEnvironment1 DataEnvironment1 = new DataEnvironment_DataEnvironment1();
	}
	
	internal class DataEnvironment_DataEnvironment1 : Microsoft.VisualBasic.Compatibility.VB6.BaseDataEnvironment
	{
		public ADODB.Connection Connection1;
		public DataEnvironment_DataEnvironment1()
		{
			ADODB.Parameter par;
			
			
			Connection1 = new ADODB.Connection();
			Connection1.ConnectionString = "Provider=MSDASQL.1;Persist Security Info=False;Data Source=xiaoshan;";
			m_Connections.Add(Connection1, "Connection1", null, null);
		}
		private void DataEnvironment_Initialize()
		{
			
			
			Connection1.ConnectionString = "DSN=deluku;DBQ=" + (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\lib\\jiliang.mdb;DriverId=25;FIL=MS Access;MaxBufferSize=2048;PageTimeout=5;UID=admin;";
			
			
		}
		
		private void rsranmingxibiao_WillChangeField(int cFields, object Fields, ADODB.EventStatusEnum adStatus, ADODB.Recordset pRecordset)
		{
			
		}
	}
}
