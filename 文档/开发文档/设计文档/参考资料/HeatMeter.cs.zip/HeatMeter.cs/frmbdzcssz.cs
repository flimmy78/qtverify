// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmbdzcssz : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmbdzcssz defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmbdzcssz Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmbdzcssz();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		ADODB.Recordset Namefind;
		private void Findguige()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[5].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Gname from guigek order by Gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[5].Items.Add(Namefind.Fields["Gname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[5].SelectedIndex = 0;
			
		}
		private void FindXinghao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[2].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Xname from xinghaok order by Xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[2].Items.Add(Namefind.Fields["Xname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[2].SelectedIndex = 0;
			
		}
		private void Findsongjian()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[8].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Sname from songjiank order by Sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[8].Items.Add(Namefind.Fields["Sname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[8].SelectedIndex = 0;
			
		}
		private void Findzhizao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[7].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Zname from zhizaok order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[7].Items.Add(Namefind.Fields["Zname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[7].SelectedIndex = 0;
			
		}
		
		
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short j;
			short k;
			//If Text1.Text = "" Then
			//    MsgBox "请重新输入表号！"
			//       Exit Sub
			//    End If
			//    If Val(shuju(4).Text) <> 1 And Val(shuju(4).Text) <> 2 And Val(shuju(4).Text) <> 3 Then
			//    MsgBox "计量等级超出范围，请重新输入！！"
			//       Exit Sub
			//    End If
			sub_Renamed.XingHao = Strings.Trim(System.Convert.ToString(shuju[2].Text));
			sub_Renamed.GuiGe = Strings.Trim(System.Convert.ToString(shuju[1].Text));
			sub_Renamed.YouXiaoQi = Strings.Trim(System.Convert.ToString(shuju[4].Text));
			sub_Renamed.JianCeYuan = Strings.Trim(System.Convert.ToString(shuju[5].Text));
			sub_Renamed.ZhizaoDanwei = Strings.Trim(System.Convert.ToString(shuju[7].Text));
			sub_Renamed.SongjianDanwei = Strings.Trim(System.Convert.ToString(shuju[8].Text));
			//Jsqwdmax = Val(Twd(0).Text)
			//Jsqwdmin = Val(Twd(1).Text)
			//Jsqwcmax = Val(Twc(0).Text)
			//Jsqwcmin = Val(Twc(1).Text)
			//calculator.Text22.Text = Twc(1).Text
			//calculator.Text28.Text = Twc(1).Text
			//calculator.Text25.Text = (20 + Val(Twc(0).Text)) / 2
			//calculator.Text32.Text = (20 + Val(Twc(0).Text)) / 2
			//calculator.Text33.Text = Val(Twc(0).Text) - 5
			//Dim jsd
			//Dim jsdz
			//Dim jsdz1
			//Dim jsdd
			//jsd = Val(Twd(1).Text) + 5
			//jsdz = (Val(Twd(1).Text) + Val(Twd(0).Text)) / 2 - 5
			//jsdz1 = (Val(Twd(1).Text) + Val(Twd(0).Text)) / 2 + 5
			//jsdd = Val(Twd(0).Text) - 5
			//calculator.Frame12.Caption = "出口温度：" + "" & Twd(1).Text & "" + "-" + "" & jsd & "" + "℃"
			//calculator.Frame13.Caption = "出口温度：" + "" & jsdz & "" + "-" + "" & jsdz1 & "" + "℃"
			//calculator.Frame14.Caption = "入口温度：" + "" & jsdd & "" + "-" + "" & Twd(0).Text & "" + "℃"
			this.Hide();
		}
		
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT gname from guigek where gname=\'" + Strings.Trim(System.Convert.ToString(shuju[5].Text)) + " \' order by gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["gname"].Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT Zname from zhizaok where Zname=\'" + Strings.Trim(System.Convert.ToString(shuju[7].Text)) + " \' order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["Zname"].Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT sname from songjiank where sname=\'" + Strings.Trim(System.Convert.ToString(shuju[8].Text)) + " \' order by sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["sname"].Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT xname from xinghaok where xname=\'" + Strings.Trim(System.Convert.ToString(shuju[2].Text)) + " \' order by xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["xname"].Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
		}
		
		public void frmbdzcssz_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Timer1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Timer1.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			= ;true;
			Findguige();
			Findsongjian();
			FindXinghao();
			Findzhizao();
			shuju[2].Text = sub_Renamed.XingHao;
			// shuju(1).Text = GuiGe
			shuju[4].Text = sub_Renamed.YouXiaoQi;
			// shuju(5).Text = Worke
			shuju[7].Text = sub_Renamed.ZhizaoDanwei;
			shuju[8].Text = sub_Renamed.SongjianDanwei;
			sub_Renamed.FlagBiaoshuju = false;
			
		}
	}
}
