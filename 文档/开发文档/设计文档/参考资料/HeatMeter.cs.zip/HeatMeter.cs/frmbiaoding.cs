// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmbiaoding : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmbiaoding defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmbiaoding Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmbiaoding();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		object Wenducaiji;
		string SHujucaiji;
		string QIshi;
		float K1;
		float B1;
		float K2;
		float B2;
		float K3;
		float B3;
		
		string s1;
		object s2;
		object i1;
		float ll;
		object s3;
		object s4;
		object s5;
		
		object s6;
		short[] M = new short[10];
		
		short i;
		
		short[] mm = new short[11];
		short Wendujisuan;
		short Js;
		
		float[] Tpjs = new float[90001];
		
		float Sum_data;
		short Sum_plus;
		short Pinlvjs;
		short Pinlvsz1;
		
		bool FlagLL;
		object Ds;
		object Ds2;
		object Ds3;
		short Jsk;
		double[] Js1 = new double[90001];
		float Js2;
		
		short malP;
		short malDP;
		float[] Lpres = new float[11];
		float[] Ldpre = new float[11];
		float Ppres;
		float DPpre;
		
		int llJs;
		
		float maxLL;
		float minLL;
		string Data_in1;
		int Kk1;
		short Wendu_js1;
		
		private void adz_Click()
		{
			
			Timer8.Enabled = false;
			
			
		}
		
		public void Cbeijians_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			Timer12.Enabled = false;
			
		}
		
		
		
		private void Command11_Click()
		{
			object Timer3 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Timer3.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			= ;false;
			if (comm.Default.MSComm1.PortOpen == true)
			{
				comm.Default.MSComm1.PortOpen = false;
			}
			
		}
		
		private void Command12_Click()
		{
			object Timer3 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			//UPGRADE_WARNING: 未能解析对象 Timer3.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			= ;true;
		}
		
		
		
		public void Command10_Click(System.Object eventSender, System.EventArgs eventArgs) //
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option4.Checked == true)
			{
				Timer14.Enabled = false;
				Timer16.Enabled = false;
				Text6.Text = "";
				Text12.Text = "";
				Text15.Text = "";
				Text7.Text = "";
				Text12.Visible = true;
				Text15.Visible = true;
			}
			else if (frmjsbdz.Default.Option5.Checked == true)
			{
				Text12.Text = "";
				Text6.Text = "";
				Text15.Text = "";
				Text7.Text = "";
				Timer18.Enabled = false;
				Timer19.Enabled = false;
			}
			else if (frmjsbdz.Default.Option3.Checked == true)
			{
				
			}
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
		}
		
		public void Command13_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			MSComm6.PortOpen = true;
			
			if (frmjsbdz.Default.Option4.Checked == true) //唯立
			{
				
				MSComm6.Settings = "9600,n,8,1";
				MSComm6.InputLen = (short) 0; //串口清空
				Timer14.Enabled = true;
				sub_Renamed.delay_times((0.5));F;);
				Timer16.Enabled = true;
				
			}
			else if (frmjsbdz.Default.Option5.Checked == true) //华易
			{
				MSComm6.Settings = "4800,n,8,1";
				MSComm6.InputLen = (short) 0;
				Kk1 = 0;
				Wendu_js1 = (short) 0;
				Timer18.Enabled = true;
				//Timer19.Enabled = True
				
			}
			else if (frmjsbdz.Default.Option3.Checked == true) //计量院
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
				
			}
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Timer1.Enabled = false;
			sub_Renamed.jsjs = 0;
			sub_Renamed.Leiji = 0;
			Text14.Text = (0).ToString();
			
		}
		
		
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Timer12.Enabled = false;
			// If comm.MSComm1.PortOpen = True Then comm.MSComm1.PortOpen = False
		}
		
		
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object MSComm1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Admins == true)
			{
				for (i = 0; i <= 3; i++)
				{
					if (Conversion.Val(Text3[i].Text) == 0)
					{
						MessageBox.Show("检表数量不得为空或0！");
						return;
					}
					if (Conversion.Val(Text3[i].Text) >= 13)
					{
						MessageBox.Show("检表数量不得超过12只表！");
						return;
					}
				}
				
				sub_Renamed.Stueck15 = (short) (Conversion.Val(Text3[0].Text));
				sub_Renamed.Stueck20 = (short) (Conversion.Val(Text3[1].Text));
				sub_Renamed.Stueck25 = (short) (Conversion.Val(Text3[2].Text));
				sub_Renamed.Stueck32 = (short) (Conversion.Val(Text3[3].Text));
				
				
				FileSystem.FileClose(3);
				FileSystem.FileOpen(3, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Stueckzall.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
				FileSystem.WriteLine(3, sub_Renamed.Stueck15);
				FileSystem.WriteLine(3, sub_Renamed.Stueck20);
				FileSystem.WriteLine(3, sub_Renamed.Stueck25);
				FileSystem.WriteLine(3, sub_Renamed.Stueck32);
				FileSystem.FileClose(3);
			}
			
			sub_Renamed.Ld6 = 0;
			sub_Renamed.MID6 = (short) 1;
			sub_Renamed.StrSql = "select * from Adminis ";
			sub_Renamed.RsZbs = new ADODB.Recordset();
			sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			sub_Renamed.RsZbs.MoveFirst();
			//       RsZbs.Edit
			sub_Renamed.RsZbs.Fields["TFshuliang"].Value = sub_Renamed.Ld6;
			sub_Renamed.RsZbs.Fields["TPshuliang"].Value = sub_Renamed.MID6;
			sub_Renamed.RsZbs.Update(null, null);
			sub_Renamed.RsZbs.Close();
			
			//UPGRADE_WARNING: 未能解析对象 MSComm1.PortOpen 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (comm.Default.MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			
			Timer1.Enabled = false;
			Timer14.Enabled = false;
			Timer16.Enabled = false;
			Timer18.Enabled = false;
			Timer19.Enabled = false;
			Timer8.Enabled = false;
			Timer12.Enabled = false;
			
			sub_Renamed.BiaoDingactive = false;
			this.Close();
		}
		
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 251);
			sub_Renamed.delay_times(1);
		}
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Mdlguanfa.Send_Data((short) 252);
			sub_Renamed.delay_times(1);
		}
		
		public void frmbiaoding_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object MSComm1 = null;
			object Timer3 = null;
			object Timer7 = null;
			object Timer6 = null;
			object Timer5 = null;
			object Timer4 = null;
			object Label1 = null;
			object Label3 = null;
			object mc = null;
			object Commandt = null;
			object Commandk = null;
			object Command14 = null;
			object Command11 = null;
			object Command12 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.BiaoDingactive = true;
			if (sub_Renamed.Chinese == true)
			{
				this.Text = "数据采集与程序测试";
				Frame1[0].Text = "标准温度计";
				Frame2[1].Text = "模拟量";
				Frame6[0].Text = "瞬流采集";
				Frame6[1].Text = "天平采集";
				Frame7.Text = "管路布局";
				Frame3.Text = "被检表";
				Frame5[0].Text = "气动阀";
				Command13.Text = "采集";
				Command10.Text = "停止";
				wendu.Text = "采集";
				ting.Text = "停止";
				Command1.Text = "停止";
				tianping.Text = "采集";
				//UPGRADE_WARNING: 未能解析对象 Command12.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Command12.Caption = "采集";
				//UPGRADE_WARNING: 未能解析对象 Command11.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Command11.Caption = "停止";
				//UPGRADE_WARNING: 未能解析对象 Command14.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Command14.Caption = "保存";
				//UPGRADE_WARNING: 未能解析对象 Commandk.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Commandk.Caption = "开始";
				//UPGRADE_WARNING: 未能解析对象 Commandt.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Commandt.Caption = "停止";
				//UPGRADE_WARNING: 未能解析对象 mc.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				mc.Caption = "采脉冲";
				Cbeijians.Text = "采集";
				qd.Text = "启动水泵";
				tz.Text = "停止水泵";
				Command3.Text = "启动打压泵";
				Command5.Text = "停止打压泵";
				Command4.Text = "退出";
				
				
				Label2[0].Text = "进口";
				Label2[1].Text = "出口";
				//Label10(6).Caption = "脉冲数"
				//UPGRADE_WARNING: 未能解析对象 Label3.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Label3.Caption = "计时";
				Label8[7].Text = "秒";
				//Label10(0).Caption = "表号"
				//UPGRADE_WARNING: 未能解析对象 Label1.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Label1.Caption = "累积值";
				Label7[0].Text = "进口温度";
				Label7[1].Text = "出口温度";
				Label7[2].Text = "压力";
				Label7[3].Text = "差压";
				Label8[0].Text = "质量";
				Label8[4].Text = "流速";
			}
			else
			{
				this.Text = "Program tests";
				Frame1[0].Text = "Standard thermometer";
				Frame2[1].Text = "Analog";
				Frame6[0].Text = "Flowrate";
				Frame6[1].Text = "Balance";
				Frame7.Text = "Test-line";
				Frame3.Text = "Meter";
				Frame5[0].Text = "Valves";
				Command13.Text = "Reading";
				Command10.Text = "Stop";
				wendu.Text = "Reading";
				ting.Text = "Stop";
				Command1.Text = "Stop";
				tianping.Text = "Reading";
				//UPGRADE_WARNING: 未能解析对象 Command12.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Command12.Caption = "Read";
				//UPGRADE_WARNING: 未能解析对象 Command11.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Command11.Caption = "Stop";
				//UPGRADE_WARNING: 未能解析对象 Command14.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Command14.Caption = "Save";
				//UPGRADE_WARNING: 未能解析对象 Commandk.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Commandk.Caption = "Start";
				//UPGRADE_WARNING: 未能解析对象 Commandt.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Commandt.Caption = "Stop";
				//UPGRADE_WARNING: 未能解析对象 mc.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				mc.Caption = "Reading";
				Cbeijians.Text = "Reading";
				qd.Text = "Pump on";
				tz.Text = "Pump off";
				Command3.Text = "Pressure on";
				Command5.Text = "Pressure off";
				Command4.Text = "Quit";
				
				Label2[0].Text = "Flow";
				Label2[1].Text = "Return";
				//Label10(6).Caption = "Pulse"
				//UPGRADE_WARNING: 未能解析对象 Label3.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Label3.Caption = "Timing";
				Label8[7].Text = "s";
				//Label10(0).Caption = "Number"
				//UPGRADE_WARNING: 未能解析对象 Label1.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Label1.Caption = "Volume";
				Label7[0].Text = "Flow temp.";
				Label7[1].Text = "Return temp.";
				Label7[2].Text = "Pressure";
				Label7[3].Text = "Press.diff.";
				Label8[0].Text = "Mass";
				Label8[4].Text = "Flowrate";
				
			}
			//MsgBox "注意把秤的电源打开...."
			
			Timer1.Enabled = false; //天平
			Timer14.Enabled = false; //标温采集（唯立）
			Timer16.Enabled = false; //标温采集（唯立）
			Timer18.Enabled = false; //标温采集（华易）
			Timer19.Enabled = false; //标温采集（华易）
			//UPGRADE_WARNING: 未能解析对象 Timer4.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Timer4.Enabled = false; //计时
			//UPGRADE_WARNING: 未能解析对象 Timer5.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Timer5.Enabled = false; //外接流量计
			//UPGRADE_WARNING: 未能解析对象 Timer6.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Timer6.Enabled = false; //标准表
			//UPGRADE_WARNING: 未能解析对象 Timer7.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Timer7.Enabled = false;
			//UPGRADE_WARNING: 未能解析对象 Timer3.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Timer3.Enabled = false; //瞬流
			Timer8.Enabled = false; //温度
			Timer12.Enabled = false; //压力，差压
			
			
			TPcom();
			sub_Renamed.delay_times(1);
			
			Text3[0].Text = (sub_Renamed.Stueck15).ToString();
			Text3[1].Text = (sub_Renamed.Stueck20).ToString();
			Text3[2].Text = (sub_Renamed.Stueck25).ToString();
			Text3[3].Text = (sub_Renamed.Stueck32).ToString();
			
			comm.Default.MSComm1.CommPort = sub_Renamed.Com1;
			MSComm2.CommPort = sub_Renamed.Com2; //天平
			MSComm2.RThreshold = (short) 50;
			if (sub_Renamed.Bizerba == true || sub_Renamed.Mettler == true)
			{
				MSComm2.InputMode = MSCommLib.InputModeConstants.comInputModeBinary;
			}
			else
			{
				MSComm2.InputMode = MSCommLib.InputModeConstants.comInputModeText;
			}
			MSComm6.CommPort = sub_Renamed.Com4; //标铂
			
			MSComm5.CommPort = sub_Renamed.Com3; //温度
			//MSComm1.CommPort = Com5 '被检表
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			//UPGRADE_WARNING: 未能解析对象 MSComm1.PortOpen 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			
			if (sub_Renamed.Ld5 == 1)
			{
				Option6.Checked = true;
			}
			else if (sub_Renamed.Ld5 == 2)
			{
				Option5.Checked = true;
			}
			else if (sub_Renamed.Ld5 == 3)
			{
				Option4.Checked = true;
			}
			
			if (sub_Renamed.Ld4 == 3)
			{
				Option1.Checked = true;
			}
			else if (sub_Renamed.Ld4 == 4)
			{
				Option2.Checked = true;
			}
			else if (sub_Renamed.Ld4 == 5)
			{
				Option3.Checked = true;
			}
			
			
			
			//管理员时
			if (sub_Renamed.Admins == true)
			{
				Frame4.Visible = true;
				Frame7.Visible = true;
				Frame8.Visible = true;
				Frame5[0].Width = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(5175);
				
				for (i = 1; i <= 8; i++)
				{
					if (sub_Renamed.Ld4 == 3)
					{
						Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (i - 1) * 840);
						if (i == 6)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (4 - 1) * 840);
						}
						if (i == 7)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (5 - 1) * 840);
						}
						if (i == 8)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (6 - 1) * 840);
						}
						Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 840);
						if (i == 6)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (4 - 1) * 840);
						}
						if (i == 7)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 840);
						}
						if (i == 8)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 840);
						}
						Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 840);
						if (i == 6)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (4 - 1) * 840);
						}
						if (i == 7)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 840);
						}
						if (i == 8)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 840);
						}
						Siajin[4].Visible = false;
						Siajin[5].Visible = false;
						Lab[4].Visible = false;
						Lab[5].Visible = false;
						Shapzsd[4].Visible = false;
						Shapzsd[5].Visible = false;
						Lab[3].Text = "中流量阀";
					}
					else if (sub_Renamed.Ld4 == 4)
					{
						Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (i - 1) * 700);
						if (i == 6)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (5 - 1) * 700);
						}
						if (i == 7)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (6 - 1) * 700);
						}
						if (i == 8)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (7 - 1) * 700);
						}
						Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 700);
						if (i == 6)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 700);
						}
						if (i == 7)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 700);
						}
						if (i == 8)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (7 - 1) * 700);
						}
						Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 700);
						if (i == 6)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 700);
						}
						if (i == 7)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 700);
						}
						if (i == 8)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (7 - 1) * 700);
						}
						Siajin[4].Visible = true;
						Siajin[5].Visible = false;
						Lab[4].Visible = true;
						Lab[5].Visible = false;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = false;
					}
					else if (sub_Renamed.Ld4 == 5)
					{
						Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (i - 1) * 600);
						Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 600);
						Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 600);
						Siajin[4].Visible = true;
						Siajin[5].Visible = true;
						Lab[4].Visible = true;
						Lab[5].Visible = true;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = true;
					}
				}
			}
			else //非管理员时
			{
				Frame5[0].Width = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(7335);
				for (i = 1; i <= 8; i++)
				{
					if (sub_Renamed.Ld4 == 3)
					{
						Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 1176);
						if (i == 6)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (4 - 1) * 1176);
						}
						if (i == 7)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (5 - 1) * 1176);
						}
						if (i == 8)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (6 - 1) * 1176);
						}
						Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (i - 1) * 1176);
						if (i == 6)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (4 - 1) * 1176);
						}
						if (i == 7)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (5 - 1) * 1176);
						}
						if (i == 8)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (6 - 1) * 1176);
						}
						Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (i - 1) * 1176);
						if (i == 6)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (4 - 1) * 1176);
						}
						if (i == 7)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (5 - 1) * 1176);
						}
						if (i == 8)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (6 - 1) * 1176);
						}
						Siajin[4].Visible = false;
						Siajin[5].Visible = false;
						Lab[4].Visible = false;
						Lab[5].Visible = false;
						Shapzsd[4].Visible = false;
						Shapzsd[5].Visible = false;
						Lab[3].Text = "中流量阀";
					}
					else if (sub_Renamed.Ld4 == 4)
					{
						Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 980);
						if (i == 6)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (5 - 1) * 980);
						}
						if (i == 7)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (6 - 1) * 980);
						}
						if (i == 8)
						{
							Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (7 - 1) * 980);
						}
						Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (i - 1) * 980);
						if (i == 6)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (5 - 1) * 980);
						}
						if (i == 7)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (6 - 1) * 980);
						}
						if (i == 8)
						{
							Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (7 - 1) * 980);
						}
						Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (i - 1) * 980);
						if (i == 6)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (5 - 1) * 980);
						}
						if (i == 7)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (6 - 1) * 980);
						}
						if (i == 8)
						{
							Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (7 - 1) * 980);
						}
						Siajin[4].Visible = true;
						Siajin[5].Visible = false;
						Lab[4].Visible = true;
						Lab[5].Visible = false;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = false;
					}
					else if (sub_Renamed.Ld4 == 5)
					{
						Siajin[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 840);
						Lab[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (i - 1) * 840);
						Shapzsd[i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + (i - 1) * 840);
						Siajin[4].Visible = true;
						Siajin[5].Visible = true;
						Lab[4].Visible = true;
						Lab[5].Visible = true;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = true;
					}
				}
				
				if (sub_Renamed.MID1 == 2) //二个标准表时可测压力
				{
					Text5.Visible = false;
					Label7[3].Visible = false;
					Label19[1].Visible = false;
					Text4.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(720));
					Label7[2].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(780);
					Label19[0].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(780);
				}
				else if (sub_Renamed.MID1 == 3) //三个标准表时不测压力与差压
				{
					Frame3.Visible = false;
					qd.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(7920));
					qd.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(120));
					tz.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(7920));
					tz.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(720));
					Command3.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(9240));
					Command3.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(120));
					Command5.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(9240));
					Command5.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(720));
					Command4.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(8640));
					Command4.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1320));
					this.Width = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(10710));
				}
				
			} //管理员时结束
			
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			//UPGRADE_WARNING: 未能解析对象 MSComm1.PortOpen 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (comm.Default.MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			sub_Renamed.delay_times((0.5));F;);
			//If MSComm2.PortOpen = False Then MSComm2.PortOpen = True
			if (comm.Default.MSComm1.CommPort == false)
			{
				comm.Default.MSComm1.CommPort = true;
			}
			if (MSComm6.PortOpen == false)
			{
				MSComm6.PortOpen = true;
			}
			
			
			
			
			MSComm5.CommPort = sub_Renamed.Com3; //cmbPortNum.ListIndex + 1
			
			MSComm5.InputMode = MSCommLib.InputModeConstants.comInputModeBinary;
			MSComm5.Settings = "9600,n,8,2"; //strCommPara
			MSComm5.PortOpen = true;
			//
			//   '*  设置接收缓冲区的大小，当收到10个字节开始响应事件
			MSComm5.RThreshold = (short) 10;
			Mdlguanfa.Flagbzwd = false;
			
			
		}
		
		public void frmbiaoding_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.BiaoDingactive = false;
			//  SubExit
			sub_Renamed.delay_times(1);
		}
		
		
		
		private void mc_Click()
		{
			object Timer5 = null;
			//UPGRADE_WARNING: 未能解析对象 Timer5.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			= ;true;
		}
		
		private void MSComm1_OnComm()
		{
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option1.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option1_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (EventSender.Checked)
			{
				for (i = 1; i <= 8; i++)
				{
					Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (i - 1) * 840)));
					if (i == 6)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (4 - 1) * 840)));
					}
					if (i == 7)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (5 - 1) * 840)));
					}
					if (i == 8)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (6 - 1) * 840)));
					}
					Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 840)));
					if (i == 6)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (4 - 1) * 840)));
					}
					if (i == 7)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 840)));
					}
					if (i == 8)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 840)));
					}
					Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 840)));
					if (i == 6)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (4 - 1) * 840)));
					}
					if (i == 7)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 840)));
					}
					if (i == 8)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 840)));
					}
					Siajin[4].Visible = false;
					Siajin[5].Visible = false;
					Lab[4].Visible = false;
					Lab[5].Visible = false;
					Shapzsd[4].Visible = false;
					Shapzsd[5].Visible = false;
					Lab[3].Text = "中流量阀";
				}
				
				
				sub_Renamed.Ld4 = 3;
				sub_Renamed.StrSql = "select * from Adminis ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.RsZbs.Fields["Leitung"].Value = sub_Renamed.Ld4;
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
				
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option2.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option2_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (EventSender.Checked)
			{
				for (i = 1; i <= 8; i++)
				{
					Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (i - 1) * 700)));
					if (i == 6)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (5 - 1) * 700)));
					}
					if (i == 7)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (6 - 1) * 700)));
					}
					if (i == 8)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (7 - 1) * 700)));
					}
					Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 700)));
					if (i == 6)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 700)));
					}
					if (i == 7)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 700)));
					}
					if (i == 8)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (7 - 1) * 700)));
					}
					Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 700)));
					if (i == 6)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 700)));
					}
					if (i == 7)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 700)));
					}
					if (i == 8)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (7 - 1) * 700)));
					}
					Siajin[4].Visible = true;
					Siajin[5].Visible = false;
					Lab[4].Visible = true;
					Lab[5].Visible = false;
					Lab[3].Text = "中流一阀";
					Shapzsd[4].Visible = true;
					Shapzsd[5].Visible = false;
				}
				sub_Renamed.Ld4 = 4;
				sub_Renamed.StrSql = "select * from Adminis ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.RsZbs.Fields["Leitung"].Value = sub_Renamed.Ld4;
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
				
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option3.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option3_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (EventSender.Checked)
			{
				for (i = 1; i <= 8; i++)
				{
					Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240 + (i - 1) * 600)));
					Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 600)));
					Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 600)));
					Siajin[4].Visible = true;
					Siajin[5].Visible = true;
					Lab[4].Visible = true;
					Lab[5].Visible = true;
					Lab[3].Text = "中流一阀";
					Shapzsd[4].Visible = true;
					Shapzsd[5].Visible = true;
				}
				sub_Renamed.Ld4 = 5;
				sub_Renamed.StrSql = "select * from Adminis ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.RsZbs.Fields["Leitung"].Value = sub_Renamed.Ld4;
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option4.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option4_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				sub_Renamed.Ld5 = 3;
				sub_Renamed.StrSql = "select * from Adminis ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.RsZbs.Fields["Bshuliang"].Value = sub_Renamed.Ld5;
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option5.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option5_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				sub_Renamed.Ld5 = 2;
				sub_Renamed.StrSql = "select * from Adminis ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.RsZbs.Fields["Bshuliang"].Value = sub_Renamed.Ld5;
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option6.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option6_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				sub_Renamed.Ld5 = 1;
				sub_Renamed.StrSql = "select * from Adminis ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.RsZbs.Fields["Bshuliang"].Value = sub_Renamed.Ld5;
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
			}
		}}
		
		public void qd_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 249);
			sub_Renamed.delay_times(1);
		}
		private void tc_Click()
		{
			this.Close();
			
		}
		
		
		
		
		
		public void Siajin_Enter(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Siajin.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Command13.Focus();
			if ([Index;].value == true;);
			{
				Mdlguanfa.Zhu_Kai(ref Index);
			}
			else
			{
				Mdlguanfa.Zhu_Guan(ref Index);
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text13.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text13_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Conversion.Val(Text13.Text) > 105)
			{
				
				System.Int32 temp_i = 1;
				Mdlguanfa.Zhu_Guan(ref temp_i); //关主管道
				sub_Renamed.delay_times((0.5));F;);
				System.Int32 temp_i2 = 7;
				Mdlguanfa.Zhu_Kai(ref temp_i2); //放水开
				sub_Renamed.delay_times((0.5));F;);
			}
		}
		
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text3.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text3_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text3.GetIndex(eventSender);
			if (Conversion.Val(Text3[Index].Text) > 12)
			{
				MessageBox.Show("检表数量最多不得大于12只，请重输入！");
				Text3[Index].Text = "";
				Text3[Index].Focus();
			}
		}
		
		public void tianping_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.jsjs = 0;
			sub_Renamed.Leiji = 0;
			if (MSComm2.PortOpen == false)
			{
				MSComm2.PortOpen = true;
			}
			Timer1.Enabled = true; //'''''''''''''''''''
			
		}
		
		
		public void Timer12_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short[] s = new short[16];
			short Recount = 0;
			object sss;
			string Rxd = "";
			Mdlguanfa.Send_DataSl((short) 245); //liusu
			sub_Renamed.delay_times((0.4));F;);
			//UPGRADE_WARNING: 未能解析对象 comm.MSComm1.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Rxd = System.Convert.ToString(comm.Default.MSComm1.Input);
			//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
			Recount = System.Convert.ToInt16(LenB(Rxd));
			for (i = 1; i <= Recount; i++)
			{
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				s[i] = System.Convert.ToInt16(AscB(MidB(Rxd, i, 1)));
			}
			if (s[2] == 245)
			{
				
				if (sub_Renamed.MID1 != 3)
				{
					Lpres[malP] = (float) ((s[4] * 256 + s[5] - 883) * 0.0007783); //2.5MPa
					Ppres = Ppres + Lpres[malP];
					malP++;
					if (malP == 3)
					{
						Text4.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Ppres / 3, "0.00"); // 压力
						//                       If Val(Text4.Text) < 0.01 Then Text4.Text = "0.00"
						malP = (short) 0;
						Ppres = 0;
					}
				}
				if (sub_Renamed.MID1 == 0 | sub_Renamed.MID1 == 1)
				{
					Ldpre[malDP] = (float) ((s[6] * 256 + s[7] - 883) * 0.0467); //150kPa
					DPpre = DPpre + Ldpre[malDP];
					malDP++;
					if (malDP == 3)
					{
						Text5.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(DPpre / 3, "0.0"); // 差压
						//                       If Val(Text5.Text) < 0.1 Then Text5.Text = "0.0"
						malDP = (short) 0;
						DPpre = 0;
					}
				}
			}
			
			//     If comm.MSComm1.PortOpen = True Then comm.MSComm1.PortOpen = False
			
			
		}
		
		private void Timer2_Timer()
		{
			object Timer2 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				Kk1++;
				sub_Renamed.delay_times(1);
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 9));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = System.Convert.ToString(MSComm6.Input);
			Text6.Text = Data_in1;
			
			Wendu_js1++;
			if (Wendu_js1 < 30)
			{
				//   Text5.Text = Data_in1
			}
			else if (Wendu_js1 >= 30 & Wendu_js1 <= 60)
			{
				if (Wendu_js1 == 30)
				{
					MessageBox.Show("铂电阻检测切换");
				}
				Text7.Text = Data_in1;
				
			}
			else if (Wendu_js1 > 60)
			{
				//UPGRADE_WARNING: 未能解析对象 Timer2.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				= ;false;
				Wendu_js1 = (short) 0;
			}
		}
		
		
		
		public void Timer14_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text12.Visible = false;
			MSComm6.Output = "FETC? (@2)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text12.Text = System.Convert.ToString(MSComm6.Input);
			if (Text12.Text == "")
			{
				Text6.Text = Text14.Text;
			}
			else
			{
				Text6.Text = Text6.Text(Conversion.Val(Text12.Text), "0.000");
			}
		}
		
		public void Timer16_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text15.Visible = false;
			MSComm6.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text15.Text = System.Convert.ToString(MSComm6.Input);
			if (Text15.Text == "")
			{
				Text7.Text = Text7.Text;
			}
			else
			{
				Text7.Text = Text7.Text(Conversion.Val(Text15.Text), "0.000");
			}
		}
		
		public void Timer18_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				Kk1++;
				sub_Renamed.delay_times(1);
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 9));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = System.Convert.ToString(MSComm6.Input);
			//
			Text6.Text = Data_in1;
			
			Wendu_js1++;
			if (Wendu_js1 < 15)
			{
				//   Text5.Text = Data_in1
			}
			else if (Wendu_js1 >= 15 & Wendu_js1 <= 30)
			{
				if (Wendu_js1 == 15)
				{
					MessageBox.Show("请在十秒钟内将出口铂电阻接入测试仪！");
				}
				Text7.Text = Data_in1;
				
			}
			else if (Wendu_js1 > 30)
			{
				Timer18.Enabled = false;
				Wendu_js1 = (short) 0;
			}
		}
		
		
		
		private void Timer4_Timer()
		{
			object Textjs = null;
			//UPGRADE_WARNING: 未能解析对象 Textjs.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Textjs.Text = Conversion.Val(Textjs.Text) + 0.01;
		}
		
		
		
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.jsjs++;
			if (sub_Renamed.jsjs > 190000)
			{
				sub_Renamed.jsjs = 10;
			}
			sub_Renamed.zl[sub_Renamed.jsjs] = (float) (Conversion.Val(Text13.Text));
			if (sub_Renamed.jsjs >= 2)
			{
				sub_Renamed.Leiji = sub_Renamed.Leiji + sub_Renamed.zl[sub_Renamed.jsjs] - sub_Renamed.zl[sub_Renamed.jsjs - 1];
				Text14.Text = Text14.Text((sub_Renamed.Leiji) / (sub_Renamed.jsjs - 1) * 3.6 * 1.0056, "0.000");
				if (Conversion.Val(Text14.Text) < 0.01 || Conversion.Val(Text14.Text) > 8)
				{
					Text14.Text = (0).ToString();
				}
			}
			
			
		}
		
		
		
		public void Timer8_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			try
			{
				//If Flagbzwd = False Then
				//   Flagbzwd = True
				Js++;
				if (Js == 5)
				{
					Js = (short) 1;
				}
				sub_Renamed.m_lngAddress = Js;
				//   Else
				//    m_lngAddress = 2
				//    Flagbzwd = False
				//   End If
				if (MSComm5.PortOpen == false)
				{
					MSComm5.PortOpen = true;
				}
				
				Mdlguanfa.abytOrder[0] = (byte) (sub_Renamed.m_lngAddress | 0x80);
				Mdlguanfa.abytOrder[1] = (byte) (sub_Renamed.m_lngAddress | 0x80);
				Mdlguanfa.abytOrder[2] = (byte) (0x52);
				Mdlguanfa.abytOrder[3] = (byte) 0; // Val(txtPara(0).Text)
				Mdlguanfa.abytOrder[4] = (byte) 0;
				Mdlguanfa.abytOrder[5] = (byte) 0;
				
				//*  增加校验
				sub_Renamed.AddSum(ref Mdlguanfa.abytOrder, 0);
				//   labCommFlag = ""
				
				//*  发送命令
				MSComm5.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Mdlguanfa.abytOrder);
				//   delay_times (0.01)
			}
			catch
			{
				goto aa;
			}
aa:
			1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
		}
		
		private void TPcom()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,6,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,6,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,6,2";
			}
			
			
			
		}
		
		public void ting_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			
			Timer8.Enabled = false;
			
		}
		
		
		private void TP_Click()
		{
			//Timer1.Enabled = True
		}
		
		public void tz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 250);
			sub_Renamed.delay_times(1);
		}
		
		public void wendu_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Wendujisuan = (short) 0;
			Js = (short) 0;
			Timer8.Enabled = true;
			
		}
		
		
		public void MSComm5_OnComm(System.Object eventSender, System.EventArgs eventArgs)
		{
			try
			{
				byte[] abytReturnData = null;
				string strValue;
				int lngIndex;
				float sngValue = 0;
				switch (MSComm5.CommEvent)
				{
					case (short) 2:
						//         '*  仪表有数据返回
						//UPGRADE_WARNING: 未能解析对象 MSComm5.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						abytReturnData = () );MSComm5.Input;
						
						sngValue = System.Convert.ToSingle(abytReturnData[1] * 256 + abytReturnData[0]);
						if (sngValue >= 32768)
						{
							sngValue = sngValue - 65536;
						}
						if (Js == 1)
						{
							Text1.Text = ((sngValue) / 10).ToString();
						}
						if (Js == 2)
						{
							Text2.Text = ((sngValue) / 10).ToString();
						}
						break;
						//            If Js = 3 Then Text3(0).Text = sngValue / 100 'yali
						//            If Js = 4 Then Text4.Text = sngValue / 10  'chaya
					default:
						break;
				}
			}
			catch
			{
				goto aa;
			}
aa:
			1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
		}
		
		// VBConversions Note: Former VB static variables moved to class level because they aren't supported in C#.
		private int MSComm2_OnComm_xian;
		
		public void MSComm2_OnComm(System.Object eventSender, System.EventArgs eventArgs)
		{
			object danwei;
			object mtype;
			object quality = null;
			object mass = null;
			object arg;
			object dot = null;
			object statusC;
			object Statusb = null;
			object Statusa = null;
			object fuhao;
			object j = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object guo = null;
			object foot1;
			object head1;
			object head2;
			object foot2;
			// static int xian; VBConversions Note: Static variable moved to class level and renamed MSComm2_OnComm_xian. Local static variables are not supported in C#.
			if (sub_Renamed.Satorius == true)
			{
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s2 = Strings.Trim(System.Convert.ToString(MSComm2.Input));
						sub_Renamed.Tpcj1++;
						if (sub_Renamed.Tpcj1 > 3000)
						{
							sub_Renamed.Tpcj1 = (short) 5;
						}
						if (sub_Renamed.Tpcj1 > 2)
						{
							for (i = 1; i <= 30; i++)
							{
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s6 = Strings.Mid(System.Convert.ToString(s2), i, 1);
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s3 = Strings.Mid(System.Convert.ToString(s2), i + 13, 1);
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s5 = Strings.Mid(System.Convert.ToString(s2), i, 5);
								//UPGRADE_WARNING: 未能解析对象 s5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if (Strings.StrComp(System.Convert.ToString(s5), "0.000", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									Text13.Text = (0).ToString();
									return;
								}
								//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if (Strings.StrComp(System.Convert.ToString(s6), "+", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									Text13.Text = Strings.Mid(System.Convert.ToString(s2), i + 1, 9).Trim();
									break;
									//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								}
								else if (Strings.StrComp(System.Convert.ToString(s6), "-", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									Text13.Text = "-" + Strings.Mid(System.Convert.ToString(s2), i + 1, 9).Trim();
									break;
								}
							}
						}
						break;
					default:
						break;
				}
			}
			else if (sub_Renamed.Bizerba == true)
			{
				
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s2 = MSComm2.Input;
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						for (i = 1; i <= (s2); i++)
						{
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 head1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							head1 = Strings.Chr(System.Convert.ToInt32(((s2), i, 1));););
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 head2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							head2 = Strings.Chr(System.Convert.ToInt32(((s2), i + 1, 1));););
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 foot1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							foot1 = Conversion.Hex(((s2), i + 13, 1);););
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 foot2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							foot2 = Conversion.Hex(((s2), i + 14, 1);););
							//UPGRADE_WARNING: 未能解析对象 foot2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 foot1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 head2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 head1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (((string) head1 == "S" && (string) head2 == "T" && (string) foot1 == "D" && (string) foot2 == "A") || ((string) head1 == "U" && (string) head2 == "S" && (string) foot1 == "D" && (string) foot2 == "A"))
							{
								for (j = i + 3; j <= i + 10; System.Convert.ToInt32(System.Convert.ToInt32(j++))) //LenB(s2)
								{
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = "";
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), j, 1));););
									//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), System.Convert.ToInt32(j) + 1, 1));););
									//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), System.Convert.ToInt32(j) + 2, 1));););
									//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), System.Convert.ToInt32(j) + 3, 1));););
									//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), System.Convert.ToInt32(j) + 4, 1));););
									//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), System.Convert.ToInt32(j) + 5, 1));););
									//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), System.Convert.ToInt32(j) + 6, 1));););
									//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32(((s2), System.Convert.ToInt32(j) + 7, 1));););
									break;
								}
								//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								guo = Strings.Trim(System.Convert.ToString(guo));
								//                        If IsNumeric(guo) = False Then GoTo err
								break;
							}
						}
						//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Text13.Text = System.Convert.ToString(guo);
						break;
						
					default:
						break;
				}
				
			}
			else if (sub_Renamed.Mettler == true)
			{
				
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						s1 = System.Convert.ToString(MSComm2.Input);
						
						//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						fuhao = "";
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						if ((s1) < 17)
						{
							return; //没有校验和
						}
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						for (i = 1; i <= (s1); i++)
						{
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							if (((s1, ;i;, ;1)) == 2 && AscB(MidB(s1, i + 16, 1)) == 0xD)
							{
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 Statusa 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Statusa = ((s1, ;i + 1;, ;1));
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 Statusb 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Statusb = ((s1, ;i + 2;, ;1));
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 statusC 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								statusC = ((s1, ;i + 3;, ;1));
								//UPGRADE_WARNING: 未能解析对象 dot 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								dot = Statusa & 7;
								//UPGRADE_WARNING: 未能解析对象 arg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								arg = Statusa & 0x18;
								// mass = Val(Chr(AscB(MidB(s1, i + 4, 1)))) * 100000
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 5, 1))););) * 10000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 6, 1))););) * 1000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 7, 1))););) * 100;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 8, 1))););) * 10;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 9, 1)));););
								//quality = Val(Chr(AscB(MidB(s1, i + 10, 1)))) * 100000
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 11, 1))););) * 10000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 12, 1))););) * 1000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 13, 1))););) * 100;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 14, 1))););) * 10;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32(((s1), i + 15, 1)));););
								
								if ((int) dot == 1)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToInt32(mass) * 10 - 1000000;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToInt32(quality) * 10 - 1000000;
								}
								else if ((int) dot == 2)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = mass;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = quality;
								}
								else if ((int) dot == 3)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.1;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.1;
								}
								else if ((int) dot == 4)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.01;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.01;
								}
								else if ((int) dot == 5)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.001;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.001;
								}
								//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mtype = Statusb & 1;
								//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								fuhao = Statusb & 2;
								//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								danwei = Statusb & 0x10;
								//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) fuhao == 2)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToInt32(System.Convert.ToInt32(- mass));
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToInt32(System.Convert.ToInt32(- quality));
								}
								//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) danwei == 0)
								{
									danwei = "磅";
								}
								else
								{
									//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									danwei = "千克";
								}
								//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) mtype == 0)
								{
									mtype = "毛重";
								}
								else
								{
									//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mtype = "净重";
								}
								///'''''''''''''''显示毛重和皮重或者显示净重和皮重,毛重=净重+皮重
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Text13.Text = Conversion.Str(mass); //+ danwei '+ ",皮重" + Str(quality) + danwei
								break;
							}
						}
						break;
						
					default:
						break;
				}
				
				
			}
			
			
		}
	}
}
