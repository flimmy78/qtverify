// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmbjbdz : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmbjbdz defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmbjbdz Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmbjbdz();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		public void calculkey_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = calculkey.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			float t1 = 0; // 共公变量  标准温度值
			float t2 = 0;
			float t3 = 0;
			float rv0 = 0;
			float rv1 = 0;
			float rv2 = 0;
			float rv3 = 0;
			float bv = 0;
			float av = 0;
			
			
			rv1 = (float) (Conversion.Val(Text39[2].Text)); //电阻值
			rv2 = (float) (Conversion.Val(Text40[2].Text));
			rv3 = (float) (Conversion.Val(Text41[2].Text));
			
			t1 = (float) (Conversion.Val(Text39[1].Text)); //厂家提供的标准温度值
			t2 = (float) (Conversion.Val(Text40[1].Text));
			t3 = (float) (Conversion.Val(Text41[1].Text));
			
			bv = (float) ((rv3 - rv1 + (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 - rv1)) / (rv1 * t3 * t3 - rv3 * t1 * t1 - (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 * t1 * t1 - rv1 * t2 * t2)));
			av = (float) ((rv2 - rv1 + bv * (rv2 * t1 * t1 - rv1 * t2 * t2)) / (rv1 * t2 - rv2 * t1));
			rv0 = rv1 / (1 + av * t1 + bv * t1 * t1);
			Text11[6].Text = (System.Math.Round(rv0, 4)).ToString();
			Text12[6].Text = (System.Math.Round(av * Math.Pow(10, 3), 4)).ToString();
			Text13[6].Text = (System.Math.Round(bv * Math.Pow(10, 7), 4)).ToString();
			
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
			
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Text11[6].Text = (1000).ToString();
			Text12[6].Text = (3.9083).ToString();
			Text13[6].Text = (-5.775).ToString();
		}
		
		public void Command6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			FileSystem.FileClose(1);
			object m5;
			object m2 = null;
			object m1 = null;
			object m3 = null;
			object m6;
			float m4;
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\bjpt_canshu.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			
			//m0 = Text29.Text
			//UPGRADE_WARNING: 未能解析对象 m1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m1 = Conversion.Val(Text11[6].Text);
			//UPGRADE_WARNING: 未能解析对象 m2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m2 = Conversion.Val(Text12[6].Text);
			//UPGRADE_WARNING: 未能解析对象 m3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m3 = Conversion.Val(Text13[6].Text);
			
			FileSystem.WriteLine(1, m1);
			FileSystem.WriteLine(1, m2);
			FileSystem.WriteLine(1, m3);
			
			FileSystem.FileClose(1);
			
		}
		
		public void frmbjbdz_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Chinese == false)
			{
				this.Text = "Tested Temp.sensor";
				Frame3[3].Text = "Parameters";
				Text38[1].Text = "Tem.(℃)";
				Text38[2].Text = "Res.(Ω)";
				calculkey[1].Text = "Cal.";
				Command6.Text = "Save";
				Command2.Text = "Default";
				Command1.Text = "Quit";
				Text39[3].Text = "Point 1";
				Text40[3].Text = "Point 2";
				Text41[3].Text = "Point 3";
			}
			else
			{
				Text38[2].Text = "电阻(Ω)";
				Text38[1].Text = "温度(℃)";
				this.Text = "被检铂电阻参数";
				Frame3[3].Text = "参数";
				calculkey[1].Text = "计算";
				Command6.Text = "保存";
				Command2.Text = "默认";
				Command1.Text = "退出";
				Text39[3].Text = "第I点";
				Text40[3].Text = "第II点";
				Text41[3].Text = "第III点";
			}
			
			
			short n;
			object m5;
			object m2 = null;
			object m0;
			object m1 = null;
			object m3 = null;
			object m6;
			string m4;
			float m7;
			short int1;
			FileSystem.FileClose(1);
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\bjpt_canshu.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			
			
			FileSystem.Input(1, ref m1);
			FileSystem.Input(1, ref m2);
			FileSystem.Input(1, ref m3);
			//Input #1, m4
			//Input #1, m5
			//Input #1, m6
			//Input #1, m7
			
			
			//Text29.Text = m0
			//UPGRADE_WARNING: 未能解析对象 m1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text11[6].Text = () );m1;
			//UPGRADE_WARNING: 未能解析对象 m2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text12[6].Text = () );m2;
			//UPGRADE_WARNING: 未能解析对象 m3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text13[6].Text = () );m3;
			//Text30.Text = m4
			//Text11(5).Text = m5
			//Text12(5).Text = m6
			//Text13(5).Text = m7
			
			FileSystem.FileClose(1);
			//shuju(5).Text = Worke
		}
	}
}
