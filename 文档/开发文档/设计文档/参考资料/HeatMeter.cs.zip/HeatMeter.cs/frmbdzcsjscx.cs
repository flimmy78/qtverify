// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmbdzcsjscx : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmbdzcsjscx defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmbdzcsjscx Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmbdzcsjscx();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		private Microsoft.Office.Interop.Excel.Application objExcel;
		string filepath;
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs) //查询
		{
			string sqlStr = "";
			bool first = default(bool);
			first = true;
			sqlStr = "select * from bdzdz";
			if (txtCCBH.Text != "")
			{
				first = false;
				sqlStr = sqlStr + " Where CCBH1=\'" + txtCCBH.Text + "\'";
			}
			if (txtJCRQ.Text != "")
			{
				if (!first)
				{
					sqlStr = sqlStr + " and JCRQ1 = DateValue(\'" + txtJCRQ.Text + "\')";
				}
				else
				{
					first = false;
					sqlStr = sqlStr + " where JCRQ1 = DateValue(\'" + txtJCRQ.Text + "\')";
				}
			}
			if (txtSJDW.Text != "")
			{
				if (!first)
				{
					sqlStr = sqlStr + " and SJDW1 = \'" + txtSJDW.Text + "\'";
				}
				else
				{
					first = false;
					sqlStr = sqlStr + " where SJDW1 =  \'" + txtSJDW.Text + "\'";
				}
			}
			// If (txtZZC.Text <> "") Then
			// If (Not first) Then
			//sqlStr = sqlStr + " and ZZC = '" + txtZZC + "'"
			//Else
			//first = False
			//sqlStr = sqlStr + " where ZZC =  '" + txtZZC + "'"
			//End If
			//End If
			//  MsgBox sqlStr
			Adodc1.Enabled = true;
			Adodc1.RecordSource = sqlStr;
			Adodc1.Refresh();
			Debug.Print("liangjie" + this.Adodc1.ConnectionString);
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs) //将选定项打开, 如果不存在此文件如何处理呀？
		{
			string fileName = "";
			string msg = "";
			Microsoft.Office.Interop.Excel.Application objExcel = default(Microsoft.Office.Interop.Excel.Application);
			objExcel = new Microsoft.Office.Interop.Excel.Application();
			fileName = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\report\\" + txtHidden.Text.Trim() + ".xls";
			//UPGRADE_WARNING: Dir 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			if (FileSystem.Dir(fileName, (Microsoft.VisualBasic.FileAttribute) 0) != "")
			{
				objExcel.SheetsInNewWorkbook = 1;
				objExcel.Workbooks.Open(fileName, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
				objExcel.Visible = true;
				
				//objExcel.Sheets.Application.DisplayFullScreen = True
				//objExcel.Application.WindowState = xlMinimized
				
				Debug.Print("filename" + fileName);
				//   On Error GoTo 0   ' 关闭错误陷阱。
				//   On Error Resume Next   ' 改变错误陷阱。
				if (Information.Err().Number != 0)
				{
					msg = " 打开文件时,遇到了错误 ";
					MessageBox.Show(msg);
				}
			}
			else
			{
				objExcel.Quit();
				//UPGRADE_NOTE: 在对对象 objExcel 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
				objExcel = null;
				msg = "没找到此文件! ";
				MessageBox.Show(msg);
			}
			
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs) //将选定项删除
		{
			// Dim fso
			// Dim msg
			// Dim fileName As String
			//fileName = App.Path + "\report\" + txtHidden.Text + ".XLS"
			//Debug.Print "filename"; fileName
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Chinese == true)
			{
				if (Interaction.MsgBox("您确认要删除该条记录么?", MsgBoxStyle.OkCancel, "确认") == MsgBoxResult.Ok)
				{
					
					
					Adodc1.Recordset.Delete((ADODB.AffectEnum) 1);
					Adodc1.Recordset.UpdateBatch((ADODB.AffectEnum) 3); //?????
					//    Set fso = CreateObject("Scripting.FileSystemObject")
					//    If Dir(fileName) <> "" Then
					//    fso.deletefile (fileName)
					//    Else
					//    msg = "没删除Excel文件，仅删除记录了 "
					//    MsgBox msg
					//    End If
					//    If Err.number <> 0 Then
					//    msg = " 没删除Excel文件，仅删除记录了"
					//    MsgBox msg
					//    End If
				}
				
			}
			else
			{
				if (Interaction.MsgBox("You confirm that you want to delete this record?", MsgBoxStyle.YesNo, "Delete") == MsgBoxResult.Yes)
				{
					Adodc1.Recordset.Delete((ADODB.AffectEnum) 1);
					Adodc1.Recordset.UpdateBatch((ADODB.AffectEnum) 3); //?????
				}
			}
			
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs) //将某指定时间前的所有记录删除
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			string delStr = "";
			string fileName;
			object msg;
			object fso;
			if (sub_Renamed.Chinese == true)
			{
				if (Interaction.MsgBox("您确认要删除" + "以前的所有检测结果么？", MsgBoxStyle.OkCancel, "确认") == MsgBoxResult.Ok)
				{
					
					delStr = "select * from jsqjc where JCRQ1 < DateValue(\'" + txtRQ.Text + "\')";
					Adodc1.Enabled = true;
					Adodc1.RecordSource = delStr;
					Adodc1.Refresh();
					fso = Interaction.CreateObject("Scripting.FileSystemObject", "");
					while (!Adodc1.Recordset.EOF)
					{
						//      fileName = App.Path + "\report\" + txtHidden.Text + ".xls"
						
						Adodc1.Recordset.Delete((ADODB.AffectEnum) 1);
						Adodc1.Recordset.UpdateBatch((ADODB.AffectEnum) 3);
						Adodc1.Recordset.MoveNext();
						//        If Dir(fileName) <> "" Then
						//        fso.deletefile (fileName)
						//        Else
						//        msg = "没删除Excel文件 "
						//        MsgBox msg
						//        End If
					}
					//Data.Command4_Click
				}
				
			}
			else
			{
				if (Interaction.MsgBox("You confirm that you want to delete previously all test results?", MsgBoxStyle.YesNo, "Delete") == MsgBoxResult.Yes)
				{
					
					delStr = "select * from jsqjc where JCRQ1 < DateValue(\'" + txtRQ.Text + "\')";
					Adodc1.Enabled = true;
					Adodc1.RecordSource = delStr;
					Adodc1.Refresh();
					fso = Interaction.CreateObject("Scripting.FileSystemObject", "");
					while (!Adodc1.Recordset.EOF)
					{
						//      fileName = App.Path + "\report\" + txtHidden.Text + ".xls"
						
						Adodc1.Recordset.Delete((ADODB.AffectEnum) 1);
						Adodc1.Recordset.UpdateBatch((ADODB.AffectEnum) 3);
						Adodc1.Recordset.MoveNext();
						//        If Dir(fileName) <> "" Then
						//        fso.deletefile (fileName)
						//        Else
						//        msg = "没删除Excel文件 "
						//        MsgBox msg
						//        End If
					}
					//Data.Command4_Click
				}
				
				
			}
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs) //卸载窗体
		{
			this.Close();
			//Form2.Show
		}
		
		
		public void frmbdzcsjscx_Load(System.Object eventSender, System.EventArgs eventArgs) //加载
		{
			object FileNum = null;
			if (sub_Renamed.Chinese == true)
			{
				DataGrid1.Columns(0).Caption = "记录编号";
				DataGrid1.Columns(1).Caption = "出厂编号";
				DataGrid1.Columns(2).Caption = "检测日期";
				DataGrid1.Columns(3).Caption = "送检单位";
				this.Text = "铂电阻参数法数据查询";
				Frame1.Text = "条件查询";
				Frame2.Text = "操作功能";
				Label1.Text = "出厂编号";
				Label2.Text = "检测日期";
				Label3.Text = "送检单位";
				Label5.Text = "(格式：2008-08-08)";
				Label8.Text = "将当前项";
				Label8.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240));
				Label9.Text = "或者";
				Label9.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2340));
				Label7.Text = "将";
				Label6.Text = "之前的所有记录";
				Adodc1.Text = "查询结果";
				Command1.Text = "依条件查询";
				Command2.Text = "打开";
				Command3.Text = "删除";
				Command2.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1260));
				Command3.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2880));
				
				Command4.Text = "删除";
				Command5.Text = "退出";
			}
			else
			{
				DataGrid1.Columns(0).Caption = "Record No.";
				DataGrid1.Columns(1).Caption = "Meter No.";
				DataGrid1.Columns(2).Caption = "Date";
				DataGrid1.Columns(3).Caption = "Applicant";
				this.Text = "Query-Temperature(characteristic)";
				Frame1.Text = "under condition";
				Frame2.Text = "Operation";
				Label1.Text = "Meter No.";
				Label2.Text = "Date";
				Label3.Text = "Applicant";
				Label5.Text = "(Format：2008-08-08)";
				Label8.Text = "The report";
				Label8.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2880));
				Label9.Text = "Or";
				Label9.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1320));
				Label7.Text = "All";
				Label6.Text = "before will be";
				Adodc1.Text = "Results";
				Command1.Text = "Query";
				Command2.Text = "Open";
				Command3.Text = "Delete";
				Command2.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240));
				Command3.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1800));
				Command4.Text = "Deleted";
				Command5.Text = "Exit";
			}
			
			
			filepath = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath;
			//Set objExcel = New excel.Application
			try
			{
				//UPGRADE_WARNING: 未能解析对象 FileNum 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				FileNum = FileSystem.FreeFile(); //Freefile()函数是获得一个未被使用的文件号
				//UPGRADE_WARNING: 未能解析对象 FileNum 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				FileSystem.FileOpen(System.Convert.ToInt32(FileNum), (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\fileNo.ini", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
				//UPGRADE_WARNING: 未能解析对象 FileNum 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				FileSystem.Input(System.Convert.ToInt32(FileNum), ref Mdlguanfa.fileNo);
				//UPGRADE_WARNING: 未能解析对象 FileNum 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				FileSystem.FileClose(FileNum);
				Debug.Print("fileNo=" + System.Convert.ToString(Mdlguanfa.fileNo));
			}
			catch
			{
				goto fileError;
			}
			return;
//			Debug.Print(filepath);
fileError:
			MessageBox.Show("打开文件错误，请检查运行目录下面fileNo.ini文件！");
		}
		
		public void frmbdzcsjscx_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs) //卸载过程处理
		{
			
			
		}
	}
}
