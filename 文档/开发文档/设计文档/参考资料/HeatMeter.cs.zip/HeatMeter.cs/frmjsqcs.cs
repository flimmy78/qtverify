// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmjsqcs : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmjsqcs defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmjsqcs Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmjsqcs();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		ADODB.Recordset Namefind;
		private void Findguige()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[5].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Gname from guigek order by Gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[5].Items.Add(Namefind.Fields["Gname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[1].SelectedIndex = 0;
			
		}
		private void FindXinghao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[2].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Xname from xinghaok order by Xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[2].Items.Add(Namefind.Fields["Xname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[2].SelectedIndex = 0;
			
		}
		private void Findsongjian()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[8].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Sname from songjiank order by Sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[8].Items.Add(Namefind.Fields["Sname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[8].SelectedIndex = 0;
			
		}
		private void Findzhizao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[7].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Zname from zhizaok order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[7].Items.Add(Namefind.Fields["Zname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[7].SelectedIndex = 0;
			
		}
		
		
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Jsqwcmin;
			object Jsqwcmax;
			object Jsqwdmin;
			object Jsqwdmax;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short j;
			short k;
			if (Text1.Text == "")
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请输入表号！");
				}
				else
				{
					MessageBox.Show("Please enter the meter No.!");
				}
				return;
			}
			if (Conversion.Val(shuju[4].Text) != 1 && Conversion.Val(shuju[4].Text) != 2 && Conversion.Val(shuju[4].Text) != 3)
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("计量等级超出范围，请重新输入！");
				}
				else
				{
					MessageBox.Show("The class is out of range,  Please reenter!");
				}
				return;
			}
			sub_Renamed.XingHao = Strings.Trim(System.Convert.ToString(shuju[2].Text));
			sub_Renamed.GuiGe = Strings.Trim(System.Convert.ToString(shuju[1].Text));
			sub_Renamed.YouXiaoQi = Strings.Trim(System.Convert.ToString(shuju[4].Text));
			sub_Renamed.JianCeYuan = Strings.Trim(System.Convert.ToString(shuju[5].Text));
			sub_Renamed.ZhizaoDanwei = Strings.Trim(System.Convert.ToString(shuju[7].Text));
			sub_Renamed.SongjianDanwei = Strings.Trim(System.Convert.ToString(shuju[8].Text));
			//UPGRADE_WARNING: 未能解析对象 Jsqwdmax 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Jsqwdmax = Conversion.Val(Twd[0].Text);
			//UPGRADE_WARNING: 未能解析对象 Jsqwdmin 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Jsqwdmin = Conversion.Val(Twd[1].Text);
			//UPGRADE_WARNING: 未能解析对象 Jsqwcmax 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Jsqwcmax = Conversion.Val(Twc[0].Text);
			//UPGRADE_WARNING: 未能解析对象 Jsqwcmin 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Jsqwcmin = Conversion.Val(Twc[1].Text);
			calculator.Default.Text22.Text = System.Convert.ToString(Twc[1].Text);
			calculator.Default.Text28.Text = System.Convert.ToString(Twc[1].Text);
			calculator.Default.Text25.Text = ((20 + Conversion.Val(Twc[0].Text)) / 2).ToString();
			calculator.Default.Text32.Text = ((20 + Conversion.Val(Twc[0].Text)) / 2).ToString();
			calculator.Default.Text33.Text = (Conversion.Val(Twc[0].Text) - 5).ToString();
			object jsd = null;
			object jsdz = null;
			object jsdz1 = null;
			object jsdd = null;
			//UPGRADE_WARNING: 未能解析对象 jsd 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			jsd = Conversion.Val(Twd[1].Text) + 5;
			//UPGRADE_WARNING: 未能解析对象 jsdz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			jsdz = (Conversion.Val(Twd[1].Text) + Conversion.Val(Twd[0].Text)) / 2 - 5;
			//UPGRADE_WARNING: 未能解析对象 jsdz1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			jsdz1 = (Conversion.Val(Twd[1].Text) + Conversion.Val(Twd[0].Text)) / 2 + 5;
			//UPGRADE_WARNING: 未能解析对象 jsdd 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			jsdd = Conversion.Val(Twd[0].Text) - 5;
			//UPGRADE_WARNING: 未能解析对象 jsd 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			calculator.Default.Frame12.Text = "出口温度：" + "" + Twd[1].Text + "" + "-" + "" + System.Convert.ToString(jsd) + "" + "℃";
			//UPGRADE_WARNING: 未能解析对象 jsdz1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 jsdz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			calculator.Default.Frame13.Text = "出口温度：" + "" + System.Convert.ToString(jsdz) + "" + "-" + "" + System.Convert.ToString(jsdz1) + "" + "℃";
			//UPGRADE_WARNING: 未能解析对象 jsdd 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			calculator.Default.Frame14.Text = "入口温度：" + "" + System.Convert.ToString(jsdd) + "" + "-" + "" + Twd[0].Text + "" + "℃";
			this.Hide();
		}
		
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT gname from guigek where gname=\'" + Strings.Trim(System.Convert.ToString(shuju[5].Text)) + " \' order by gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["gname"].Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT Zname from zhizaok where Zname=\'" + Strings.Trim(System.Convert.ToString(shuju[7].Text)) + " \' order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["Zname"].Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT sname from songjiank where sname=\'" + Strings.Trim(System.Convert.ToString(shuju[8].Text)) + " \' order by sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["sname"].Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT xname from xinghaok where xname=\'" + Strings.Trim(System.Convert.ToString(shuju[2].Text)) + " \' order by xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["xname"].Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
		}
		
		public void frmjsqcs_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Timer1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			if (sub_Renamed.Chinese == true)
			{
				
				Frame1[0].Text = "检定参数";
				Frame1[1].Text = "参数设置";
				
				
				Label2[0].Text = "表 编 号";
				Label2[1].Text = "送检单位";
				Label2[5].Text = "规    格";
				Label2[7].Text = "型    号";
				Label2[2].Text = "制造单位";
				Label2[6].Text = "计量等级";
				Label2[8].Text = "检 测 员";
				
				
				
				Command1.Text = "确认";
				Command3.Text = "保存";
			}
			else
			{
				
				
				Frame1[0].Text = "Informations";
				Frame1[1].Text = "Parameters";
				
				Label2[0].Text = "Meter No.";
				Label2[1].Text = "Applicant";
				Label2[5].Text = "Dimension";
				Label2[7].Text = "Type";
				Label2[2].Text = "Producer";
				Label2[6].Text = "Class";
				Label2[8].Text = "Tester";
				
				
				
				
				Command1.Text = "Ok";
				Command3.Text = "Save";
			}
			
			
			
			//UPGRADE_WARNING: 未能解析对象 Timer1.Enabled 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			= ;true;
			Findguige();
			Findsongjian();
			FindXinghao();
			Findzhizao();
			shuju[2].Text = sub_Renamed.XingHao;
			// shuju(1).Text = GuiGe
			shuju[4].Text = sub_Renamed.YouXiaoQi;
			// shuju(5).Text = Worke
			shuju[7].Text = sub_Renamed.ZhizaoDanwei;
			shuju[8].Text = sub_Renamed.SongjianDanwei;
			sub_Renamed.FlagBiaoshuju = false;
			
		}
	}
}
