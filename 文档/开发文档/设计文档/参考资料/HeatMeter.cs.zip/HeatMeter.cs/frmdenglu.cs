// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using Microsoft.VisualBasic.CompilerServices;

namespace 热量表
{
	partial class frmdenglu : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmdenglu defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmdenglu Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmdenglu();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		ADODB.Recordset Namefind;
		ADODB.Recordset NameFindM;
		short Denglucishu;
		ADODB.Recordset RSmima;
		object mima2;
		object mima1;
		object mima3;
		short mima4;
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//Dim Namefind As ADODB.Recordset
			
			
			if (Combo1.Text.Trim() == "SDM" && Text2.Text.Trim() == "8888")
			{
				sub_Renamed.Denglu = true;
				MessageBox.Show("可设定新的工号与密码，并再次点击《确定》确认。确认设定后点《退出》重新进入！");
				Combo1.Text = "";
				Text2.Text = "";
				goto eee;
			}
			
			if (Combo1.Text.Trim() == "MDS" && Text2.Text.Trim() == "8888")
			{
				sub_Renamed.Admins = true;
				MessageBox.Show("可设定检定管路、标准表数量等参数！");
				goto AAA;
			}
			
			
			if (sub_Renamed.Denglu == true && Combo1.Text.Trim() != "SDM")
			{
				
				
				sub_Renamed.StrSql = "select * from op ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.AddNew(null, null);
				//       RsZbs.Edit
				sub_Renamed.RsZbs.Fields["gonghao"].Value = Combo1.Text.Trim();
				sub_Renamed.RsZbs.Fields["mima"].Value = Text2.Text.Trim();
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
				Command1.Enabled = false;
				goto eee;
			}
			else if (sub_Renamed.Denglu == false)
			{
				
				Namefind = new ADODB.Recordset();
				sub_Renamed.sqlStr = "SELECT * from op where gonghao=\'" + Combo1.Text.Trim() + "\'" + "and mima=\'" + Text2.Text.Trim() + "\'";
				
				Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				
				if (Namefind.RecordCount != 0)
				{
					Namefind.MoveFirst();
					sub_Renamed.PassMima = System.Convert.ToString(Namefind.Fields["mima"].Value);
					sub_Renamed.PassGonghao = System.Convert.ToString(Namefind.Fields["gonghao"].Value);
					//                  Worke = Namefind.Fields("xingming")
				}
				else
				{
					MessageBox.Show("密码与姓名错误,请重新输入！");
					Combo1.Focus();
					Namefind.Close();
					//UPGRADE_NOTE: 在对对象 Namefind 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
					Namefind = null;
					Denglucishu++;
					if (Denglucishu > 3)
					{
						ProjectData.EndApp();
					}
					return;
				}
				
				Namefind.Close();
				//UPGRADE_NOTE: 在对对象 Namefind 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
				Namefind = null;
				this.Close();
				MDIForm1.Default.Show();
				
			}
AAA:
			this.Close();
			MDIForm1.Default.Show();
eee:
			1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
		}
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
			ProjectData.EndApp();
		}
		
		public void frmdenglu_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Combo1.Items.Clear();
			
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT gonghao from op order by gonghao";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					Combo1.Items.Add(Namefind.Fields["gonghao"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			Combo1.SelectedIndex = 0;
			
			sub_Renamed.Denglu = false;
			Timer1.Enabled = true;
		}
		
		public void combo1_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			if (KeyAscii == 13)
			{
				Text2.Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text2_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			if (KeyAscii == 13)
			{
				
				Command1_Click(Command1, new System.EventArgs());
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			Combo1.Focus();
			Timer1.Enabled = false;
		}
	}
}
