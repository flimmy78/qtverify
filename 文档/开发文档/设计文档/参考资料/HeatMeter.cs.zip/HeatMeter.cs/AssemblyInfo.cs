// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


// 有关程序集的常规信息是通过下列
// 属性集控制的。更改这些属性值可
// 修改与程序集关联的信息。


// TODO: 检查程序集的属性值


[assembly:AssemblyTitle("")]
[assembly:AssemblyDescription("")]
[assembly:AssemblyCompany("德鲁计量")]
[assembly:AssemblyProduct("热量表检测")]
[assembly:AssemblyCopyright("2003版")]
[assembly:AssemblyTrademark("sdim")]
[assembly:AssemblyCulture("")]

// 程序集的版本信息由下列 4 个值组成:

//	主版本
//	次版本
//	内部版本号
//	修订

// 您可以指定所有这些值，也可以使用“内部版本号”和“修订号”的默认值，
// 方法是按如下所示使用“*”:

[assembly:AssemblyVersion("1.0.*")]



