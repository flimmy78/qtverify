// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class Frmbdzshz : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static Frmbdzshz defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static Frmbdzshz Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new Frmbdzshz();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		object t;
		object b8;
		object Rtp;
		object deltaW;
		object wt;
		object wrt;
		object a8;
		object r;
		object a;
		double b;
		public object t1;
		public object t2;
		public float t3;
		short Pt_XH;
		float[] pt1000 = new float[101];
		short msg;
		ADODB.Recordset Namefind;
		
		
		short[] WuCha = new short[21];
		float[] mi = new float[9];
		float[] mi1 = new float[9];
		float[] Jinkou1 = new float[21];
		float[] Jinkou2 = new float[21];
		float[] Jinkou3 = new float[21];
		
		float[] Chukou1 = new float[21];
		float[] Chukou2 = new float[21];
		float[] Chukou3 = new float[21];
		
		float[] jkChangA = new float[21];
		float[] jkChangB = new float[21];
		float[] jkChangR = new float[21];
		
		float[] ckChangA = new float[21];
		float[] ckChangB = new float[21];
		float[] ckChangR = new float[21];
		public object jkAbc(ref short i)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			float rv0 = 0;
			float rv1 = 0;
			float rv2 = 0;
			float rv3 = 0;
			float bv = 0;
			float av = 0;
			rv1 = (float) (Conversion.Val(Text55[i].Text)); //电阻值
			rv2 = (float) (Conversion.Val(Text57[i].Text));
			rv3 = (float) (Conversion.Val(Text59[i].Text));
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			t1 = Conversion.Val(Text31[0].Text); //厂家提供的标准温度值
			//UPGRADE_WARNING: 未能解析对象 t2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			t2 = Conversion.Val(Text31[1].Text);
			t3 = (float) (Conversion.Val(Text31[2].Text));
			//UPGRADE_WARNING: 未能解析对象 t2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			bv = System.Convert.ToSingle(System.Convert.ToDouble(rv3 - rv1 + System.Convert.ToDouble(rv3 * t1 - rv1 * t3) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t2) - System.Convert.ToDouble(rv2 * t1)) * (rv2 - rv1)) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t3 * t3 - System.Convert.ToDouble(rv3 * t1) * System.Convert.ToDouble(t1)) - System.Convert.ToDouble((rv3 * t1 - rv1 * t3) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t2) - System.Convert.ToDouble(rv2 * t1)) * System.Convert.ToDouble(System.Convert.ToDouble(rv2 * t1) * System.Convert.ToDouble(t1) - System.Convert.ToDouble(rv1 * t2 * System.Convert.ToDouble(t2))))));
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 t2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			av = System.Convert.ToSingle(System.Convert.ToDouble(rv2 - rv1 + bv * (System.Convert.ToDouble(rv2 * t1) * System.Convert.ToDouble(t1) - System.Convert.ToDouble(rv1 * t2 * System.Convert.ToDouble(t2)))) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t2) - System.Convert.ToDouble(rv2 * t1)));
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			rv0 = System.Convert.ToSingle(rv1 / (System.Convert.ToDouble(1 + System.Convert.ToInt32(av * t1)) + System.Convert.ToDouble(bv * t1 * System.Convert.ToDouble(t1))));
			jkChangR[i] = (float) (System.Math.Round(rv0, 2));
			jkChangA[i] = (float) (System.Math.Round(av * Math.Pow(10, 3), 4));
			jkChangB[i] = (float) (System.Math.Round(bv * Math.Pow(10, 7), 4));
			//    jkChangA(i) = Round(av, 4)
			//    jkChangB(i) = Round(bv, 4)
		}
		public object ckAbc(ref short i)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			float rv0 = 0;
			float rv1 = 0;
			float rv2 = 0;
			float rv3 = 0;
			float bv = 0;
			float av = 0;
			
			
			rv1 = (float) (Conversion.Val(Text56[i].Text)); //电阻值
			rv2 = (float) (Conversion.Val(Text58[i].Text));
			rv3 = (float) (Conversion.Val(Text60[i].Text));
			
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			t1 = Conversion.Val(Text31[0].Text); //厂家提供的标准温度值
			//UPGRADE_WARNING: 未能解析对象 t2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			t2 = Conversion.Val(Text31[1].Text);
			t3 = (float) (Conversion.Val(Text31[2].Text));
			
			//UPGRADE_WARNING: 未能解析对象 t2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			bv = System.Convert.ToSingle(System.Convert.ToDouble(rv3 - rv1 + System.Convert.ToDouble(rv3 * t1 - rv1 * t3) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t2) - System.Convert.ToDouble(rv2 * t1)) * (rv2 - rv1)) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t3 * t3 - System.Convert.ToDouble(rv3 * t1) * System.Convert.ToDouble(t1)) - System.Convert.ToDouble((rv3 * t1 - rv1 * t3) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t2) - System.Convert.ToDouble(rv2 * t1)) * System.Convert.ToDouble(System.Convert.ToDouble(rv2 * t1) * System.Convert.ToDouble(t1) - System.Convert.ToDouble(rv1 * t2 * System.Convert.ToDouble(t2))))));
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 t2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			av = System.Convert.ToSingle(System.Convert.ToDouble(rv2 - rv1 + bv * (System.Convert.ToDouble(rv2 * t1) * System.Convert.ToDouble(t1) - System.Convert.ToDouble(rv1 * t2 * System.Convert.ToDouble(t2)))) / System.Convert.ToDouble(System.Convert.ToDouble(rv1 * t2) - System.Convert.ToDouble(rv2 * t1)));
			//UPGRADE_WARNING: 未能解析对象 t1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			rv0 = System.Convert.ToSingle(rv1 / (System.Convert.ToDouble(1 + System.Convert.ToInt32(av * t1)) + System.Convert.ToDouble(bv * t1 * System.Convert.ToDouble(t1))));
			ckChangR[i] = (float) (System.Math.Round(rv0, 2));
			ckChangA[i] = (float) (System.Math.Round(av * Math.Pow(10, 3), 4));
			ckChangB[i] = (float) (System.Math.Round(bv * Math.Pow(10, 7), 4));
			// ckChangA(i) = Round(av, 4)
			//    ckChangB(i) = Round(bv, 4)
			
		}
		private void about_Click()
		{
			object aboutForm = null;
			//UPGRADE_WARNING: 未能解析对象 aboutForm.Show 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			());
		}
		//Function standom_t(Fenzi As Single) As Single        '由标准电阻值计算 标准温度
		//On Error Resume Next
		//'        t1 = T
		//'        T = Round(T, 4)
		//
		// Xb = Val(Text4(0).Text) / 10 ^ 3    '铂电阻的一次项
		//            Xa = Val(Text5(0).Text) / 10 ^ 7    '铂电阻的二次顶
		//            Xc = Fenzi / Val(Text3(0).Text)
		//            standom_t = Round((-1 * Xb + Sqr(Xb ^ 2 - 4 * Xa * (1 - Xc))) / (2 * Xa), 4)
		//End Function
		//Function standom_t1(Fenzi As Single) As Single        '由标准电阻值计算 标准温度
		//On Error Resume Next
		//'        t1 = T
		//'        T = Round(T, 4)
		//
		// Xb = Val(Text4(1).Text) / 10 ^ 3    '铂电阻的一次项
		//            Xa = Val(Text5(1).Text) / 10 ^ 7    '铂电阻的二次顶
		//            Xc = Fenzi / Val(Text3(1).Text)
		//            standom_t1 = Round((-1 * Xb + Sqr(Xb ^ 2 - 4 * Xa * (1 - Xc))) / (2 * Xa), 4)
		//End Function
		//Function standom_t()       '由标准电阻值计算 标准温度
		//     Dim d(9) As Double
		//        d(0) = 439.932854
		//        d(1) = 472.41802
		//        d(2) = 37.684494
		//        d(3) = 7.472018
		//        d(4) = 2.920828
		//        d(5) = 0.005184
		//        d(6) = -0.963864
		//        d(7) = -0.188732
		//        d(8) = 0.191203
		//        d(9) = 0.049025
		//'       If Option1.value = True Then
		//                a8 = Val(Text4(0).Text) * 10 ^ -5
		//                b8 = Val(Text5(0).Text) * 10 ^ -5
		//                Rtp = Val(Text3(0).Text)
		//'                Else
		//'                a8 = Val(Text4(1).Text) * 10 ^ -5
		//'                b8 = Val(Text5(1).Text) * 10 ^ -5
		//'                Rtp = Val(Text3(1).Text)
		//'       End If
		//        wt = r / Rtp
		//        deltaW = a8 * (wt - 1) + b8 * (wt - 1) ^ 2    'deltaW8(t)=a8(w(t)-1)+b8(w(t)-1))^2
		//        wrt = wt - deltaW                             'deltaW8(t)=w(t)-Wr(t)
		//        t = 0
		//        For i = 0 To 9
		//            t = t + d(i) * ((wrt - 2.64) / 1.64) ^ i  't=d0*sum[di(Wr(t)-2.64)/1.64]^I;I:1 to 9
		//        Next i
		//        t1 = t
		//        t = Round(t, 4)
		//End Function
		//Function standom_t1()      '由标准电阻值计算 标准温度
		//   Dim d(9) As Double
		//        d(0) = 439.932854
		//        d(1) = 472.41802
		//        d(2) = 37.684494
		//        d(3) = 7.472018
		//        d(4) = 2.920828
		//        d(5) = 0.005184
		//        d(6) = -0.963864
		//        d(7) = -0.188732
		//        d(8) = 0.191203
		//        d(9) = 0.049025
		//'       If Option1.value = False Then
		//'                a8 = Val(Text4(0).Text) * 10 ^ -5
		//'                b8 = Val(Text5(0).Text) * 10 ^ -5
		//'                Rtp = Val(Text3(0).Text)
		//'        Else
		//                a8 = Val(Text4(1).Text) * 10 ^ -5
		//                b8 = Val(Text5(1).Text) * 10 ^ -5
		//                Rtp = Val(Text3(1).Text)
		//'       End If
		//        wt = r / Rtp
		//        deltaW = a8 * (wt - 1) + b8 * (wt - 1) ^ 2    'deltaW8(t)=a8(w(t)-1)+b8(w(t)-1))^2
		//        wrt = wt - deltaW                             'deltaW8(t)=w(t)-Wr(t)
		//        t = 0
		//        For i = 0 To 9
		//            t = t + d(i) * ((wrt - 2.64) / 1.64) ^ i  't=d0*sum[di(Wr(t)-2.64)/1.64]^I;I:1 to 9
		//        Next i
		//        t1 = t
		//        t = Round(t, 4)
		//End Function
		
		//Private Sub calculkey_Click()
		//On Error Resume Next
		//    't1,t2,t3 共公变量  标准温度值
		//    rv1 = Val(Text39(2).Text)        '温度电阻值
		//    rv2 = Val(Text40(2).Text)
		//    rv3 = Val(Text41(2).Text)
		//
		//    t1 = Val(Text39(1).Text)         '厂家提供的标准温度值
		//    t2 = Val(Text40(1).Text)
		//    t3 = Val(Text41(1).Text)
		//    On Error GoTo calquit
		//    bv = (rv3 - rv1 + (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 - rv1)) / (rv1 * t3 * t3 - rv3 * t1 * t1 - (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 * t1 * t1 - rv1 * t2 * t2))
		//    av = (rv2 - rv1 + bv * (rv2 * t1 * t1 - rv1 * t2 * t2)) / (rv1 * t2 - rv2 * t1)
		//    rv0 = rv1 / (1 + av * t1 + bv * t1 * t1)
		//    Text11(0).Text = Round(rv0, 2)
		//    Text12(0).Text = Round(av * 10 ^ 3, 4)
		//    Text13(0).Text = Round(bv * 10 ^ 7, 4)
		//
		//    GoTo nomorlquit
		//calquit:     MsgBox "输入有误"
		//nomorlquit:
		//End Sub
		
		private void exitCommand_Click()
		{
			this.Close();
		}
		
		
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmbdzcssz.Default.Show();
			
		}
		
		private void cmdCeLiang_Click()
		{
			
		}
		
		private void cmdDaYin_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			msg = (short) (Interaction.MsgBox("请您确认是否打印？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "打印提示"));
			switch (msg)
			{
				case (short) MsgBoxResult.Yes:
					Module1.PrintCouple();
					break;
				case (short) MsgBoxResult.No:
					return;
			}
		}
		
		
		private void cmdpause_Click()
		{
			
		}
		
		public void cmdQuit_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		private void cmdxsbx_Click()
		{
			
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Wendu_js1;
			object Kk1;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			MSComm6.PortOpen = true;
			Timer9.Enabled = false;
			Timer5.Enabled = false;
			Timer3.Enabled = false;
			Timer7.Enabled = false;
			if (Pt_XH == 2)
			{
				MSComm6.Settings = "9600,n,8,1";
				MSComm6.InputLen = (short) 0; //串口清空
				Timer1.Enabled = true;
				//Timer2.Enabled = True
			}
			else if (Pt_XH == 3)
			{
				MSComm6.Settings = "4800,n,8,1";
				MSComm6.InputLen = (short) 0;
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = 0;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
				Timer6.Enabled = true;
				//Timer22.Enabled = True
			}
			else if (Pt_XH == 1)
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
			}
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Pt_XH == 2)
			{
				Timer1.Enabled = false;
				//Timer2.Enabled = False
				Text10[1].Text = "";
				//Text31(1).Text = ""
				//Text26(1).Text = ""
				//Text27(1).Text = ""
				Text10[1].Visible = true;
				Text26[1].Visible = true;
			}
			else if (Pt_XH == 3)
			{
				Text10[1].Text = "";
				//Text31(1).Text = ""
				//Text26(1).Text = ""
				//Text27(1).Text = ""
				Timer6.Enabled = false;
				//Timer22.Enabled = False
			}
			else if (Pt_XH == 1)
			{
				
			}
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Kk1;
			object Wendu_js1;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			MSComm6.PortOpen = true;
			Timer1.Enabled = false;
			Timer6.Enabled = false;
			Timer5.Enabled = false;
			Timer9.Enabled = false;
			if (Pt_XH == 2)
			{
				MSComm6.Settings = "9600,n,8,1";
				MSComm6.InputLen = (short) 0; //串口清空
				Timer3.Enabled = true;
				//Timer4.Enabled = True
			}
			else if (Pt_XH == 3)
			{
				MSComm6.Settings = "4800,n,8,1";
				MSComm6.InputLen = (short) 0;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = 0;
				Timer7.Enabled = true;
				//Timer22.Enabled = True
			}
			else if (Pt_XH == 1)
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
			}
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Pt_XH == 2)
			{
				Timer3.Enabled = false;
				//Timer10.Enabled = False
				Text10[2].Text = "";
				//Text31(2).Text = ""
				//Text26(2).Text = ""
				//Text27(2).Text = ""
				Text10[2].Visible = true;
				Text26[2].Visible = true;
			}
			else if (Pt_XH == 3)
			{
				Text10[2].Text = "";
				//Text31(2).Text = ""
				//Text26(2).Text = ""
				//Text27(2).Text = ""
				Timer7.Enabled = false;
				//Timer22.Enabled = False
			}
			else if (Pt_XH == 1)
			{
				
			}
		}
		
		public void Command7_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Kk1;
			object Wendu_js1;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			MSComm6.PortOpen = true;
			
			Timer1.Enabled = false;
			Timer6.Enabled = false;
			Timer3.Enabled = false;
			Timer7.Enabled = false;
			if (Pt_XH == 2)
			{
				MSComm6.Settings = "9600,n,8,1";
				MSComm6.InputLen = (short) 0; //串口清空
				Timer9.Enabled = true;
				//Timer10.Enabled = True
			}
			else if (Pt_XH == 3)
			{
				MSComm6.Settings = "4800,n,8,1";
				MSComm6.InputLen = (short) 0;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = 0;
				Timer5.Enabled = true;
				//Timer22.Enabled = True
			}
			else if (Pt_XH == 1)
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
			}
		}
		
		public void Command8_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Pt_XH == 2)
			{
				Timer9.Enabled = false;
				//Timer10.Enabled = False
				Text10[0].Text = "";
				//Text31(0).Text = ""
				//Text26(0).Text = ""
				//Text27(0).Text = ""
				Text10[0].Visible = true;
				//Text26(0).Visible = True
			}
			else if (Pt_XH == 3)
			{
				Text10[0].Text = "";
				//Text31(0).Text = ""
				//Text26(0).Text = ""
				//Text27(0).Text = ""
				Timer5.Enabled = false;
				//Timer22.Enabled = False
			}
			else if (Pt_XH == 1)
			{
				
			}
		}
		
		public void Frmbdzshz_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Frame4 = null;
			object Index = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Chinese == true)
			{
				this.Text = "铂电阻参数计算法检测";
				Label12[4].Text = "检测数据输入";
				Label12[1].Text = "检测数据计算";
				Frame1[0].Text = "第一温度点";
				Frame1[7].Text = "第二温度点";
				Frame1[8].Text = "第三温度点";
				Frame2[0].Text = "单支计算结果";
				Frame2[1].Text = "配对计算结果";
				
				
				Label1[0].Text = "标准温度";
				Label1[1].Text = "标准温度";
				Label1[2].Text = "标准温度";
				
				Label21[0].Text = "电阻值(Ω)";
				Label21[1].Text = "电阻值(Ω)";
				Label21[2].Text = "电阻值(Ω)";
				Label24[0].Text = "温度值(℃)";
				Label24[1].Text = "温度值(℃)";
				Label24[2].Text = "温度值(℃)";
				Label7[0].Text = "被检温度传感器";
				Label7[1].Text = "被检温度传感器";
				Label7[2].Text = "被检温度传感器";
				Label12[0].Text = "(以下输入铂电阻值Ω)";
				Label12[2].Text = "(以下输入铂电阻值Ω)";
				Label12[3].Text = "(以下输入铂电阻值Ω)";
				
				Text28.Text = "编号";
				Text45[0].Text = "进口";
				Text70[2].Text = "进口";
				Text70[4].Text = "进口";
				Text7.Text = "进口";
				Text9.Text = "进口";
				Text15.Text = "进口";
				Text33[0].Text = "进口";
				
				Text70[1].Text = "出口";
				Text70[3].Text = "出口";
				Text70[5].Text = "出口";
				Text8.Text = "出口";
				Text14.Text = "出口";
				Text16.Text = "出口";
				Text32[0].Text = "出口";
				
				Text27[0].Text = "误差";
				Text27[1].Text = "误差";
				Text27[2].Text = "误差";
				Text27[3].Text = "误差";
				Text27[4].Text = "误差";
				Text27[5].Text = "误差";
				Text34[0].Text = "误差(%)";
				
				Text1[1].Text = "第一温度点";
				Text2.Text = "第二温度点";
				Text6.Text = "第三温度点";
				Text37[0].Text = "最大误差点";
				
				wcx[0].Text = "误差限(℃)";
				wcx[1].Text = "误差限(℃)";
				wcx[2].Text = "误差限(℃)";
				
				Command1.Text = "参    数";
				SSCommand2.Text = "生成表格";
				SSCommand1.Text = "保存记录";
				cmdquit.Text = "退出系统";
				Labt.Text = "操作步骤：1、请首先进行参数设置；2、输入检定数据；3、生成表格；4、保存数据；5、退出。";
			}
			else
			{
				this.Text = "Temperature Sensors-Characteristic curve";
				Label12[4].Text = "Value input";
				Label12[1].Text = "Value Calculation";
				Frame1[0].Text = "Temp.point 1";
				Frame1[7].Text = "Temp.point 2";
				Frame1[8].Text = "Temp.point 3";
				Frame2[0].Text = "Results(single sensor)";
				Frame2[1].Text = "Results(pair)";
				
				Label1[0].Text = "Stand.temp.";
				Label1[1].Text = "Stand.temp.";
				Label1[2].Text = "Stand.temp.";
				
				Label21[0].Text = "Resis.Ω)";
				Label21[1].Text = "Resis.(Ω)";
				Label21[2].Text = "Resis.(Ω)";
				Label24[0].Text = "Temp.(℃)";
				Label24[1].Text = "Temp.(℃)";
				Label24[2].Text = "Temp.(℃)";
				Label7[0].Text = "Temp.Sensor";
				Label7[1].Text = "Temp.Sensor";
				Label7[2].Text = "Temp.Sensor";
				Label12[0].Text = "(Input resistance value Ω)";
				Label12[2].Text = "(Input resistance value Ω)";
				Label12[3].Text = "(Input resistance value Ω)";
				
				Text28.Text = "No.";
				Text45[0].Text = "Flow";
				Text70[2].Text = "Flow";
				Text70[4].Text = "Flow";
				Text7.Text = "Flow";
				Text9.Text = "Flow";
				Text15.Text = "Flow";
				Text33[0].Text = "Flow";
				
				Text70[1].Text = "Return";
				Text70[3].Text = "Return";
				Text70[5].Text = "Return";
				Text8.Text = "Retu.";
				Text14.Text = "Retu.";
				Text16.Text = "Retu.";
				Text32[0].Text = "Retu.";
				
				Text27[0].Text = "Δθ";
				Text27[1].Text = "Δθ";
				Text27[2].Text = "Δθ";
				Text27[3].Text = "Δθ";
				Text27[4].Text = "Δθ";
				Text27[5].Text = "Δθ";
				Text34[0].Text = "Δθ(%)";
				
				Text1[1].Text = "Temp.point 1";
				Text2.Text = "Temp.point 2";
				Text6.Text = "Temp.point 3";
				Text37[0].Text = "Temp.at max.error";
				wcx[0].Text = "MPE (℃)";
				wcx[1].Text = "MPE (℃)";
				wcx[2].Text = "MPE (℃)";
				
				
				Command1.Text = "Setup";
				SSCommand2.Text = "Report";
				SSCommand1.Text = "Save";
				cmdquit.Text = "Exit";
				Labt.Text = "Step：1、Setup 2、Data input 3、Report 4、Save 5、Exit";
			}
			
			
			//读被检铂电阻参数：
			
			Timer1.Enabled = false;
			
			Timer3.Enabled = false;
			
			Timer9.Enabled = false;
			
			Timer5.Enabled = false;
			Timer6.Enabled = false;
			Timer7.Enabled = false;
			
			//MSComm3.CommPort = Com4 '标温进口
			//MSComm3.RThreshold = 80
			MSComm6.CommPort = sub_Renamed.Com4; //标准出口
			MSComm6.RThreshold = (short) 80;
			
			
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
			//
			for ( = ;0; i <= 95); i++;);
			{
				Text26[sub_Renamed.i].Text = "";
				//        Text81(i).Visible = True
				//        Text82(i).Visible = True
			}
			//    Frame2(1).Width = 4095
			
			//读被检铂电阻参数：
			short n = 0;
			short int1;
			FileSystem.FileClose(1);
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\bjpt_canshu.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			
			
			FileSystem.Input(1, ref mi1[1]);
			FileSystem.Input(1, ref mi1[2]);
			FileSystem.Input(1, ref mi1[3]);
			// Frame2(1).Width = 2055
			
			
			//
			//'frmbdzcssz.Twcd.text = m0
			//Text3(0).Text = mi(1)
			//Text4(0).Text = mi(2)
			//Text5(0).Text = mi(3)
			//'Text30.Text = m4
			Text11[0].Text = (mi1[1]).ToString();
			Text12[0].Text = (mi1[2]).ToString();
			Text13[0].Text = (mi1[3]).ToString();
			
			FileSystem.FileClose(1);
			
			FileSystem.FileClose(23);
			Module1.sFileCanShu = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\pt_canshu.dll";
			FileSystem.FileOpen(23, Module1.sFileCanShu, OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			for (n = 1; n <= 7; n++)
			{
				FileSystem.Input(23, ref mi[n]);
			}
			FileSystem.FileClose(23);
			
			FileSystem.FileClose(11);
			FileSystem.FileOpen(11, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(11, ref Pt_XH);
			FileSystem.FileClose(11);
			
			
			
			//Dim i As Integer
			for ( = ;0; i <= 15); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 Index 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Index = sub_Renamed.i;
				Text44[Index].Text = "";
				Text55[Index].Text = "";
				Text56[Index].Text = "";
				Text57[Index].Text = "";
				Text58[Index].Text = "";
				Text59[Index].Text = "";
				Text60[Index].Text = "";
				Text17[Index].Text = "";
				Text18[Index].Text = "";
				Text19[Index].Text = "";
				Text20[Index].Text = "";
				Text21[Index].Text = "";
				Text22[Index].Text = "";
				Text23[Index].Text = "";
				Text24[Index].Text = "";
				Text25[Index].Text = "";
				
				//    Text80(Index).Text = ""
				//    Text81(Index).Text = ""
				//    Text82(Index).Text = ""
				
				Text17[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text18[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text19[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text20[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text21[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text22[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text23[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text24[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				Text25[Index].BackColor = System.Drawing.ColorTranslator.FromOle(0x8000000B);
				
				//    Text80(Index).BackColor = &HC0E0FF
				//    Text81(Index).BackColor = &HC0E0FF
				//    Text82(Index).BackColor = &HC0E0FF
				
				
				//    Text17(Index).Locked = True
				//    Text18(Index).Locked = True
				//    Text19(Index).Locked = True
				//    Text20(Index).Locked = True
				//    Text21(Index).Locked = True
				//    Text22(Index).Locked = True
				//    Text23(Index).Locked = True
				//    Text24(Index).Locked = True
				//    Text25(Index).Locked = True
				
				//    (Index).Locked = True
				//    Text81(Index).Locked = True
				//    Text82(Index).LoText80cked = True
				
				
				
				Text17[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text18[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text19[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text20[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text21[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text22[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text23[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text24[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				Text25[Index].TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
				
				//    Text80(Index).Alignment = 1
				//    Text81(Index).Alignment = 1
				//    Text82(Index).Alignment = 1
			}
			Text10[0].Text = "";
			Text10[1].Text = "";
			Text10[2].Text = "";
			Text31[0].Text = "";
			Text31[1].Text = "";
			Text31[2].Text = "";
			//    Text26(0).Text = ""
			//    Text26(1).Text = ""
			//    Text26(2).Text = ""
			//    Text27(0).Text = ""
			//    Text27(1).Text = ""
			//    Text27(2).Text = ""
			
			//    Text38(0).Text = "" '铂电阻计算输入框
			//    Text39(1).Text = ""
			//    Text39(2).Text = ""
			//    Text40(1).Text = ""
			//    Text40(2).Text = ""
			//    Text41(1).Text = ""
			//    Text41(2).Text = ""
			
			//UPGRADE_WARNING: 未能解析对象 Frame4.Visible 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			frame4.Visible = false;
			
			
			//    For i = 0 To 15
			//        Text80(i).Visible = False
			//        Text81(i).Visible = False
			//        Text82(i).Visible = False
			//    Next i
			
			
			
			//shuju(5).Text = Worke
			//shuju(6).Text = Worke
			
			
		}
		
		
		
		
		private void ptin_Click()
		{
			
		}
		
		public void Frmbdzshz_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			Timer1.Enabled = false;
			Timer3.Enabled = false;
			Timer9.Enabled = false;
			Timer5.Enabled = false;
			Timer6.Enabled = false;
			Timer7.Enabled = false;
			
			if (MSComm6.PortOpen == true)
			{
				MSComm6.PortOpen = false;
			}
		}
		
		//UPGRADE_ISSUE: Frame 事件 Frame3.DblClick 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="ABD9AF39-7E24-4AFF-AD8D-3675C1AA3054"”
		// VBConversions Note: Former VB static variables moved to class level because they aren't supported in C#.
		private bool Frame3_DblClick_sw = default(bool);
		
		private void Frame3_DblClick(short Index)
		{
			object Label5 = null;
			object Frame4 = null;
			// static bool sw = default(bool); VBConversions Note: Static variable moved to class level and renamed Frame3_DblClick_sw. Local static variables are not supported in C#.
			Frame3_DblClick_sw = !Frame3_DblClick_sw;
			if (Frame3_DblClick_sw == true)
			{
				//UPGRADE_WARNING: 未能解析对象 Frame4.Visible 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Frame4.Visible = true;
				//UPGRADE_WARNING: 未能解析对象 Label5.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				label5.Caption = "(双击关闭)";
				//        Text39(1).SetFocus
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 Frame4.Visible 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Frame4.Visible = false;
				//UPGRADE_WARNING: 未能解析对象 Label5.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Label5.Caption = "(双击数据输入)";
			}
		}
		
		
		
		private void Frame4_DblClick()
		{
			object Frame4 = null;
			//UPGRADE_WARNING: 未能解析对象 Frame4.Visible 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Frame4.Visible = false;
			
		}
		
		private void myfile_Click()
		{
			
		}
		
		
		
		private void reports_Click()
		{
			
		}
		
		private void savekey_Click()
		{
			//On Error Resume Next
			//Close #1
			//Dim m0, m4 As String, m1, m2, m3, m5, m6, m7 As Single
			//Open App.Path + "\pt_canshu.dll" For Output As #1
			//
			//m0 = frmbdzcssz.Twcd.text
			//m1 = Val(Text3(0).Text)
			//m2 = Val(Text4(0).Text)
			//m3 = Val(Text5(0).Text)
			//m4 = Text30.Text
			//m5 = Val(Text3(1).Text)
			//m6 = Val(Text4(1).Text)
			//m7 = Val(Text5(1).Text)
			//
			//Write #1, m0
			//Write #1, m1
			//Write #1, m2
			//Write #1, m3
			//Write #1, m4
			//Write #1, m5
			//Write #1, m6
			//Write #1, m7
			//
			//Close #1
			
		}
		
		public void SSCommand1_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			short jd = 0;
			
			sub_Renamed.yibiao_No = int.Parse("");
			sub_Renamed.yibiao_No = (int) (sub_Renamed.yibiao_No + double.Parse(Conversion.Str(Mdlguanfa.yibiaoNo)));
			sub_Renamed.save_execel();
			sub_Renamed.XlApp.Workbooks[1].SaveAs((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\report\\" + (sub_Renamed.yibiao_No).ToString().Trim() + ".xls", null, null, null, null, null, (Microsoft.Office.Interop.Excel.XlSaveAsAccessMode) 1, null, null, null, null, null);
			
			if (sub_Renamed.Chinese == true)
			{
				sub_Renamed.Title = "保存数据";
				msg = (short) (Interaction.MsgBox("请您确认输入项是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示"));
			}
			else
			{
				sub_Renamed.Title = "Save";
				msg = (short) (Interaction.MsgBox("Please confirm the saved data are correct？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "Note"));
			}
			switch (msg)
			{
				case (short) MsgBoxResult.Yes:
					sub_Renamed.StrSql = "select * from bdzdz ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					for (jd = 0; jd <= 15; jd++)
					{
						if (Strings.Len(this.Text44[jd].Text) == 0)
						{
							break;
						}
						sub_Renamed.RsZbs.AddNew(null, null);
						sub_Renamed.RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
						sub_Renamed.RsZbs.Fields[1].Value = this.Text44[jd].Text;
						sub_Renamed.RsZbs.Fields[2].Value = DateAndTime.Today;
						sub_Renamed.RsZbs.Fields[3].Value = frmbdzcssz.Default.shuju[8].Text;
						sub_Renamed.RsZbs.Update(null, null);
					}
					sub_Renamed.RsZbs.Close();
					
					//            MsgBox "保存完毕！保存路径\lib\jiliang.mdb jcjg", vbInformation, "保存完毕"
					//            MsgBox App.Path & "\report\" & Trim(yibiao_No) & ".xls"
					return;
				case (short) MsgBoxResult.No:
					
					return;
			}
		}
		
		public void SSCommand2_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.gain_fileNO();
			
			
			Module1.PrintCouple();
		}
		public void Text10_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text10.GetIndex(eventSender); //电阻_温度值转换（上一行）
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				//           If Val(Text10(Index).Text) <= 99 Or Val(Text10(Index).Text) > 140 Then
				//            MsgBox ("进口二等标准铂电阻输入电阻值超出范围！")
				//              Text10(Index).Text = ""
				//              Text31(Index).Text = ""
				//              Text10(Index).SetFocus
				//              Exit Sub
				//            End If
				//
				//
				//           r = Val(Text10(Index).Text)
				//           Call standom_t
				//           Text31(Index).Text = standom_t(Val(r))
				//           Text26(Index).SetFocus
				Index++;
				if (Index == 3)
				{
					Index = (short) 0;
				}
				Text10[Index].Focus();
				
				
				
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text10.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text10_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text10.GetIndex(eventSender);
			
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option1.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_Rpt = mi[1];
				//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_a8 = mi[2];
				//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_b8 = mi[3];
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text10[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 20 & sub_Renamed.pt_om <= 40)
				{
					pt_centgrade();
					Text31[Index].Text = Text31(sub_Renamed.centgrade, "0.000");
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text10[Index].Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 99 & sub_Renamed.pt_om <= 140)
				{
					Text31[Index].Text = Text31(standom_t((float) (Conversion.Val(Text10[Index].Text))), "0.000");
				}
			}
		}
		
		
		public void Text13_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text13.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//On Error Resume Next
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text17_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text17.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				Text26[Index].Text = Text26(System.Math.Abs(Conversion.Val(Text17[Index].Text) - System.Convert.ToDouble(Text31[0].Text)), "0.0");
				if (System.Math.Abs((System.Convert.ToDouble(Text17[Index].Text)) - Conversion.Val(Text31[0].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[0].Text)) //误差判断，超过误差显示为红色
				{
					Text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text18_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text18.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				Text26[Index + 16].Text = Text26(System.Math.Abs(Conversion.Val(Text18[Index].Text) - System.Convert.ToDouble(Text31[0].Text)), "0.0");
				if (System.Math.Abs((System.Convert.ToDouble(Text18[Index].Text)) - Conversion.Val(Text31[0].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[0].Text)) //误差判断，超过误差显示为红色
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text19_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text19.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				Text26[Index + 32].Text = Text26(System.Math.Abs(Conversion.Val(Text19[Index].Text) - System.Convert.ToDouble(Text31[1].Text)), "0.0");
				if (System.Math.Abs((System.Convert.ToDouble(Text19[Index].Text)) - Conversion.Val(Text31[1].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[1].Text)) //误差判断，超过误差显示为红色
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text20_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text20.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				Text26[Index + 48].Text = Text26(System.Math.Abs(Conversion.Val(Text20[Index].Text) - System.Convert.ToDouble(Text31[1].Text)), "0.0");
				if (System.Math.Abs((System.Convert.ToDouble(Text20[Index].Text)) - Conversion.Val(Text31[1].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[1].Text)) //误差判断，超过误差显示为红色
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text21_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text21.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				Text26[Index + 64].Text = Text26(System.Math.Abs(Conversion.Val(Text21[Index].Text) - System.Convert.ToDouble(Text31[2].Text)), "0.0");
				if (System.Math.Abs((System.Convert.ToDouble(Text21[Index].Text)) - Conversion.Val(Text31[2].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[2].Text)) //误差判断，超过误差显示为红色
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text22_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text22.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				Text26[Index + 80].Text = Text26(System.Math.Abs(Conversion.Val(Text22[Index].Text) - System.Convert.ToDouble(Text31[2].Text)), "0.0");
				if (System.Math.Abs((System.Convert.ToDouble(Text22[Index].Text)) - Conversion.Val(Text31[2].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[2].Text)) //误差判断，超过误差显示为红色
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text23_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text23.GetIndex(eventSender);
			KeyAscii = (short) 0;
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text24_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text24.GetIndex(eventSender);
			KeyAscii = (short) 0;
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text25_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text25.GetIndex(eventSender);
			KeyAscii = (short) 0;
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text26_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text26.GetIndex(eventSender); //电阻_温度值转换（下一行）
			//    If KeyAscii = 13 Then
			//           r = Val(Text26(Index).Text)
			//'           Call standom_t
			//           Text27(Index).Text = standom_t1(Val(r))
			//
			//           Index = Index + 1
			//           If Index = 3 Then Index = 0
			//           Text26(Index).SetFocus
			//    End If
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		
		public void Text11_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text11.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//On Error Resume Next
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			//    If KeyAscii = 13 Then Text12(Index).SetFocus
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text12_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text12.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			//    If KeyAscii = 13 Then Text13(Index).SetFocus
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text29_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text3_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text3.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text30_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		private void Text39_keypress(short Index, short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//    If KeyAscii = 13 Then
			//    Index = Index + 1
			//    If Index >= 3 Then
			//        Index = 1
			//        Text40(1).SetFocus
			//    Else
			//        Text39(Index).SetFocus
			//    End If
			//    End If
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text31.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text31_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text31.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Conversion.Val(Text31[Index].Text) > 0)
			{
				if (Index == 0)
				{
					
					Text1[0].Text = Text1(0.3 + 0.005 * Conversion.Val(Text31[0].Text), "0.00");
				}
				else if (Index == 1)
				{
					Text1[2].Text = Text1(0.3 + 0.005 * Conversion.Val(Text31[1].Text), "0.00");
					
					
				}
				else if (Index == 2)
				{
					Text1[3].Text = Text1(0.3 + 0.005 * Conversion.Val(Text31[2].Text), "0.00");
				}
			}
		}
		
		public void Text4_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text4.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		private void Text40_keypress(short Index, short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//    If KeyAscii = 13 Then
			//    Index = Index + 1
			//    If Index >= 3 Then
			//        Index = 1
			//        Text41(Index).SetFocus
			//    Else
			//        Text40(Index).SetFocus
			//    End If
			//    End If
		}
		private void Text41_keypress(short Index, short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//    If KeyAscii = 13 Then
			//    Index = Index + 1
			//    If Index >= 3 Then
			//        Index = 1
			//        Text39(Index).SetFocus
			//    Else
			//        Text41(Index).SetFocus
			//    End If
			//    End If
		}
		
		public void Text44_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text44.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			if (KeyAscii == 13)
			{
				Text55[Index].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		
		
		public void Text5_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text5.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//Else
			//    KeyAscii = 0
			//End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text55_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text55.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			double t = 0;
			if (KeyAscii == 13)
			{
				if (Conversion.Val(Text55[Index].Text) <= 995 || Conversion.Val(Text55[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text55[Index].Text = "";
					Text17[Index].Text = "";
					Text55[Index].Focus();
					goto EventExitSub;
				}
				
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //标称铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) (Conversion.Val(Text55[Index].Text) / Conversion.Val(Text11[0].Text));
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				Text17[Index].Text = (System.Math.Round(t, 2)).ToString();
				//               Jinkou1(Index) = Round(t, 4)
				Text26[Index].Text = Text26(System.Math.Abs(Conversion.Val(Text17[Index].Text) - System.Convert.ToDouble(Text31[0].Text)), "0.0");
				if (System.Math.Abs(t - Conversion.Val(Text31[0].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[0].Text)) //误差判断，超过误差显示为红色
				{
					Text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[1] = (short) 1;
				}
				else
				{
					Text17[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[1] = (short) 0;
				}
				Text56[Index].Focus();
				Index++;
				
				if (Index >= 16)
				{
					Index = (short) 0;
					
					Text44[Index].Focus();
				}
			}
			
			
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text56_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text56.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			double deltaCa1;
			double deltaCa2;
			if (KeyAscii == 13)
			{
				if (Conversion.Val(Text56[Index].Text) <= 995 || Conversion.Val(Text56[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text56[Index].Text = "";
					Text18[Index].Text = "";
					Text56[Index].Focus();
					goto EventExitSub;
				}
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text56[Index].Text)) / Conversion.Val(Text11[0].Text));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Chukou1[Index] = (float) (System.Math.Round(System.Convert.ToDouble(t), 2));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text18[Index].Text = (System.Math.Round(System.Convert.ToDouble(t), 2)).ToString();
				
				
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(System.Convert.ToDouble(t) - Conversion.Val(Text31[0].Text)) > (0.3 + 0.005 * Conversion.Val(Text31[0].Text))) //误差判断，超过误差显示为红色
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[2] = (short) 1;
				}
				else
				{
					Text18[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[2] = (short) 0;
				}
				Text26[Index + 16].Text = Text26(System.Math.Abs(Conversion.Val(Text18[Index].Text) - System.Convert.ToDouble(Text31[0].Text)), "0.0");
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text57[Index].Focus();
				}
				else
				{
					Text44[Index].Focus();
				}
				//        End If
				
			}
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text57_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text57.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			double t = 0;
			if (KeyAscii == 13)
			{
				if (Conversion.Val(Text57[Index].Text) <= 995 || Conversion.Val(Text57[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text57[Index].Text = "";
					Text19[Index].Text = "";
					Text57[Index].Focus();
					goto EventExitSub;
				}
				
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text57[Index].Text)) / Conversion.Val(Text11[0].Text));
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//      Jinkou2(Index) = Round(t, 2)
				Text19[Index].Text = (System.Math.Round(t, 2)).ToString();
				
				if (System.Math.Abs(t - Conversion.Val(Text31[1].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[1].Text)) //误差判断，超过误差显示为红色
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[3] = (short) 1;
				}
				else
				{
					Text19[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[3] = (short) 0;
				}
				Text26[Index + 32].Text = Text26(System.Math.Abs(Conversion.Val(Text19[Index].Text) - System.Convert.ToDouble(Text31[1].Text)), "0.0");
				//    If Option4.value = True Then     '单支测量显示绝对误差
				//     Text24(Index).Text = Round(Text19(Index).Text - Text31(1).Text, 2)
				//    End If
				
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text58[Index].Focus();
				}
				else
				{
					Text57[Index].Focus();
				}
			}
			
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text58_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text58.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			double deltaCa1;
			double deltaCa2;
			if (KeyAscii == 13)
			{
				if (Conversion.Val(Text58[Index].Text) <= 995 || Conversion.Val(Text58[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text58[Index].Text = "";
					Text20[Index].Text = "";
					Text58[Index].Focus();
					goto EventExitSub;
				}
				
				
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text58[Index].Text)) / Conversion.Val(Text11[0].Text));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Chukou2[Index] = (float) (System.Math.Round(System.Convert.ToDouble(t), 2));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text20[Index].Text = (System.Math.Round(System.Convert.ToDouble(t), 2)).ToString();
				
				//        If Option4 = True Then
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(System.Convert.ToDouble(t) - Conversion.Val(Text31[1].Text)) > 0.3 + 0.005 * Conversion.Val(Text31[1].Text)) //误差判断，超过误差显示为红色
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[4] = (short) 1;
				}
				else
				{
					Text20[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[4] = (short) 0;
				}
				
				//        End If
				Text26[Index + 48].Text = Text26(System.Math.Abs(Conversion.Val(Text20[Index].Text) - System.Convert.ToDouble(Text31[1].Text)), "0.0");
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text59[Index].Focus();
				}
				else
				{
					Text58[Index].Focus();
				}
				
			}
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text59_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text59.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			double t = 0;
			if (KeyAscii == 13)
			{
				if (Conversion.Val(Text59[Index].Text) <= 995 || Conversion.Val(Text59[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text59[Index].Text = "";
					Text21[Index].Text = "";
					Text59[Index].Focus();
					goto EventExitSub;
				}
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text59[Index].Text)) / Conversion.Val(Text11[0].Text));
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//      Jinkou3(Index) = Round(t, 2)
				jkAbc(ref Index);
				
				//
				Text21[Index].Text = (System.Math.Round(t, 2)).ToString();
				
				if (System.Math.Abs(t - Conversion.Val(Text31[2].Text)) > (0.3 + 0.005 * Conversion.Val(Text31[2].Text))) //误差判断，超过误差显示为红色
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[3] = (short) 1;
				}
				else
				{
					Text21[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[3] = (short) 0;
				}
				
				Text26[Index + 64].Text = Text26(System.Math.Abs(Conversion.Val(Text21[Index].Text) - System.Convert.ToDouble(Text31[2].Text)), "0.0");
				
				
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text60[Index].Focus();
				}
				else
				{
					Text59[Index].Focus();
				}
				
			}
			
			
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text60_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text60.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			double deltaCa1;
			double deltaCa2;
			object x1 = null;
			object x2 = null;
			object x3 = null;
			object x4 = null;
			object Tv = null;
			short tR = 0;
			object[] Wu = new object[101];
			object[] Wu1 = new object[101];
			object k = null;
			object Maxwu = null;
			object K1;
			object Maxwu1 = null;
			object j1;
			object j2;
			object j3;
			if (KeyAscii == 13)
			{
				
				if (Conversion.Val(Text60[Index].Text) <= 995 || Conversion.Val(Text60[Index].Text) > 1400)
				{
					MessageBox.Show("被检铂电阻输入值超出范围！");
					Text60[Index].Text = "";
					Text22[Index].Text = "";
					Text60[Index].Focus();
					goto EventExitSub;
				}
				//On Error Goto x_eorro VBConversions Warning: could not be converted to try/catch - logic too complex
				Mdlguanfa.Xb = (float) (Conversion.Val(Text12[0].Text) / Math.Pow(10, 3)); //铂电阻的一次项
				Mdlguanfa.Xa = (float) (Conversion.Val(Text13[0].Text) / Math.Pow(10, 7)); //铂电阻的二次顶
				Mdlguanfa.Xc = (float) ((System.Convert.ToDouble(Text60[Index].Text)) / Conversion.Val(Text11[0].Text));
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				t = (-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa);
				//         Chukou3(Index) = Round(t, 2)
				ckAbc(ref Index);
				
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text22[Index].Text = (System.Math.Round(System.Convert.ToDouble(t), 2)).ToString();
				//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(System.Convert.ToDouble(t) - Conversion.Val(Text31[2].Text)) > (0.3 + 0.005 * Conversion.Val(Text31[2].Text))) //误差判断，超过误差显示为红色
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					WuCha[3] = (short) 1;
				}
				else
				{
					Text22[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					WuCha[3] = (short) 0;
				}
				Text26[Index + 80].Text = Text26(System.Math.Abs(Conversion.Val(Text22[Index].Text) - System.Convert.ToDouble(Text31[2].Text)), "0.0");
				
				//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Tv = 95;
				//UPGRADE_WARNING: 未能解析对象 Maxwu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Maxwu = 0;
				//          tR = 76
				for (tR = 1; tR <= 92; tR++)
				{
					//UPGRADE_WARNING: 未能解析对象 j1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					j1 = Conversion.Val(Text11[0].Text);
					//UPGRADE_WARNING: 未能解析对象 j2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					j2 = Conversion.Val(Text12[0].Text);
					//UPGRADE_WARNING: 未能解析对象 j3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					j3 = Conversion.Val(Text13[0].Text);
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x1 = (jkChangR[Index] - ckChangR[Index]) / Conversion.Val(Text11[0].Text);
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x2 = System.Convert.ToInt32(System.Convert.ToDouble(Tv) * (jkChangA[Index] - Conversion.Val(Text12[0].Text)) - tR * (ckChangA[Index] - Conversion.Val(Text12[0].Text))) / 1000;
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x3 = (Math.Pow(Tv, 2) * (jkChangB[Index] - Conversion.Val(Text13[0].Text)) - Math.Pow(tR, 2) * (ckChangB[Index] - Conversion.Val(Text13[0].Text))) / 10000000;
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x4 = System.Convert.ToInt32(System.Convert.ToDouble(Conversion.Val(Text12[0].Text) * (System.Convert.ToInt32(Tv) - tR)) / 1000) + (Conversion.Val(Text13[0].Text) * (Math.Pow(Tv, 2) - Math.Pow(tR, 2))) / 10000000;
					//UPGRADE_WARNING: 未能解析对象 x4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Wu(tR) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Wu[tR] = Wu(System.Convert.ToDouble(System.Convert.ToInt32(System.Convert.ToDouble(x1) + System.Convert.ToDouble(x2) + System.Convert.ToDouble(x3)) / System.Convert.ToDouble(x4)) * 100, "0.00");
					//UPGRADE_WARNING: 未能解析对象 Maxwu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Wu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					if (System.Math.Abs(Wu[tR]) > Maxwu || System.Math.Abs(Wu[tR]) == Maxwu)
					{
						//UPGRADE_WARNING: 未能解析对象 Wu(tR) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 Maxwu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Maxwu = Wu[tR];
						//UPGRADE_WARNING: 未能解析对象 k 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						k = tR;
					}
					
				}
				//UPGRADE_WARNING: 未能解析对象 Maxwu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Maxwu1 = 0;
				for (Tv = 94; (int) Tv <= 4; Tv = (int) Tv + 1)
				{
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x1 = (jkChangR[Index] - ckChangR[Index]) / Conversion.Val(Text11[0].Text);
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x2 = System.Convert.ToInt32(System.Convert.ToDouble(Tv) * (jkChangA[Index] - Conversion.Val(Text12[0].Text)) - tR * (ckChangA[Index] - Conversion.Val(Text12[0].Text))) / 1000;
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x3 = (Math.Pow(Tv, 2) * (jkChangB[Index] - Conversion.Val(Text13[0].Text)) - Math.Pow(tR, 2) * (ckChangB[Index] - Conversion.Val(Text13[0].Text))) / 10000000;
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x4 = System.Convert.ToInt32(System.Convert.ToDouble(Conversion.Val(Text12[0].Text) * (System.Convert.ToInt32(Tv) - tR)) / 1000) + (Conversion.Val(Text13[0].Text) * (Math.Pow(Tv, 2) - Math.Pow(tR, 2))) / 10000000;
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Wu1(Tv) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Wu1[(int) Tv] = Wu1(System.Convert.ToDouble(System.Convert.ToInt32(System.Convert.ToDouble(x1) + System.Convert.ToDouble(x2) + System.Convert.ToDouble(x3)) / System.Convert.ToDouble(x4)) * 100, "0.00");
					//UPGRADE_WARNING: 未能解析对象 Maxwu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Wu1() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					if (System.Math.Abs(Wu1[(int) Tv]) > Maxwu1 || System.Math.Abs(Wu1[(int) Tv]) == Maxwu1)
					{
						//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 Wu1(Tv) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 Maxwu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Maxwu1 = Wu1[(int) Tv];
						//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 K1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						K1 = Tv;
					}
					
				}
				//UPGRADE_WARNING: 未能解析对象 Maxwu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Maxwu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(Maxwu1) >= System.Math.Abs(Maxwu))
				{
					//UPGRADE_WARNING: 未能解析对象 Maxwu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text23[Index].Text = () );Maxwu1;
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text24[Index].Text = () );Tv;
					//UPGRADE_WARNING: 未能解析对象 Tv 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text25[Index].Text = System.Convert.ToInt32(Tv) - 3;
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 Maxwu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text23[Index].Text = () );Maxwu;
					Text24[Index].Text = (95).ToString();
					//UPGRADE_WARNING: 未能解析对象 k 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text25[Index].Text = () );k;
					//
				}
				
				if (System.Math.Abs(Conversion.Val(Text23[Index].Text)) > (0.5 + 3 * Conversion.Val(frmbdzcssz.Default.Twcd.Text) / (Conversion.Val(Text24[Index].Text) - Conversion.Val(Text25[Index].Text))))
				{
					Text23[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					
				}
				else
				{
					Text23[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008);
					
				}
				
				
				
				Index++;
				if (Index >= 16)
				{
					Index = (short) 0;
					Text44[Index].Focus();
				}
				else
				{
					Text60[Index].Focus();
				}
				
			}
			goto quit;
x_eorro:
			MessageBox.Show("检查一下是否标准温度输入有误?");
quit:
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		private void user_Click()
		{
			object userForm = null;
			//UPGRADE_WARNING: 未能解析对象 userForm.Show 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			userForm.show();
		}
		
		private void Textbh_KeyPress(short KeyAscii)
		{
			object Textbh = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Qingling();
			string Strsql1 = "";
			if (KeyAscii == 13)
			{
				sub_Renamed.RsZbs = new ADODB.Recordset();
				//UPGRADE_WARNING: 未能解析对象 Textbh.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Strsql1 = "select * from dianzu where dianzu.bianhao=\'" + Strings.Trim(System.Convert.ToString(Textbh.text)) + "\' order by bianhao";
				sub_Renamed.RsZbs.Open(Strsql1, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				if (sub_Renamed.RsZbs.RecordCount != 0)
				{
					
					Text44[0].Text = () (sub_Renamed.RsZbs.Fields[0].Value));
					Text55[0].Text = () (sub_Renamed.RsZbs.Fields[1].Value));
					Text56[0].Text = () (sub_Renamed.RsZbs.Fields[2].Value));
					Text57[0].Text = () (sub_Renamed.RsZbs.Fields[3].Value));
					Text58[0].Text = () (sub_Renamed.RsZbs.Fields[4].Value));
					Text59[0].Text = () (sub_Renamed.RsZbs.Fields[5].Value));
					Text60[0].Text = () (sub_Renamed.RsZbs.Fields[6].Value));
					Text17[0].Text = () (sub_Renamed.RsZbs.Fields[7].Value));
					Text18[0].Text = () (sub_Renamed.RsZbs.Fields[8].Value));
					Text19[0].Text = () (sub_Renamed.RsZbs.Fields[9].Value));
					Text20[0].Text = () (sub_Renamed.RsZbs.Fields[10].Value));
					Text21[0].Text = () (sub_Renamed.RsZbs.Fields[11].Value));
					Text22[0].Text = () (sub_Renamed.RsZbs.Fields[12].Value));
					Text23[0].Text = () (sub_Renamed.RsZbs.Fields[13].Value));
					Text24[0].Text = () (sub_Renamed.RsZbs.Fields[14].Value));
					Text25[0].Text = () (sub_Renamed.RsZbs.Fields[15].Value));
					
				}
				sub_Renamed.RsZbs.Close();
				
			}
			
		}
		
		public void Qingling()
		{
			for ( = ;0; i <= 15); i++;);
			{
				
				Text44[sub_Renamed.i].Text = "";
				Text55[sub_Renamed.i].Text = "";
				Text56[sub_Renamed.i].Text = "";
				Text57[sub_Renamed.i].Text = "";
				Text58[sub_Renamed.i].Text = "";
				Text59[sub_Renamed.i].Text = "";
				Text60[sub_Renamed.i].Text = "";
				Text17[sub_Renamed.i].Text = "";
				Text18[sub_Renamed.i].Text = "";
				Text19[sub_Renamed.i].Text = "";
				Text20[sub_Renamed.i].Text = "";
				Text21[sub_Renamed.i].Text = "";
				Text22[sub_Renamed.i].Text = "";
				Text23[sub_Renamed.i].Text = "";
				Text24[sub_Renamed.i].Text = "";
				Text25[sub_Renamed.i].Text = "";
			}
		}
		
		public float standom_t(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[2] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[3] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[1];
			returnValue = (float) (System.Math.Round((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa), 4));
			return returnValue;
		}
		public float standom_t1(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[5] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[6] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[4];
			returnValue = (float) (System.Math.Round(System.Convert.ToDouble((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa)), 4));
			return returnValue;
		}
		
		private void pt_centgrade()
		{
			//以下是铂电阻计算程序：
			double[] d = new double[10];
			double wt = 0;
			double deltaW = 0;
			double wrt = 0;
			double pt;
			double r = 0;
			double t = 0;
			double a;
			double b;
			double a8 = 0;
			double b8 = 0;
			double rpt = 0;
			
			float t1;
			float t2;
			float t3;
			
			float[] pt1000 = new float[101];
			short i = 0;
			
			d[0] = 439.932854;
			d[1] = 472.41802;
			d[2] = 37.684494;
			d[3] = 7.472018;
			d[4] = 2.920828;
			d[5] = 0.005184;
			d[6] = -0.963864;
			d[7] = -0.188732;
			d[8] = 0.191203;
			d[9] = 0.049025;
			
			//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			r = System.Convert.ToDouble(sub_Renamed.pt_om);
			//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			a8 = System.Convert.ToDouble(sub_Renamed.pt_a8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b8 = System.Convert.ToDouble(sub_Renamed.pt_b8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			rpt = System.Convert.ToDouble(sub_Renamed.pt_Rpt);
			
			wt = r / rpt;
			deltaW = a8 * (wt - 1) + b8 * Math.Pow((wt - 1), 2);
			wrt = wt - deltaW;
			t = 0;
			for (i = 0; i <= 9; i++)
			{
				t = t + d[i] * Math.Pow(((wrt - 2.64) / 1.64), i); //t=d0*sum[di(Wr(t)-2.64)/1.64]^I;I:1 to 9
			}
			t1 = (float) t;
			sub_Renamed.centgrade = System.Math.Round(t, 4);
			
		}
		
		
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text10[1].Visible = false;
			MSComm6.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text10[1].Text = () );MSComm6.Input;
			if (Text10[1].Text == "")
			{
				Text31[1].Text = Text31[1].Text;
			}
			else
			{
				Text31[1].Text = Text31(Conversion.Val(Text10[1].Text), "0.000");
			}
		}
		
		public void Timer3_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text10[2].Visible = false;
			MSComm6.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text10[2].Text = () );MSComm6.Input;
			if (Text10[2].Text == "")
			{
				Text31[2].Text = Text31[2].Text;
			}
			else
			{
				Text31[2].Text = Text31(Conversion.Val(Text10[2].Text), "0.000");
			}
		}
		
		public void Timer5_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Data_in1 = null;
			object Kk1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = System.Convert.ToInt32(Kk1) + 1;
				sub_Renamed.delay_times(1);
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 2));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = MSComm6.Input;
			//
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text10[0].Text = () );Data_in1;
			
			//    Wendu_js1 = Wendu_js1 + 1
			//If Wendu_js1 < 15 Then
			//'   Text5.Text = Data_in1
			//ElseIf Wendu_js1 >= 15 And Wendu_js1 <= 30 Then
			//    If Wendu_js1 = 15 Then MsgBox "请在十秒钟内将出口铂电阻接入测试仪！"
			//    Text26(0).Text = Data_in1
			//
			//ElseIf Wendu_js1 > 30 Then
			//Timer5.Enabled = False
			//    Wendu_js1 = 0
			//End If
		}
		
		public void Timer6_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Data_in1 = null;
			object Kk1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = System.Convert.ToInt32(Kk1) + 1;
				sub_Renamed.delay_times(1);
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 2));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = MSComm6.Input;
			//
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text10[1].Text = () );Data_in1;
			
			//    Wendu_js1 = Wendu_js1 + 1
			//If Wendu_js1 < 15 Then
			//'   Text5.Text = Data_in1
			//ElseIf Wendu_js1 >= 15 And Wendu_js1 <= 30 Then
			//    If Wendu_js1 = 15 Then MsgBox "请在十秒钟内将出口铂电阻接入测试仪！"
			//    Text26(1).Text = Data_in1
			//
			//ElseIf Wendu_js1 > 30 Then
			//Timer6.Enabled = False
			//    Wendu_js1 = 0
			//End If
		}
		
		public void Timer7_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Data_in1 = null;
			object Kk1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			MSComm6.Output = "S";
			MSComm6.PortOpen = false;
			MSComm6.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = System.Convert.ToInt32(Kk1) + 1;
				sub_Renamed.delay_times(1);
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(MSComm6.InBufferCount >= 9 | Kk1 > 2));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm6.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = MSComm6.Input;
			//
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text10[2].Text = () );Data_in1;
			
			//    Wendu_js1 = Wendu_js1 + 1
			//If Wendu_js1 < 15 Then
			//'   Text5.Text = Data_in1
			//ElseIf Wendu_js1 >= 15 And Wendu_js1 <= 30 Then
			//    If Wendu_js1 = 15 Then MsgBox "请在十秒钟内将出口铂电阻接入测试仪！"
			//    Text26(2).Text = Data_in1
			//
			//ElseIf Wendu_js1 > 30 Then
			//Timer7.Enabled = False
			//    Wendu_js1 = 0
			//End If
		}
		
		public void Timer9_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text10[0].Visible = false;
			MSComm6.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm6.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text10[0].Text = () );MSComm6.Input;
			if (Text10[0].Text == "")
			{
				Text31[0].Text = Text31[0].Text;
			}
			else
			{
				Text31[0].Text = Text31(Conversion.Val(Text10[0].Text), "0.000");
			}
		}
	}
}
