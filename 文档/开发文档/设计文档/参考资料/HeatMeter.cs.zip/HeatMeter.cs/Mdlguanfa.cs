// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using System.Runtime.InteropServices;

namespace 热量表
{
	sealed class Mdlguanfa
	{
		
		public static float Xa;
		public static float Xb;
		public static float Xc;
		public static bool Sdzd;
		
		public static string[] Zs = new string[31]; //证书
		public static byte[] fs = new byte[7];
		public static byte[] Fx = new byte[11];
		public static string Read_data;
		public static short DJ;
		public static short Bpadd;
		
		//Public Plxz As Single
		public static short Dull;
		public static double Yanshi;
		public static bool Zhuan;
		
		public static bool SHEDU;
		
		
		public static bool Flagbz;
		public static float[] Wdxz1 = new float[21];
		public static float[] Wdxz2 = new float[21];
		public static float Wdxz3;
		public static float Wdxz4;
		public static float Wdxz5;
		public static float Wdxz6;
		public static bool FlagWdxz;
		public static int m_lngOPFlag;
		public static bool Flagbzwd;
		public static byte[] abytOrder = new byte[8];
		public static int lngReturn;
		public static string workdirectory; //当前工作目录
		public static int fileNo; //读取的初始配置文件---内部编号
		public static float Bbs;
		
		public static bool Comkou;
		
		//Public workdirectory As String '当前工作目录
		//Public fileNo As Long '读取的初始配置文件---内部编号
		//Public Declare Function QueryPerformanceCounter Lib "kernel32" ()
		//Public Declare Function QueryPerformanceFrequency Lib "kernel32" ()
		[DllImport("winmm.dll", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int timeSetEvent(int uDelay, int uResolution, int lpFunction, int dwUser, int uFlags);
		[DllImport("winmm.dll", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int timeKillEvent(int uID);
		[DllImport("kernel32", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int GetTickCount();
		
		
		
		//Public Declare Function GetTickCount Lib "kernel32" () As Long
		[DllImport("kernel32", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern void Sleep(int dwMilliseconds);
		public static int yibiaoNo; //被检表编号，内部编号
		
		public static float Qp;
		//阀门控制
		static public short Send_Data(short i)
		{
			short returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			fs[0] = (byte) 255;
			fs[1] = i;
			fs[2] = (byte) 0;
			fs[3] = (byte) 0;
			fs[4] = (byte) 254;
			returnValue = (short) (-1);
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			sub_Renamed.delay_times((0.5));F;);
			returnValue = (short) 0; //成功返回值0
			if (sub_Renamed.Frmdumoactive == true && i == 249)
			{
				frmdumo.Default.qd.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 250)
			{
				frmdumo.Default.tz.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				frmdumo.Default.qd.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 251)
			{
				frmdumo.Default.Command3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 252)
			{
				frmdumo.Default.Command5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				frmdumo.Default.Command3.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			return returnValue;
		}
		
		static public short Send_DataSl(short i)
		{
			short returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			fs[0] = (byte) 255;
			fs[1] = i;
			fs[2] = (byte) 0;
			fs[3] = (byte) 0;
			fs[4] = (byte) 254;
			returnValue = (short) (-1);
			
			//发送
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			sub_Renamed.delay_times((0.2));F;);
			returnValue = (short) 0; //成功返回值0
			
			// If comm.MSComm1.PortOpen = True Then comm.MSComm1.PortOpen = False
			return returnValue;
		}
		
		static public void OpenPort1()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
		}
		
		static public void OpenPort3()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//    If comm.MSComm3.PortOpen = False Then
			//        comm.MSComm3.PortOpen = True
			//    End If
		}
		
		
		static public short Zhu_Kai(ref short i)
		{
			short returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			if (i == 1)
			{
				Send_Data((short) 225); //进水
			}
			else if (i == 2)
			{
				Send_Data((short) 227); //小流量
			}
			else if (i == 3)
			{
				Send_Data((short) 229); //中流量1
			}
			else if (i == 4)
			{
				Send_Data((short) 231); //中流量2
			}
			else if (i == 5)
			{
				Send_Data((short) 233); //中流量3
			}
			else if (i == 6)
			{
				Send_Data((short) 235); //大流量
			}
			else if (i == 7)
			{
				Send_Data((short) 237); //放水阀
			}
			else if (i == 8)
			{
				Send_Data((short) 239); //打压阀
			}
			
			
			
			
			if (sub_Renamed.Form1active == true)
			{
				Form1.Default.Siajin[i].Value = true; //开关状态
				Form1.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xC000); //汉字提示
				Form1.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC000); //标志
			}
			else if (sub_Renamed.BZForm1active == true)
			{
				BZForm1.Default.Siajin[i].Value = true; //开关状态
				BZForm1.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xC000); //汉字提示
				BZForm1.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC000); //标志
			}
			else if (sub_Renamed.Zongtiactive == true)
			{
				FrmZongti.Default.Siajin[i].Value = true; //开关状态
				FrmZongti.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xC000); //汉字提示
				FrmZongti.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC000); //标志
			}
			else if (sub_Renamed.BZZJactive == true)
			{
				BZZJ.Default.Siajin[i].Value = true; //开关状态
				BZZJ.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xC000); //汉字提示
				BZZJ.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC000); //标志
			}
			else if (sub_Renamed.BiaoDingactive == true)
			{
				.value[i].value = true; //开关状态
				frmbiaoding.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xC000); //汉字提示
				frmbiaoding.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC000); //标志
			}
			else if (sub_Renamed.FmrBzbactive == true)
			{
				.value[i].value = true; //开关状态
				fmrbzb1.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xC000); //汉字提示
				fmrbzb1.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC000); //标志
			}
			else if (sub_Renamed.Frmxsactive == true)
			{
				Frmxs.Default.Siajin[i].Value = true; //开关状态
				Frmxs.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xC000); //汉字提示
				Frmxs.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC000); //标志
			}
			
			if (sub_Renamed.Frmdumoactive == true && i == 3)
			{
				frmdumo.Default.CommandX.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 1)
			{
				frmdumo.Default.CommandZ.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 7)
			{
				frmdumo.Default.Command7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 8)
			{
				if (double.Parse(frmdumo.Default.Text1.Text) == 1)
				{
					frmdumo.Default.Command1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				}
			}
			if (sub_Renamed.Frmdumoactive == true && i == 8)
			{
				if (double.Parse(frmdumo.Default.Text1.Text) == 2)
				{
					frmdumo.Default.CommandZ2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
					frmdumo.Default.Command2.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
				}
			}
			
			returnValue = (short) 0;
			
			return returnValue;
		}
		static public short Zhu_Guan(ref short i)
		{
			short returnValue = 0;
			
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (i == 1)
			{
				Send_Data((short) 224); //进水阀
			}
			else if (i == 2)
			{
				Send_Data((short) 226); //小流量
			}
			else if (i == 3)
			{
				Send_Data((short) 228); //中流量1
			}
			else if (i == 4)
			{
				Send_Data((short) 230); //中流量2
			}
			else if (i == 5)
			{
				Send_Data((short) 232); //中流量3
			}
			else if (i == 6)
			{
				Send_Data((short) 234); //大流量
			}
			else if (i == 7)
			{
				Send_Data((short) 236); //放水阀
			}
			else if (i == 8)
			{
				Send_Data((short) 238); //打压阀
			}
			if (sub_Renamed.Form1active == true)
			{
				.value[i].value = false; //开关状态
				Form1.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
				Form1.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
			}
			else if (sub_Renamed.BZForm1active == true)
			{
				BZForm1.Default.Siajin[i].Value = false; //开关状态
				BZForm1.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
				BZForm1.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			else if (sub_Renamed.Zongtiactive == true)
			{
				FrmZongti.Default.Siajin[i].Value = false; //开关状态
				FrmZongti.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
				FrmZongti.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			else if (sub_Renamed.BZZJactive == true)
			{
				.value[i].value = false; //开关状态
				BZZJ.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
				BZZJ.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			else if (sub_Renamed.BiaoDingactive == true)
			{
				frmbiaoding.Default.Siajin[i].Value = false; //开关状态
				frmbiaoding.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
				frmbiaoding.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			else if (sub_Renamed.FmrBzbactive == true)
			{
				.value[i].value = false; //开关状态
				fmrbzb1.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
				fmrbzb1.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			else if (sub_Renamed.Frmxsactive == true)
			{
				.value[i].value = false; //开关状态
				Frmxs.Default.Lab[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //
				Frmxs.Default.Shapzsd[i].BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			
			if (sub_Renamed.Frmdumoactive == true && i == 3)
			{
				frmdumo.Default.Commandxg.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				frmdumo.Default.CommandX.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 1)
			{
				frmdumo.Default.CommandZg.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				frmdumo.Default.CommandZ.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			if (sub_Renamed.Frmdumoactive == true && i == 8)
			{
				frmdumo.Default.Command2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				frmdumo.Default.Command1.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF);
			}
			returnValue = (short) 0;
			
			return returnValue;
		}
	}
}
