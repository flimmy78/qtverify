// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic.CompilerServices;

//UPGRADE_NOTE: sub 已升级到 sub_Renamed。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"”
namespace 热量表
{
	sealed class sub_Renamed
	{
		public const string DEFSOURCE = "Provider = MSDASQL.1;Persist Security Info=False;Data Source=deluku ";
		public static ADODB.Connection db;
		public static dao.Database dbK;
		//UPGRADE_WARNING: 结构 rssK 中的数组可能需要先初始化才可以使用。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"”
		public static dao.Recordset rssK;
		//UPGRADE_WARNING: 结构 rsK 中的数组可能需要先初始化才可以使用。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"”
		public static dao.Recordset rsK;
		public static string StrSql;
		public static ADODB.Recordset RsZbs;
		//自动采集模块
		public static delu0.delu tx = new delu0.delu();
		public static string cmd_type;
		public static string addr_meter;
		public static bool Rechen; //计算误差
		public static bool RechenLC; //计算误差
		public static bool Erstpunkt;
		public static bool Readone;
		public static bool Uzerror;
		public static string Txd;
		
		public static short Tpcj1;
		public static int m_lngAddress;
		public static ADODB.Connection DbMima;
		[DllImport("C:\\WINDOWS\\SYSTEM\\DSStream.dll", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern object DSStream_RouteInPinToOutPin(short iCardID, short idInPin, short idOutPin);
		[DllImport("C:\\WINDOWS\\SYSTEM\\DSStream.dll", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern object DSStream_INITIALIZE();
		public static Microsoft.Office.Interop.Excel.Application objexl;
		public static Microsoft.Office.Interop.Excel.Workbook objwork;
		public static Microsoft.Office.Interop.Excel.Worksheet objsheet;
		public static Microsoft.Office.Interop.Excel.Application XlApp;
		public static Microsoft.Office.Interop.Excel.Workbook Xlbook;
		public static Microsoft.Office.Interop.Excel.Worksheet Xlsheet;
		
		public static float[] Jsyq = new float[9];
		public static float[] JsyqV = new float[9];
		public static float[] JsyqE = new float[9];
		public static bool Denglu;
		public static bool Admins; //登录时设置管理员
		public static float[] ZlChuzhi = new float[21];
		public static float[] ZlZhongzhi = new float[21];
		public static float[] ZlShizhi = new float[21];
		public static float[] Jdtiaojie = new float[21];
		public static float[] lLChuzhi = new float[21];
		public static float[] llZhongzhi = new float[21];
		public static float[] LlShizhi = new float[21];
		public static float[] Biaozhunzhi = new float[21];
		public static float[] BiaozhunzhiE = new float[21];
		
		public static short Llxuanze;
		public static short JsslD;
		public static float[] LjslD = new float[11];
		public static float ZongslD;
		public static short JsslZ;
		public static float[] LjslZ = new float[11];
		public static float ZongslZ;
		public static short JsslX;
		public static float[] LjslX = new float[11];
		public static float ZongslX;
		
		public static string dSjdw;
		
		public static string dZzdw;
		public static float dXll;
		public static float dZll;
		public static float dDll;
		public static short dWdsj;
		public static short dDdsj;
		public static short dBjbs;
		public static string[] dSjbh = new string[11];
		public static float[] Cz = new float[11];
		public static float[] Mz = new float[11];
		public static float[] Jsqbdzll = new float[11];
		public static float xs1;
		public static float xs2;
		public static float xs3;
		public static short Jd_point;
		public static short Jd_number;
		public static short[] Jd_biaowei = new short[25]; //用于计算表位号是否有表。
		public static short End_biaowei; //用于标识最后一个安装表的表位号
		public static short Jd_meter;
		public static float[] Jd_flow = new float[11];
		public static float[] Jd_liang = new float[11];
		public static float[] Jd_wc = new float[21];
		public static object pt_a8;
		public static object pt_om;
		public static object pt_Rpt;
		public static object pt_b8;
		public static double centgrade; //用于标准铂电阻_温度值转换计算
		
		public static float SicherQ; //用于误差限的保险比例
		public static float SicherE;
		public static string TP;
		public static bool Bizerba;
		public static bool Satorius;
		public static bool Mettler;
		
		public static Microsoft.Office.Interop.Excel.Application objExcel; //表格
		public static float[] Zlwendu = new float[21];
		public static float[] ZlMiDu = new float[21];
		public static float Zlm0;
		public static float Zlm1;
		
		public static string Biaobianhao;
		public static string Biaobianhao9;
		public static short wdsj;
		public static short ddsj;
		//Public Csh1 As String
		//Public Csh2 As String
		//Public Csh3 As String
		//Public Csh4 As String
		//Public Csh5 As String
		//Public Csh6 As String
		//Public Csh7 As String
		//Public Csh8 As String
		//Public Csh9 As String
		//Public Csh10 As String
		//Public Csh11 As String
		//Public Csh12 As String
		//Public Csh13 As String
		public static bool Dbjb;
		public static bool Jdks2; //用于重复检定时在参数设置中不将排气激活
		public static bool Jdks1;
		public static bool Jdks;
		public static bool Jbqschutz;
		public static bool Flagnext;
		public static bool Pqschutz;
		public static bool Comopen;
		
		//极差系数
		public const double dn2 = 1.13;
		public const double dn3 = 1.69;
		public const double dn4 = 2.06;
		public const double dn5 = 2.33;
		public const double dn6 = 2.53;
		public const double dn7 = 2.7;
		public const double dn8 = 2.85;
		public const double dn9 = 2.97;
		public const double dn10 = 3.08;
		
		public static int jsjs;
		public static float[] zl = new float[90001];
		public static float jkwd;
		public static float ckwd;
		public static int wdjs;
		public static float[] wdcz = new float[90001];
		public static float[] wdzz = new float[90001];
		public static float inlet;
		public static float outlet;
		public static float zeit;
		public static float Njkwd;
		public static float Nckwd;
		public static int Nwdjs;
		public static float[] Nwdcz = new float[90001];
		public static float[] Nwdzz = new float[90001];
		public static float Ninlet;
		public static float Noutlet;
		public static float[] Lsjs = new float[11];
		public static float Leiji;
		
		public static short MID1; //标准表参数设置用
		public static short MID2;
		public static short MID3;
		public static short MID4;
		public static short MID5;
		public static short MID6;
		public static bool Form1active;
		public static bool BZForm1active;
		public static bool Zongtiactive;
		public static bool BZZJactive;
		public static bool BiaoDingactive;
		public static bool FmrBzbactive;
		public static bool Frmxsactive;
		public static bool Frmdumoactive;
		
		public static short Com1;
		public static short Com2;
		public static short Com3;
		public static short Com4;
		public static short Com5;
		public static short Com6;
		public static short Com7;
		public static short Com8;
		public static short Com9;
		public static short Com10;
		public static short Com11;
		public static short Com12;
		public static short Com13;
		public static short Com14;
		public static short Com15;
		public static short Com16;
		public static short Com17;
		public static object YF12;
		public static object XF12;
		public static object XF11;
		public static object YF11;
		public static object XF1;
		public static float YF1;
		public static object YF22;
		public static object XF22;
		public static object XF21;
		public static object YF21;
		public static object XF2;
		public static float YF2;
		public static object YF32;
		public static object XF32;
		public static object XF31;
		public static object YF31;
		public static object XF3;
		public static float YF3;
		public static object YF42;
		public static object XF42;
		public static object XF41;
		public static object YF41;
		public static object XF4;
		public static float YF4;
		public static object YF52;
		public static object XF52;
		public static object XF51;
		public static object YF51;
		public static object XF5;
		public static float YF5;
		public static object YF62;
		public static object XF62;
		public static object XF61;
		public static object YF61;
		public static object XF6;
		public static float YF6;
		public static object ZF4;
		public static object ZF2;
		public static object ZF1;
		public static object ZF3;
		public static object ZF5;
		public static short ZF6;
		
		public static string sqlStr;
		public static string Worker;
		public static string DBNAME;
		public static string Worke;
		public static string PassGonghao;
		public static string PassMima;
		public static string Title;
		public static short i;
		public static bool FlagBiaoshuju;
		
		public static int yibiao_No;
		
		public static string ZhizaoDanwei;
		public static string XingHao;
		public static string GuiGe;
		public static string YouXiaoQi;
		public static string JianCeYuan;
		public static string SongjianDanwei;
		public static string Jibie;
		public static bool Flagjiance;
		
		public static short TPBand;
		public static string TPVerify;
		public static short TPStop;
		public static short TPData;
		public static float[,] Llfaktor = new float[7, 25];
		public static short[,] Fdfaktor = new short[7, 25];
		public static float[,] Edfaktor = new float[7, 16];
		public static float[,] LlfaktorYS = new float[7, 25];
		public static short[,] FdfaktorYS = new short[7, 25];
		public static float[,] EdfaktorYS = new float[7, 16];
		
		
		
		public static float[,] Teminlet = new float[7, 25];
		public static float[,] Temoutlet = new float[7, 25];
		public static float[] TemVor = new float[13];
		public static float[] TemRuc = new float[13];
		
		public static float[] Ks1 = new float[13]; //xiao
		public static float[] Lld1 = new float[13];
		public static float[] Ks2 = new float[13]; //zhong
		public static float[] Lld2 = new float[13];
		public static float[] Ks3 = new float[13]; //da
		public static float[] Lld3 = new float[13];
		public static float[] Ks4 = new float[13]; //da
		public static float[] Lld4 = new float[13];
		
		public static float Qmax1;
		public static float Qmax2;
		public static float Qmax3;
		public static float Vk1;
		public static float Vk2;
		public static float Vk3;
		public static float Md1;
		public static float Md2;
		public static float Md3;
		public static float Ld1; //4mA输出底量
		public static float Ld2;
		public static float Ld3;
		public static float Ld4; //检表管路
		public static float Ld5; //检表数量型式
		public static float Ld6; //调节阀数量
		public static float[] LLQmax = new float[7]; //检测阀门流量点
		
		
		public static short Stueck;
		public static short Stueck15;
		public static short Stueck20;
		public static short Stueck25;
		public static short Stueck32;
		public static short Stueck40;
		public static short Stueck50;
		public static bool Flagcom;
		public static bool Chinese;
		public static bool Tem;
		public static short Firstmal; //用于记录表位后误差的显示
		public static short iTimeOut;
		public static string[] Meter_Type0;
		//极差系数选择FUNCTION
		public static float range_factor(short x)
		{
			float returnValue = 0;
			float y = 0;
			switch (x)
			{
				case (short) 2:
					y = (float) dn2;
					break;
				case (short) 3:
					y = (float) dn3;
					break;
				case (short) 4:
					y = (float) dn4;
					break;
				case (short) 5:
					y = (float) dn5;
					break;
				case (short) 6:
					y = (float) dn6;
					break;
				case (short) 7:
					y = (float) dn7;
					break;
				case (short) 8:
					y = (float) dn8;
					break;
				case (short) 9:
					y = (float) dn9;
					break;
				case (short) 10:
					y = (float) dn10;
					break;
			}
			returnValue = y;
			return returnValue;
		}
		public static void gain_fileNO()
		{
			object FileNum;
			//Set objExcel = New excel.Application
			try
			{
				FileSystem.FileClose(12);
				FileSystem.FileOpen(12, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\fileNo.ini", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
				
				FileSystem.Input(12, ref Mdlguanfa.fileNo);
				
				FileSystem.FileClose(12);
				Mdlguanfa.yibiaoNo = Mdlguanfa.fileNo + 1;
			}
			catch
			{
				MessageBox.Show("打开文件错误，请检查运行目录下面fileNo.ini文件！");
				
				
				
			}
			
		}
		public static void save_execel()
		{
			object FileNum;
			//Set objExcel = New excel.Application
			try
			{
				//   filenum = FreeFile 'Freefile()函数是获得一个未被使用的文件号
				//   Open workdirectory & "\fileNo.ini" For Input As filenum
				//   Input #filenum, fileNo
				//   Close #filenum
				//   Debug.Print "fileNo="; fileNo
				//   yibiaoNo = fileNo + 1
				// Exit Sub
				
				
				
				FileSystem.FileClose(12);
				FileSystem.FileOpen(12, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\fileNo.ini", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
				
				FileSystem.WriteLine(12, Mdlguanfa.yibiaoNo);
				
				FileSystem.FileClose(12);
			}
			catch
			{
				MessageBox.Show("打开文件错误，请检查运行目录下面fileNo.ini文件！");
				
				
				
			}
			
		}
		public static void delay_times(float pause)
		{
			object x = null;
			//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			x = VB.DateAndTime.Timer;
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(VB.DateAndTime.Timer- x > pause));
		}
		
		//UPGRADE_WARNING: 应用程序将在 Sub Main() 结束时终止。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="E08DDC71-66BA-424F-A612-80AF11498FF8"”
		public static void Main()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			string sAtt = "";
			string sDriver = "";
			sAtt = "DBQ=" + (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\LIB\\jiliang.mdb";
			sDriver = "Microsoft Access Driver (*.mdb)";
			UpgradeSupport.DAODBEngine_definst.RegisterDatabase("deluku", sDriver, true, sAtt);
			db = new ADODB.Connection();
			db.Open(DEFSOURCE, "", "", -1);
			Worke = "aaa";
			//UPGRADE_ISSUE: App 属性 App.PrevInstance 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="076C26E5-B7A9-4E77-B69C-B4448DF39E58"”
			if ())
			{
				MessageBox.Show("程序已经被运行了！");
				ProjectData.EndApp();
			}
			FileSystem.FileClose(1);
			
			Admins = false;
			
			frmdenglu.Default.Show();
			
			
			
			
			FileSystem.FileClose(2);
			FileSystem.FileOpen(2, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Biaohao.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(2, ref Biaobianhao);
			
			FileSystem.FileClose(2);
			FileSystem.FileClose(21);
			FileSystem.FileOpen(21, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Biaohaon.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(21, ref Biaobianhao9);
			FileSystem.FileClose(21);
			
			FileSystem.FileClose(10);
			FileSystem.FileOpen(10, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\COM_canshu.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(10, ref Com1);
			FileSystem.Input(10, ref Com2);
			FileSystem.Input(10, ref Com3);
			FileSystem.Input(10, ref Com4);
			FileSystem.Input(10, ref Com5);
			FileSystem.Input(10, ref Com6);
			FileSystem.Input(10, ref Com7);
			FileSystem.Input(10, ref Com8);
			FileSystem.Input(10, ref Com9);
			FileSystem.Input(10, ref Com10);
			FileSystem.Input(10, ref Com11);
			FileSystem.Input(10, ref Com12);
			FileSystem.Input(10, ref Com13);
			FileSystem.Input(10, ref Com14);
			FileSystem.Input(10, ref Com15);
			FileSystem.Input(10, ref Com16);
			
			FileSystem.FileClose(10);
			
			FileSystem.FileClose(3);
			FileSystem.FileOpen(3, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\TPCOM.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(3, ref TPBand);
			FileSystem.Input(3, ref TPVerify);
			FileSystem.Input(3, ref TPData);
			FileSystem.Input(3, ref TPStop);
			FileSystem.Input(3, ref TP);
			FileSystem.FileClose(3);
			
			StrSql = "select * from Adminis ";
			RsZbs = new ADODB.Recordset();
			RsZbs.Open(StrSql, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			RsZbs.MoveFirst();
			
			Ld1 = System.Convert.ToSingle(RsZbs.Fields["XiaoDiliang"].Value);
			Ld2 = System.Convert.ToSingle(RsZbs.Fields["ZhongDiliang"].Value);
			Ld3 = System.Convert.ToSingle(RsZbs.Fields["DaDiliang"].Value);
			MID1 = System.Convert.ToInt16(RsZbs.Fields["BZBshuliang"].Value);
			MID2 = System.Convert.ToInt16(RsZbs.Fields["BZBfangfa"].Value);
			MID3 = System.Convert.ToInt16(RsZbs.Fields["DaBZB"].Value);
			MID4 = System.Convert.ToInt16(RsZbs.Fields["ZhongBZB"].Value);
			MID5 = System.Convert.ToInt16(RsZbs.Fields["XiaoBZB"].Value);
			MID6 = System.Convert.ToInt16(RsZbs.Fields["TPshuliang"].Value);
			Ld4 = System.Convert.ToSingle(RsZbs.Fields["Leitung"].Value);
			Ld5 = System.Convert.ToSingle(RsZbs.Fields["Bshuliang"].Value);
			Ld6 = System.Convert.ToSingle(RsZbs.Fields["TFshuliang"].Value);
			RsZbs.Close();
			
			
			//标准表系数和脉冲当量
			StrSql = "select * from bzbbd ";
			RsZbs = new ADODB.Recordset();
			RsZbs.Open(StrSql, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			RsZbs.MoveFirst();
			for (i = 0; i <= 10; i++)
			{
				Lld1[i] = System.Convert.ToSingle(RsZbs.Fields[i].Value);
				Ks1[i] = System.Convert.ToSingle(RsZbs.Fields[i + 11].Value);
			}
			Qmax1 = System.Convert.ToSingle(RsZbs.Fields[22].Value);
			Vk1 = System.Convert.ToSingle(RsZbs.Fields[23].Value);
			Md1 = System.Convert.ToSingle(RsZbs.Fields[24].Value);
			RsZbs.Close();
			
			StrSql = "select * from bzbbd1 ";
			RsZbs = new ADODB.Recordset();
			RsZbs.Open(StrSql, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			RsZbs.MoveFirst();
			for (i = 0; i <= 10; i++)
			{
				Lld2[i] = System.Convert.ToSingle(RsZbs.Fields[i].Value);
				Ks2[i] = System.Convert.ToSingle(RsZbs.Fields[i + 11].Value);
			}
			Qmax2 = System.Convert.ToSingle(RsZbs.Fields[22].Value);
			Vk2 = System.Convert.ToSingle(RsZbs.Fields[23].Value);
			Md2 = System.Convert.ToSingle(RsZbs.Fields[24].Value);
			RsZbs.Close();
			
			
			StrSql = "select * from bzbbd2 ";
			RsZbs = new ADODB.Recordset();
			RsZbs.Open(StrSql, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			RsZbs.MoveFirst();
			for (i = 0; i <= 10; i++)
			{
				Lld3[i] = System.Convert.ToSingle(RsZbs.Fields[i].Value);
				Ks3[i] = System.Convert.ToSingle(RsZbs.Fields[i + 11].Value);
			}
			Qmax3 = System.Convert.ToSingle(RsZbs.Fields[22].Value);
			Vk3 = System.Convert.ToSingle(RsZbs.Fields[23].Value);
			Md3 = System.Convert.ToSingle(RsZbs.Fields[24].Value);
			RsZbs.Close();
			
			
			object gsmc = null;
			string gs;
			object shuliang;
			short shux;
			short ix = 0;
			FileSystem.FileClose(10);
			FileSystem.FileOpen(10, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Delujiliang.ini", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(10, ref gsmc);
			FileSystem.Input(10, ref gsmc);
			//UPGRADE_WARNING: 未能解析对象 gsmc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			ix = (short) (gsmc.ToString().IndexOf("数量=") + 1);
			//    If ix = 0 Then MsgBox "文件丢失": Close #10: End
			//UPGRADE_WARNING: 未能解析对象 gsmc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			ix = short.Parse(Strings.Mid(System.Convert.ToString(gsmc), ix + 3, Strings.Len(gsmc)));
			Meter_Type0 = new string[ix + 1];
			FileSystem.Input(10, ref gsmc);
			for (i = 1; i <= ix; i++)
			{
				FileSystem.Input(10, ref gsmc);
				//UPGRADE_WARNING: 未能解析对象 gsmc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				gsmc = Strings.Mid(System.Convert.ToString(gsmc), 5);
				//        If Trim(gsmc) = "" Then MsgBox "文件错误": Close #10: End
				//UPGRADE_WARNING: 未能解析对象 gsmc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Meter_Type0[i] = Strings.Trim(System.Convert.ToString(gsmc));
				
			}
			FileSystem.FileClose(10);
			
			
			FileSystem.FileClose(13);
			FileSystem.FileOpen(13, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Stueckzall.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			
			FileSystem.Input(13, ref Stueck15);
			FileSystem.Input(13, ref Stueck20);
			FileSystem.Input(13, ref Stueck25);
			FileSystem.Input(13, ref Stueck32);
			FileSystem.Input(13, ref Stueck40);
			FileSystem.Input(13, ref Stueck50);
			FileSystem.FileClose(13);
			
			//     Close #13
			//        Dim j As Integer
			//    Open App.Path + "\zhengshu_canshu.dll" For Input As #13
			//    For j = 0 To 22
			//    Input #13, Zs(j)
			//    Next j
			//    Close #13
			Module1.The_value_count = (short) 2000;
			
			comm.Default.MSComm1.CommPort = Com1;
			Mdlguanfa.Sdzd = false;
			Form1active = false;
			BZForm1active = false;
			Zongtiactive = false;
			BZZJactive = false;
			BiaoDingactive = false;
			FmrBzbactive = false;
			Frmxsactive = false;
			Frmdumoactive = false;
			Chinese = true;
			
			Satorius = false;
			Bizerba = false;
			Mettler = false;
			if (TP == "Bizerba")
			{
				Bizerba = true;
			}
			if (TP == "Satorius")
			{
				Satorius = true;
			}
			if (TP == "Mettler")
			{
				Mettler = true;
			}
			
			//UPGRADE_WARNING: Dir 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			dao.Workspace WS = default(dao.Workspace);
			dao.Database DB1 = default(dao.Database);
			dao.TableDef TD = default(dao.TableDef);
			dao.Field FLD = default(dao.Field);
			dao.Index IDX;
			dao.Workspace WS2 = default(dao.Workspace);
			dao.Database DB2 = default(dao.Database);
			string pwd;
			short num = 0;
			//UPGRADE_WARNING: 结构 rd2 中的数组可能需要先初始化才可以使用。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"”
			dao.Recordset rd2 = default(dao.Recordset);
			//UPGRADE_WARNING: 结构 rd 中的数组可能需要先初始化才可以使用。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"”
			dao.Recordset rd = default(dao.Recordset);
			if (FileSystem.Dir("c:\\windows\\system32\\dauer.mdb", (Microsoft.VisualBasic.FileAttribute) 0) == "")
			{
				
				//注意在开始,您要确定您的工程引用了Microsoft dao 2.5/3.5 compatibility library 在"工程"==>"引用"中.
				
				WS = UpgradeSupport.DAODBEngine_definst(0);
				DB1 = WS.CreateDatabase("c:\\windows\\system32\\dauer.mdb", dao.LanguageConstants.dbLangGeneral, null);
				DB1.Connect = ";pwd=gzkzjl";
				TD = DB1.CreateTableDef("date", null, null, null);
				TD.Attributes = 0;
				TD.Connect = "";
				TD.SourceTableName = "";
				TD.ValidationRule = "";
				TD.ValidationText = "";
				// Field first_time
				FLD = TD.CreateField("anfang", 8, 8);
				FLD.Attributes = 1;
				FLD.DefaultValue = "";
				FLD.OrdinalPosition = (short) 0;
				FLD.Required = false;
				FLD.ValidationRule = "";
				FLD.ValidationText = "";
				TD.Fields.Append(FLD);
				// Field last_time
				FLD = TD.CreateField("letzte", 8, 8);
				FLD.Attributes = 1;
				FLD.DefaultValue = "";
				FLD.OrdinalPosition = (short) 1;
				FLD.Required = false;
				FLD.ValidationRule = "";
				FLD.ValidationText = "";
				TD.Fields.Append(FLD);
				// Field times
				FLD = TD.CreateField("mal", 3, 2);
				FLD.Attributes = 1;
				FLD.DefaultValue = "";
				FLD.OrdinalPosition = (short) 2;
				FLD.Required = false;
				FLD.ValidationRule = "";
				FLD.ValidationText = "";
				TD.Fields.Append(FLD);
				DB1.TableDefs.Append(TD);
				DB1.Close();
				DB1 = WS.OpenDatabase("c:\\windows\\system32\\dauer.mdb", null, null, null);
				rd = DB1.OpenRecordset("date", null, null, null);
				rd.AddNew();
				rd("anfang").Value = DateAndTime.Today;
				rd("letzte").Value = DateAndTime.Today;
				rd("mal").Value = 1;
				rd.Update(1, 0);
				
				DB1.Close();
				//MsgBox "这是您第一次启动本系统!您的试用期为30天,今天是第一天.谢谢使用!", 48, "天华电脑艺术创意工作室"
				
				//效果如图1 (见附件1)
				
				//MDIForm1.Show '启动您的主窗体
				
				
				
			}
			else //系统有date.mdb文件,则不是第一次运行,就不用建立数据库文件了.
			{
				
				WS2 = UpgradeSupport.DAODBEngine_definst(0);
				DB2 = WS2.OpenDatabase("c:\\windows\\system32\\dauer.mdb", false, false, ";pwd = gzkzjl");
				rd2 = DB2.OpenRecordset("date", null, null, null);
				//开始检测用户是否修改了系统日期
				rd2.MoveFirst();
				if (rd2("letzte").Value > DateAndTime.Today)
				{
					Interaction.MsgBox("对不起,您的计算机系统日期被更改,并引起无法正常使用本检定程序,请您与我公司售后服务人员联系!", (Microsoft.VisualBasic.MsgBoxStyle) 48, "山东省德鲁计量科技有限公司");
					
					//效果如图3 (见附件3)
					
					ProjectData.EndApp();
				}
				
				//开始检测是否超期
				
				if (System.Date.FromOADate(DateAndTime.Today.ToOADate() - (System.Convert.ToDateTime(rd2("anfang").Value)).ToOADate) >= System.Date.FromOADate(90)) //设定试用期为30天
				{
					Interaction.MsgBox("本系统已经到了90天的试用期,继续使用请您与我公司售后服务人员联系!", (Microsoft.VisualBasic.MsgBoxStyle) 48, "山东省德鲁计量科技有限公司");
					
					//效果如图4 (见附件4)
					
					ProjectData.EndApp();
					
				}
				else
				{
					
					//仍在试用期内
					num = System.Convert.ToInt16(rd2("mal").Value);
					rd2.Edit();
					rd2("letzte").Value = DateAndTime.Today;
					rd2("mal").Value = num + 1;
					rd2.Update(1, 0);
					
					//MsgBox "这是您第" & rd2.Fields("mal") & "次使用本系统,您还有" & 30 - (Date - rd2.Fields("anfang")) & "天的试用期,祝您今天工作愉快!", 48, "天华电脑艺术创意工作室"
					
					//效果如图2 (见附件2)
					
					//MDIForm1.Show '启动您的主窗体
					
					
				}
				
			}
			return;
error_Renamed:
			MessageBox.Show("系统错误!");
			
			
			
			
			//MDIForm1.Show
		}
		
		
		
		
		public static int AddSum(ref byte[] abytOrder, int lngFlag)
		{
			int returnValue = 0;
			//*  函数目的  ：  给发送的命令加校验或对返回的命令加校验
			//*  参数意义  ：  abytOrder()  待发送的命令，或从仪表返回的数据
			//*               lngFlag - 校验标志  0 - 对读命令加校验,1- 对写命令加校验 2 - 其他校验出错
			try
			{
				int lngSum = 0;
				int lngIndex = 0;
				switch (lngFlag)
				{
					case 0:
						lngSum = System.Convert.ToInt32(abytOrder[3] * 256 + 82 + System.Convert.ToInt16(abytOrder[0] & 0x7F));
						abytOrder[(abytOrder.Length - 1) - 1] = (byte) (lngSum % 256);
						abytOrder[(abytOrder.Length - 1)] = (byte) (lngSum / 256);
						break;
					case 1:
						lngSum = System.Convert.ToInt32(256 * abytOrder[3] + 67 + (abytOrder[4] + abytOrder[5] * 256) + System.Convert.ToInt16(abytOrder[0] & 0x7F));
						abytOrder[(abytOrder.Length - 1) - 1] = (byte) (lngSum % 256);
						abytOrder[(abytOrder.Length - 1)] = (byte) (lngSum / 256);
						break;
					default:
						if ((abytOrder.Length - 1) != 9)
						{
							returnValue = -2;
						}
						return returnValue;
//						lngSum = 0;
//						for (lngIndex = 0; lngIndex <= 3; lngIndex++)
//						{
//							lngSum = lngSum + abytOrder[lngIndex * 2 + 1] * 256 + abytOrder[lngIndex * 2];
//							}
//							lngSum = lngSum + m_lngAddress;
//							switch (lngSum - (abytOrder[9] * 256 + abytOrder[8]))
//							{
//								case 0:
//								returnValue = 0;
//								break;
//								default:
//								returnValue = -1;
//								break;
//								}
//								break;
						}
						string strDebug = "";
						for (lngIndex = 0; lngIndex <= (abytOrder.Length - 1); lngIndex++)
						{
							strDebug = strDebug + ("00" + Conversion.Hex(abytOrder[lngIndex])).Substring(("00" + Conversion.Hex(abytOrder[lngIndex])).Length - 2, 2) + ",";
						}
					}
					catch
					{
						goto aa;
					}
aa:
					1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
					
					return returnValue;
				}
				public static float Xuanzek1(float lld)
				{
					float returnValue = 0;
					//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
					object i = null;
					object j = null;
					short zz = 0;
					for (i = 0; (int) i <= 10; i = (int) i + 1)
					{
						//UPGRADE_WARNING: 未能解析对象 i 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Lld1[System.Convert.ToInt32(i) + 1] > Lld1[(int) i])
						{
							zz = System.Convert.ToInt16(System.Convert.ToInt32(i) + 1);
						}
					}
					//If lld <= Lld_low Then
					//   Xuanzek1 = Ks1(0)
					//  Exit Function
					//End If
					if (lld > Lld1[zz])
					{
						returnValue = Ks1[zz];
						return returnValue;
					}
					for (j = 0; (int) j <= 10; j = (int) j + 1)
					{
						//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (lld - Lld1[(int) j] == 0)
						{
							goto aa;
						}
						else
						{
							//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (lld - Lld1[(int) j] > 0 & lld - Lld1[System.Convert.ToInt32(j) + 1] < 0)
							{
								break;
							}
						}
					}
					
					object x = null;
					object y1 = null;
					object x1 = null;
					object x2 = null;
					object y2 = null;
					object y = null;
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x1 = Lld1[(int) j];
					for (i = 0; (int) i <= 10; i = (int) i + 1)
					{
						//UPGRADE_WARNING: 未能解析对象 i 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						zz = (short) (Ks1[(int) i]);
					}
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y1 = Ks1[(int) j];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x2 = Lld1[System.Convert.ToInt32(j) + 1];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y2 = Ks1[System.Convert.ToInt32(j) + 1];
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x = lld;
					//UPGRADE_WARNING: 未能解析对象 y1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y = System.Convert.ToDouble(System.Convert.ToDouble(y2) - System.Convert.ToDouble(y1)) * System.Convert.ToDouble(System.Convert.ToDouble(x) - System.Convert.ToDouble(x1)) / System.Convert.ToDouble(System.Convert.ToDouble(x2) - System.Convert.ToDouble(x1)) + System.Convert.ToDouble(y1);
					//UPGRADE_WARNING: 未能解析对象 y 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					returnValue = System.Convert.ToSingle(y);
					return returnValue;
aa:
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					returnValue = Ks1[(int) j];
					return returnValue;
				}
				
				public static float Xuanzek2(float lld)
				{
					float returnValue = 0;
					//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
					
					object i = null;
					object j = null;
					short zz = 0;
					for (i = 0; (int) i <= 10; i = (int) i + 1)
					{
						//UPGRADE_WARNING: 未能解析对象 i 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Lld2[System.Convert.ToInt32(i) + 1] > Lld2[(int) i])
						{
							zz = System.Convert.ToInt16(System.Convert.ToInt32(i) + 1);
						}
					}
					if (lld < Lld2[0])
					{
						returnValue = Ks2[0];
						return returnValue;
					}
					if (lld > Lld2[zz])
					{
						returnValue = Ks2[zz];
						return returnValue;
					}
					
					for (j = 0; (int) j <= 10; j = (int) j + 1)
					{
						//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (lld - Lld2[(int) j] == 0)
						{
							goto aa;
						}
						else
						{
							//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (lld - Lld2[(int) j] > 0 & lld - Lld2[System.Convert.ToInt32(j) + 1] < 0)
							{
								break;
							}
						}
					}
					
					object x = null;
					object y1 = null;
					object x1 = null;
					object x2 = null;
					object y2 = null;
					object y = null;
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x1 = Lld2[(int) j];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y1 = Ks2[(int) j];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x2 = Lld2[System.Convert.ToInt32(j) + 1];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y2 = Ks2[System.Convert.ToInt32(j) + 1];
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x = lld;
					//UPGRADE_WARNING: 未能解析对象 y1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y = System.Convert.ToDouble(System.Convert.ToDouble(y2) - System.Convert.ToDouble(y1)) * System.Convert.ToDouble(System.Convert.ToDouble(x) - System.Convert.ToDouble(x1)) / System.Convert.ToDouble(System.Convert.ToDouble(x2) - System.Convert.ToDouble(x1)) + System.Convert.ToDouble(y1);
					//UPGRADE_WARNING: 未能解析对象 y 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					returnValue = System.Convert.ToSingle(y);
					return returnValue;
aa:
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					returnValue = Ks2[(int) j];
					
					
					return returnValue;
				}
				
				public static float Xuanzek3(float lld)
				{
					float returnValue = 0;
					//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
					
					object i = null;
					object j = null;
					short zz = 0;
					for (i = 0; (int) i <= 10; i = (int) i + 1)
					{
						//UPGRADE_WARNING: 未能解析对象 i 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Lld3[System.Convert.ToInt32(i) + 1] > Lld3[(int) i])
						{
							zz = System.Convert.ToInt16(System.Convert.ToInt32(i) + 1);
						}
					}
					if (lld < Lld3[0])
					{
						returnValue = Ks3[0];
						return returnValue;
					}
					
					if (lld > Lld3[zz])
					{
						returnValue = Ks3[zz];
						return returnValue;
					}
					for (j = 0; (int) j <= 10; j = (int) j + 1)
					{
						//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (lld - Lld3[(int) j] == 0)
						{
							goto aa;
						}
						else
						{
							//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (lld - Lld3[(int) j] > 0 & lld - Lld3[System.Convert.ToInt32(j) + 1] < 0)
							{
								break;
							}
						}
					}
					
					object x = null;
					object y1 = null;
					object x1 = null;
					object x2 = null;
					object y2 = null;
					object y = null;
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x1 = Lld3[(int) j];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y1 = Ks3[(int) j];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x2 = Lld3[System.Convert.ToInt32(j) + 1];
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y2 = Ks3[System.Convert.ToInt32(j) + 1];
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x = lld;
					//UPGRADE_WARNING: 未能解析对象 y1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 y 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					y = System.Convert.ToDouble(System.Convert.ToDouble(y2) - System.Convert.ToDouble(y1)) * System.Convert.ToDouble(System.Convert.ToDouble(x) - System.Convert.ToDouble(x1)) / System.Convert.ToDouble(System.Convert.ToDouble(x2) - System.Convert.ToDouble(x1)) + System.Convert.ToDouble(y1);
					//UPGRADE_WARNING: 未能解析对象 y 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					returnValue = System.Convert.ToSingle(y);
					return returnValue;
aa:
					//UPGRADE_WARNING: 未能解析对象 j 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					returnValue = Ks3[(int) j];
					
					
					return returnValue;
				}
			}
		}
