// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	sealed class UpgradeSupport
	{
		internal static dao.DBEngine DAODBEngine_definst = new dao.DBEngine();
		internal static Microsoft.Office.Interop.Excel.Global ExcelGlobal_definst = new Microsoft.Office.Interop.Excel.Global();
	}
}
