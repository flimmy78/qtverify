// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]public partial class frmzongticx
	{
#region Windows 窗体设计器生成的代码
		[System.Diagnostics.DebuggerNonUserCode()]public frmzongticx()
		{
			//此调用是 Windows 窗体设计器所必需的。
			InitializeComponent();
		}
		//窗体重写释放，以清理组件列表。
		[System.Diagnostics.DebuggerNonUserCode()]protected override void Dispose(bool Disposing)
		{
			if (Disposing)
			{
				if (!(components == null))
				{
					components.Dispose();
				}
			}
			base.Dispose(Disposing);
		}
		//Windows 窗体设计器所必需的
		private System.ComponentModel.Container components = null;
		public System.Windows.Forms.ToolTip ToolTip1;
		public AxMSComCtl2.AxDTPicker DTPicker1;
		public System.Windows.Forms.Label _lblDate_7;
		public System.Windows.Forms.GroupBox _fraDate_3;
		public AxMSComCtl2.AxDTPicker DTPicker2;
		public System.Windows.Forms.Label _lblDate_6;
		public System.Windows.Forms.GroupBox _fraDate_2;
		public System.Windows.Forms.Button Command1;
		public System.Windows.Forms.Button Command2;
		public System.Windows.Forms.ComboBox Combo1;
		public System.Windows.Forms.GroupBox Frame2;
		public System.Windows.Forms.GroupBox Frame1;
		public AxMSHierarchicalFlexGridLib.AxMSHFlexGrid hfgRollups;
		public Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray fraDate;
		public Microsoft.VisualBasic.Compatibility.VB6.LabelArray lblDate;
		//注意: 以下过程是 Windows 窗体设计器所必需的
		//可以使用 Windows 窗体设计器来修改它。
		//不要使用代码编辑器修改它。
		[System.Diagnostics.DebuggerStepThrough()]private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmzongticx));
			this.components = new System.ComponentModel.Container();
			base.Load += frmzongticx_Load;
			this.ToolTip1 = new System.Windows.Forms.ToolTip(components);
			this.Frame1 = new System.Windows.Forms.GroupBox();
			this._fraDate_3 = new System.Windows.Forms.GroupBox();
			this.DTPicker1 = new AxMSComCtl2.AxDTPicker();
			this._lblDate_7 = new System.Windows.Forms.Label();
			this._fraDate_2 = new System.Windows.Forms.GroupBox();
			this.DTPicker2 = new AxMSComCtl2.AxDTPicker();
			this._lblDate_6 = new System.Windows.Forms.Label();
			this.Command1 = new System.Windows.Forms.Button();
			this.Command1.Click += this.Command1_Click;
			this.Command2 = new System.Windows.Forms.Button();
			this.Command2.Click += this.Command2_Click;
			this.Frame2 = new System.Windows.Forms.GroupBox();
			this.Combo1 = new System.Windows.Forms.ComboBox();
			this.hfgRollups = new AxMSHierarchicalFlexGridLib.AxMSHFlexGrid();
			this.fraDate = new Microsoft.VisualBasic.Compatibility.VB6.GroupBoxArray(components);
			this.lblDate = new Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components);
			this.Frame1.SuspendLayout();
			this._fraDate_3.SuspendLayout();
			this._fraDate_2.SuspendLayout();
			this.Frame2.SuspendLayout();
			this.SuspendLayout();
			this.ToolTip1.Active = true;
			((System.ComponentModel.ISupportInitialize) this.DTPicker1).BeginInit();
			((System.ComponentModel.ISupportInitialize) this.DTPicker2).BeginInit();
			((System.ComponentModel.ISupportInitialize) this.hfgRollups).BeginInit();
			((System.ComponentModel.ISupportInitialize) this.fraDate).BeginInit();
			((System.ComponentModel.ISupportInitialize) this.lblDate).BeginInit();
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "总体检测查询";
			this.ClientSize = new System.Drawing.Size(1016, 449);
			this.Location = new System.Drawing.Point(4, 23);
			this.Icon = (System.Drawing.Icon) (resources.GetObject("frmzongticx.Icon"));
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.BackgroundImage = (System.Drawing.Image) (resources.GetObject("frmzongticx.BackgroundImage"));
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
			this.ControlBox = true;
			this.Enabled = true;
			this.KeyPreview = false;
			this.MaximizeBox = true;
			this.MinimizeBox = true;
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.ShowInTaskbar = true;
			this.HelpButton = false;
			this.WindowState = System.Windows.Forms.FormWindowState.Normal;
			this.Name = "frmzongticx";
			this.Frame1.Size = new System.Drawing.Size(1009, 81);
			this.Frame1.Location = new System.Drawing.Point(0, 0);
			this.Frame1.TabIndex = 0;
			this.Frame1.BackColor = System.Drawing.SystemColors.Control;
			this.Frame1.Enabled = true;
			this.Frame1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Frame1.Visible = true;
			this.Frame1.Name = "Frame1";
			this._fraDate_3.Text = "开始日期：";
			this._fraDate_3.Font = new System.Drawing.Font("楷体_GB2312", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this._fraDate_3.ForeColor = System.Drawing.Color.Red;
			this._fraDate_3.Size = new System.Drawing.Size(153, 65);
			this._fraDate_3.Location = new System.Drawing.Point(8, 8);
			this._fraDate_3.TabIndex = 8;
			this._fraDate_3.BackColor = System.Drawing.SystemColors.Control;
			this._fraDate_3.Enabled = true;
			this._fraDate_3.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._fraDate_3.Visible = true;
			this._fraDate_3.Name = "_fraDate_3";
			DTPicker1.OcxState = (System.Windows.Forms.AxHost.State) (resources.GetObject("DTPicker1.OcxState"));
			this.DTPicker1.Size = new System.Drawing.Size(121, 25);
			this.DTPicker1.Location = new System.Drawing.Point(24, 24);
			this.DTPicker1.TabIndex = 9;
			this.DTPicker1.Name = "DTPicker1";
			this._lblDate_7.Text = "日";
			this._lblDate_7.Font = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this._lblDate_7.Size = new System.Drawing.Size(3, 21);
			this._lblDate_7.Location = new System.Drawing.Point(248, 24);
			this._lblDate_7.TabIndex = 10;
			this.ToolTip1.SetToolTip(this._lblDate_7, "双击后将粘贴剪贴板中的数据！");
			this._lblDate_7.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this._lblDate_7.BackColor = System.Drawing.Color.Transparent;
			this._lblDate_7.Enabled = true;
			this._lblDate_7.ForeColor = System.Drawing.SystemColors.ControlText;
			this._lblDate_7.Cursor = System.Windows.Forms.Cursors.Default;
			this._lblDate_7.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._lblDate_7.UseMnemonic = true;
			this._lblDate_7.Visible = true;
			this._lblDate_7.AutoSize = false;
			this._lblDate_7.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this._lblDate_7.Name = "_lblDate_7";
			this._fraDate_2.Text = "截止日期：";
			this._fraDate_2.Font = new System.Drawing.Font("楷体_GB2312", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this._fraDate_2.ForeColor = System.Drawing.Color.Red;
			this._fraDate_2.Size = new System.Drawing.Size(153, 65);
			this._fraDate_2.Location = new System.Drawing.Point(168, 8);
			this._fraDate_2.TabIndex = 5;
			this._fraDate_2.BackColor = System.Drawing.SystemColors.Control;
			this._fraDate_2.Enabled = true;
			this._fraDate_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._fraDate_2.Visible = true;
			this._fraDate_2.Name = "_fraDate_2";
			DTPicker2.OcxState = (System.Windows.Forms.AxHost.State) (resources.GetObject("DTPicker2.OcxState"));
			this.DTPicker2.Size = new System.Drawing.Size(121, 25);
			this.DTPicker2.Location = new System.Drawing.Point(24, 24);
			this.DTPicker2.TabIndex = 6;
			this.DTPicker2.Name = "DTPicker2";
			this._lblDate_6.Text = "日";
			this._lblDate_6.Font = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this._lblDate_6.Size = new System.Drawing.Size(3, 21);
			this._lblDate_6.Location = new System.Drawing.Point(248, 24);
			this._lblDate_6.TabIndex = 7;
			this.ToolTip1.SetToolTip(this._lblDate_6, "双击后将粘贴剪贴板中的数据！");
			this._lblDate_6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
			this._lblDate_6.BackColor = System.Drawing.Color.Transparent;
			this._lblDate_6.Enabled = true;
			this._lblDate_6.ForeColor = System.Drawing.SystemColors.ControlText;
			this._lblDate_6.Cursor = System.Windows.Forms.Cursors.Default;
			this._lblDate_6.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this._lblDate_6.UseMnemonic = true;
			this._lblDate_6.Visible = true;
			this._lblDate_6.AutoSize = false;
			this._lblDate_6.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this._lblDate_6.Name = "_lblDate_6";
			this.Command1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.Command1.Text = "查找";
			this.Command1.Font = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Command1.Size = new System.Drawing.Size(73, 33);
			this.Command1.Location = new System.Drawing.Point(776, 24);
			this.Command1.TabIndex = 4;
			this.Command1.BackColor = System.Drawing.SystemColors.Control;
			this.Command1.CausesValidation = true;
			this.Command1.Enabled = true;
			this.Command1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Command1.Cursor = System.Windows.Forms.Cursors.Default;
			this.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Command1.TabStop = true;
			this.Command1.Name = "Command1";
			this.Command2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.Command2.Text = "退出";
			this.Command2.Font = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Command2.Size = new System.Drawing.Size(73, 33);
			this.Command2.Location = new System.Drawing.Point(904, 24);
			this.Command2.TabIndex = 3;
			this.Command2.BackColor = System.Drawing.SystemColors.Control;
			this.Command2.CausesValidation = true;
			this.Command2.Enabled = true;
			this.Command2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Command2.Cursor = System.Windows.Forms.Cursors.Default;
			this.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Command2.TabStop = true;
			this.Command2.Name = "Command2";
			this.Frame2.Text = "表号";
			this.Frame2.Font = new System.Drawing.Font("宋体", (float) (10.5F), System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Frame2.ForeColor = System.Drawing.Color.FromArgb(192, 0, 0);
			this.Frame2.Size = new System.Drawing.Size(145, 65);
			this.Frame2.Location = new System.Drawing.Point(328, 8);
			this.Frame2.TabIndex = 1;
			this.Frame2.BackColor = System.Drawing.SystemColors.Control;
			this.Frame2.Enabled = true;
			this.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Frame2.Visible = true;
			this.Frame2.Name = "Frame2";
			this.Combo1.Font = new System.Drawing.Font("宋体", 12, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, System.Convert.ToByte(134));
			this.Combo1.ForeColor = System.Drawing.Color.Black;
			this.Combo1.Size = new System.Drawing.Size(125, 24);
			this.Combo1.Location = new System.Drawing.Point(8, 24);
			this.Combo1.TabIndex = 2;
			this.Combo1.BackColor = System.Drawing.SystemColors.Window;
			this.Combo1.CausesValidation = true;
			this.Combo1.Enabled = true;
			this.Combo1.IntegralHeight = true;
			this.Combo1.Cursor = System.Windows.Forms.Cursors.Default;
			this.Combo1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Combo1.Sorted = false;
			this.Combo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
			this.Combo1.TabStop = true;
			this.Combo1.Visible = true;
			this.Combo1.Name = "Combo1";
			hfgRollups.OcxState = (System.Windows.Forms.AxHost.State) (resources.GetObject("hfgRollups.OcxState"));
			this.hfgRollups.Size = new System.Drawing.Size(1009, 351);
			this.hfgRollups.Location = new System.Drawing.Point(0, 88);
			this.hfgRollups.TabIndex = 11;
			this.hfgRollups.Name = "hfgRollups";
			this.Controls.Add(Frame1);
			this.Controls.Add(hfgRollups);
			this.Frame1.Controls.Add(_fraDate_3);
			this.Frame1.Controls.Add(_fraDate_2);
			this.Frame1.Controls.Add(Command1);
			this.Frame1.Controls.Add(Command2);
			this.Frame1.Controls.Add(Frame2);
			this._fraDate_3.Controls.Add(DTPicker1);
			this._fraDate_3.Controls.Add(_lblDate_7);
			this._fraDate_2.Controls.Add(DTPicker2);
			this._fraDate_2.Controls.Add(_lblDate_6);
			this.Frame2.Controls.Add(Combo1);
			this.fraDate.SetIndex(_fraDate_3, (short) (3));
			this.fraDate.SetIndex(_fraDate_2, (short) (2));
			this.lblDate.SetIndex(_lblDate_7, (short) (7));
			this.lblDate.SetIndex(_lblDate_6, (short) (6));
			((System.ComponentModel.ISupportInitialize) this.lblDate).EndInit();
			((System.ComponentModel.ISupportInitialize) this.fraDate).EndInit();
			((System.ComponentModel.ISupportInitialize) this.hfgRollups).EndInit();
			((System.ComponentModel.ISupportInitialize) this.DTPicker2).EndInit();
			((System.ComponentModel.ISupportInitialize) this.DTPicker1).EndInit();
			this.Frame1.ResumeLayout(false);
			this._fraDate_3.ResumeLayout(false);
			this._fraDate_2.ResumeLayout(false);
			this.Frame2.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
#endregion
	}
}
