// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmjsbdz : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmjsbdz defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmjsbdz Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmjsbdz();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		short pt;
		public void calculkey_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = calculkey.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			float t1 = 0; // 共公变量  标准温度值
			float t2 = 0;
			float t3 = 0;
			float rv0 = 0;
			float rv1 = 0;
			float rv2 = 0;
			float rv3 = 0;
			float bv = 0;
			float av = 0;
			//If Len(Text39(1).Text) > 0 And Len(Text40(1).Text) > 0 And Len(Text41(1).Text) > 0 Then
			
			
			rv1 = (float) (Conversion.Val(Text39[2].Text)); //温度电阻值
			rv2 = (float) (Conversion.Val(Text40[2].Text));
			rv3 = (float) (Conversion.Val(Text41[2].Text));
			
			t1 = (float) (Conversion.Val(Text39[1].Text)); //厂家提供的标准温度值
			t2 = (float) (Conversion.Val(Text40[1].Text));
			t3 = (float) (Conversion.Val(Text41[1].Text));
			
			bv = (float) ((rv3 - rv1 + (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 - rv1)) / (rv1 * t3 * t3 - rv3 * t1 * t1 - (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 * t1 * t1 - rv1 * t2 * t2)));
			av = (float) ((rv2 - rv1 + bv * (rv2 * t1 * t1 - rv1 * t2 * t2)) / (rv1 * t2 - rv2 * t1));
			rv0 = rv1 / (1 + av * t1 + bv * t1 * t1);
			Text11[6].Text = (System.Math.Round(rv0, 2)).ToString();
			Text12[6].Text = (System.Math.Round(av * Math.Pow(10, 3), 4)).ToString();
			Text13[6].Text = (System.Math.Round(bv * Math.Pow(10, 7), 4)).ToString();
			//    ElseIf Len(Text39(4).Text) > 0 And Len(Text40(4).Text) > 0 And Len(Text41(4).Text) > 0 Then
			rv1 = (float) (Conversion.Val(Text39[5].Text)); //温度电阻值
			rv2 = (float) (Conversion.Val(Text40[5].Text));
			rv3 = (float) (Conversion.Val(Text41[5].Text));
			
			t1 = (float) (Conversion.Val(Text39[4].Text)); //厂家提供的标准温度值
			t2 = (float) (Conversion.Val(Text40[4].Text));
			t3 = (float) (Conversion.Val(Text41[4].Text));
			
			bv = (float) ((rv3 - rv1 + (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 - rv1)) / (rv1 * t3 * t3 - rv3 * t1 * t1 - (rv3 * t1 - rv1 * t3) / (rv1 * t2 - rv2 * t1) * (rv2 * t1 * t1 - rv1 * t2 * t2)));
			av = (float) ((rv2 - rv1 + bv * (rv2 * t1 * t1 - rv1 * t2 * t2)) / (rv1 * t2 - rv2 * t1));
			rv0 = rv1 / (1 + av * t1 + bv * t1 * t1);
			Text11[5].Text = (System.Math.Round(rv0, 2)).ToString();
			Text12[5].Text = (System.Math.Round(av * Math.Pow(10, 3), 4)).ToString();
			Text13[5].Text = (System.Math.Round(bv * Math.Pow(10, 7), 4)).ToString();
			//   End If
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			FileSystem.FileClose(1);
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			if (Option3.Checked == true)
			{
				pt = (short) 1;
			}
			else if (Option4.Checked == true)
			{
				pt = (short) 2;
			}
			else if (Option5.Checked == true)
			{
				pt = (short) 3;
			}
			FileSystem.WriteLine(1, pt);
			FileSystem.FileClose(1);
			
			this.Close();
			
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			FileSystem.FileClose(1);
			object m5 = null;
			object m3 = null;
			object m1 = null;
			object m2 = null;
			object m4 = null;
			object m6 = null;
			float m7 = 0;
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\pt_canshu.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			
			//UPGRADE_WARNING: 未能解析对象 m1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m1 = Conversion.Val(Text11[1].Text);
			//UPGRADE_WARNING: 未能解析对象 m2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m2 = Conversion.Val(Text12[1].Text);
			//UPGRADE_WARNING: 未能解析对象 m3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m3 = Conversion.Val(Text13[1].Text);
			//UPGRADE_WARNING: 未能解析对象 m4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m4 = Conversion.Val(Text11[0].Text);
			//UPGRADE_WARNING: 未能解析对象 m5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m5 = Conversion.Val(Text12[0].Text);
			//UPGRADE_WARNING: 未能解析对象 m6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m6 = Conversion.Val(Text13[0].Text);
			m7 = 1;
			FileSystem.WriteLine(1, m1);
			FileSystem.WriteLine(1, m2);
			FileSystem.WriteLine(1, m3);
			FileSystem.WriteLine(1, m4);
			FileSystem.WriteLine(1, m5);
			FileSystem.WriteLine(1, m6);
			FileSystem.WriteLine(1, m7);
			FileSystem.FileClose(1);
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			FileSystem.FileClose(1);
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			if (Option3.Checked == true)
			{
				pt = (short) 1;
			}
			else if (Option4.Checked == true)
			{
				pt = (short) 2;
			}
			else if (Option5.Checked == true)
			{
				pt = (short) 3;
			}
			FileSystem.WriteLine(1, pt);
			FileSystem.FileClose(1);
			
			this.Close();
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			FileSystem.FileClose(1);
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			if (Option3.Checked == true)
			{
				pt = (short) 1;
			}
			else if (Option4.Checked == true)
			{
				pt = (short) 2;
			}
			else if (Option5.Checked == true)
			{
				pt = (short) 3;
			}
			FileSystem.WriteLine(1, pt);
			FileSystem.FileClose(1);
			
			this.Close();
		}
		
		public void Command6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			FileSystem.FileClose(1);
			object m5 = null;
			object m3 = null;
			object m1 = null;
			object m2 = null;
			object m4 = null;
			object m6 = null;
			float m7 = 0;
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\pt_canshu.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			
			
			//UPGRADE_WARNING: 未能解析对象 m1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m1 = Conversion.Val(Text11[6].Text);
			//UPGRADE_WARNING: 未能解析对象 m2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m2 = Conversion.Val(Text12[6].Text);
			//UPGRADE_WARNING: 未能解析对象 m3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m3 = Conversion.Val(Text13[6].Text);
			
			//UPGRADE_WARNING: 未能解析对象 m4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m4 = Conversion.Val(Text11[5].Text);
			//UPGRADE_WARNING: 未能解析对象 m5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m5 = Conversion.Val(Text12[5].Text);
			//UPGRADE_WARNING: 未能解析对象 m6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			m6 = Conversion.Val(Text13[5].Text);
			m7 = 2;
			FileSystem.WriteLine(1, m1);
			FileSystem.WriteLine(1, m2);
			FileSystem.WriteLine(1, m3);
			FileSystem.WriteLine(1, m4);
			FileSystem.WriteLine(1, m5);
			FileSystem.WriteLine(1, m6);
			FileSystem.WriteLine(1, m7);
			FileSystem.FileClose(1);
			
		}
		
		public void frmjsbdz_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			short n;
			object m5 = null;
			object m3 = null;
			object m1 = null;
			object m2 = null;
			object m4 = null;
			object m6 = null;
			float m7 = 0;
			if (sub_Renamed.Chinese == false)
			{
				this.Text = "Standard thermometer parameters";
				this.Option1.Text = "Pt25 Platinum resistance thermometer";
				this.Option2.Text = "Pt100 Platinum resistance thermometer";
				this.Frame4.Text = "Multi-meter producer";
				this.Frame3[2].Text = "Parameters for flow";
				this.Frame3[1].Text = "Parameters for return";
				this.Command2.Text = "Save";
				this.Command3.Text = "Quit";
				this.Frame3[3].Text = "Parameters for flow";
				this.Frame3[0].Text = "Parameters for return";
				this.Text38[3].Text = "Flow";
				this.Text38[0].Text = "Return";
				this.Text38[1].Text = "Tem.(℃)";
				this.Text38[2].Text = "Res.(Ω)";
				this.Text38[4].Text = "Tem.(℃)";
				this.Text38[5].Text = "Res.(Ω)";
				this.calculkey[1].Text = "Cal.";
				this.Command6.Text = "Save";
				this.Command1.Text = "Quit";
				this.Option3.Text = "NIM";
				this.Option4.Text = "Weili";
				this.Option5.Text = "Huayi";
				this.Command4.Text = "Quit";
				Text39[3].Text = "Point 1";
				Text40[3].Text = "Point 2";
				Text41[3].Text = "Point 3";
				Text39[0].Text = "Point 1";
				Text40[0].Text = "Point 2";
				Text41[0].Text = "Point 3";
			}
			else
			{
				this.Text = "标准铂电阻参数";
				this.Option1.Text = "Pt25 标准铂电阻";
				this.Option2.Text = "Pt100 标准铂电阻";
				this.Frame4.Text = "数字温度计型号";
				this.Frame3[2].Text = "进口铂电阻参数";
				this.Frame3[1].Text = "出口铂电阻参数";
				this.Command2.Text = "保存";
				this.Command3.Text = "退出";
				this.Frame3[3].Text = "进口铂电阻参数";
				this.Frame3[0].Text = "出口铂电阻参数";
				this.Text38[3].Text = "进口";
				this.Text38[0].Text = "出口";
				this.Text38[1].Text = "温度(℃)";
				this.Text38[2].Text = "电阻(Ω)";
				this.Text38[4].Text = "温度(℃)";
				this.Text38[5].Text = "电阻(Ω)";
				this.calculkey[1].Text = "计算";
				this.Command6.Text = "保存";
				this.Command1.Text = "退出";
				this.Option3.Text = "计量院";
				this.Option4.Text = "唯立";
				this.Option5.Text = "华易";
				this.Command4.Text = "退出";
				Text39[3].Text = "第I点";
				Text40[3].Text = "第II点";
				Text41[3].Text = "第III点";
				Text39[0].Text = "第I点";
				Text40[0].Text = "第II点";
				Text41[0].Text = "第III点";
			}
			
			FileSystem.FileClose(1);
			FileSystem.FileOpen(1, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\pt_canshu.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(1, ref m1);
			FileSystem.Input(1, ref m2);
			FileSystem.Input(1, ref m3);
			FileSystem.Input(1, ref m4);
			FileSystem.Input(1, ref m5);
			FileSystem.Input(1, ref m6);
			FileSystem.Input(1, ref m7);
			FileSystem.FileClose(1);
			
			if (m7 == 1)
			{
				this.Option1.Checked = true;
				this.Option2.Checked = false;
			}
			else if (m7 == 2)
			{
				this.Option2.Checked = true;
				this.Option1.Checked = false;
			}
			
			if (Option2.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 m1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text11[6].Text = () );m1;
				//UPGRADE_WARNING: 未能解析对象 m2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text12[6].Text = () );m2;
				//UPGRADE_WARNING: 未能解析对象 m3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text13[6].Text = () );m3;
				
				//UPGRADE_WARNING: 未能解析对象 m4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text11[5].Text = () );m4;
				//UPGRADE_WARNING: 未能解析对象 m5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text12[5].Text = () );m5;
				//UPGRADE_WARNING: 未能解析对象 m6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text13[5].Text = () );m6;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 m1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text11[1].Text = () );m1;
				//UPGRADE_WARNING: 未能解析对象 m2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text12[1].Text = () );m2;
				//UPGRADE_WARNING: 未能解析对象 m3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text13[1].Text = () );m3;
				
				//UPGRADE_WARNING: 未能解析对象 m4 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text11[0].Text = () );m4;
				//UPGRADE_WARNING: 未能解析对象 m5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text12[0].Text = () );m5;
				//UPGRADE_WARNING: 未能解析对象 m6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text13[0].Text = () );m6;
			}
			
			FileSystem.FileClose(11);
			FileSystem.FileOpen(11, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(11, ref pt);
			FileSystem.FileClose(11);
			if (pt == 1)
			{
				Option3.Checked = true;
				Option4.Checked = false;
				Option5.Checked = false;
				Frame1.Enabled = false;
				Frame2.Enabled = false;
				
			}
			else if (pt == 2)
			{
				Option4.Checked = true;
				Option3.Checked = false;
				Option5.Checked = false;
				Frame1.Enabled = false;
				Frame2.Enabled = false;
				
			}
			else if (pt == 3)
			{
				Option5.Checked = true;
				Option4.Checked = false;
				Option3.Checked = false;
			}
		}
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option1.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option1_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option1.Checked == true)
				{
					Frame2.Enabled = false;
					
					Command1.Enabled = false;
					Command6.Enabled = false;
					calculkey[1].Enabled = false;
					Frame1.Enabled = true;
					
					Command2.Enabled = true;
					Command3.Enabled = true;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option2.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option2_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option2.Checked == true)
				{
					Frame1.Enabled = false;
					Command2.Enabled = false;
					Command3.Enabled = false;
					Frame2.Enabled = true;
					Command1.Enabled = true;
					Command6.Enabled = true;
					calculkey[1].Enabled = true;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option4.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option4_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option4.Checked == true)
				{
					Frame1.Enabled = false;
					Frame2.Enabled = false;
					Option1.Enabled = false;
					Option2.Enabled = false;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option5.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option5_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option5.Checked == true)
				{
					Frame1.Enabled = true;
					Frame2.Enabled = true;
					Option1.Enabled = true;
					Option2.Enabled = true;
				}
			}
		}
	}
}
