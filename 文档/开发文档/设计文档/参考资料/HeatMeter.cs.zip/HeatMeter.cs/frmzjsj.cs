// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;

namespace 热量表
{
	partial class frmzjsj : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmzjsj defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmzjsj Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmzjsj();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		Microsoft.Office.Interop.Excel.Application XlApp;
		Microsoft.Office.Interop.Excel.Workbook Xlbook;
		
		Microsoft.Office.Interop.Excel.Worksheet Xlsheet;
		string datSD;
		string datFD;
		
		private void DataSFD()
		{
			datSD = DTPicker1.Year + "年" + System.Convert.ToString(DTPicker1.Month) + "月" + System.Convert.ToString(DTPicker1.Day) + "日";
			datFD = DTPicker2.Year + "年" + System.Convert.ToString(DTPicker2.Month) + "月" + System.Convert.ToString(DTPicker2.Day) + "日";
			
		}
		
		public void cmdbc_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short j = 0;
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("请您确认输入项是否正确，并保存？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
				if (msg == MsgBoxResult.Yes)
				{
					if (Text1.Text == "" || Text2[0].Text == "" || Text2[17].Text == "")
					{
						Interaction.MsgBox("数据错误！请退出", MsgBoxStyle.Information, "提示");
						return;
					}
					Mdlguanfa.Zs[0] = Text1.Text.Trim();
					Mdlguanfa.Zs[1] = Strings.Trim(System.Convert.ToString(Text2[1].Text));
					Mdlguanfa.Zs[2] = Strings.Trim(System.Convert.ToString(Text2[0].Text));
					Mdlguanfa.Zs[3] = Strings.Trim(System.Convert.ToString(Text2[17].Text));
					Mdlguanfa.Zs[4] = Strings.Trim(System.Convert.ToString(Text2[2].Text));
					Mdlguanfa.Zs[5] = Strings.Trim(System.Convert.ToString(Text2[3].Text));
					Mdlguanfa.Zs[6] = Strings.Trim(System.Convert.ToString(Text2[5].Text));
					Mdlguanfa.Zs[7] = Strings.Trim(System.Convert.ToString(Text2[11].Text));
					Mdlguanfa.Zs[8] = Strings.Trim(System.Convert.ToString(Text2[19].Text));
					Mdlguanfa.Zs[9] = Strings.Trim(System.Convert.ToString(Text2[9].Text));
					Mdlguanfa.Zs[10] = Strings.Trim(System.Convert.ToString(Text2[10].Text));
					Mdlguanfa.Zs[11] = Strings.Trim(System.Convert.ToString(Text2[21].Text));
					
					Mdlguanfa.Zs[14] = Strings.Trim(System.Convert.ToString(Text2[7].Text));
					Mdlguanfa.Zs[15] = Strings.Trim(System.Convert.ToString(Text2[8].Text));
					Mdlguanfa.Zs[16] = Strings.Trim(System.Convert.ToString(Text2[12].Text));
					Mdlguanfa.Zs[17] = Strings.Trim(System.Convert.ToString(Text2[18].Text));
					Mdlguanfa.Zs[18] = Strings.Trim(System.Convert.ToString(Text2[6].Text));
					Mdlguanfa.Zs[19] = Strings.Trim(System.Convert.ToString(Text2[13].Text));
					Mdlguanfa.Zs[20] = Strings.Trim(System.Convert.ToString(Text2[14].Text));
					Mdlguanfa.Zs[21] = Strings.Trim(System.Convert.ToString(Text2[20].Text));
					Mdlguanfa.Zs[22] = Strings.Trim(System.Convert.ToString(Text2[4].Text));
					FileSystem.FileClose(13);
					
					FileSystem.FileOpen(13, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\zhengshu_canshu.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
					for (j = 0; j <= 22; j++)
					{
						FileSystem.WriteLine(13, Mdlguanfa.Zs[j]);
					}
					
					FileSystem.FileClose(13);
				}
				else if (msg == MsgBoxResult.No)
				{
					return;
				}
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("Please confirm the saved data are correct？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "Note");
				if (msg == MsgBoxResult.Yes)
				{
					
					if (Text1.Text == "" || Text2[0].Text == "" || Text2[17].Text == "")
					{
						Interaction.MsgBox("数据错误！请退出", MsgBoxStyle.Information, "提示");
						return;
					}
					Mdlguanfa.Zs[0] = Text1.Text.Trim();
					Mdlguanfa.Zs[1] = Strings.Trim(System.Convert.ToString(Text2[1].Text));
					Mdlguanfa.Zs[2] = Strings.Trim(System.Convert.ToString(Text2[0].Text));
					Mdlguanfa.Zs[3] = Strings.Trim(System.Convert.ToString(Text2[17].Text));
					Mdlguanfa.Zs[4] = Strings.Trim(System.Convert.ToString(Text2[2].Text));
					Mdlguanfa.Zs[5] = Strings.Trim(System.Convert.ToString(Text2[3].Text));
					Mdlguanfa.Zs[6] = Strings.Trim(System.Convert.ToString(Text2[5].Text));
					Mdlguanfa.Zs[7] = Strings.Trim(System.Convert.ToString(Text2[11].Text));
					Mdlguanfa.Zs[8] = Strings.Trim(System.Convert.ToString(Text2[19].Text));
					Mdlguanfa.Zs[9] = Strings.Trim(System.Convert.ToString(Text2[9].Text));
					Mdlguanfa.Zs[10] = Strings.Trim(System.Convert.ToString(Text2[10].Text));
					Mdlguanfa.Zs[11] = Strings.Trim(System.Convert.ToString(Text2[21].Text));
					
					Mdlguanfa.Zs[14] = Strings.Trim(System.Convert.ToString(Text2[7].Text));
					Mdlguanfa.Zs[15] = Strings.Trim(System.Convert.ToString(Text2[8].Text));
					Mdlguanfa.Zs[16] = Strings.Trim(System.Convert.ToString(Text2[12].Text));
					Mdlguanfa.Zs[17] = Strings.Trim(System.Convert.ToString(Text2[18].Text));
					Mdlguanfa.Zs[18] = Strings.Trim(System.Convert.ToString(Text2[6].Text));
					Mdlguanfa.Zs[19] = Strings.Trim(System.Convert.ToString(Text2[13].Text));
					Mdlguanfa.Zs[20] = Strings.Trim(System.Convert.ToString(Text2[14].Text));
					Mdlguanfa.Zs[21] = Strings.Trim(System.Convert.ToString(Text2[20].Text));
					Mdlguanfa.Zs[22] = Strings.Trim(System.Convert.ToString(Text2[4].Text));
					
					FileSystem.FileClose(13);
					
					FileSystem.FileOpen(13, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\zhengshu_canshu.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
					for (j = 0; j <= 22; j++)
					{
						FileSystem.WriteLine(13, Mdlguanfa.Zs[j]);
					}
					
					FileSystem.FileClose(13);
				}
				else if (msg == MsgBoxResult.No)
				{
					return;
				}
				
			}
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			XlApp.Quit();
			FileSystem.Kill((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\1.tmp");
			FileSystem.Kill((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\temp.xlt");
			//UPGRADE_NOTE: 在对对象 Xlbook 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			Xlbook = null;
			//UPGRADE_NOTE: 在对对象 XlApp 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			XlApp = null;
			Module1.strSource = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\检测记录表头.xlt";
			Module1.strDestination = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Temp.xlt";
			FileSystem.FileCopy(Module1.strSource, Module1.strDestination);
			XlApp = new Microsoft.Office.Interop.Excel.Application();
			XlApp = () (Interaction.CreateObject("Excel.Application", "")));
			XlApp.Visible = true; // False
			Xlbook = XlApp.Workbooks.Open(Module1.strDestination, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
			Xlsheet = () (Xlbook.Worksheets[1]));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[6, 4] = Text1.Text.Trim();
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[6, 6] = Strings.Trim(System.Convert.ToString(Text2[1].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[8, 3] = Strings.Trim(System.Convert.ToString(Text2[0].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[10, 3] = Strings.Trim(System.Convert.ToString(Text2[17].Text));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[12, 3] = Strings.Trim(System.Convert.ToString(Text2[2].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[14, 3] = Strings.Trim(System.Convert.ToString(Text2[3].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[16, 3] = Strings.Trim(System.Convert.ToString(Text2[5].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[18, 3] = Strings.Trim(System.Convert.ToString(Text2[11].Text));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[20, 3] = Strings.Trim(System.Convert.ToString(Text2[19].Text));
			//UPGRADE_WARNING: 未能解析对象 DTPicker1.Year 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[31, 4] = DTPicker1.Year;
			//UPGRADE_WARNING: 未能解析对象 DTPicker1.Month 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[31, 6] = DTPicker1.Month;
			
			//UPGRADE_WARNING: 未能解析对象 DTPicker1.Day 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[31, 8] = DTPicker1.Day;
			//UPGRADE_WARNING: 未能解析对象 DTPicker2.Year 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[33, 4] = DTPicker2.Year;
			//UPGRADE_WARNING: 未能解析对象 DTPicker2.Month 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[33, 6] = DTPicker2.Month;
			
			//UPGRADE_WARNING: 未能解析对象 DTPicker2.Day 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[33, 8] = DTPicker2.Day;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[49, 4] = Strings.Trim(System.Convert.ToString(Text2[7].Text));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[51, 2] = Strings.Trim(System.Convert.ToString(Text2[8].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[53, 8] = Strings.Trim(System.Convert.ToString(Text2[12].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[55, 3] = Strings.Trim(System.Convert.ToString(Text2[18].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[57, 2] = Strings.Trim(System.Convert.ToString(Text2[6].Text));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[57, 4] = Strings.Trim(System.Convert.ToString(Text2[13].Text));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[57, 6] = Strings.Trim(System.Convert.ToString(Text2[14].Text));
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[59, 3] = Strings.Trim(System.Convert.ToString(Text2[20].Text));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Xlsheet.Cells[59, 6] = Strings.Trim(System.Convert.ToString(Text2[4].Text));
			
			//For i = 0 To 5
			//Xlsheet.Cells(70 + i, 1) = dyZsNo(i + 1)
			//Xlsheet.Cells(70 + i, 2) = FrmZongti.Text22(i + 1).Text
			//Xlsheet.Cells(70 + i, 4) = FrmZongti.Text32(i + 15).Text
			//Xlsheet.Cells(70 + i, 6) = FrmZongti.Text32(i + 8).Text
			//Xlsheet.Cells(70 + i, 8) = FrmZongti.Text32(i + 1).Text
			//
			//'If Abs(Val(FrmZongti.Text32(i).Text)) > Val(FrmZongti.Text33(i).Text) Then
			//     Xlsheet.Cells(70 + i, 11) = "合格"
			//'Else
			//'     Xlsheet.Cells(70 + i, 11) = "合格"
			//'End If
			//
			//Next i
			//For i = 6 To 7
			//Xlsheet.Cells(70 + i, 1) = dyZsNo(i + 1)
			//Xlsheet.Cells(70 + i, 2) = FrmZongti.Text22(i + 1).Text
			//Xlsheet.Cells(70 + i, 4) = FrmZongti.Text32(i + 19).Text
			//Xlsheet.Cells(70 + i, 6) = FrmZongti.Text32(i + 17).Text
			//Xlsheet.Cells(70 + i, 8) = FrmZongti.Text32(i + 15).Text
			//
			//'If Abs(Val(FrmZongti.Text32(i).Text)) > Val(FrmZongti.Text33(i).Text) Then
			//     Xlsheet.Cells(70 + i, 11) = "合格"
			//'Else
			//'     Xlsheet.Cells(70 + i, 11) = "合格"
			//'End If
			//
			//Next i
		}
		
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Zhengshu;
			//UPGRADE_WARNING: 未能解析对象 Zhengshu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Zhengshu = true;
			
			//UPGRADE_NOTE: 在对对象 Xlbook 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			Xlbook = null;
			//UPGRADE_NOTE: 在对对象 XlApp 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			XlApp = null;
			
			this.Hide();
			//Form2.Show
			
		}
		
		public void frmzjsj_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			DTPicker1.Year = DateAndTime.Year(DateAndTime.Today);
			DTPicker1.Month = DateAndTime.Month(DateAndTime.Today);
			DTPicker1.Day = VB.DateAndTime.Day(DateAndTime.Today);
			DTPicker2.Year = DateAndTime.Year(DateAndTime.Today);
			DTPicker2.Month = DateAndTime.Month(DateAndTime.Today);
			DTPicker2.Day = VB.DateAndTime.Day(DateAndTime.Today);
			
			this.Height = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(8655));
			this.Width = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(7785));
			Text1.Text = Mdlguanfa.Zs[0];
			//     Text2(1).Text = Zs(1)
			Text2[0].Text = Mdlguanfa.Zs[2];
			Text2[17].Text = Mdlguanfa.Zs[3];
			Text2[2].Text = Mdlguanfa.Zs[4];
			Text2[3].Text = Mdlguanfa.Zs[5];
			Text2[5].Text = Mdlguanfa.Zs[6];
			Text2[11].Text = Mdlguanfa.Zs[7];
			Text2[19].Text = Mdlguanfa.Zs[8];
			Text2[9].Text = Mdlguanfa.Zs[9];
			Text2[10].Text = Mdlguanfa.Zs[10];
			Text2[21].Text = Mdlguanfa.Zs[11];
			
			Text2[7].Text = Mdlguanfa.Zs[14];
			Text2[8].Text = Mdlguanfa.Zs[15];
			Text2[12].Text = Mdlguanfa.Zs[16];
			Text2[18].Text = Mdlguanfa.Zs[17];
			Text2[6].Text = Mdlguanfa.Zs[18];
			Text2[13].Text = Mdlguanfa.Zs[19];
			Text2[14].Text = Mdlguanfa.Zs[20];
			Text2[20].Text = Mdlguanfa.Zs[21];
			Text2[4].Text = Mdlguanfa.Zs[22];
			
			
			
			
			
		}
	}
}
