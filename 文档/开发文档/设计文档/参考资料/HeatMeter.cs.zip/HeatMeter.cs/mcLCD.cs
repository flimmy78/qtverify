// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	internal class mcLCD
	{
		
		
		
		public struct Coordinate
		{
			public short x;
			public short y;
		}
		
		Coordinate BasePoint;
		
		short SegWidth;
		short SegHeight;
		
		System.Windows.Forms.PictureBox p;
public int BackColor
		{
			set
			{
				
				p.BackColor = System.Drawing.ColorTranslator.FromOle(value);
				
			}
		}
		
		
public string Caption
		{
			set
			{
				short OrigX = 0;
				
				OrigX = BasePoint.x;
				//UPGRADE_ISSUE: PictureBox 方法 p.Cls 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
				p.Cls();
				
				while (value != "")
				{
					if (value.Substring(0, 1) != ":")
					{
						DrawNumber((short) (Conversion.Val(value.Substring(0, 1))));
						BasePoint.x = (short) (BasePoint.x + SegWidth + 3);
					}
					else
					{
						//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
						p.Line(BasePoint.x + (SegWidth / 2) - 4, BasePoint.y + (SegHeight / 2) - 6) - (BasePoint.x + (SegWidth / 2)), ;BasePoint.y + (SegHeight / 2) - 3;);, ;BF;
						//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
						p.Line(BasePoint.x + (SegWidth / 2) - 4, BasePoint.y + (SegHeight / 2) + 4) - (BasePoint.x + (SegWidth / 2)), ;BasePoint.y + (SegHeight / 2) + 7;);, ;BF;
						BasePoint.x = BasePoint.x + SegWidth;
					}
					value = value.Substring(value.Length - (value.Length - 1), value.Length - 1);
				}
				
				BasePoint.x = OrigX;
				
			}
		}
public int ForeColor
		{
			set
			{
				
				p.ForeColor = System.Drawing.ColorTranslator.FromOle(value);
				
			}
		}
		
		private void DrawNumber(short number)
		{
			
			switch (number)
			{
				case (short) 0:
					DrawSegment((short) (1));
					DrawSegment((short) (2));
					DrawSegment((short) (3));
					DrawSegment((short) (4));
					DrawSegment((short) (5));
					DrawSegment((short) (6));
					break;
				case (short) 1:
					DrawSegment((short) (2));
					DrawSegment((short) (3));
					break;
				case (short) 2:
					DrawSegment((short) (1));
					DrawSegment((short) (2));
					DrawSegment((short) (7));
					DrawSegment((short) (5));
					DrawSegment((short) (4));
					break;
				case (short) 3:
					DrawSegment((short) (1));
					DrawSegment((short) (2));
					DrawSegment((short) (7));
					DrawSegment((short) (3));
					DrawSegment((short) (4));
					break;
				case (short) 4:
					DrawSegment((short) (2));
					DrawSegment((short) (3));
					DrawSegment((short) (7));
					DrawSegment((short) (6));
					break;
				case (short) 5:
					DrawSegment((short) (1));
					DrawSegment((short) (6));
					DrawSegment((short) (7));
					DrawSegment((short) (3));
					DrawSegment((short) (4));
					break;
				case (short) 6:
					DrawSegment((short) (1));
					DrawSegment((short) (6));
					DrawSegment((short) (7));
					DrawSegment((short) (3));
					DrawSegment((short) (4));
					DrawSegment((short) (5));
					break;
				case (short) 7:
					DrawSegment((short) (1));
					DrawSegment((short) (2));
					DrawSegment((short) (3));
					break;
				case (short) 8:
					DrawSegment((short) (1));
					DrawSegment((short) (2));
					DrawSegment((short) (3));
					DrawSegment((short) (4));
					DrawSegment((short) (5));
					DrawSegment((short) (6));
					DrawSegment((short) (7));
					break;
				case (short) 9:
					DrawSegment((short) (1));
					DrawSegment((short) (2));
					DrawSegment((short) (3));
					DrawSegment((short) (4));
					DrawSegment((short) (6));
					DrawSegment((short) (7));
					break;
			}
			
		}
		
		
		private void DrawSegment(short SegNum)
		{
			
			//
			//      1
			//     ___
			//    |   |
			// 6  |   |  2
			//    |-7-|
			// 5  |   |  3
			//    |___|
			//
			//      4
			//
			
			switch (SegNum)
			{
				case (short) 1:
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 1, BasePoint.y) - (BasePoint.x + SegWidth - 1);, ;BasePoint.y;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 2, BasePoint.y + 1) - (BasePoint.x + SegWidth - 2);, ;BasePoint.y + 1;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 3, BasePoint.y + 2) - (BasePoint.x + SegWidth - 3);, ;BasePoint.y + 2;);
					break;
				case (short) 2:
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + SegWidth - 1, BasePoint.y + 1) - (BasePoint.x + SegWidth - 1);, ;BasePoint.y + (SegHeight / 2) - 1;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + SegWidth - 2, BasePoint.y + 2) - (BasePoint.x + SegWidth - 2);, ;BasePoint.y + (SegHeight / 2);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + SegWidth - 3, BasePoint.y + 3) - (BasePoint.x + SegWidth - 3);, ;BasePoint.y + (SegHeight / 2) - 1;);
					break;
				case (short) 3:
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + SegWidth - 1, BasePoint.y + (SegHeight / 2) + 2) - (BasePoint.x + SegWidth - 1);, ;BasePoint.y + SegHeight;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + SegWidth - 2, BasePoint.y + (SegHeight / 2) + 1) - (BasePoint.x + SegWidth - 2);, ;BasePoint.y + SegHeight - 1;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + SegWidth - 3, BasePoint.y + (SegHeight / 2) + 2) - (BasePoint.x + SegWidth - 3);, ;BasePoint.y + SegHeight - 2;);
					break;
				case (short) 4:
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 3, BasePoint.y + SegHeight - 2) - (BasePoint.x + SegWidth - 3);, ;BasePoint.y + SegHeight - 2;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 2, BasePoint.y + SegHeight - 1) - (BasePoint.x + SegWidth - 2);, ;BasePoint.y + SegHeight - 1;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 1, BasePoint.y + SegHeight) - (BasePoint.x + SegWidth - 1);, ;BasePoint.y + SegHeight;);
					break;
				case (short) 5:
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x, BasePoint.y + (SegHeight / 2) + 2) - (BasePoint.x);, ;BasePoint.y + SegHeight;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 1, BasePoint.y + (SegHeight / 2) + 1) - (BasePoint.x + 1);, ;BasePoint.y + SegHeight - 1;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 2, BasePoint.y + (SegHeight / 2) + 2) - (BasePoint.x + 2);, ;BasePoint.y + SegHeight - 2;);
					break;
				case (short) 6:
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x, BasePoint.y + 1) - (BasePoint.x);, ;BasePoint.y + (SegHeight / 2) - 1;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 1, BasePoint.y + 2) - (BasePoint.x + 1);, ;BasePoint.y + (SegHeight / 2);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 2, BasePoint.y + 3) - (BasePoint.x + 2);, ;BasePoint.y + (SegHeight / 2) - 1;);
					break;
				case (short) 7:
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 3, BasePoint.y + (SegHeight / 2) - 1) - (BasePoint.x + SegWidth - 3);, ;BasePoint.y + (SegHeight / 2) - 1;);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 2, BasePoint.y + (SegHeight / 2)) - (BasePoint.x + SegWidth - 2);, ;BasePoint.y + (SegHeight / 2);
					//UPGRADE_ISSUE: PictureBox 方法 p.Line 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
					p.Line(BasePoint.x + 3, BasePoint.y + (SegHeight / 2) + 1) - (BasePoint.x + SegWidth - 3);, ;BasePoint.y + (SegHeight / 2) + 1;);
					break;
			}
			
		}
		
		public void NewLCD(System.Windows.Forms.PictureBox PBox)
		{
			
			p = PBox;
			
			//UPGRADE_ISSUE: PictureBox 属性 p.ScaleMode 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
			p.ScaleMode = 3; // pixel
			//UPGRADE_ISSUE: PictureBox 属性 p.AutoRedraw 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
			P.AutoRedraw = true;
			
			BasePoint.x = (short) 2;
			BasePoint.y = (short) 2;
			
			SegHeight = (short) (Microsoft.VisualBasic.Compatibility.VB6.Support.PixelsToTwipsY(p.ClientRectangle.Height) - 6);
			SegWidth = System.Convert.ToInt16((SegHeight / 2) + 2);
			
		}
	}
}
