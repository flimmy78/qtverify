// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class Frmxs : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static Frmxs defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static Frmxs Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new Frmxs();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		
		short i;
		
		short[] M = new short[10];
		
		float Leiji;
		short Fdizhi;
		short Fzhi;
		short Fzhi1;
		short Fzhi2;
		byte[] Fd = new byte[7];
		
		byte[] fs = new byte[1];
		double Tj1;
		double Tj2;
		double Tj3;
		short j;
		short Js;
		string Wenducaiji;
		short Wendujisuan;
		short Jssl;
		float Ljsl;
		bool Jiashui;
		
		object YF12;
		object XF12;
		object XF11;
		object YF11;
		object XF1;
		float YF1;
		object YF22;
		object XF22;
		object XF21;
		object YF21;
		object XF2;
		float YF2;
		object YF32;
		object XF32;
		object XF31;
		object YF31;
		object XF3;
		float YF3;
		object YF42;
		object XF42;
		object XF41;
		object YF41;
		object XF4;
		float YF4;
		object YF52;
		object XF52;
		object XF51;
		object YF51;
		object XF5;
		float YF5;
		object YF62;
		object XF62;
		object XF61;
		object YF61;
		object XF6;
		float YF6;
		object ZF4;
		object ZF2;
		object ZF1;
		object ZF3;
		object ZF5;
		short ZF6;
		
		public void cmdQuit_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Text15.Text = Text13.Text;
		}
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Text14.Text = Text13.Text;
		}
		
		public void Frmxs_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object MSComm4 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.Frmxsactive = true;
			//MsgBox "重要说明：请将标准表脉冲输入串口临时接至标准温度计串口处！"
			for (i = 0; i <= 7; i++)
			{
				Text1[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1060)));
				Text1[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(850)));
				Text1[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900)));
				Text1[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 1035)));
				Text9[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1060)));
				Text9[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text9[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(10030)));
				Text9[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 1035)));
				Text10[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1060)));
				Text10[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text10[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(11210)));
				Text10[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 1035)));
			}
			
			Text10[7].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1050)));
			Text9[7].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1050)));
			Text1[7].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1050)));
			
			for (i = 1; i <= 9; i++)
			{
				Text11[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text11[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(930)));
			}
			Text11[1].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1740)));
			Text11[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2930)));
			Text11[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4110)));
			Text11[4].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(5290)));
			Text11[5].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(6475)));
			Text11[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(7660)));
			Text11[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(8840)));
			Text11[8].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(10030)));
			Text11[9].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(11210)));
			
			for (i = 0; i <= 23; i++)
			{
				Text2[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360)));
				Text2[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text2[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1740)));
				Text2[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 345)));
				Text3[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360)));
				Text3[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text3[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2930)));
				Text3[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 345)));
				Text4[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360)));
				Text4[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text4[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4110)));
				Text4[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 345)));
				Text5[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360)));
				Text5[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text5[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(5290)));
				Text5[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 345)));
				Text6[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360)));
				Text6[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text6[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(6475)));
				Text6[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 345)));
				Text7[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360)));
				Text7[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text7[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(7660)));
				Text7[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 345)));
				Text8[i].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360)));
				Text8[i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1200)));
				Text8[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(8840)));
				Text8[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1400 + i * 345)));
			}
			
			for (i = 1; i <= 7; i++)
			{
				if (sub_Renamed.Ld4 == 3)
				{
					Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 4320 / 4)));
					if (i == 6)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (4 - 1) * 4320 / 4)));
					}
					if (i == 7)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 4320 / 4)));
					}
					Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 4320 / 4)));
					if (i == 6)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (4 - 1) * 4320 / 4)));
					}
					if (i == 7)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (5 - 1) * 4320 / 4)));
					}
					Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 4320 / 4)));
					if (i == 6)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (4 - 1) * 4320 / 4)));
					}
					if (i == 7)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (5 - 1) * 4320 / 4)));
					}
					Siajin[4].Visible = false;
					Siajin[5].Visible = false;
					Lab[4].Visible = false;
					Lab[5].Visible = false;
					Shapzsd[4].Visible = false;
					Shapzsd[5].Visible = false;
					Lab[3].Text = "中流量阀";
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 4320 / 5)));
					if (i == 6)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (5 - 1) * 4320 / 5)));
					}
					if (i == 7)
					{
						Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (6 - 1) * 4320 / 5)));
					}
					Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 4320 / 5)));
					if (i == 6)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (5 - 1) * 4320 / 5)));
					}
					if (i == 7)
					{
						Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (6 - 1) * 4320 / 5)));
					}
					Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 4320 / 5)));
					if (i == 6)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (5 - 1) * 4320 / 5)));
					}
					if (i == 7)
					{
						Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (6 - 1) * 4320 / 5)));
					}
					Siajin[4].Visible = true;
					Siajin[5].Visible = false;
					Lab[4].Visible = true;
					Lab[5].Visible = false;
					Lab[3].Text = "中流一阀";
					Shapzsd[4].Visible = true;
					Shapzsd[5].Visible = false;
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					Siajin[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360 + (i - 1) * 4320 / 6)));
					Lab[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 4320 / 6)));
					Shapzsd[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(480 + (i - 1) * 4320 / 6)));
					Siajin[4].Visible = true;
					Siajin[5].Visible = true;
					Lab[4].Visible = true;
					Lab[5].Visible = true;
					Lab[3].Text = "中流一阀";
					Shapzsd[4].Visible = true;
					Shapzsd[5].Visible = true;
				}
			}
			
			
			if (sub_Renamed.MID3 == 0)
			{
				Opda.Enabled = false;
			}
			else if (sub_Renamed.MID3 == 1)
			{
				Opda.Text = "DN15表";
			}
			else if (sub_Renamed.MID3 == 2)
			{
				Opda.Text = "DN25表";
			}
			if (sub_Renamed.MID4 == 0)
			{
				OpZhong.Enabled = false;
			}
			else if (sub_Renamed.MID4 == 1)
			{
				OpZhong.Text = "DN6表";
			}
			else if (sub_Renamed.MID4 == 2)
			{
				OpZhong.Text = "DN10表";
			}
			if (sub_Renamed.MID5 == 0)
			{
				Opxiao.Enabled = false;
			}
			else if (sub_Renamed.MID5 == 1)
			{
				Opxiao.Text = "DN2表";
			}
			else if (sub_Renamed.MID5 == 2)
			{
				Opxiao.Text = "DN3表";
			}
			
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer3.Enabled = false;
			
			
			
			
			TPcom();
			sub_Renamed.delay_times(1);
			
			Jiashui = false;
			
			comm.Default.MSComm1.CommPort = sub_Renamed.Com1;
			MSComm2.CommPort = sub_Renamed.Com2;
			MSComm2.RThreshold = (short) 30;
			
			if (sub_Renamed.Bizerba == true || sub_Renamed.Mettler == true)
			{
				MSComm2.InputMode = ;;
			}
			else
			{
				MSComm2.InputMode = ;;
			}
			
			MSComm5.CommPort = sub_Renamed.Com3; //温度
			comm.Default.MSComm4.CommPort = sub_Renamed.Com16; //标准表累流
			
			//UPGRADE_WARNING: 未能解析对象 MSComm4.PortOpen 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (comm.Default.MSComm4.PortOpen == true)
			{
				mSComm4.PortOpen = false;
			}
			
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			sub_Renamed.delay_times(1);
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			if (comm.Default.MSComm4.PortOpen == false)
			{
				comm.Default.MSComm4.PortOpen = true;
			}
			if (MSComm2.PortOpen == false)
			{
				MSComm2.PortOpen = true;
			}
			
			
			
			
			MSComm5.RThreshold = (short) 10;
			MSComm5.InputMode = ;;
			MSComm5.Settings = "9600,n,8,2"; //strCommPara
			//   MSComm5.PortOpen = True
			
			Js = (short) 0;
			Timer1.Enabled = true;
			Timer2.Enabled = true;
			Timer3.Enabled = true;
		}
		
		
		
		public void Frmxs_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			object MSComm4 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer3.Enabled = false;
			
			Jiashui = false;
			//UPGRADE_WARNING: 未能解析对象 MSComm4.PortOpen 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (comm.Default.MSComm4.PortOpen == true)
			{
				MSComm4.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			//MsgBox "重要说明：请将标准温度计串口接至原处！"
			sub_Renamed.Frmxsactive = false;
		}
		
		
		
		public void Label4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Text13.Text = (0).ToString();
		}
		
		// VBConversions Note: Former VB static variables moved to class level because they aren't supported in C#.
		private int MSComm2_OnComm_xian;
		
		public void MSComm2_OnComm(System.Object eventSender, System.EventArgs eventArgs)
		{
			object danwei;
			object mtype;
			object quality = null;
			object mass = null;
			object arg;
			object dot = null;
			object statusC;
			object Statusb = null;
			object Statusa = null;
			object fuhao;
			object s1 = null;
			object s5 = null;
			object s3;
			object s6 = null;
			object s2 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object guo = null;
			object foot1;
			object head1;
			object head2;
			object foot2;
			// static int xian; VBConversions Note: Static variable moved to class level and renamed MSComm2_OnComm_xian. Local static variables are not supported in C#.
			if (sub_Renamed.Satorius == true)
			{
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s2 = Strings.Trim(System.Convert.ToString(MSComm2.Input));
						sub_Renamed.Tpcj1++;
						if (sub_Renamed.Tpcj1 > 3000)
						{
							sub_Renamed.Tpcj1 = (short) 5;
						}
						if (sub_Renamed.Tpcj1 > 2)
						{
							for (i = 1; i <= 30; i++)
							{
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s6 = Strings.Mid(System.Convert.ToString(s2), i, 1);
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s3 = Strings.Mid(System.Convert.ToString(s2), i + 13, 1);
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s5 = Strings.Mid(System.Convert.ToString(s2), i, 5);
								//UPGRADE_WARNING: 未能解析对象 s5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if (Strings.StrComp(System.Convert.ToString(s5), "0.000", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									Text3[24].Text = (0).ToString();
									return;
								}
								//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if (Strings.StrComp(System.Convert.ToString(s6), "+", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									Text3[24].Text = Strings.Mid(System.Convert.ToString(s2), i + 1, 9).Trim();
									break;
									//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								}
								else if (Strings.StrComp(System.Convert.ToString(s6), "-", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									Text3[24].Text = "-" + Strings.Mid(System.Convert.ToString(s2), i + 1, 9).Trim();
									break;
								}
							}
						}
						break;
						
					default:
						break;
				}
				
			}
			else if (sub_Renamed.Bizerba == true)
			{
				
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s2 = MSComm2.Input;
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						for (i = 1; i <= (s2); i++)
						{
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 head1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							head1 = Strings.Chr(System.Convert.ToInt32((MidB(s2, i, 1))));
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 head2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							head2 = Strings.Chr(System.Convert.ToInt32((MidB(s2, i + 1, 1))));
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 foot1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							foot1 = Conversion.Hex((MidB(s2, i + 13, 1)));
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 foot2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							foot2 = Conversion.Hex((MidB(s2, i + 14, 1)));
							//UPGRADE_WARNING: 未能解析对象 foot2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 foot1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 head2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 head1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (((string) head1 == "S" && (string) head2 == "T" && (string) foot1 == "D" && (string) foot2 == "A") || ((string) head1 == "U" && (string) head2 == "S" && (string) foot1 == "D" && (string) foot2 == "A"))
							{
								for (j = () (i + 3)); j <= i + 10; j++) //LenB(s2)
								{
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = "";
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 1, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 2, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 3, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 4, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 5, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 6, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 7, 1))));
									break;
								}
								//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								guo = Strings.Trim(System.Convert.ToString(guo));
								//                        If IsNumeric(guo) = False Then GoTo err
								break;
							}
						}
						//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Text3[24].Text = () );guo;
						break;
						
					default:
						break;
				}
				
				
			}
			else if (sub_Renamed.Mettler == true)
			{
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s1 = MSComm2.Input;
						//            Text5.Text = ""
						//            Text6.Text = ""
						//            For i = 1 To LenB(s1)
						//                    Text6.Text = Text6.Text + Hex(AscB(MidB(s1, i, 1)))
						//            Next i
						//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						fuhao = "";
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						if ((s1) < 17)
						{
							return; //没有校验和
						}
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						for (i = 1; i <= (s1); i++)
						{
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							if ((MidB(s1, i, 1)) == 2 && AscB(MidB(s1, i + 16, 1)) == 0xD)
							{
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 Statusa 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Statusa = (MidB(s1, i + 1, 1));
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 Statusb 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Statusb = (MidB(s1, i + 2, 1));
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 statusC 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								statusC = (MidB(s1, i + 3, 1));
								//UPGRADE_WARNING: 未能解析对象 dot 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								dot = Statusa & 7;
								//UPGRADE_WARNING: 未能解析对象 arg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								arg = Statusa & 0x18;
								// mass = Val(Chr(AscB(MidB(s1, i + 4, 1)))) * 100000
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 5, 1))))) * 10000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 6, 1))))) * 1000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 7, 1))))) * 100;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 8, 1))))) * 10;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 9, 1)))));
								//quality = Val(Chr(AscB(MidB(s1, i + 10, 1)))) * 100000
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 11, 1))))) * 10000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 12, 1))))) * 1000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 13, 1))))) * 100;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 14, 1))))) * 10;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, i + 15, 1)))));
								
								if ((int) dot == 1)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToInt32(mass) * 10 - 1000000;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToInt32(quality) * 10 - 1000000;
								}
								else if ((int) dot == 2)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = mass;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = quality;
								}
								else if ((int) dot == 3)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.1;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.1;
								}
								else if ((int) dot == 4)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.01;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.01;
								}
								else if ((int) dot == 5)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.001;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.001;
								}
								//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mtype = Statusb & 1;
								//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								fuhao = Statusb & 2;
								//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								danwei = Statusb & 0x10;
								//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) fuhao == 2)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToInt32(- mass);
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToInt32(- quality);
								}
								//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) danwei == 0)
								{
									danwei = "磅";
								}
								else
								{
									//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									danwei = "千克";
								}
								//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) mtype == 0)
								{
									mtype = "毛重";
								}
								else
								{
									//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mtype = "净重";
								}
								///'''''''''''''''显示毛重和皮重或者显示净重和皮重,毛重=净重+皮重
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Text3[24].Text = Conversion.Str(mass); //+ danwei '+ ",皮重" + Str(quality) + danwei
								break;
							}
						}
						break;
						
					default:
						break;
				}
				
				
			}
			
			
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Opda.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Opda_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (sub_Renamed.MID1 == 2)
				{
					if (Opda.Text == "DN15表")
					{
						//     Labt.Caption = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.015/0.03/0.05/0.07/0.10/0.15/0.25/0.35/0.50。流量点处请填写瞬时流量显示实际值"
					}
					else if (Opda.Text == "DN25表")
					{
						Labt.Text = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.4/0.5/0.7/1.05/1.5/2.5/3.5/4.0/5.0/7.0。流量点处请填写瞬时流量显示实际值";
					}
				}
				else if (sub_Renamed.MID1 == 3)
				{
					if (Opda.Text == "DN15表")
					{
						//     Labt.Caption = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.06/0.1/0.15/0.25/0.36/0.40/0.50。流量点处请填写瞬时流量显示实际值"
					}
					else if (Opda.Text == "DN25表")
					{
						Labt.Text = "提示：请依次检定下列流量点(m3/h)附近的K系数: 1.0/1.25/1.5/2.5/3.5/4.0/5.0/7.0。流量点处请填写瞬时流量显示实际值";
					}
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Opxiao.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Opxiao_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (sub_Renamed.MID1 == 2)
				{
					//   If Opxiao.Caption = "DN2表" Then
					//      Labt.Caption = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.015/0.03/0.04/0.05/0.06/0.07。流量点处请填写瞬时流量显示实际值"
					//   ElseIf Opxiao.Caption = "DN3表" Then
					//      Labt.Caption = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.015/0.03/0.04/0.05/0.06/0.07/0.08/0.10/0.12。流量点处请填写瞬时流量显示实际值"
					//   End If
				}
				else if (sub_Renamed.MID1 == 3)
				{
					if (Opxiao.Text == "DN2表")
					{
						//      Labt.Caption = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.015/0.03/0.04/0.05/0.06/0.07。流量点处请填写瞬时流量显示实际值"
					}
					else if (Opxiao.Text == "DN3表")
					{
						Labt.Text = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.015/0.03/0.04/0.05/0.06/0.07/0.08/0.10/0.12。流量点处请填写瞬时流量显示实际值";
					}
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 OpZhong.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void OpZhong_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (sub_Renamed.MID1 == 2)
				{
					if (OpZhong.Text == "DN6表")
					{
						Labt.Text = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.015/0.03/0.05/0.07/0.10/0.15/0.25/0.35/0.50。流量点处请填写瞬时流量显示实际值";
					}
					else if (OpZhong.Text == "DN10表")
					{
						//     Labt.Caption = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.015/0.03/0.05/0.07/0.15/0.25/0.35/0.50/0.7/1.05/1.2。流量点处请填写瞬时流量显示实际值"
					}
				}
				else if (sub_Renamed.MID1 == 3)
				{
					if (OpZhong.Text == "DN6表")
					{
						//     Labt.Caption = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.06/0.1/0.15/0.25/0.36/0.40/0.50。流量点处请填写瞬时流量显示实际值"
					}
					else if (OpZhong.Text == "DN10表")
					{
						Labt.Text = "提示：请依次检定下列流量点(m3/h)附近的K系数: 0.10/0.12/0.15/0.25/0.35/0.45/0.5/0.7/1.05/1.2。流量点处请填写瞬时流量显示实际值";
					}
				}
			}
		}
		
		public void qd_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//comm.MSComm1.CommPort = Com1
			//If comm.MSComm1.PortOpen = False Then comm.MSComm1.PortOpen = True
			
			Mdlguanfa.Send_Data((short) 249);
			
			sub_Renamed.delay_times(1);
		}
		
		public void qingl_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			for (i = 0; i <= 23; i++)
			{
				
				Text2[i].Text = "";
				Text3[i].Text = "";
				Text4[i].Text = "";
				Text5[i].Text = "";
				Text6[i].Text = "";
				Text7[i].Text = "";
				Text8[i].Text = "";
			}
			
			for (j = 0; j <= 7; j++)
			{
				Text1[j].Text = "";
				Text9[j].Text = "";
				Text10[j].Text = "";
			}
		}
		
		public void Siajin_Enter(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Siajin.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Command1.Focus();
			if ([Index;].value == true;);
			{
				Mdlguanfa.Zhu_Kai(ref Index);
			}
			else
			{
				Mdlguanfa.Zhu_Guan(ref Index);
				
			}
			
			
		}
		
		
		
		public void SSCommand1_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.Title = "保存数据";
			//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			msg = Interaction.MsgBox("请你确认将表格中新的所有仪表系数覆盖原全部仪表系数？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
			if (msg == MsgBoxResult.Yes)
			{
				if (Opxiao.Checked == true)
				{
					sub_Renamed.StrSql = "select * from bzbbd ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					sub_Renamed.RsZbs.MoveFirst();
					//       RsZbs.Edit
					
					for (i = 0; i <= 10; i++)
					{
						sub_Renamed.RsZbs.Fields[i].Value = "";
						sub_Renamed.RsZbs.Fields[i + 11].Value = "";
					}
					
					for (i = 0; i <= 7; i++)
					{
						if (Text1[i].Text == "")
						{
							break;
						}
						sub_Renamed.RsZbs.Fields[i].Value = Strings.Trim(System.Convert.ToString(Text1[i].Text));
						sub_Renamed.RsZbs.Fields[i + 11].Value = Strings.Trim(System.Convert.ToString(Text9[i].Text));
						sub_Renamed.RsZbs.Fields["bz"].Value = "1";
					}
					
					sub_Renamed.RsZbs.Update(null, null);
					sub_Renamed.RsZbs.Close();
					
				}
				else if (OpZhong.Checked == true)
				{
					
					sub_Renamed.StrSql = "select * from bzbbd1 ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					sub_Renamed.RsZbs.MoveFirst();
					//       RsZbs.Edit
					i = (short) 0;
					
					for (i = 0; i <= 10; i++)
					{
						sub_Renamed.RsZbs.Fields[i].Value = "";
						sub_Renamed.RsZbs.Fields[i + 11].Value = "";
					}
					
					for (i = 0; i <= 7; i++)
					{
						if (Text1[i].Text == "")
						{
							break;
						}
						sub_Renamed.RsZbs.Fields[i].Value = Strings.Trim(System.Convert.ToString(Text1[i].Text));
						sub_Renamed.RsZbs.Fields[i + 11].Value = Strings.Trim(System.Convert.ToString(Text9[i].Text));
						sub_Renamed.RsZbs.Fields["bz"].Value = "2";
					}
					
					sub_Renamed.RsZbs.Update(null, null);
					sub_Renamed.RsZbs.Close();
				}
				else if (Opda.Checked == true)
				{
					
					sub_Renamed.StrSql = "select * from bzbbd2 ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					sub_Renamed.RsZbs.MoveFirst();
					//       RsZbs.Edit
					i = (short) 0;
					
					for (i = 0; i <= 10; i++)
					{
						sub_Renamed.RsZbs.Fields[i].Value = "";
						sub_Renamed.RsZbs.Fields[i + 11].Value = "";
					}
					
					for (i = 0; i <= 7; i++)
					{
						if (Text1[i].Text == "")
						{
							break;
						}
						sub_Renamed.RsZbs.Fields[i].Value = Strings.Trim(System.Convert.ToString(Text1[i].Text));
						sub_Renamed.RsZbs.Fields[i + 11].Value = Strings.Trim(System.Convert.ToString(Text9[i].Text));
						sub_Renamed.RsZbs.Fields["bz"].Value = "3";
					}
					
					sub_Renamed.RsZbs.Update(null, null);
					sub_Renamed.RsZbs.Close();
					
				}
				
				return;
			}
			else if (msg == MsgBoxResult.No)
			{
				
				return;
			}
		}
		
		public void tc_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short z = 0;
			Module1.strSource = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\xishu.xlt";
			
			sub_Renamed.XlApp = new Microsoft.Office.Interop.Excel.Application();
			sub_Renamed.XlApp = () (Interaction.CreateObject("Excel.Application", "")));
			sub_Renamed.XlApp.Visible = true; // False
			sub_Renamed.Xlbook = sub_Renamed.XlApp.Workbooks.Open(Module1.strSource, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
			sub_Renamed.Xlsheet = () (sub_Renamed.Xlbook.Worksheets[1]));
			for (z = 0; z <= 7; z++)
			{
				
				//       xlsheet.Cells(z, 1) = Trim(Text1(z).Text)
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z * 3 + 3, 1] = Strings.Trim(System.Convert.ToString(Text1[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z * 3 + 3, 9] = Strings.Trim(System.Convert.ToString(Text9[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z * 3 + 3, 10] = Strings.Trim(System.Convert.ToString(Text10[z].Text));
				
				
			}
			for (z = 0; z <= 23; z++)
			{
				
				//       xlsheet.Cells(z, 1) = Trim(Text1(z).Text)
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z + 3, 2] = Strings.Trim(System.Convert.ToString(Text2[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z + 3, 3] = Strings.Trim(System.Convert.ToString(Text3[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z + 3, 4] = Strings.Trim(System.Convert.ToString(Text4[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z + 3, 5] = Strings.Trim(System.Convert.ToString(Text5[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z + 3, 6] = Strings.Trim(System.Convert.ToString(Text6[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z + 3, 7] = Strings.Trim(System.Convert.ToString(Text7[z].Text));
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[z + 3, 8] = Strings.Trim(System.Convert.ToString(Text8[z].Text));
				
			}
			
		}
		
		private void Tdll_Change()
		{
			object Tdll = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Tdll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Conversion.Val((Tdll.Text > 100).ToString()) || Conversion.Val(Tdll.Text) < 0)
			{
				Tdll.Text = 50;
			}
			
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			
			
			
			//UPGRADE_WARNING: 未能解析对象 Tdll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Fzhi = System.Convert.ToInt16(Conversion.Int(Conversion.Val(Tdll.Text) * 40.95 / 256));
			//UPGRADE_WARNING: 未能解析对象 Tdll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			Fzhi1 = System.Convert.ToInt16((Conversion.Val(Tdll.Text) * 40.95) % 256);
			
			Fd[0] = (byte) 255;
			Fd[1] = (byte) 242;
			Fd[2] = Fzhi;
			Fd[3] = Fzhi1;
			Fd[4] = (byte) 254;
			
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Fd);
			sub_Renamed.delay_times((0.1));F;);
			
			
			
		}
		
		
		
		public void text15_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			if (KeyAscii == 13)
			{
				Text16.Text = Text16.Text(Conversion.Val(Text15.Text) - Conversion.Val(Text14.Text), "0.000");
				//  Text7(Index).Text = Text16.Text
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text15.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text15_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			
			Text16.Text = Text16.Text(Conversion.Val(Text15.Text) - Conversion.Val(Text14.Text), "0.000");
			//  Text7(Index).Text = Text16.Text
			
		}
		
		public void Text2_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text2.GetIndex(eventSender);
			if (KeyAscii == 13)
			{
				Text3[Index].Focus();
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Text3_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text3.GetIndex(eventSender);
			if (KeyAscii == 13)
			{
				Text4[Index].Text = Text4(Conversion.Val(Text3[Index].Text) - Conversion.Val(Text2[Index].Text), "0.000");
				//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text5[Index].Text = Text5(mdlyingpanxuliehao.MiDu(System.Convert.ToString(Text3[26].Text)), "0.000");
				if (Conversion.Val(Text5[Index].Text) > 0)
				{
					Text6[Index].Text = Text6(Conversion.Val(Text4[Index].Text) / Conversion.Val(Text5[Index].Text) * 0.9971, "0.0000");
				}
				Text7[Index].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text3.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text3_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text3.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Index == 24)
			{
				
				if (Conversion.Val(Text3[24].Text) >= 105)
				{
					System.Int32 temp_i = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i);
					sub_Renamed.delay_times(1);
					
					System.Int32 temp_i2 = 6;
					Mdlguanfa.Zhu_Guan(ref temp_i2);
					sub_Renamed.delay_times(1);
					if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
					{
						System.Int32 temp_i3 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i3); //中流量开2
						sub_Renamed.delay_times(1);
					}
					if (sub_Renamed.Ld4 == 5)
					{
						System.Int32 temp_i4 = 5;
						Mdlguanfa.Zhu_Guan(ref temp_i4); //中流量开3
						sub_Renamed.delay_times(1);
					}
					System.Int32 temp_i5 = 3;
					Mdlguanfa.Zhu_Guan(ref temp_i5);
					sub_Renamed.delay_times(1);
					System.Int32 temp_i6 = 2;
					Mdlguanfa.Zhu_Guan(ref temp_i6);
					sub_Renamed.delay_times(1);
					Mdlguanfa.Send_Data((short) 250); //
					sub_Renamed.delay_times(1);
					
					
					if (sub_Renamed.Chinese == true)
					{
						MessageBox.Show("超出天平最大秤量，本次检定数据无效，请退出子程序并重新开始检定");
					}
					else
					{
						MessageBox.Show("Beyond the largest weighing scale, the test was terminated, please exit and restart the program");
					}
					return;
				}
			}
		}
		public void Text5_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text5.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text3[Index].Focus();
			}
			
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text6.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text6_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text6.GetIndex(eventSender);
			if (Conversion.Val(Text7[Index].Text) > 0)
			{
				Text8[Index].Text = Text8(Conversion.Val(Text6[Index].Text) / Conversion.Val(Text7[Index].Text), "0.0000");
			}
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text7.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text7_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text7.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Conversion.Val(Text7[Index].Text) > 0)
			{
				Text8[Index].Text = Text8(Conversion.Val(Text6[Index].Text) / Conversion.Val(Text7[Index].Text), "0.0000");
			}
			
			
		}
		
		public void Text7_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text7.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text2[Index + 1].Focus();
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text8.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text8_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text8.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			float Max1 = 0;
			float Min1 = 0;
			if (Index == 0 | Index == 1 | Index == 2)
			{
				Max1 = 0;
				
				Text9[0].Text = Text9((Conversion.Val(Text8[0].Text) + Conversion.Val(Text8[1].Text) + Conversion.Val(Text8[2].Text)) / 3, "0.0000");
				for (i = 0; i <= 2; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 0; i <= 2; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[0].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[0].Text) - Conversion.Val(Text9[0].Text)), 2) + Math.Pow((Conversion.Val(Text8[1].Text) - Conversion.Val(Text9[0].Text)), 2) + Math.Pow((Conversion.Val(Text8[2].Text) - Conversion.Val(Text9[0].Text)), 2)) / 2) / Conversion.Val(Text9[0].Text) * 100, "0.00");
				
			}
			
			
			if (Index == 3 | Index == 4 | Index == 5)
			{
				Max1 = 0;
				
				Text9[1].Text = Text9((Conversion.Val(Text8[3].Text) + Conversion.Val(Text8[4].Text) + Conversion.Val(Text8[5].Text)) / 3, "0.0000");
				for (i = 3; i <= 5; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 3; i <= 5; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[1].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[3].Text) - Conversion.Val(Text9[1].Text)), 2) + Math.Pow((Conversion.Val(Text8[4].Text) - Conversion.Val(Text9[1].Text)), 2) + Math.Pow((Conversion.Val(Text8[5].Text) - Conversion.Val(Text9[1].Text)), 2)) / 2) / Conversion.Val(Text9[1].Text) * 100, "0.00");
				
				
			}
			
			
			if (Index == 6 | Index == 7 | Index == 8)
			{
				
				Max1 = 0;
				Text9[2].Text = Text9((Conversion.Val(Text8[6].Text) + Conversion.Val(Text8[7].Text) + Conversion.Val(Text8[8].Text)) / 3, "0.0000");
				for (i = 6; i <= 8; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 6; i <= 8; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[2].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[6].Text) - Conversion.Val(Text9[2].Text)), 2) + Math.Pow((Conversion.Val(Text8[7].Text) - Conversion.Val(Text9[2].Text)), 2) + Math.Pow((Conversion.Val(Text8[8].Text) - Conversion.Val(Text9[2].Text)), 2)) / 2) / Conversion.Val(Text9[2].Text) * 100, "0.00");
				
			}
			
			
			
			if (Index == 9 | Index == 10 | Index == 11)
			{
				Max1 = 0;
				Text9[3].Text = Text9((Conversion.Val(Text8[9].Text) + Conversion.Val(Text8[10].Text) + Conversion.Val(Text8[11].Text)) / 3, "0.0000");
				for (i = 9; i <= 11; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 9; i <= 11; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[3].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[9].Text) - Conversion.Val(Text9[3].Text)), 2) + Math.Pow((Conversion.Val(Text8[10].Text) - Conversion.Val(Text9[3].Text)), 2) + Math.Pow((Conversion.Val(Text8[11].Text) - Conversion.Val(Text9[3].Text)), 2)) / 2) / Conversion.Val(Text9[3].Text) * 100, "0.00");
				
				
			}
			
			if (Index == 12 | Index == 13 | Index == 14)
			{
				Max1 = 0;
				
				Text9[4].Text = Text9((Conversion.Val(Text8[12].Text) + Conversion.Val(Text8[13].Text) + Conversion.Val(Text8[14].Text)) / 3, "0.0000");
				for (i = 12; i <= 14; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 12; i <= 14; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[4].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[12].Text) - Conversion.Val(Text9[4].Text)), 2) + Math.Pow((Conversion.Val(Text8[13].Text) - Conversion.Val(Text9[4].Text)), 2) + Math.Pow((Conversion.Val(Text8[14].Text) - Conversion.Val(Text9[4].Text)), 2)) / 2) / Conversion.Val(Text9[4].Text) * 100, "0.00");
				
			}
			
			if (Index == 15 | Index == 16 | Index == 17)
			{
				Max1 = 0;
				
				Text9[5].Text = Text9((Conversion.Val(Text8[15].Text) + Conversion.Val(Text8[16].Text) + Conversion.Val(Text8[17].Text)) / 3, "0.0000");
				for (i = 15; i <= 17; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 15; i <= 17; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[5].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[15].Text) - Conversion.Val(Text9[5].Text)), 2) + Math.Pow((Conversion.Val(Text8[16].Text) - Conversion.Val(Text9[5].Text)), 2) + Math.Pow((Conversion.Val(Text8[17].Text) - Conversion.Val(Text9[5].Text)), 2)) / 2) / Conversion.Val(Text9[5].Text) * 100, "0.00");
				
			}
			
			
			
			if (Index == 18 | Index == 19 | Index == 20)
			{
				Max1 = 0;
				
				Text9[6].Text = Text9((Conversion.Val(Text8[18].Text) + Conversion.Val(Text8[19].Text) + Conversion.Val(Text8[20].Text)) / 3, "0.0000");
				for (i = 18; i <= 20; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 18; i <= 20; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[6].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[18].Text) - Conversion.Val(Text9[6].Text)), 2) + Math.Pow((Conversion.Val(Text8[19].Text) - Conversion.Val(Text9[6].Text)), 2) + Math.Pow((Conversion.Val(Text8[20].Text) - Conversion.Val(Text9[6].Text)), 2)) / 2) / Conversion.Val(Text9[6].Text) * 100, "0.00");
				
			}
			
			
			
			if (Index == 21 | Index == 22 | Index == 23)
			{
				
				Max1 = 0;
				Text9[7].Text = Text9((Conversion.Val(Text8[21].Text) + Conversion.Val(Text8[22].Text) + Conversion.Val(Text8[23].Text)) / 3, "0.0000");
				for (i = 21; i <= 23; i++)
				{
					if (Conversion.Val(Text8[i].Text) > Max1 || Conversion.Val(Text8[i].Text) == Max1)
					{
						Max1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				Min1 = 100;
				for (i = 21; i <= 23; i++)
				{
					if (Conversion.Val(Text8[i].Text) < Min1 || Conversion.Val(Text8[i].Text) == Min1)
					{
						Min1 = (float) (Conversion.Val(Text8[i].Text));
					}
				}
				
				Text10[7].Text = Text10(System.Math.Sqrt((Math.Pow((Conversion.Val(Text8[21].Text) - Conversion.Val(Text9[7].Text)), 2) + Math.Pow((Conversion.Val(Text8[22].Text) - Conversion.Val(Text9[7].Text)), 2) + Math.Pow((Conversion.Val(Text8[23].Text) - Conversion.Val(Text9[7].Text)), 2)) / 2) / Conversion.Val(Text9[7].Text) * 100, "0.00");
				
			}
		}
		
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Js++;
			if (Js == 5)
			{
				Js = (short) 1;
			}
			sub_Renamed.m_lngAddress = Js;
			
			
			if (MSComm5.PortOpen == false)
			{
				MSComm5.PortOpen = true;
			}
			
			Mdlguanfa.abytOrder[0] = (byte) (sub_Renamed.m_lngAddress | 0x80);
			Mdlguanfa.abytOrder[1] = (byte) (sub_Renamed.m_lngAddress | 0x80);
			Mdlguanfa.abytOrder[2] = (byte) (0x52);
			Mdlguanfa.abytOrder[3] = (byte) 0; // Val(txtPara(0).Text)
			Mdlguanfa.abytOrder[4] = (byte) 0;
			Mdlguanfa.abytOrder[5] = (byte) 0;
			
			//*  增加校验
			sub_Renamed.AddSum(ref Mdlguanfa.abytOrder, 0);
			//   labCommFlag = ""
			
			//*  发送命令
			MSComm5.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Mdlguanfa.abytOrder);
		}
		public void MSComm5_OnComm(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] abytReturnData = null;
			string strValue;
			int lngIndex;
			float sngValue = 0;
			switch (MSComm5.CommEvent)
			{
				case (short) 2:
					//UPGRADE_WARNING: 未能解析对象 MSComm5.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					abytReturnData = () );MSComm5.Input;
					
					sngValue = System.Convert.ToSingle(abytReturnData[1] * 256 + abytReturnData[0]);
					if (sngValue >= 32768)
					{
						sngValue = sngValue - 65536;
					}
					
					//'            If Js = 1 Then Text21.Text = sngValue / 10
					//'            If Js = 2 Then Text22.Text = sngValue / 10
					//            If Js = 1 Then Text3(4).Text = Format(sngValue / 10, "0.00")
					if (Js == 2)
					{
						Text3[26].Text = Text3(sngValue / 10, "0.00");
					}
					break;
				default:
					break;
					
			}
		}
		
		private void Timer11_Timer()
		{
			
		}
		
		public void Timer2_Tick(System.Object eventSender, System.EventArgs eventArgs) //累积流量
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short[] s = new short[23];
			short Recount = 0;
			object sss = null;
			string Rxd = "";
			byte[] hh = new byte[1];
			hh[0] = (byte) 253;
			if (comm.Default.MSComm4.PortOpen == false)
			{
				comm.Default.MSComm4.PortOpen = true;
			}
			comm.Default.MSComm4.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(hh);
			
			sub_Renamed.delay_times((0.5));F;); // If FlagLL = True Then
			
			//UPGRADE_WARNING: 未能解析对象 comm.MSComm4.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Rxd = System.Convert.ToString(comm.Default.MSComm4.Input); // Read_int_From_LL()  ' MSComm4.Input
			//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
			Recount = System.Convert.ToInt16(LenB(Rxd));
			Text17.Text = "";
			for (i = 1; i <= Recount; i++)
			{
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sss = AscB(MidB(Rxd, i, 1));
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				s[i] = System.Convert.ToInt16(AscB(MidB(Rxd, i, 1)));
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text17.Text = Text17.Text + Conversion.Str(sss) + ",";
				
			}
			
			if (s[1] == 79 && s[8] == 75)
			{
				
				if (Option3.Checked == true) //无修正时
				{
					if (Opxiao.Checked == true)
					{
						Text18.Text = ((double.Parse(Text18.Text)) + s[2] * 256 + s[3]).ToString();
						Text13.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text18.Text) * sub_Renamed.Md1, "0.00");
					}
					else if (OpZhong.Checked == true)
					{
						Text18.Text = ((double.Parse(Text18.Text)) + s[4] * 256 + s[5]).ToString();
						Text13.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text18.Text) * sub_Renamed.Md2, "0.000");
					}
					else if (Opda.Checked == true)
					{
						Text18.Text = ((double.Parse(Text18.Text)) + s[6] * 256 + s[7]).ToString();
						Text13.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text18.Text) * sub_Renamed.Md3, "0.000");
					}
				}
				else //修正时
				{
					
					if (Opxiao.Checked == true)
					{
						for (i = 0; i <= 10; i++)
						{
							//UPGRADE_WARNING: 未能解析对象 ZF1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (sub_Renamed.Lld1[i + 1] > sub_Renamed.Lld1[i])
							{
								ZF1 = i + 1;
							}
						}
						
						if (Conversion.Val(Flowrate.Text) < sub_Renamed.Lld1[0])
						{
							YF1 = sub_Renamed.Ks1[0];
							goto bb1;
						}
						
						//UPGRADE_WARNING: 未能解析对象 ZF1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Conversion.Val(Flowrate.Text) > sub_Renamed.Lld1[(int) ZF1])
						{
							//UPGRADE_WARNING: 未能解析对象 ZF1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							YF1 = sub_Renamed.Ks1[(int) ZF1];
							goto bb1;
						}
						
						//UPGRADE_WARNING: 未能解析对象 ZF1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						for (i = 0; i <= ZF1; i++)
						{
							if (Conversion.Val(Flowrate.Text) - sub_Renamed.Lld1[i] == 0)
							{
								goto aa1;
							}
							else
							{
								if (Conversion.Val(Flowrate.Text) - sub_Renamed.Lld1[i] > 0 && Conversion.Val(Flowrate.Text) - sub_Renamed.Lld1[i + 1] < 0)
								{
									break;
								}
							}
						}
						//UPGRADE_WARNING: 未能解析对象 XF11 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF11 = sub_Renamed.Lld1[i];
						//UPGRADE_WARNING: 未能解析对象 YF11 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF11 = sub_Renamed.Ks1[i];
						//UPGRADE_WARNING: 未能解析对象 XF12 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF12 = sub_Renamed.Lld1[i + 1];
						//UPGRADE_WARNING: 未能解析对象 YF12 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF12 = sub_Renamed.Ks1[i + 1];
						//UPGRADE_WARNING: 未能解析对象 XF1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF1 = Conversion.Val(Flowrate.Text);
						//UPGRADE_WARNING: 未能解析对象 YF11 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF11 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF12 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 YF12 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF1 = System.Convert.ToSingle(System.Convert.ToDouble(System.Convert.ToDouble(YF12) - System.Convert.ToDouble(YF11)) * System.Convert.ToDouble(System.Convert.ToDouble(XF1) - System.Convert.ToDouble(XF11)) / System.Convert.ToDouble(System.Convert.ToDouble(XF12) - System.Convert.ToDouble(XF11)) + System.Convert.ToDouble(YF11));
						goto bb1;
aa1:
						YF1 = sub_Renamed.Ks1[i];
bb1:
						
						Text18.Text = (s[2] * 256 + s[3]).ToString();
						Text13.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text13.Text) + Conversion.Val(Text18.Text) * sub_Renamed.Md1 * YF1, "0.000");
						
					}
					else if (OpZhong.Checked == true)
					{
						for (i = 0; i <= 10; i++)
						{
							//UPGRADE_WARNING: 未能解析对象 ZF2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (sub_Renamed.Lld2[i + 1] > sub_Renamed.Lld2[i])
							{
								ZF2 = i + 1;
							}
						}
						
						if (Conversion.Val(Flowrate.Text) < sub_Renamed.Lld2[0])
						{
							YF2 = sub_Renamed.Ks2[0];
							goto bb2;
						}
						
						//UPGRADE_WARNING: 未能解析对象 ZF2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Conversion.Val(Flowrate.Text) > sub_Renamed.Lld2[(int) ZF2])
						{
							//UPGRADE_WARNING: 未能解析对象 ZF2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							YF2 = sub_Renamed.Ks2[(int) ZF2];
							goto bb2;
						}
						
						//UPGRADE_WARNING: 未能解析对象 ZF2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						for (i = 0; i <= ZF2; i++)
						{
							if (Conversion.Val(Flowrate.Text) - sub_Renamed.Lld2[i] == 0)
							{
								goto aa2;
							}
							else
							{
								if (Conversion.Val(Flowrate.Text) - sub_Renamed.Lld2[i] > 0 && Conversion.Val(Flowrate.Text) - sub_Renamed.Lld2[i + 1] < 0)
								{
									break;
								}
							}
						}
						//UPGRADE_WARNING: 未能解析对象 XF21 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF21 = sub_Renamed.Lld2[i];
						//UPGRADE_WARNING: 未能解析对象 YF21 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF21 = sub_Renamed.Ks2[i];
						//UPGRADE_WARNING: 未能解析对象 XF22 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF22 = sub_Renamed.Lld2[i + 1];
						//UPGRADE_WARNING: 未能解析对象 YF22 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF22 = sub_Renamed.Ks2[i + 1];
						//UPGRADE_WARNING: 未能解析对象 XF2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF2 = Conversion.Val(Flowrate.Text);
						//UPGRADE_WARNING: 未能解析对象 YF21 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF21 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF22 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 YF22 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF2 = System.Convert.ToSingle(System.Convert.ToDouble(System.Convert.ToDouble(YF22) - System.Convert.ToDouble(YF21)) * System.Convert.ToDouble(System.Convert.ToDouble(XF2) - System.Convert.ToDouble(XF21)) / System.Convert.ToDouble(System.Convert.ToDouble(XF22) - System.Convert.ToDouble(XF21)) + System.Convert.ToDouble(YF21));
						goto bb2;
aa2:
						YF2 = sub_Renamed.Ks2[i];
bb2:
						Text18.Text = (s[4] * 256 + s[5]).ToString();
						Text13.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text13.Text) + Conversion.Val(Text18.Text) * sub_Renamed.Md2 * YF2, "0.000");
						
					}
					else if (Opda.Checked == true)
					{
						for (i = 0; i <= 10; i++)
						{
							//UPGRADE_WARNING: 未能解析对象 ZF3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (sub_Renamed.Lld3[i + 1] > sub_Renamed.Lld3[i])
							{
								ZF3 = i + 1;
							}
						}
						
						if (Conversion.Val(Flowrate.Text) < sub_Renamed.Lld3[0])
						{
							YF3 = sub_Renamed.Ks3[0];
							goto bb3;
						}
						
						//UPGRADE_WARNING: 未能解析对象 ZF3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Conversion.Val(Flowrate.Text) > sub_Renamed.Lld3[(int) ZF3])
						{
							//UPGRADE_WARNING: 未能解析对象 ZF3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							YF3 = sub_Renamed.Ks3[(int) ZF3];
							goto bb3;
						}
						
						//UPGRADE_WARNING: 未能解析对象 ZF3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						for (i = 0; i <= ZF3; i++)
						{
							if (Conversion.Val(Flowrate.Text) - sub_Renamed.Lld3[i] == 0)
							{
								goto aa3;
							}
							else
							{
								if (Conversion.Val(Flowrate.Text) - sub_Renamed.Lld3[i] > 0 && Conversion.Val(Flowrate.Text) - sub_Renamed.Lld3[i + 1] < 0)
								{
									break;
								}
							}
						}
						//UPGRADE_WARNING: 未能解析对象 XF31 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF31 = sub_Renamed.Lld3[i];
						//UPGRADE_WARNING: 未能解析对象 YF31 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF31 = sub_Renamed.Ks3[i];
						//UPGRADE_WARNING: 未能解析对象 XF32 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF32 = sub_Renamed.Lld3[i + 1];
						//UPGRADE_WARNING: 未能解析对象 YF32 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF32 = sub_Renamed.Ks3[i + 1];
						//UPGRADE_WARNING: 未能解析对象 XF3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						XF3 = Conversion.Val(Flowrate.Text);
						//UPGRADE_WARNING: 未能解析对象 YF31 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF31 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF32 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 XF3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 YF32 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						YF3 = System.Convert.ToSingle(System.Convert.ToDouble(System.Convert.ToDouble(YF32) - System.Convert.ToDouble(YF31)) * System.Convert.ToDouble(System.Convert.ToDouble(XF3) - System.Convert.ToDouble(XF31)) / System.Convert.ToDouble(System.Convert.ToDouble(XF32) - System.Convert.ToDouble(XF31)) + System.Convert.ToDouble(YF31));
						goto bb3;
aa3:
						YF3 = sub_Renamed.Ks3[i];
bb3:
						Text18.Text = (s[6] * 256 + s[7]).ToString();
						Text13.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text13.Text) + Conversion.Val(Text18.Text) * sub_Renamed.Md3 * YF3, "0.00");
						
					}
					
					
				} // If Option3.value = True Then '无修正时
				
				
			}
			
		}
		
		public void Timer3_Tick(System.Object eventSender, System.EventArgs eventArgs) //瞬流
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short[] s = new short[16];
			short Recount = 0;
			object sss = null;
			string Rxd = "";
			Mdlguanfa.Send_DataSl((short) 245); //liusu
			sub_Renamed.delay_times((0.4));F;);
			
			
			//UPGRADE_WARNING: 未能解析对象 comm.MSComm1.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Rxd = System.Convert.ToString(comm.Default.MSComm1.Input);
			//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
			Recount = System.Convert.ToInt16(LenB(Rxd));
			Text12.Text = "";
			for (i = 1; i <= Recount; i++)
			{
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sss = AscB(MidB(Rxd, i, 1));
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				s[i] = System.Convert.ToInt16(AscB(MidB(Rxd, i, 1)));
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text12.Text = Text12.Text + Conversion.Str(sss) + ",";
			}
			if (s[2] == 245)
			{
				
				if (Opxiao.Checked == true)
				{
					Ljsl = Ljsl + (s[4] * 256 + s[5] - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Vk1;
					Jssl++;
					if (Jssl == 5)
					{
						Flowrate.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Ljsl / Jssl, "0.000");
						Jssl = (short) 0;
						Ljsl = 0;
					}
					//                   FlagLS = False
					return;
				}
				else if (OpZhong.Checked == true)
				{
					Ljsl = Ljsl + (s[6] * 256 + s[7] - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Vk2;
					Jssl++;
					if (Jssl == 5)
					{
						Flowrate.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Ljsl / Jssl, "0.00");
						Jssl = (short) 0;
						Ljsl = 0;
					}
					//                   FlagLS = False
					return;
				}
				else if (Opda.Checked == true)
				{
					Ljsl = Ljsl + (s[8] * 256 + s[9] - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax3 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk3;
					Jssl++;
					if (Jssl == 5)
					{
						Flowrate.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Ljsl / Jssl, "0.000");
						Jssl = (short) 0;
						Ljsl = 0;
					}
					Module1.FlagLS = false;
					return;
				}
			}
			
			
		}
		
		private void Txll_Change()
		{
			object Txll = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Txll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Conversion.Val((Txll.Text > 100).ToString()) || Conversion.Val(Txll.Text) < 0)
			{
				Txll.Text = 10;
			}
			
			//UPGRADE_WARNING: 未能解析对象 Txll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Fzhi = (short) (Conversion.Int(Conversion.Val(Txll.Text) * 40 / 256));
			//UPGRADE_WARNING: 未能解析对象 Txll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			Fzhi1 = System.Convert.ToInt16((Conversion.Val(Txll.Text) * 40) % 256);
			
			Fd[0] = (byte) 255;
			Fd[1] = (byte) 244;
			Fd[2] = Fzhi;
			Fd[3] = Fzhi1;
			Fd[4] = (byte) 254;
			
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Fd);
			sub_Renamed.delay_times((0.1));F;);
		}
		
		private void Tzll_Change()
		{
			object Tzll = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Tzll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Conversion.Val((Tzll.Text > 100).ToString()) || Conversion.Val(Tzll.Text) < 0)
			{
				Tzll.Text = 50;
			}
			
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			
			//UPGRADE_WARNING: 未能解析对象 Tzll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Fzhi = (short) (Conversion.Int(Conversion.Val(Tzll.Text) * 40 / 256));
			//UPGRADE_WARNING: 未能解析对象 Tzll.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			Fzhi1 = System.Convert.ToInt16((Conversion.Val(Tzll.Text) * 40) % 256);
			
			Fd[0] = (byte) 255;
			Fd[1] = (byte) 243;
			Fd[2] = Fzhi;
			Fd[3] = Fzhi1;
			Fd[4] = (byte) 254;
			
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Fd);
			sub_Renamed.delay_times((0.1));F;);
		}
		
		private void TPcom()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,6,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,6,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,6,2";
			}
			
			
			
		}
		
		
		
		
		//Sub qingl()
		//For i = 0 To 8
		// Text2(i).Text = ""
		//  Text3(i).Text = ""
		//   Text4(i).Text = ""
		//    Text5(i).Text = ""
		//     Text6(i).Text = ""
		//      Text7(i).Text = ""
		//       Text8(i).Text = ""
		//     Next i
		//     For i = 9 To 15
		// Text2(i).Text = ""
		//  Text3(i).Text = ""
		//   Text4(i).Text = ""
		//    Text5(i).Text = ""
		//     Text6(i).Text = ""
		//      Text7(i).Text = ""
		//       Text8(i).Text = ""
		//     Next i
		//     For i = 16 To 23
		// Text2(i).Text = ""
		//  Text3(i).Text = ""
		//   Text4(i).Text = ""
		//    Text5(i).Text = ""
		//     Text6(i).Text = ""
		//      Text7(i).Text = ""
		//       Text8(i).Text = ""
		//     Next i
		//
		//
		//     For j = 0 To 7
		//
		//       Text9(j).Text = ""
		//        Text10(j).Text = ""
		//        Next j
		//End Sub
		
		public void Kaifapl()
		{
			// Dim Fdizhi As Integer
			//        Dim Fzhi As Integer
			//        Dim Fzhi1 As Integer
			//        Dim Fzhi2 As Single
			//        If comm.MSComm1.PortOpen = False Then comm.MSComm1.PortOpen = True
			//
			//             Fzhi2 = Val(Txtpl(0).Text)
			//             If Fzhi2 > 50 Then Fzhi2 = 50
			//              Fzhi = Int(Fzhi2 / 50 / 256 * 40)
			//              Fzhi1 = (Fzhi2 / 50 * 40) Mod 256
			//        Dim Fd(6) As Byte
			//            Fd(0) = 255
			//            Fd(1) = 248
			//            Fd(2) = Fzhi
			//            Fd(3) = Fzhi1
			//            Fd(4) = 254
			//          comm.MSComm1.Output = Fd
			//        delay
		}
		
		public void GUANfapl()
		{
			// Dim Fdizhi As Integer
			//        Dim Fzhi As Integer
			//        Dim Fzhi1 As Integer
			//        Dim Fzhi2 As Single
			//        If comm.MSComm1.PortOpen = False Then comm.MSComm1.PortOpen = True
			//
			//             Fzhi2 = Val(Txtpl(1).Text)
			//             If Fzhi2 > 50 Then Fzhi2 = 50
			//              Fzhi = Int(Fzhi2 / 50 / 256 * 40)
			//              Fzhi1 = (Fzhi2 / 50 * 40) Mod 256
			//        Dim Fd(6) As Byte
			//            Fd(0) = 255
			//            Fd(1) = 248
			//            Fd(2) = Fzhi
			//            Fd(3) = Fzhi1
			//            Fd(4) = 254
			//          comm.MSComm1.Output = Fd
			//        delay
		}
		
		
		public void tz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//comm.MSComm1.CommPort = Com1
			//If comm.MSComm1.PortOpen = False Then comm.MSComm1.PortOpen = True
			
			Mdlguanfa.Send_Data((short) 250);
			
			sub_Renamed.delay_times(1);
		}
	}
}
