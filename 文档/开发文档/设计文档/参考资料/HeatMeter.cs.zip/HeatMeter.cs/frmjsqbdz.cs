// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;

namespace 热量表
{
	partial class frmjsqbdz : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmjsqbdz defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmjsqbdz Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmjsqbdz();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		short msg;
		ADODB.Recordset Namefind;
		
		float[] lLChuzhi = new float[21];
		float[] llZhongzhi = new float[21];
		object jj;
		bool Gaicanshu;
		short Biao_Xuhao;
		bool Gaibiaohao;
		bool Yanshi;
		bool DanJian;
		bool Wancheng;
		bool Sendend;
		string arg;
		short txt_idx;
		float[] mi = new float[9];
		short Pt_XH;
		float[] Kxs1 = new float[21];
		string Data_in1;
		int Kk1;
		short Wendu_js1;
		short t6;
		object[] Dif_errorresult = new object[9];
		object[] Result_repeatability = new object[9];
		float[] Fundmental_error = new float[9]; //容积类最终示值误差
		
		object xx;
		object s;
		string s0;
		object s2;
		object s1;
		object s3;
		string s4;
		object s6;
		object s5;
		object s7;
		string s8;
		string data;
		object sj2;
		object sj5;
		object sj6;
		object sc2;
		object sc5;
		object sc6;
		
		object p;
		object t;
		byte[] MeterTime1 = new byte[33];
		double[] MeterTime = new double[33];
		byte[] MeterRead1 = new byte[26];
		double[] MeterRead = new double[26];
		byte[] jiance = new byte[18];
		float tstart;
		double[] aa0 = new double[2];
		byte[] aa1 = new byte[2];
		float Kxs;
		float[,,] dif_error = new float[9, 11, 9]; //相对示值误差--第三类用
		private void cmdDaYin_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			msg = (short) (Interaction.MsgBox("请您确认是否打印？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "打印提示"));
			switch (msg)
			{
				case (short) MsgBoxResult.Yes:
					Module1.PrintCalCular();
					break;
				case (short) MsgBoxResult.No:
					return;
			}
		}
		public void cmdQuit_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		public float standom_t(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[2] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[3] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[1];
			returnValue = (float) (System.Math.Round(System.Convert.ToDouble((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa)), 4));
			return returnValue;
		}
		public float standom_t1(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[5] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[6] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[4];
			returnValue = (float) (System.Math.Round(System.Convert.ToDouble((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa)), 4));
			return returnValue;
		}
		
		
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//Wendu_js1 = 0
			Timer3.Enabled = false;
			Label51.Visible = false;
			Command1.Visible = false;
		}
		
		public void Command10_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option4.Checked == true)
			{
				Timer14.Enabled = false;
				Timer16.Enabled = false;
				Text12.Text = "";
				Text14.Text = "";
				Text15.Text = "";
				Text16.Text = "";
				Text16.Visible = true;
				Text15.Visible = true;
			}
			else if (frmjsbdz.Default.Option5.Checked == true)
			{
				Text12.Text = "";
				Text14.Text = "";
				Text15.Text = "";
				Text16.Text = "";
				Timer18.Enabled = false;
				Timer19.Enabled = false;
			}
			else if (frmjsbdz.Default.Option3.Checked == true)
			{
				
			}
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
		}
		
		
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.Flagnext = true;
			Command3.Visible = false;
			for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
			{
				sub_Renamed.ZlChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text6[sub_Renamed.i].Text));
			}
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.Flagnext = true;
			Command4.Visible = false;
			for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
			{
				lLChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text2[sub_Renamed.i].Text));
			}
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			MSComm1.PortOpen = true;
			
			if (frmjsbdz.Default.Option4.Checked == true) //唯立
			{
				
				MSComm1.Settings = "9600,n,8,1";
				MSComm1.InputLen = (short) 0; //串口清空
				Timer14.Enabled = true;
				sub_Renamed.delay_times((0.5));F;);
				Timer16.Enabled = true;
				
			}
			else if (frmjsbdz.Default.Option5.Checked == true) //华易
			{
				MSComm1.Settings = "4800,n,8,1";
				MSComm1.InputLen = (short) 0;
				Kk1 = 0;
				Wendu_js1 = (short) 0;
				Timer18.Enabled = true;
				//Timer19.Enabled = True
				
			}
			else if (frmjsbdz.Default.Option3.Checked == true) //计量院
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
				
			}
		}
		
		public void Command6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.Flagnext = true;
			Command6.Visible = false;
		}
		
		private void Command7_Click()
		{
			
		}
		
		public void frmjsqbdz_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			for ( = ;1; i <= (sub_Renamed.Meter_Type0.Length - 1)); i++;);
			{
				Metertype.Items.Add(sub_Renamed.Meter_Type0[sub_Renamed.i]);
			}
			
			for ( = ;0; i <= 11); i++;);
			{
				Frame2[sub_Renamed.i].Enabled = false;
				Text19[sub_Renamed.i + 1].Visible = false;
			}
			
			for ( = ;0; i <= 11); i++;);
			{
				
				Text10[2 * sub_Renamed.i].Text = "进口温度";
				Text10[2 * sub_Renamed.i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC0C0FF);
				Text10[2 * sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
				Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i].Font, 9);
				Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i].Font, false);
				
				Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i + 1].Font, false);
				Text10[2 * sub_Renamed.i + 1].Text = "出口温度";
				Text10[2 * sub_Renamed.i + 1].BackColor = System.Drawing.ColorTranslator.FromOle(0xFFFF80);
				Text10[2 * sub_Renamed.i + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
				Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i + 1].Font, 9);
				
				Text6[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1155)));
				Label6[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1230)));
				Label11[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1230)));
				
				Text2[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1635)));
				Label4[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1725)));
				Text4[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2115)));
				Label5[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2235)));
				
			}
			
			读表号一.Enabled = false;
			读表号二.Enabled = false;
			读表号三.Enabled = false;
			读表号四.Enabled = false;
			读表号五.Enabled = false;
			读表号六.Enabled = false;
			读表号七.Enabled = false;
			读表号八.Enabled = false;
			读表号九.Enabled = false;
			读表号十.Enabled = false;
			读表号十一.Enabled = false;
			读表号十二.Enabled = false;
			
			状态一.Enabled = false;
			状态二.Enabled = false;
			状态三.Enabled = false;
			状态四.Enabled = false;
			状态五.Enabled = false;
			状态六.Enabled = false;
			状态七.Enabled = false;
			状态八.Enabled = false;
			状态九.Enabled = false;
			状态十.Enabled = false;
			状态十一.Enabled = false;
			状态十二.Enabled = false;
			
			读数1.Enabled = false;
			读数2.Enabled = false;
			读数3.Enabled = false;
			读数4.Enabled = false;
			读数5.Enabled = false;
			读数6.Enabled = false;
			读数7.Enabled = false;
			读数8.Enabled = false;
			读数9.Enabled = false;
			读数10.Enabled = false;
			读数11.Enabled = false;
			读数12.Enabled = false;
			
			状态一.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态二.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态三.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态四.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态五.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态六.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态七.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态八.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态九.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态十.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态十一.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			状态十二.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(840));
			
			sub_Renamed.Flagnext = false;
			sub_Renamed.Comopen = false; //串口打开标识
			Command3.Visible = false;
			Command4.Visible = false;
			
			Timer14.Enabled = false; //标温采集（唯立）
			Timer16.Enabled = false; //标温采集（唯立）
			Timer18.Enabled = false; //标温采集（华易）
			Timer19.Enabled = false; //标温采集（华易）
			//Timer2.Enabled = False '标温采集
			Timer3.Enabled = false; //等待检定时间
			Timer4.Enabled = false; //采集平均标温
			Label51.Visible = false;
			Text38.Visible = false;
			Label2.Visible = false;
			Label55.Visible = false;
			
			
			//MSComm2.CommPort = Com5
			MSComm1.CommPort = sub_Renamed.Com4;
			//MSComm2.RThreshold = 44
			MSComm1.RThreshold = (short) 40;
			
			
			//If MSComm3.PortOpen = True Then MSComm3.PortOpen = False
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			
			
			sub_Renamed.Jdks = false;
			object n = null;
			FileSystem.FileClose(23);
			Module1.sFileCanShu = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\pt_canshu.dll";
			FileSystem.FileOpen(23, Module1.sFileCanShu, OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			for (n = 1; (int) n <= 7; n = (int) n + 1)
			{
				//UPGRADE_WARNING: 未能解析对象 n 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				FileSystem.Input(23, ref mi[(int) n]);
			}
			FileSystem.FileClose(23);
			
			FileSystem.FileClose(11);
			FileSystem.FileOpen(11, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(11, ref Pt_XH);
			FileSystem.FileClose(11);
			
			
			for ( = ;0; i <= 15); i++;);
			{
				Text33[sub_Renamed.i].Text = "";
				Text44[sub_Renamed.i].Text = "";
				Text11[sub_Renamed.i].Text = "";
				Text11[sub_Renamed.i].Visible = false;
				Text33[sub_Renamed.i].Visible = false;
				Text44[sub_Renamed.i].Visible = false;
			}
			
			
			
			
			//读标准铂电阻参数结束
			Command6.Visible = false;
			
			Labt.Text = "请正确选择被检表的安装位置、计量单位、最小温差值!";
			
		}
		private void stb()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			short st;
			short pp = 0;
			double cl = 0;
			double tt = 0;
			double t = 0;
			object p5 = null;
			double v1;
			double ab = 0;
			double h1 = 0;
			double volume;
			double w3 = 0;
			double w1 = 0;
			double Gf = 0;
			double z = 0;
			double y = 0;
			double o = 0;
			double b = 0;
			double y1 = 0;
			double gg = 0;
			double w = 0;
			double w2 = 0;
			double v = 0;
			double AAA = 0;
			double h6 = 0;
			double aa = 0;
			double h2 = 0;
			double kr = 0;
			double vr = 0;
			double tf = 0;
			double hf = 0;
			double g7;
			double g5 = 0;
			double g3 = 0;
			double g1 = 0;
			double g2 = 0;
			double g4 = 0;
			double g6 = 0;
			double h = 0;
			double vf = 0;
			double hr = 0;
			double tR = 0;
			double kf = 0;
			st = (short) 0;
			if (st == 0)
			{
				tt = Conversion.Val(Text14.Text); //进口温度输入
			}
AAAA:
			if (st == 1)
			{
				tt = Conversion.Val(Text12.Text); //出口温度输入
			}
			cl = tt;
			t = tt + 273.15;
			pp = (short) 6;
			
			//pp = Val(Text10.Text)
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			p5 = pp * 100000;
			o = t / Module1.tc;
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b = System.Convert.ToDouble(System.Convert.ToDouble(p5) / Module1.pc);
			y = 1 - Module1.d1 * Math.Pow(o, 2) - Module1.d2 * Math.Pow(o, -6);
			y1 = -2 * Module1.d1 * o + 6 * Module1.d2 * Math.Pow(o, -7);
			z = y + System.Math.Sqrt(System.Math.Abs(Module1.d3 * Math.Pow(y, 2) - 2 * Module1.d4 * o + 2 * Module1.d5 * b));
			gg = Module1.d6 - o;
			if (System.Math.Abs(gg) < 0.000158)
			{
				gg = 0;
			}
			Gf = Module1.d6 - o;
			if (System.Math.Abs(Gf) < 0.0000596)
			{
				Gf = 0;
			}
			w = Module1.B1 * Module1.d5 * Math.Pow(z, (-5 / 17));
			w1 = w + (Module1.B2 + Module1.B3 * o + Module1.b4 * Math.Pow(o, 2) + Module1.b5 * Math.Pow(gg, 10) + Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -1)) - Math.Pow((Module1.d8 + Math.Pow(o, 11)), -1) * (Module1.b7 + 2 * Module1.b8 * b + 3 * Module1.b9 * Math.Pow(b, 2));
			w2 = w1 - Module1.c0 * Math.Pow(o, 18) * (Module1.d9 + Math.Pow(o, 2)) * (-3 * Math.Pow((Module1.e0 + b), -4) + Module1.e1);
			w3 = w2 + 3 * Module1.c1 * (Module1.e2 - o) * Math.Pow(b, 2) + 4 * Module1.c2 * Math.Pow(o, -20) * Math.Pow(b, 3);
			v = 1000 * w3 * Module1.vc;
			volume = 1 / v;
			
			AAA = Module1.a1 + Module1.a2 * o + Module1.a3 * Math.Pow(o, 2) + Module1.a4 * Math.Pow(o, 3) + Module1.a5 * Math.Pow(o, 4) + Module1.a6 * Math.Pow(o, 5) + Module1.a7 * Math.Pow(o, 6) + Module1.a8 * Math.Pow(o, 7) + Module1.a9 * Math.Pow(o, 8) + Module1.b0 * Math.Pow(o, 9);
			h1 = Module1.a0 * o * (1 - System.Math.Log(o)) + AAA + Module1.B1 * ((17 / 29) * z - (17 / 12) * y) * Math.Pow(z, (12 / 17)) + (Module1.B2 + Module1.B3 * o + Module1.b4 * Math.Pow(o, 2) + Module1.b5 * Math.Pow(gg, 10) + Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -1)) * b;
			h2 = h1 - Math.Pow((Module1.d8 + Math.Pow(o, 11)), -1) * (Module1.b7 * b + Module1.b8 * Math.Pow(b, 2) + Module1.b9 * Math.Pow(b, 3)) - Module1.c0 * Math.Pow(o, 18) * (Module1.d9 + Math.Pow(o, 2)) * (Math.Pow((Module1.e0 + b), -3) + Module1.e1 * b);
			h6 = h2 + Module1.c1 * (Module1.e2 - o) * Math.Pow(b, 3) + Module1.c2 * Math.Pow(o, -20) * Math.Pow(b, 4);
			//Text2.Text = Left$(CStr(h6#), 6)
			ab = Module1.a2 + 2 * Module1.a3 * o;
			aa = ab + 3 * Module1.a4 * Math.Pow(o, 2) + 4 * Module1.a5 * Math.Pow(o, 3) + 5 * Module1.a6 * Math.Pow(o, 4) + 6 * Module1.a7 * Math.Pow(o, 5) + 7 * Module1.a8 * Math.Pow(o, 6) + 8 * Module1.a9 * Math.Pow(o, 7) + 9 * Module1.b0 * Math.Pow(o, 8);
			g1 = Module1.a0 * System.Math.Log(o) - aa + Module1.B1 * ((((5 * z) / 12) - (Module1.d3 - 1) * y) * y1 + Module1.d4) * Math.Pow(z, (-5 / 17));
			g2 = (- Module1.B3 - 2 * Module1.b4 * o + 10 * Module1.b5 * Math.Pow(Gf, 9) + 19 * Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -2) * Math.Pow(o, 18)) * b;
			g3 = 11 * Math.Pow((Module1.d8 + Math.Pow(o, 11)), -2) * Math.Pow(o, 10) * (Module1.b7 * b + Module1.b8 * Math.Pow(b, 2) + Module1.b9 * Math.Pow(b, 3));
			g4 = Module1.c0 * Math.Pow(o, 17) * (18 * Module1.d9 + 20 * Math.Pow(o, 2)) * (Math.Pow((Module1.e0 + b), -3) + Module1.e1 * b);
			g5 = Module1.c1 * Math.Pow(b, 3) + 20 * Module1.c2 * Math.Pow(o, -21) * Math.Pow(b, 4);
			g6 = g1 + g2 - g3 + g4 + g5;
			//Text3.Text = Left$(CStr(g6#), 6)
			h = (Module1.pc * Module1.vc) * (o * g6 + h6);
			h = h / 1000;
			
			if (st == 1)
			{
				goto XXX;
			}
			hf = h;
			vf = v;
			tf = cl;
			st = (short) 1;
			goto AAAA;
			
XXX:
			hr = h;
			vr = v;
			tR = cl;
			
			kr = (hf - hr) / ((tf - tR) * vr);
			kf = (hf - hr) / ((tf - tR) * vf);
			
			if (Option1.Checked == true)
			{
				if (Option3.Checked == true)
				{
					Kxs1[txt_idx] = float.Parse(VB.Strings.Left((kf).ToString(), 6)); //进口K系数 MJ
				}
				else
				{
					Kxs1[txt_idx] = float.Parse(VB.Strings.Left((kf / 3.6).ToString(), 6)); //进口K系数 kWh
				}
			}
			else
			{
				if (Option3.Checked == true)
				{
					Kxs1[txt_idx] = float.Parse(VB.Strings.Left((kr).ToString(), 6)); //出口K系数 MJ
				}
				else
				{
					Kxs1[txt_idx] = float.Parse(VB.Strings.Left((kr / 3.6).ToString(), 6)); //出口K系数 kWh
				}
			}
			Text3[txt_idx].Text = (System.Math.Round(((double.Parse(Text14.Text)) - double.Parse(Text12.Text)) * ((System.Convert.ToDouble(Text4[txt_idx].Text)) - System.Convert.ToDouble(Text2[txt_idx].Text)) * Kxs1[txt_idx] / 1000, 4)).ToString(); //理论热量
			
		}
		
		
		
		public void frmjsqbdz_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //
			Timer2.Enabled = false;
			Timer3.Enabled = false;
			Timer4.Enabled = false;
			if (MSComm3.PortOpen == true)
			{
				MSComm3.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
		}
		
		public void kaishi_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //
			
			//If Jdks = False Then
			//  MsgBox "请先输入检定参数！"
			//  Exit Sub
			//End If
			
			if (Text14.Text == "" || double.Parse(Text14.Text) == 0)
			{
				MessageBox.Show("进口温度采集不正常！");
				return;
			}
			if (Text12.Text == "" || double.Parse(Text12.Text) == 0)
			{
				MessageBox.Show("出口温度采集不正常！");
				return;
			}
			
			
			short h = 0;
			if (sub_Renamed.Comopen == true)
			{
				//读表号过程
				for ( = ;0; i <= 11); i++;);
				{
					Text1[sub_Renamed.i].Text = "";
					Text11[sub_Renamed.i].Text = "";
				}
				sub_Renamed.cmd_type = "RD_NUM";
				Biao_Xuhao = (short) 0;
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				Timer21.Enabled = true;
				
				Wancheng = false;
				
				do
				{
					System.Windows.Forms.Application.DoEvents();
				} while (!(Timer21.Enabled == false));
				
				if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 5 | Metertype.SelectedIndex == 7) //超声表进入检定状态
				{
					sub_Renamed.delay_times(1);
					sub_Renamed.cmd_type = "WR_INPUT_JIANDING"; //检定状态
					//        data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
					//        data = Mid(data, 3)
					Biao_Xuhao = (short) 0;
					Timer21.Enabled = true;
					Wancheng = false;
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
					} while (!(Timer21.Enabled == false));
				}
			}
			else
			{
				for ( = ;0; i <= 11); i++;);
				{
					h = (short) (h + Strings.Len(Text1[sub_Renamed.i].Text));
				}
				
				if (h == 0)
				{
					MessageBox.Show("请先输入被检表的表号！");
					Text1[0].Focus();
					return;
				}
			}
			
			kaishi.Enabled = false;
			SSCommand11.Visible = false;
			SSCommand2.Visible = true;
			
			
			sub_Renamed.End_biaowei = (short) 0;
			sub_Renamed.Jd_number = (short) 0;
			for ( = ;0; i <= 11); i++;);
			{
				sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 0;
				if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
				{
					sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 1;
					sub_Renamed.End_biaowei = sub_Renamed.i;
				}
				sub_Renamed.Jd_number = () (sub_Renamed.Jd_number + sub_Renamed.Jd_biaowei[sub_Renamed.i]));
			}
			
			sub_Renamed.Jd_meter = sub_Renamed.Jd_number;
			
			sub_Renamed.gain_fileNO();
			sub_Renamed.objExcel = new Microsoft.Office.Interop.Excel.Application();
			sub_Renamed.objExcel.SheetsInNewWorkbook = 1;
			sub_Renamed.objExcel.Workbooks.Add();
			//objExcel.Sheets.Application.DisplayFullScreen = True
			sub_Renamed.objExcel.Application.WindowState = Microsoft.Office.Interop.Excel.XlWindowState.xlMinimized;
			sub_Renamed.objExcel.Application.Visible = true;
			//Call give_ini
			list();
			//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			xx = 1;
			
			short j = 0;
			short k = 0;
			for (xx = 1; (int) xx <= sub_Renamed.Jd_point; xx = (int) xx + 1) //流程： 逐个流量点进行
			{
				
				sub_Renamed.Flagnext = false;
				
				//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Labt.Text = "请将进口温度调至(90～95)℃，温差调至" + "" + System.Convert.ToString(sub_Renamed.Jd_wc[System.Convert.ToInt32(xx) - 1]) + "" + "K 附近。然后点《下一步》开始检定!";
				
				Command6.Visible = true;
				Command6.Focus();
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times(1);
				} while (!(sub_Renamed.Flagnext == true));
				
				
				
				if (frmshz.Default.Option6.Checked == true) //初值回零
				{
					
					for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
					{
						if (Strings.Len(Text1[sub_Renamed.i].Text) > 0) //对无表号表位不赋0值
						{
							Text2[sub_Renamed.i].Text = (0).ToString();
							Text6[sub_Renamed.i].Text = (0).ToString();
							sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
							lLChuzhi[sub_Renamed.i] = 0;
						}
						else
						{
							Text2[sub_Renamed.i].Text = "";
							Text6[sub_Renamed.i].Text = "";
						}
					}
					
				}
				else
				{
					
					if (sub_Renamed.Comopen == true) //当自动采集.读初值
					{
						Labt.Text = "正在采集被检表数据......";
						
						for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
						{
							if (Strings.Len(Text1[sub_Renamed.i].Text) > 0) //对无表号表位不赋0值
							{
								Text2[sub_Renamed.i].Text = (0).ToString();
								Text6[sub_Renamed.i].Text = (0).ToString();
								sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
								lLChuzhi[sub_Renamed.i] = 0;
							}
							else
							{
								Text2[sub_Renamed.i].Text = "";
								Text6[sub_Renamed.i].Text = "";
							}
						}
						
						sub_Renamed.Readone = true; //不读温度值
						sub_Renamed.Rechen = false; //采集数据不计算误差
						sub_Renamed.Erstpunkt = true;
						switch (Metertype.SelectedIndex)
						{
							case 0:
							case 3:
							case 4:
							case 5:
							case 6:
							case 8:
								sub_Renamed.cmd_type = "RD_HIGH_DATA";
								break;
						}
						Biao_Xuhao = (short) 0;
						
						Timer21.Enabled = true;
						Wancheng = false;
						
						do
						{
							System.Windows.Forms.Application.DoEvents();
						} while (!(Timer21.Enabled == false));
						Readingonerror();
						sub_Renamed.delay_times(1);
						sub_Renamed.Erstpunkt = false;
						
					}
					else //不是自动采集，读初值
					{
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if ((int) xx == 1) //第一遍时
						{
							sub_Renamed.Flagnext = false;
							Command3.Visible = true;
							if (Option3.Checked == true)
							{
								Labt.Text = "请输入被检表热量初值E0（MJ），并点击《下一步》确认。";
							}
							else if (Option4.Checked == true)
							{
								Labt.Text = "请输入被检表热量初值E0（kWh），并点击《下一步》确认。";
							}
							
							for ( = ;0; i <= 11); i++;);
							{
								sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
								Text6[sub_Renamed.i].Text = "";
							}
							Text6[0].Focus();
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
								sub_Renamed.delay_times(1);
							} while (!(sub_Renamed.Flagnext == true));
							
							Labt.Text = "请输入模拟流量初值V0（L），点击《下一步》确认。";
							
							sub_Renamed.Flagnext = false;
							Command4.Visible = true;
							
							for ( = ;0; i <= 11); i++;);
							{
								lLChuzhi[sub_Renamed.i] = 0;
								Text2[sub_Renamed.i].Text = "";
							}
							Text2[0].Focus();
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
								sub_Renamed.delay_times(1);
							} while (!(sub_Renamed.Flagnext == true));
						}
						else //如果不是第一遍
						{
							for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
							{
								Text6[sub_Renamed.i].Text = Text8[sub_Renamed.i].Text;
								sub_Renamed.ZlChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text8[sub_Renamed.i].Text));
								sub_Renamed.ZlZhongzhi[sub_Renamed.i] = 0;
								Text2[sub_Renamed.i].Text = Text4[sub_Renamed.i].Text;
								lLChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text4[sub_Renamed.i].Text));
								llZhongzhi[sub_Renamed.i] = 0;
								Text8[sub_Renamed.i].Text = "";
								Text4[sub_Renamed.i].Text = "";
							}
						}
					}
					
				} //初值回零结束
				
				
				Labt.Text = "";
				
				//采温度
				sub_Renamed.jkwd = 0;
				sub_Renamed.ckwd = 0;
				sub_Renamed.wdjs = 0;
				Timer4.Enabled = true;
				
				
				Label55.Visible = true;
				Label2.Visible = true;
				Text38.Visible = true;
				Text38.Text = (Mdlguanfa.Qp).ToString();
				Command1.Visible = true;
				Timer3.Enabled = true;
				
				//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Labt.Text = "正在" + "" + System.Convert.ToString(Conversion.Val(Text38.Text)) + "" + "m3/h处模拟流量约" + "" + System.Convert.ToString(sub_Renamed.Jd_liang[System.Convert.ToInt32(xx) - 1]) + "" + "L进行检测，请等待约       秒";
				
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times(1);
				} while (!(Timer3.Enabled == false));
				sub_Renamed.delay_times(2);
				
				Timer4.Enabled = false; //温度采集平均值结束
				sub_Renamed.delay_times(1);
				Text14.Text = (sub_Renamed.inlet).ToString();
				Text12.Text = (sub_Renamed.outlet).ToString();
				
				if (sub_Renamed.Comopen == true) //自动采集时，读末值
				{
					for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
					{
						sub_Renamed.ZlZhongzhi[sub_Renamed.i] = 0;
						llZhongzhi[sub_Renamed.i] = 0;
						Text8[sub_Renamed.i].Text = "";
						Text4[sub_Renamed.i].Text = "";
						Text5[sub_Renamed.i].Text = "";
					}
					
					
					Labt.Text = "正在采集被检表数据......";
					sub_Renamed.Erstpunkt = false;
					sub_Renamed.Rechen = true; //用于采集数据计算误差
					
					
					switch (Metertype.SelectedIndex)
					{
						case 3: //力创汇中读数温度
						case 4:
						case 5:
							sub_Renamed.Readone = true; //不读温度值
							break;
						default:
							sub_Renamed.Readone = false; //读温度值
							break;
					}
					
					sub_Renamed.RechenLC = false;
					sub_Renamed.cmd_type = "RD_HIGH_DATA";
					Biao_Xuhao = (short) 0;
					
					
					Timer21.Enabled = true;
					Wancheng = false;
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
					} while (!(Timer21.Enabled == false));
					Readingonerror();
					sub_Renamed.delay_times(1);
					switch (Metertype.SelectedIndex)
					{
						case 3: //力创汇中读数温度
						case 4:
						case 5:
							if (frmcanshushezhi1.Default.Option11.Checked == true) //当检总量时读力创汇中温度
							{
								读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
								
								
								
								sub_Renamed.Erstpunkt = false;
								sub_Renamed.Readone = false; //读温度值
								sub_Renamed.RechenLC = true; //采集数据不计算误差
								sub_Renamed.cmd_type = "RD_DATA"; //读温度值
								Biao_Xuhao = (short) 0;
								Timer21.Enabled = true;
								Wancheng = false;
								
								do
								{
									System.Windows.Forms.Application.DoEvents();
								} while (!(Timer21.Enabled == false));
								Readingonerror();
								sub_Renamed.delay_times(1);
							}
							break;
					}
					
					
					//
					//自动时开始计算误差
					
					//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.Jsyq[System.Convert.ToInt32(xx) - 1] = float.Parse(Jsyq(1 + System.Math.Abs(4 * Conversion.Val(Twcd.Text) / (Conversion.Val(Text14.Text) - Conversion.Val(Text12.Text))), "0.00")); //示值误差技术要求
					
					for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
					{
						if (Strings.Len(Text1[sub_Renamed.i].Text) == 8)
						{
							txt_idx = sub_Renamed.i;
							stb();
							sub_Renamed.ZlChuzhi[sub_Renamed.i] = System.Convert.ToSingle(Text6[sub_Renamed.i].Text);
							sub_Renamed.ZlZhongzhi[sub_Renamed.i] = System.Convert.ToSingle(Text8[sub_Renamed.i].Text);
							Module1.Moni[sub_Renamed.i] = (float) (Conversion.Val(Text4[sub_Renamed.i].Text) - Conversion.Val(Text2[sub_Renamed.i].Text)); //体积示值
							sub_Renamed.ZlShizhi[sub_Renamed.i] = (float) (Conversion.Val((System.Convert.ToDouble(Text8[sub_Renamed.i].Text)) - System.Convert.ToDouble(Text6[sub_Renamed.i].Text).ToString())); //热量示值
							
							Text5[sub_Renamed.i].Text = Text5((sub_Renamed.ZlShizhi[sub_Renamed.i] - Conversion.Val(Text3[sub_Renamed.i].Text)) / Conversion.Val(Text3[sub_Renamed.i].Text) * 100, "0.0"); //示值误差
							
							//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (System.Math.Abs(Conversion.Val(Text5[sub_Renamed.i].Text)) > sub_Renamed.Jsyq[System.Convert.ToInt32(xx) - 1])
							{
								Text5[sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); // 红
							}
							else
							{
								Text5[sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
							}
							
							
							//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.Teminlet[(int) xx, sub_Renamed.i] = (float) (Conversion.Val(Text10[2 * sub_Renamed.i].Text));
							//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.Temoutlet[(int) xx, sub_Renamed.i] = (float) (Conversion.Val(Text10[2 * sub_Renamed.i + 1].Text));
							//                Dim xy As Integer
							//
							//                If xx > 2 Then
							//                xy = 2
							//                Else
							//                xy = xx
							//                End If
							sub_Renamed.TemVor[sub_Renamed.i] = (float) (Conversion.Val(Text10[2 * sub_Renamed.i].Text));
							sub_Renamed.TemRuc[sub_Renamed.i] = (float) (Conversion.Val(Text10[2 * sub_Renamed.i + 1].Text));
							
							//计算温度示值误差
							
							if (System.Math.Abs(sub_Renamed.TemVor[sub_Renamed.i] - double.Parse(Text14.Text)) > 0.3 + 0.005 * Conversion.Val(Text14.Text))
							{
								Text10[2 * sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
							}
							else
							{
								Text10[2 * sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
							}
							if (System.Math.Abs(sub_Renamed.TemRuc[sub_Renamed.i] - double.Parse(Text12.Text)) > 0.3 + 0.005 * Conversion.Val(Text12.Text))
							{
								Text10[2 * sub_Renamed.i + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
							}
							else
							{
								Text10[2 * sub_Renamed.i + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
							}
							
							
							
							
						}
					}
					
					
					
				}
				else //不是自动采集时‘读末值
				{
					
					Labt.Text = "请输入模拟流量终值V1（L）";
					for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
					{
						Module1.Moni[sub_Renamed.i] = 0;
						Text4[sub_Renamed.i].Text = "";
					}
					Text4[0].Focus();
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
						sub_Renamed.delay_times(1);
					} while (!(Module1.Moni[sub_Renamed.End_biaowei] > 0));
					
					
					if (Option3.Checked == true)
					{
						Labt.Text = "请输入被检表热量终值E1（MJ）";
					}
					else if (Option4.Checked == true)
					{
						Labt.Text = "请输入被检表热量终值E1（kWh）";
					}
					
					
					
					for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
					{
						sub_Renamed.ZlZhongzhi[sub_Renamed.i] = 0;
						Text8[sub_Renamed.i].Text = "";
					}
					Text8[0].Focus();
					Module1.Sbs = (short) 0;
					do
					{
						System.Windows.Forms.Application.DoEvents();
						sub_Renamed.delay_times(1);
					} while (!(sub_Renamed.ZlZhongzhi[sub_Renamed.End_biaowei] > 0));
					
				} //采集结束，读末值
				
				
				k = (short) 0;
				for (j = 0; j <= sub_Renamed.End_biaowei; j++)
				{
					
					if (Strings.Len(Text1[j].Text) > 0)
					{
						if (j == 0)
						{
							k = (short) 1;
						}
						else if (j == 1)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
						}
						else if (j == 2)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
						}
						else if (j == 3)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
						}
						else if (j == 4)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
						}
						else if (j == 5)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
						}
						else if (j == 6)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
						}
						else if (j == 7)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
						}
						else if (j == 8)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
						}
						else if (j == 9)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
						}
						else if (j == 10)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
						}
						else if (j == 11)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
						}
						else if (j == 12)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
							else if (k == 12)
							{
								k = (short) 13;
							}
						}
						else if (j == 13)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
							else if (k == 12)
							{
								k = (short) 13;
							}
							else if (k == 13)
							{
								k = (short) 14;
							}
						}
						else if (j == 14)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
							else if (k == 12)
							{
								k = (short) 13;
							}
							else if (k == 13)
							{
								k = (short) 14;
							}
							else if (k == 14)
							{
								k = (short) 15;
							}
						}
						else if (j == 15)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
							else if (k == 12)
							{
								k = (short) 13;
							}
							else if (k == 13)
							{
								k = (short) 14;
							}
							else if (k == 14)
							{
								k = (short) 15;
							}
							else if (k == 15)
							{
								k = (short) 16;
							}
						}
						
						
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 1) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text14.Text) - Conversion.Val(Text12.Text), "0.00"); //与点有关系，不用执行循环
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 2) = Text1[j].Text; //与点有关系，不用执行循环
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 3) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlChuzhi[j], "##0.###");
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 4) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlZhongzhi[j], "##0.###");
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 5) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlShizhi[j], "##0.###");
						//     objExcel.ActiveSheet.Cells(5 + Jd_number * (xx - 1) + k, 6) = Format(text16.Text, "##0.##")
						//     objExcel.ActiveSheet.Cells(5 + Jd_number * (xx - 1) + k, 7) = Format(text15.Text, "##0.##")
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 8) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Text14.Text, "##0.##");
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 9) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Text12.Text, "###0.##");
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 10) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Module1.Moni[j], "###0.###");
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 11) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text3[j].Text), "###0.###");
						
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 12) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Text5[j].Text, "0.0");
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 13) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Jsyq[System.Convert.ToInt32(xx) - 1], "0.00");
						
						
						//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (System.Math.Abs(System.Convert.ToDouble(Text5[j].Text)) > sub_Renamed.Jsyq[System.Convert.ToInt32(xx) - 1])
						{
							//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 14) = "不合格";
							//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 14).Font.Color = 0xFF;
						}
						else
						{
							//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 14) = "合  格";
							//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.cells(System.Convert.ToInt32(5 + System.Convert.ToInt32(sub_Renamed.Jd_number * System.Convert.ToInt32(System.Convert.ToInt32(xx) - 1))) + k, 14).Font.Color = 0x80000008;
						}
					}
				}
				
			}
			//'全部结束处理
			
			
			// yibiao_No = ""
			//yibiao_No = yibiao_No + Str(yibiaoNo)
			//Call save_execel
			//objExcel.Workbooks(1).SaveAs (App.Path & "\report\" & Trim(yibiao_No) & ".xls")
			//'objExcela.Workbooks.Close
			//On Error Resume Next
			
			Labt.Text = "检定完毕，请点击《保存》数据，并关闭EXCEL文件。重新检定需退出子程序！";
			
			this.kaishi.Enabled = true;
			sub_Renamed.Jdks = false;
			//
			
		}
		
		private void Label7_Click(short Index)
		{
			
		}
		
		
		
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option3.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option3_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (EventSender.Checked)
			{
				for ( = ;0; i <= 11); i++;);
				{
					Label11[sub_Renamed.i].Text = "MJ";
					Label13[sub_Renamed.i].Text = "MJ";
				}
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option4.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option4_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (EventSender.Checked)
			{
				for ( = ;0; i <= 11); i++;);
				{
					Label13[sub_Renamed.i].Text = "kWh";
					Label11[sub_Renamed.i].Text = "kWh";
				}
			}
		}
		public void SSCommand1_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.yibiao_No = int.Parse("");
			sub_Renamed.yibiao_No = int.Parse(Conversion.Str(Mdlguanfa.yibiaoNo).Trim());
			sub_Renamed.save_execel();
			sub_Renamed.objExcel.Workbooks(1).SaveAs((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\report\\" + (sub_Renamed.yibiao_No).ToString().Trim() + ".xls");
			Printjsqbdz();
		}
		
		public void SSCommand11_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.Jdks = true;
			frmshz.Default.Show();
		}
		
		
		public void SSCommand2_ClickEvent(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.Jdks2 = false;
			frmshz.Default.Show();
			frmshz.Default.Frame1[0].Enabled = false;
			frmshz.Default.Frame1[1].Enabled = false;
			frmshz.Default.Frame2.Enabled = false;
			frmshz.Default.Frame3.Enabled = false;
			//  frmzjsz.Frame4.Enabled = False
			
			
			frmshz.Default.Command1.Visible = false;
			frmshz.Default.Command2.Visible = true;
			frmshz.Default.Command3.Enabled = false;
			frmshz.Default.Command2.Focus();
		}
		
		public void Text1_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text1.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text1[Index + 1].Focus();
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text10.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text10_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text10.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
		}
		
		public void Text10_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text10.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text11_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text11.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//If (Chr$(KeyAscii) Like "[0-9]") Or (Chr$(KeyAscii) Like "[.]") Or (KeyAscii = 13) Then
			//
			//Else
			//    KeyAscii = 0
			//End If
			//If KeyAscii = 13 Then
			//           Text12(Index).SetFocus
			//     End If
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text15.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text15_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option1.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_Rpt = mi[4];
				//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_a8 = mi[5];
				//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_b8 = mi[6];
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text15.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 20 & sub_Renamed.pt_om <= 40)
				{
					pt_centgrade();
					Text12.Text = Text12.Text(sub_Renamed.centgrade, "0.000");
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text15.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 99 & sub_Renamed.pt_om <= 140)
				{
					Text12.Text = Text12.Text(standom_t1((float) (Conversion.Val(Text15.Text))), "0.000");
				}
			}
		}
		public void text16_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text15.Focus();
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text16.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text16_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option1.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_Rpt = mi[1];
				//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_a8 = mi[2];
				//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_b8 = mi[3];
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text16.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 20 & sub_Renamed.pt_om <= 40)
				{
					pt_centgrade();
					Text14.Text = Text14.Text(sub_Renamed.centgrade, "0.000");
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text16.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 99 & sub_Renamed.pt_om <= 140)
				{
					Text14.Text = Text14.Text(standom_t((float) (Conversion.Val(Text16.Text))), "0.000");
				}
			}
		}
		
		public void Text2_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text2.GetIndex(eventSender);
			//On Error Resume Next
			//If KeyAscii = 13 Then Text2(Index + 1).SetFocus
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				sub_Renamed.ZlChuzhi[Index] = (float) (Conversion.Val(Text2[Index].Text));
				
				for ( = ;Index; i <= sub_Renamed.End_biaowei - 1); i++;);
				{
					if (Strings.Len(Text1[sub_Renamed.i + 1].Text) > 0)
					{
						goto ss;
					}
				}
ss:
				Text2[sub_Renamed.i + 1].Focus();
				
				if (Strings.Len(Text1[sub_Renamed.End_biaowei].Text) > 0 && Strings.Len(Text2[sub_Renamed.End_biaowei].Text) > 0)
				{
					Command4.Focus();
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text38.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text38_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Labt.Text = "正在" + "" + System.Convert.ToString(Conversion.Val(Text38.Text)) + "" + "m3/h处模拟流量约" + "" + System.Convert.ToString(sub_Renamed.Jd_liang[System.Convert.ToInt32(xx) - 1]) + "" + "L进行检测，请等待约    秒";
			
		}
		
		public void Text8_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text8.GetIndex(eventSender);
			
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			
			if (KeyAscii == 13)
			{
				
				
				if (Strings.Len(Text6[Index].Text) == 0)
				{
					MessageBox.Show("请输入热能初值");
					
					
					goto EventExitSub;
				}
				if (Strings.Len(Text8[Index].Text) == 0)
				{
					MessageBox.Show("请输入热能终值");
					
					goto EventExitSub;
				}
				
				//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Jsyq[System.Convert.ToInt32(xx) - 1] = float.Parse(Jsyq(1 + System.Math.Abs(4 * Conversion.Val(Twcd.Text) / (Conversion.Val(Text14.Text) - Conversion.Val(Text12.Text))), "0.00")); //示值误差技术要求
				
				stb();
				
				sub_Renamed.ZlShizhi[Index] = (float) (Conversion.Val((System.Convert.ToDouble(Text8[Index].Text)) - System.Convert.ToDouble(Text6[Index].Text).ToString())); //热量示值
				
				
				Text5[Index].Text = Text5((sub_Renamed.ZlShizhi[Index] - Conversion.Val(Text3[Index].Text)) / Conversion.Val(Text3[Index].Text) * 100, "0.0"); //示值误差
				
				
				//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (System.Math.Abs(Conversion.Val(Text5[Index].Text)) > sub_Renamed.Jsyq[System.Convert.ToInt32(xx) - 1])
				{
					Text5[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); // 红
				}
				else
				{
					Text5[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
				}
				
				sub_Renamed.ZlZhongzhi[Index] = (float) (Conversion.Val(Text8[Index].Text));
				
				for ( = ;Index; i <= sub_Renamed.End_biaowei - 1); i++;);
				{
					if (Strings.Len(Text1[sub_Renamed.i + 1].Text) > 0)
					{
						goto ss;
					}
				}
ss:
				Text8[sub_Renamed.i + 1].Focus();
				
			}
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text5.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text5_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text5.GetIndex(eventSender);
			//On Error Resume Next
			//If Abs(Val(Text5(Index).Text)) > Jsyq(xx - 1) Then
			//           Text5(Index).ForeColor = &HFF& ' 红
			//       Else
			//           Text5(Index).ForeColor = &H0&
			//       End If
		}
		
		public void Text6_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text6.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				
				sub_Renamed.ZlChuzhi[Index] = (float) (Conversion.Val(Text6[Index].Text));
				for ( = ;Index; i <= sub_Renamed.End_biaowei - 1); i++;);
				{
					if (Strings.Len(Text1[sub_Renamed.i + 1].Text) > 0)
					{
						goto ss;
					}
				}
ss:
				Text6[sub_Renamed.i + 1].Focus();
				
				if (Strings.Len(Text1[sub_Renamed.End_biaowei].Text) > 0 && Strings.Len(Text6[sub_Renamed.End_biaowei].Text) > 0)
				{
					Command3.Focus();
				}
				
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		
		public void Text4_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text4.GetIndex(eventSender);
			
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object imputdata;
			float mvolume;
			if (KeyAscii == 13)
			{
				
				txt_idx = Index;
				mvolume = (float) (Conversion.Val(Text14.Text));
				if (mvolume == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("进口温度不能为零的数字！！", MsgBoxStyle.OkOnly, null);
					Text14.Focus();
					goto EventExitSub;
				}
				mvolume = (float) (Conversion.Val(Text4[Index].Text));
				if (mvolume == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("模拟流量累积值不得为零！", MsgBoxStyle.OkOnly, null);
					Text4[Index].Focus();
					goto EventExitSub;
				}
				
				if (Conversion.Val(Text14.Text) - Conversion.Val(Text12.Text) == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 imputdata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					imputdata = Interaction.MsgBox("进出口温度不能相同！", MsgBoxStyle.OkOnly, null);
					
					goto EventExitSub;
				}
				
				stb();
				Module1.Moni[Index] = (float) (Conversion.Val(Text4[Index].Text) - Conversion.Val(Text2[Index].Text));
				for ( = ;Index; i <= sub_Renamed.End_biaowei - 1); i++;);
				{
					if (Strings.Len(Text1[sub_Renamed.i + 1].Text) > 0)
					{
						goto ss;
					}
				}
ss:
				Text4[sub_Renamed.i + 1].Focus();
				
			}
			
EventExitSub:
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		private void text9_Change(short Index)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
		}
		
		private void text9_KeyPress(short Index, short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short abc;
			if (KeyAscii == 13)
			{
				//            pt_rpt = mi(1) ' Val(Text37.Text)
				//            pt_a8 = mi(2) 'Val(Text38.Text)
				//            pt_b8 = mi(3) 'Val(Text39.Text)
				//            pt_om = Val(Text9.Text)
				//            If pt_rpt = 0 Or pt_a8 = 0 Or pt_b8 = 0 Or pt_om <= 20 Or pt_om > 40 Then
				//              abc = MsgBox("标准铂电阻参数错或电阻值超范围！", vbOKOnly)
				//              Text10.SetFocus
				//              Exit Sub
				//            End If
				//            Call pt_centgrade
				//            Label2.Caption = standom_t(Val(text16.Text))
				Text12.Focus();
			}
			
		}
		
		private void pt_centgrade()
		{
			//以下是铂电阻计算程序：
			double[] d = new double[10];
			double wt = 0;
			double deltaW = 0;
			double wrt = 0;
			double pt;
			double r = 0;
			double t = 0;
			double a;
			double b;
			double a8 = 0;
			double b8 = 0;
			double rpt = 0;
			
			float t1;
			float t2;
			float t3;
			
			float[] pt1000 = new float[101];
			short i = 0;
			
			d[0] = 439.932854;
			d[1] = 472.41802;
			d[2] = 37.684494;
			d[3] = 7.472018;
			d[4] = 2.920828;
			d[5] = 0.005184;
			d[6] = -0.963864;
			d[7] = -0.188732;
			d[8] = 0.191203;
			d[9] = 0.049025;
			
			//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			r = System.Convert.ToDouble(sub_Renamed.pt_om);
			//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			a8 = System.Convert.ToDouble(sub_Renamed.pt_a8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b8 = System.Convert.ToDouble(sub_Renamed.pt_b8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			rpt = System.Convert.ToDouble(sub_Renamed.pt_Rpt);
			
			wt = r / rpt;
			deltaW = a8 * (wt - 1) + b8 * Math.Pow((wt - 1), 2);
			wrt = wt - deltaW;
			t = 0;
			for (i = 0; i <= 9; i++)
			{
				t = t + d[i] * Math.Pow(((wrt - 2.64) / 1.64), i); //t=d0*sum[di(Wr(t)-2.64)/1.64]^I;I:1 to 9
			}
			t1 = (float) t;
			sub_Renamed.centgrade = System.Math.Round(t, 4);
			
		}
		
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//
			//    MSComm6.PortOpen = False
			//    MSComm6.PortOpen = True
			//    MSComm6.Output = "S"
			//    MSComm6.PortOpen = False
			//    MSComm6.PortOpen = True
			//
			//    Do
			//      DoEvents
			//      Kk1 = Kk1 + 1
			//      delay_times (1)
			//    Loop Until MSComm6.InBufferCount >= 9 Or Kk1 > 2
			//
			//    Data_in1 = MSComm6.Input
			//'
			//    text16.Text = Data_in1
			//
			//Wendu_js1 = Wendu_js1 + 1
			//'If Wendu_js1 = 1 Then MsgBox "请将转换开关转向进口标准铂电阻"
			//If Wendu_js1 >= 1 Then
			//    Timer1.Enabled = False
			//    Wendu_js1 = 0
			//End If
			
		}
		
		
		
		public void Timer14_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text16.Visible = false;
			MSComm1.Output = "FETC? (@2)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text16.Text = System.Convert.ToString(MSComm1.Input);
			if (Text16.Text == "")
			{
				Text14.Text = Text14.Text;
			}
			else
			{
				Text14.Text = Text14.Text(Conversion.Val(Text16.Text), "0.000");
			}
		}
		
		public void Timer16_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text15.Visible = false;
			MSComm1.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text15.Text = System.Convert.ToString(MSComm1.Input);
			if (Text15.Text == "")
			{
				Text12.Text = Text12.Text;
			}
			else
			{
				Text12.Text = Text12.Text(Conversion.Val(Text15.Text), "0.000");
			}
		}
		
		public void Timer18_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			
			MSComm1.PortOpen = false;
			MSComm1.PortOpen = true;
			MSComm1.Output = "S";
			MSComm1.PortOpen = false;
			MSComm1.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				Kk1++;
				sub_Renamed.delay_times(1);
			} while (!(MSComm1.InBufferCount >= 9 | Kk1 > 9));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm1.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = System.Convert.ToString(MSComm1.Input);
			//
			Text16.Text = Data_in1;
			
			Wendu_js1++;
			if (Wendu_js1 < 15)
			{
				//   Text5.Text = Data_in1
			}
			else if (Wendu_js1 >= 15 & Wendu_js1 <= 30)
			{
				if (Wendu_js1 == 15)
				{
					MessageBox.Show("请在十秒钟内将出口铂电阻接入测试仪！");
				}
				Text15.Text = Data_in1;
				
			}
			else if (Wendu_js1 > 30)
			{
				Timer18.Enabled = false;
				Wendu_js1 = (short) 0;
			}
		}
		
		public void Timer2_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If MSComm3.PortOpen = False Then MSComm3.PortOpen = True
			// If MSComm2.PortOpen = False Then MSComm2.PortOpen = True
			//
			//   Select Case MSComm3.CommEvent
			//      Case 2
			//          sj2 = Trim(MSComm3.Input)
			//'       Tpcj1 = Tpcj1 + 1
			//         If Tpcj1 > 3000 Then Tpcj1 = 5
			//'        If Tpcj1 > 2 Then
			//           For i = 1 To 1100
			//               sj6 = Mid(sj2, i, 1)
			//'               s3 = Mid(s2, i + 13, 1)
			//               sj5 = Mid(sj2, i, 5)
			//                  If StrComp(sj5, "0.00", 1) = 0 Then
			//                        Text16.Text = 0
			//                Text14.Text = Val(Text16.Text)
			//                     Exit Sub
			//                  End If
			//                  If (StrComp(sj6, "+", 1) = 0) Then
			//                      Text16.Text = Trim(Mid(sj2, i + 1, 9))
			//                      Text14.Text = Val(Text16.Text)
			//                       Exit For
			//                  ElseIf (StrComp(sj6, "-", 1) = 0) Then
			//                      Text16.Text = "-" & Trim(Mid(sj2, i + 1, 9))
			//                      Text14.Text = Val(Text16.Text)
			//                      Exit For
			//                  End If
			//             Next i
			//
			//      Case Else
			//   End Select
			//
			//
			//
			//   Select Case MSComm2.CommEvent
			//      Case 2
			//          sc2 = Trim(MSComm2.Input)
			//'       Tpcj1 = Tpcj1 + 1
			//         If Tpcj1 > 3000 Then Tpcj1 = 5
			//'        If Tpcj1 > 2 Then
			//           For i = 1 To 1100
			//               sc6 = Mid(sc2, i, 1)
			//'               s3 = Mid(s2, i + 13, 1)
			//               sc5 = Mid(sc2, i, 5)
			//                  If StrComp(sc5, "0.00", 1) = 0 Then
			//                        Text15.Text = 0
			//                Text12.Text = Val(Text15.Text)
			//                     Exit Sub
			//                  End If
			//                  If (StrComp(sc6, "+", 1) = 0) Then
			//                      Text15.Text = Trim(Mid(sc2, i + 1, 9))
			//                      Text12.Text = Val(Text15.Text)
			//                       Exit For
			//                  ElseIf (StrComp(sc6, "-", 1) = 0) Then
			//                      Text15.Text = "-" & Trim(Mid(sc2, i + 1, 9))
			//                      Text12.Text = Val(Text15.Text)
			//                      Exit For
			//                  End If
			//             Next i
			//
			//      Case Else
			//   End Select
			
		}
		private void list()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short ii = 0;
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(1), ;4;) = "热能表计算器与铂电阻检定记录";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3)), ;sub_Renamed.objExcel.ActiveSheet.Cells(1, 10);).Merge();
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3)), ;sub_Renamed.objExcel.ActiveSheet.Cells(1, 14);).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Bold = true;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Size = 13;
			//
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(2), ;1;) = "型号：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(2, 2) = sub_Renamed.XingHao;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(2, 1)), ;sub_Renamed.objExcel.ActiveSheet.Cells(2, 2);).Font.Size = 11;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 1), objExcel.ActiveSheet.Cells(2, 2)).Borders.Weight = xlThin
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(2), ;3;) = "规格：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(2), ;4;) = sub_Renamed.GuiGe;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 3), sub_Renamed.objExcel.ActiveSheet.Cells(2, 4)).Font.Size = 11;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 3), objExcel.ActiveSheet.Cells(2, 4)).Borders.Weight = xlThin
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(2, 5) = "计量等级：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(2, 6) = sub_Renamed.YouXiaoQi;
			//       objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 6), objExcel.ActiveSheet.Cells(2, 8)).Merge
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 5), sub_Renamed.objExcel.ActiveSheet.Cells(2, 6)).Font.Size = 11;
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(3, 1) = "制造单位：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(3, 2) = sub_Renamed.ZhizaoDanwei;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(objExcel.ActiveSheet.Cells(3, 2)), ;objExcel.ActiveSheet.Cells(3, 4);).Merge();
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(3, 1)), ;sub_Renamed.objExcel.ActiveSheet.Cells(3, 4);).Font.Size = 11;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(3, 5) = "送检单位：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(3), ;6;) = sub_Renamed.SongjianDanwei;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(objExcel.ActiveSheet.Cells(3, 6)), ;objExcel.ActiveSheet.Cells(3, 10);).Merge();
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(3, 6)), ;sub_Renamed.objExcel.ActiveSheet.Cells(3, 10);).Font.Size = 11;
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(4), ;1;) = "检定日期：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(4, 2) = DateAndTime.Today;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 1), sub_Renamed.objExcel.ActiveSheet.Cells(4, 2)).Font.Size = 11;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(4, 3) = "检定员：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(4), ;4;) = sub_Renamed.JianCeYuan;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(4, 3)), ;sub_Renamed.objExcel.ActiveSheet.Cells(4, 4);).Font.Size = 11;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(4, 5) = "核验员：";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(4), ;6;) = "";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(4, 5)), ;sub_Renamed.objExcel.ActiveSheet.Cells(4, 6);).Font.Size = 11;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(7, 4), objExcel.ActiveSheet.Cells(7, 4)).Borders.Weight = xlThin
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point, 14)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point, 14)).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Rows 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Rows(5).WrapText = true;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1)), ;sub_Renamed.objExcel.ActiveSheet.Cells(5, 14);).Font.Size = 11;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(6, 1), sub_Renamed.objExcel.ActiveSheet.Cells(6 + sub_Renamed.Jd_number * sub_Renamed.Jd_point, 14)).Font.Size = 10;
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(5, 1) = "温差点";
			
			if (Option3.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 2) = "表  号";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 3) = "E0 (MJ)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 4) = "E1 (MJ)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;5;) = "E1-E0 (MJ)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;6;) = "进口电阻 (Ω)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;7;) = "出口电阻 (Ω)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;8;) = "进口温度 (℃)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;9;) = "出口温度 (℃)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;10;) = "模拟流量 (L)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;11;) = "标准值 (MJ)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 12) = "示值误差 (%)  ";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 13) = "要求±%";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;14;) = "检定结果";
			}
			else if (Option4.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 2) = "表  号";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 3) = "E0 (kWh)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 4) = "E1 (kWh)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;5;) = "E1-E0 (kWh)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;6;) = "进口电阻 (Ω)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;7;) = "出口电阻 (Ω)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;8;) = "进口温度 (℃)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;9;) = "出口温度 (℃)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;10;) = "模拟流量 (L)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 11) = "标准值 (kWh)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 12) = "示值误差 (%)  ";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 13) = "要求±%";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;14;) = "检定结果";
				
			}
			
			
			for (ii = 1; ii <= sub_Renamed.Jd_point; ii++)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(6 + (ii - 1) * sub_Renamed.Jd_number, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + ii * sub_Renamed.Jd_number, 1)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(sub_Renamed.objExcel.ActiveSheet.Cells(6 + (ii - 1) * sub_Renamed.Jd_number, 13)), ;sub_Renamed.objExcel.ActiveSheet.Cells(5 + ii * sub_Renamed.Jd_number, 13);).Merge();
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(4 + (ii - 1) * Jd_number, 11), objExcel.ActiveSheet.Cells(3 + ii * Jd_number, 11)).Merge
			}
			
		}
		
		
		public void Timer21_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object indata = null;
			short n = 0;
			object data = null;
			string s;
			object c;
			object xiang = null;
			object changdu = null;
			object qian = null;
			object hou = null;
			object x = null;
			Timer21.Enabled = false;
			if (DanJian == true)
			{
				goto bb;
			}
			
			for ( = ;Biao_Xuhao; i <= sub_Renamed.Stueck); i++;);
			{
				
				if (Text19[sub_Renamed.i + 1].Text != "通讯口不正常!")
				{
					break;
				}
				Biao_Xuhao++;
				if (Biao_Xuhao >= sub_Renamed.Stueck + 1)
				{
					Biao_Xuhao = (short) 0;
				}
				return;
				
			}
bb:
			if (Gaibiaohao == false) //读表数据
			{
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				data = sub_Renamed.tx.send_cmd((short) Metertype.SelectedIndex, sub_Renamed.cmd_type, Strings.Trim(System.Convert.ToString(Text11[Biao_Xuhao].Text)), Text21.Text.Trim() + ";;;;;;;;");
			}
			else //改表号
			{
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				data = sub_Renamed.tx.send_cmd((short) Metertype.SelectedIndex, sub_Renamed.cmd_type, Strings.Trim(System.Convert.ToString(Text11[Biao_Xuhao].Text)), sub_Renamed.addr_meter + Strings.Trim(System.Convert.ToString(Text1[Biao_Xuhao].Text)) + ";;;;;;;;");
			}
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Gaicanshu == true)
			{
				data = sub_Renamed.tx.send_cmd((short) Metertype.SelectedIndex, sub_Renamed.cmd_type, Strings.Trim(System.Convert.ToString(Text11[Biao_Xuhao].Text)), arg);
			}
			
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = Strings.Mid(System.Convert.ToString(data), 3);
			
			
			object cc = null;
			byte[] buf = null;
			//    Dim n As Integer
			
			n = (short) (Strings.Len(data) / 2);
			buf = new byte[n + 3 + 1];
			
			if (Metertype.SelectedIndex == 5 | Metertype.SelectedIndex == 8) //汇中和光大
			{
				buf = new byte[n - 1 + 1];
				//UPGRADE_WARNING: 未能解析对象 cc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cc = 0;
				for ( = ;0; i <= n - 1); i++;);
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					buf[sub_Renamed.i] = byte.Parse("&H" + Strings.Mid(System.Convert.ToString(data), sub_Renamed.i * 2 + 1, 2));
				}
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Txd = System.Convert.ToString(data);
				
			}
			else //其它表
			{
				for ( = ;0; i <= 3); i++;);
				{
					buf[sub_Renamed.i] = (byte) (0xFE);
				}
				
				//UPGRADE_WARNING: 未能解析对象 cc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cc = 0;
				for ( = ;0; i <= n - 1); i++;);
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					buf[sub_Renamed.i + 4] = byte.Parse("&H" + Strings.Mid(System.Convert.ToString(data), sub_Renamed.i * 2 + 1, 2));
					//UPGRADE_WARNING: 未能解析对象 cc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					cc = System.Convert.ToInt32(cc + buf[sub_Renamed.i + 4]) % 0x100;
				}
				
				sub_Renamed.Txd = "";
				for (p = 4; (int) p <= n + 3; p = (int) p + 1)
				{
					//UPGRADE_WARNING: 未能解析对象 p 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					t = Conversion.Hex(buf[(int) p]);
					for (jj = Strings.Len(t); jj <= 1; System.Convert.ToInt32(jj++))
					{
						//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						t = "0" + t;
					}
					//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.Txd = sub_Renamed.Txd + t;
				}
			} //汇中
			//
			if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7)
			{
				
				if (MSComm6[Biao_Xuhao].PortOpen == true)
				{
					MSComm6[Biao_Xuhao].PortOpen = false;
				}
				MSComm6[Biao_Xuhao].Settings = "9600,e,8,1";
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					MSComm6[Biao_Xuhao].PortOpen = true;
				}
				
				tstart = (float) VB.DateAndTime.Timer;
				while (VB.DateAndTime.Timer- tstart < 0.3)
				{
					System.Windows.Forms.Application.DoEvents();
				}
				
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					Text19[Biao_Xuhao + 1].Visible = true;
					if (sub_Renamed.Chinese == true)
					{
						Text19[Biao_Xuhao + 1].Text = "通讯口不正常!";
					}
					else
					{
						Text19[Biao_Xuhao + 1].Text = "Comport false!";
					}
					goto aa;
				}
				else
				{
					tstart = (float) VB.DateAndTime.Timer;
					aa1[0] = (byte) (0xFE);
					Text19[Biao_Xuhao + 1].Visible = false;
					while ((VB.DateAndTime.Timer- tstart) < 2.2)
					{
						MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(aa1);
						System.Windows.Forms.Application.DoEvents();
					}
					
					if (MSComm6[Biao_Xuhao].PortOpen == true)
					{
						MSComm6[Biao_Xuhao].PortOpen = false;
					}
					MSComm6[Biao_Xuhao].Settings = "2400,e,8,1";
					if (MSComm6[Biao_Xuhao].PortOpen == false)
					{
						MSComm6[Biao_Xuhao].PortOpen = true;
					}
					
					tstart = (float) VB.DateAndTime.Timer;
					while (VB.DateAndTime.Timer- tstart < 0.5)
					{
						System.Windows.Forms.Application.DoEvents();
					}
					MSComm6[Biao_Xuhao].OutBufferCount = 0;
					MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(buf);
				}
				
			}
			else if (Metertype.SelectedIndex == 8) //光大表
			{
				if (MSComm6[Biao_Xuhao].PortOpen == true)
				{
					MSComm6[Biao_Xuhao].PortOpen = false;
				}
				MSComm6[Biao_Xuhao].PortOpen = true;
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					Text19[Biao_Xuhao + 1].Visible = true;
					if (sub_Renamed.Chinese == true)
					{
						Text19[Biao_Xuhao].Text = "通讯口不正常!";
					}
					else
					{
						Text19[Biao_Xuhao].Text = "Comport false!";
					}
					goto aa;
				}
				else
				{
					tstart = (float) VB.DateAndTime.Timer;
					aa1[0] = (byte) (0xFE);
					aa1[1] = (byte) (0xFE);
					Text19[Biao_Xuhao + 1].Visible = false;
					while ((VB.DateAndTime.Timer- tstart) < 1)
					{
						MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(aa1);
						System.Windows.Forms.Application.DoEvents();
					}
					
					//       tstart = Timer
					//       Do While Timer - tstart < 0.3
					//       DoEvents
					//       Loop
					MSComm6[Biao_Xuhao].OutBufferCount = 0;
					MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(buf);
				}
				
			}
			else //其它表
			{
				if (MSComm6[Biao_Xuhao].PortOpen == true)
				{
					MSComm6[Biao_Xuhao].PortOpen = false;
				}
				MSComm6[Biao_Xuhao].PortOpen = true;
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					Text19[Biao_Xuhao + 1].Visible = true;
					if (sub_Renamed.Chinese == true)
					{
						Text19[Biao_Xuhao + 1].Text = "通讯口不正常!";
					}
					else
					{
						Text19[Biao_Xuhao + 1].Text = "Comport false!";
					}
					goto aa;
				}
				else
				{
					Text19[Biao_Xuhao + 1].Visible = false;
					MSComm6[Biao_Xuhao].OutBufferCount = 0;
					MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(buf);
				}
			}
			
			Gaibiaohao = false;
			Gaicanshu = false;
			
			if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7)
			{
				tstart = (float) VB.DateAndTime.Timer;
				while (VB.DateAndTime.Timer- tstart < 0.5)
				{
					System.Windows.Forms.Application.DoEvents();
				}
			}
			else
			{
				tstart = (float) VB.DateAndTime.Timer;
				while (VB.DateAndTime.Timer- tstart < 1)
				{
					System.Windows.Forms.Application.DoEvents();
				}
			}
			
			n = System.Convert.ToInt16(MSComm6[Biao_Xuhao].InBufferCount);
			//UPGRADE_WARNING: 未能解析对象 MSComm6().Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 indata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			indata = MSComm6[Biao_Xuhao].Input;
			//             n = LenB(indata)
			MSComm6[Biao_Xuhao].InBufferCount = 0;
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = getstr(indata, n);
			
			
			//从接收数据中挑出有效数据
			
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 xiang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			xiang = sub_Renamed.tx.standarddata(System.Convert.ToString(data), sub_Renamed.Txd);
			
			//UPGRADE_WARNING: 未能解析对象 xiang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = Strings.Mid(System.Convert.ToString(xiang), 3);
			
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = sub_Renamed.tx.getdata((short) Metertype.SelectedIndex, System.Convert.ToString(data), sub_Renamed.cmd_type);
			switch (sub_Renamed.cmd_type)
			{
				
			case "RD_NUM": //读表号
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (double.Parse(Strings.Mid(System.Convert.ToString(data), 1, 1)) == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text1[Biao_Xuhao].Text = Strings.Mid(System.Convert.ToString(data), 18);
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text11[Biao_Xuhao].Text = Strings.Mid(System.Convert.ToString(data), 3, 14);
					//UPGRADE_WARNING: 未能解析对象 changdu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					changdu = Strings.Trim(System.Convert.ToString(Text1[Biao_Xuhao].Text)).Length;
					//UPGRADE_WARNING: 未能解析对象 changdu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.addr_meter = Strings.Mid(System.Convert.ToString(data), 3, System.Convert.ToInt32(14 - System.Convert.ToInt32(changdu)));
					if (Biao_Xuhao == 0)
					{
						读表号一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 1)
					{
						读表号二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 2)
					{
						读表号三.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 3)
					{
						读表号四.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 4)
					{
						读表号五.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 5)
					{
						读表号六.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 6)
					{
						读表号七.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 7)
					{
						读表号八.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 8)
					{
						读表号九.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 9)
					{
						读表号十.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 10)
					{
						读表号十一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 11)
					{
						读表号十二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					
					
				}
				else
				{
					if (Text19[Biao_Xuhao + 1].Text != "通讯口不正常!")
					{
						Text1[Biao_Xuhao].Text = "读取错误";
					}
					if (Metertype.SelectedIndex == 8)
					{
						Text1[Biao_Xuhao].Text = "无此功能";
					}
				}
				break;
				
				
			case "WR_NUM": //写表号
				if (Biao_Xuhao == 0)
				{
					读表号一.Text = "已改表号";
				}
				读表号一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 1)
				{
					读表号二.Text = "已改表号";
				}
				读表号二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 2)
				{
					读表号三.Text = "已改表号";
				}
				读表号三.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 3)
				{
					读表号四.Text = "已改表号";
				}
				读表号四.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 4)
				{
					读表号五.Text = "已改表号";
				}
				读表号五.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 5)
				{
					读表号六.Text = "已改表号";
				}
				读表号六.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 6)
				{
					读表号七.Text = "已改表号";
				}
				读表号七.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 7)
				{
					读表号八.Text = "已改表号";
				}
				读表号八.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 8)
				{
					读表号九.Text = "已改表号";
				}
				读表号九.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 9)
				{
					读表号十.Text = "已改表号";
				}
				读表号十.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 10)
				{
					读表号十一.Text = "已改表号";
				}
				读表号十一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 11)
				{
					读表号十二.Text = "已改表号";
				}
				读表号十二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				break;
				
				
				
			case "RD_DATA": //读数据
			case "RD_HIGH_DATA":
				
				//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				qian = 0;
				for ( = ;0; i <= 4); i++;);
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 hou 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					hou = (System.Convert.ToInt32(qian) + 1).ToString().IndexOf(Strings.Mid(System.Convert.ToString(data), 3)) + 1;
					//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 hou 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x = Strings.Mid(System.Convert.ToString(data), 3).Substring(System.Convert.ToInt32(qian) + 1 - 1, System.Convert.ToDouble(System.Convert.ToInt32(hou) - System.Convert.ToDouble(qian)) - 1);
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text20[sub_Renamed.i].Text = () );x;
					//UPGRADE_WARNING: 未能解析对象 hou 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					qian = hou;
				}
				Text33[Biao_Xuhao].Text = Text20[2].Text;
				Text22[Biao_Xuhao].Text = Text20[0].Text;
				
				if (Strings.Len(Text33[Biao_Xuhao].Text) > 0 || Strings.Len(Text22[Biao_Xuhao].Text) > 0)
				{
					
					if (Biao_Xuhao == 0)
					{
						读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 1)
					{
						读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 2)
					{
						读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 3)
					{
						读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 4)
					{
						读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 5)
					{
						读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 6)
					{
						读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 7)
					{
						读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 8)
					{
						读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 9)
					{
						读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 10)
					{
						读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 11)
					{
						读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (sub_Renamed.Erstpunkt == true)
					{
						if (Metertype.SelectedIndex == 8)
						{
							Text2[Biao_Xuhao].Text = Text2(Conversion.Val(Text33[Biao_Xuhao].Text), "0.000");
						}
						else
						{
							Text2[Biao_Xuhao].Text = Text2(Conversion.Val(Text33[Biao_Xuhao].Text) * 1000, "0.000");
						}
					}
					if (sub_Renamed.Rechen == true && sub_Renamed.RechenLC == false)
					{
						if (Metertype.SelectedIndex == 8)
						{
							Text4[Biao_Xuhao].Text = Text4(Conversion.Val(Text33[Biao_Xuhao].Text), "0.000");
						}
						else
						{
							Text4[Biao_Xuhao].Text = Text4(Conversion.Val(Text33[Biao_Xuhao].Text) * 1000, "0.000");
						}
					}
					//            If frmcanshushezhi1.Option11.value = True Then
					if (sub_Renamed.Erstpunkt == true)
					{
						Text6[Biao_Xuhao].Text = Text6(Conversion.Val(Text22[Biao_Xuhao].Text), "0.0000");
					}
					if (sub_Renamed.Rechen == true && sub_Renamed.RechenLC == false)
					{
						Text8[Biao_Xuhao].Text = Text8(Conversion.Val(Text22[Biao_Xuhao].Text), "0.0000");
					}
					if (sub_Renamed.Readone == false)
					{
						Text10[2 * Biao_Xuhao].Text = Text10(Conversion.Val(Text20[3].Text), "0.00");
						Text10[2 * Biao_Xuhao + 1].Text = Text10(Conversion.Val(Text20[4].Text), "0.00");
						if (sub_Renamed.Tem == true)
						{
							if (sub_Renamed.Chinese == true)
							{
								if (Conversion.Val((System.Convert.ToDouble(Text10[2 * Biao_Xuhao + 1].Text)) - System.Convert.ToDouble(Text10[2 * Biao_Xuhao].Text).ToString()) > 0)
								{
									MessageBox.Show("请查看" + Conversion.Str(Biao_Xuhao + 1) + "号表温度传感器是否放反或焊反！");
								}
							}
							else
							{
								if (Conversion.Val((System.Convert.ToDouble(Text10[2 * Biao_Xuhao + 1].Text)) - System.Convert.ToDouble(Text10[2 * Biao_Xuhao].Text).ToString()) > 0)
								{
									MessageBox.Show("Please view the temperature sensor pair of meter No." + Conversion.Str(Biao_Xuhao + 1) + "  is placed or welded reversely!");
								}
							}
						}
					}
					//            End If
				}
				break;
			case "RD_FLOW_ARG": //读流量参数
				break;
				//'            Command13.BackColor = &HC00000
				//                    qian = 0
				//
				//                    Dim shu(7) As String
				//                    For i = 0 To 7
				//                        hou = InStr(qian + 1, Mid(data, 3), ";")
				//                        x = Mid(Mid(data, 3), qian + 1, hou - qian - 1)
				//                        shu(i) = x
				//                        qian = hou
				//                    Next i
				//
				//                    Select Case Metertype.ListIndex
				//                    Case 0
				//                    Text44(Biao_Xuhao).Text = shu(0)
				//                        For i = 0 To 2
				//'                            Text28(6 - i).Text = shu(i * 2 + 2)
				//                            Text23(i).Text = shu(i * 2 + 3)
				//                        Next i
				//
				//                    Case 1, 2
				//                        For i = 0 To 3
				//                            Text23(i).Text = shu(i)
				//                        Next i
				//
				//                    Case 3
				//                        For i = 0 To 2
				//                            shu(i) = shu(i) / 10000
				//                            shu(i) = ((1 - shu(i)) / shu(i)) * 100
				//                        Next i
				//                        For i = 0 To 2
				//                            Text23(i).Text = Round(shu(i), 1)
				//                        Next i
				//                    Case 4
				//                        Text23(0).Text = shu(0)
				//                        Text23(1).Text = shu(1)
				//                        Text23(2).Text = shu(3)
				//
				//                    Case Else
				//                     MsgBox "暂不具备此功能！"
				//                     exit sub
				//                    End Select
				//
				//'                    Text4.Text = Mid(data, 3)
				//'                    txtMsg.Text = data
				//            Case "WR_FLOW_ARG" '写流量参数
				//
				//                  If Biao_Xuhao = 0 Then 调一.BackColor = &HFF0000
				//                  If Biao_Xuhao = 1 Then 调二.BackColor = &HFF0000
				//                  If Biao_Xuhao = 2 Then 调三.BackColor = &HFF0000
				//                  If Biao_Xuhao = 3 Then 调四.BackColor = &HFF0000
				//                  If Biao_Xuhao = 4 Then 调五.BackColor = &HFF0000
				//                  If Biao_Xuhao = 5 Then 调六.BackColor = &HFF0000
				//                  If Biao_Xuhao = 6 Then 调七.BackColor = &HFF0000
				//                  If Biao_Xuhao = 7 Then 调八.BackColor = &HFF0000
				//                  If Biao_Xuhao = 8 Then 调九.BackColor = &HFF0000
				//                  If Biao_Xuhao = 9 Then 调十.BackColor = &HFF0000
				//                  If Biao_Xuhao = 10 Then 调十一.BackColor = &HFF0000
				//                  If Biao_Xuhao = 11 Then 调十二.BackColor = &HFF0000
				//
				//
				//
				//
				//                  If Zhijie = True Then
				//                    Command15.BackColor = &HC00000
				//                  ElseIf Huiling = True Then
				//                    Command14.BackColor = &HC00000
				//                  ElseIf Erci = True Then
				//                    Command12.BackColor = &HC00000
				//                  ElseIf Pingjun = True Then
				//                    Command13.BackColor = &HC00000
				//                  End If
				//            Case "WR_SETUP"
				//'                    txtMsg.Text = Mid(data, 3)
				//            Case "WR_CANCEL"
				//                    txtMsg.Text = Mid(data, 3)
				
		}
aa:
		if (DanJian == true)
		{
			DanJian = false;
		}
		return;
		
//		Biao_Xuhao++;
//		if (Biao_Xuhao >= sub_Renamed.Stueck + 1)
//		{
//			Biao_Xuhao = (short) 0;
//			}
//			return;
			
//			Timer21.Enabled = true;
			//'                      delay_times (0.5)
		}
		
		
		public void Timer3_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			t6++;
			Label51.Visible = true;
			if (double.Parse(Text38.Text) == 0)
			{
				Text38.Text = (Mdlguanfa.Qp).ToString();
			}
			
			//UPGRADE_WARNING: 未能解析对象 xx 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Label51.Text = Label51.Text(sub_Renamed.Jd_liang[System.Convert.ToInt32(xx) - 1] / Conversion.Val(Text38.Text) * 3.6 - t6, "0");
			if (double.Parse(Label51.Text) < 0)
			{
				Label51.Visible = false;
				//    Labt.Caption = "模拟流量结束，请输入模拟流量终值V1（L）。"
				Timer3.Enabled = false;
				Label2.Visible = false;
				Label55.Visible = false;
				Text38.Visible = false;
				t6 = (short) 0;
			}
		}
		
		
		
		
		
		private string getstr(object v, short l)
		{
			string returnValue = "";
			
			
			
			for ( = ;0; i <= l - 1); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 v() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 s1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				s1 = VB.Strings.Right("0" + Conversion.Hex(v(sub_Renamed.i)), 2);
				//UPGRADE_WARNING: 未能解析对象 s1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 s 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				s = s + System.Convert.ToString(s1);
			}
			//UPGRADE_WARNING: 未能解析对象 s 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			returnValue = System.Convert.ToString(s);
			return returnValue;
		}
		
		
		//Private Sub SendData1(data As String)
		// On Error Resume Next
		//
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		//ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(0).PortOpen = True Then MSComm6(0).PortOpen = False
		//  MSComm6(0).Settings = "9600,e,8,1"
		//If MSComm6(0).PortOpen = False Then MSComm6(0).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(0).PortOpen = False Then
		//    Text19(1).Visible = True
		//    If Chinese = True Then
		//    Text19(1).Text = "通讯口不正常!"
		//    Else
		//    Text19(1).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(1).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(0).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(0).PortOpen = True Then MSComm6(0).PortOpen = False
		//    MSComm6(0).Settings = "2400,e,8,1"
		//   If MSComm6(0).PortOpen = False Then MSComm6(0).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(0).Output = buf
		//End If
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg1 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(0).Output = buf
		//
		//Else
		//    If MSComm6(0).PortOpen = True Then MSComm6(0).PortOpen = False
		//    MSComm6(0).PortOpen = True
		//      If MSComm6(0).PortOpen = False Then
		//        Text19(1).Visible = True
		//        If Chinese = True Then
		//           Text19(1).Text = "通讯口不正常!"
		//        Else
		//           Text19(1).Text = "Comport false!"
		//        End If
		//        Exit Sub
		//      Else
		//        Text19(1).Visible = False
		//        MSComm6(0).Output = buf
		//      End If
		//End If
		//Sendend = True
		//
		//End Sub
		//Private Sub SendData2(data As String)
		//On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(1).PortOpen = True Then MSComm6(1).PortOpen = False
		//  MSComm6(1).Settings = "9600,e,8,1"
		//If MSComm6(1).PortOpen = False Then MSComm6(1).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(1).PortOpen = False Then
		//    Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(2).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(1).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(1).PortOpen = True Then MSComm6(1).PortOpen = False
		//    MSComm6(1).Settings = "2400,e,8,1"
		//   If MSComm6(1).PortOpen = False Then MSComm6(1).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(1).Output = buf
		//End If
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg2 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(1).Output = buf
		//Else
		//    If MSComm6(1).PortOpen = True Then MSComm6(1).PortOpen = False
		//    MSComm6(1).PortOpen = True
		//    If MSComm6(1).PortOpen = False Then
		//    Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(2).Visible = False
		//'
		//    MSComm6(1).Output = buf
		//
		//   End If
		//End If
		//Sendend = True
		//
		//End Sub
		//Private Sub SendData3(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(2).PortOpen = True Then MSComm6(2).PortOpen = False
		//  MSComm6(2).Settings = "9600,e,8,1"
		//If MSComm6(2).PortOpen = False Then MSComm6(2).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(2).PortOpen = False Then
		//    Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(3).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(2).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(2).PortOpen = True Then MSComm6(2).PortOpen = False
		//    MSComm6(2).Settings = "2400,e,8,1"
		//   If MSComm6(2).PortOpen = False Then MSComm6(2).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(2).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg3 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(2).Output = buf
		//Else
		//    If MSComm6(2).PortOpen = True Then MSComm6(2).PortOpen = False
		//    MSComm6(2).PortOpen = True
		//    If MSComm6(2).PortOpen = False Then
		//    Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(3).Visible = False
		//'
		//    MSComm6(2).Output = buf
		//
		//   End If
		//   End If
		//Sendend = True
		//    End Sub
		//Private Sub SendData4(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(3).PortOpen = True Then MSComm6(3).PortOpen = False
		//  MSComm6(3).Settings = "9600,e,8,1"
		//If MSComm6(3).PortOpen = False Then MSComm6(3).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(3).PortOpen = False Then
		//    Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(4).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(3).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(3).PortOpen = True Then MSComm6(3).PortOpen = False
		//    MSComm6(3).Settings = "2400,e,8,1"
		//   If MSComm6(3).PortOpen = False Then MSComm6(3).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(3).Output = buf
		//End If
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg4 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(3).Output = buf
		//Else
		//    If MSComm6(3).PortOpen = True Then MSComm6(3).PortOpen = False
		//    MSComm6(3).PortOpen = True
		//    If MSComm6(3).PortOpen = False Then
		//    Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(4).Visible = False
		//'
		//    MSComm6(3).Output = buf
		//
		//   End If
		//End If
		//  Sendend = True
		//    End Sub
		//Private Sub SendData5(data As String)
		// On Error Resume Next
		//
		//
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(4).PortOpen = True Then MSComm6(4).PortOpen = False
		//  MSComm6(4).Settings = "9600,e,8,1"
		//If MSComm6(4).PortOpen = False Then MSComm6(4).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(4).PortOpen = False Then
		//    Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(5).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(4).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(4).PortOpen = True Then MSComm6(4).PortOpen = False
		//    MSComm6(4).Settings = "2400,e,8,1"
		//   If MSComm6(4).PortOpen = False Then MSComm6(4).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(4).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg5 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(4).Output = buf
		//Else
		//    If MSComm6(4).PortOpen = True Then MSComm6(4).PortOpen = False
		//    MSComm6(4).PortOpen = True
		//    If MSComm6(4).PortOpen = False Then
		//    Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(5).Visible = False
		//'
		//    MSComm6(4).Output = buf
		//
		//   End If
		//
		//End If
		//Sendend = True
		//
		//    End Sub
		//
		//Private Sub SendData6(data As String)
		//On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(5).PortOpen = True Then MSComm6(5).PortOpen = False
		//  MSComm6(5).Settings = "9600,e,8,1"
		//If MSComm6(5).PortOpen = False Then MSComm6(5).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(5).PortOpen = False Then
		//    Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(6).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(5).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(5).PortOpen = True Then MSComm6(5).PortOpen = False
		//    MSComm6(5).Settings = "2400,e,8,1"
		//   If MSComm6(5).PortOpen = False Then MSComm6(5).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(5).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg6 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(5).Output = buf
		//Else
		//    If MSComm6(5).PortOpen = True Then MSComm6(5).PortOpen = False
		//    MSComm6(5).PortOpen = True
		//    If MSComm6(5).PortOpen = False Then
		//    Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(6).Visible = False
		//'
		//    MSComm6(5).Output = buf
		//
		//   End If
		// End If
		// Sendend = True
		//    End Sub
		//Private Sub SendData7(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(6).PortOpen = True Then MSComm6(6).PortOpen = False
		//  MSComm6(6).Settings = "9600,e,8,1"
		//If MSComm6(6).PortOpen = False Then MSComm6(6).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(6).PortOpen = False Then
		//    Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(7).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(6).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(6).PortOpen = True Then MSComm6(6).PortOpen = False
		//    MSComm6(6).Settings = "2400,e,8,1"
		//   If MSComm6(6).PortOpen = False Then MSComm6(6).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(6).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg7 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(6).Output = buf
		//Else
		//    If MSComm6(6).PortOpen = True Then MSComm6(6).PortOpen = False
		//    MSComm6(6).PortOpen = True
		//    If MSComm6(6).PortOpen = False Then
		//    Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(7).Visible = False
		//'
		//
		//    MSComm6(6).Output = buf
		// End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData8(data As String)
		//On Error Resume Next
		//      Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(7).PortOpen = True Then MSComm6(7).PortOpen = False
		//  MSComm6(7).Settings = "9600,e,8,1"
		//If MSComm6(7).PortOpen = False Then MSComm6(7).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(7).PortOpen = False Then
		//    Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(8).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(7).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(7).PortOpen = True Then MSComm6(7).PortOpen = False
		//    MSComm6(7).Settings = "2400,e,8,1"
		//   If MSComm6(7).PortOpen = False Then MSComm6(7).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(7).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg8 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(7).Output = buf
		//Else
		//    If MSComm6(7).PortOpen = True Then MSComm6(7).PortOpen = False
		//    MSComm6(7).PortOpen = True
		//    If MSComm6(7).PortOpen = False Then
		//    Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(8).Visible = False
		//'
		//
		//    MSComm6(7).Output = buf
		//End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData9(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(8).PortOpen = True Then MSComm6(8).PortOpen = False
		//  MSComm6(8).Settings = "9600,e,8,1"
		//If MSComm6(8).PortOpen = False Then MSComm6(8).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(8).PortOpen = False Then
		//    Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(9).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(8).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(8).PortOpen = True Then MSComm6(8).PortOpen = False
		//    MSComm6(8).Settings = "2400,e,8,1"
		//   If MSComm6(8).PortOpen = False Then MSComm6(8).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(8).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg9 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(8).Output = buf
		//Else
		//    If MSComm6(8).PortOpen = True Then MSComm6(8).PortOpen = False
		//    MSComm6(8).PortOpen = True
		//    If MSComm6(8).PortOpen = False Then
		//    Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(9).Visible = False
		//'
		//
		//    MSComm6(8).Output = buf
		// End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData10(data As String)
		//On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(9).PortOpen = True Then MSComm6(9).PortOpen = False
		//  MSComm6(9).Settings = "9600,e,8,1"
		//If MSComm6(9).PortOpen = False Then MSComm6(9).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(9).PortOpen = False Then
		//    Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(10).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(9).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(9).PortOpen = True Then MSComm6(9).PortOpen = False
		//    MSComm6(9).Settings = "2400,e,8,1"
		//   If MSComm6(9).PortOpen = False Then MSComm6(9).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(9).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg10 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(9).Output = buf
		//Else
		//    If MSComm6(9).PortOpen = True Then MSComm6(9).PortOpen = False
		//    MSComm6(9).PortOpen = True
		//    If MSComm6(9).PortOpen = False Then
		//    Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(10).Visible = False
		//'
		//    MSComm6(9).Output = buf
		//End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData11(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(10).PortOpen = True Then MSComm6(10).PortOpen = False
		//  MSComm6(10).Settings = "9600,e,8,1"
		//If MSComm6(10).PortOpen = False Then MSComm6(10).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(10).PortOpen = False Then
		//    Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(11).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(10).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(10).PortOpen = True Then MSComm6(10).PortOpen = False
		//    MSComm6(10).Settings = "2400,e,8,1"
		//   If MSComm6(10).PortOpen = False Then MSComm6(10).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(10).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg11 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(10).Output = buf
		//Else
		//    If MSComm6(10).PortOpen = True Then MSComm6(10).PortOpen = False
		//    MSComm6(10).PortOpen = True
		//    If MSComm6(10).PortOpen = False Then
		//    Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(11).Visible = False
		//'
		//
		//    MSComm6(10).Output = buf
		//End If
		//End If
		//Sendend = True
		//    End Sub
		//Private Sub SendData12(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(11).PortOpen = True Then MSComm6(11).PortOpen = False
		//  MSComm6(11).Settings = "9600,e,8,1"
		//If MSComm6(11).PortOpen = False Then MSComm6(11).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(11).PortOpen = False Then
		//    Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(12).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(11).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(11).PortOpen = True Then MSComm6(11).PortOpen = False
		//    MSComm6(11).Settings = "2400,e,8,1"
		//   If MSComm6(11).PortOpen = False Then MSComm6(11).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(11).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg12 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(11).Output = buf
		//Else
		//    If MSComm6(11).PortOpen = True Then MSComm6(11).PortOpen = False
		//    MSComm6(11).PortOpen = True
		//    If MSComm6(11).PortOpen = False Then
		//    Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(12).Visible = False
		//'
		//    MSComm6(11).Output = buf
		//
		//   End If
		//End If
		//    Sendend = True
		//    End Sub
		//    Private Sub delay(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm1.PortOpen = False
		//MSComm1.Settings = "9600,e,8,1"
		//MSComm1.PortOpen = True
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//MSComm1.Output = aa1
		//'DoEvents
		//Wend
		//MSComm1.PortOpen = False
		//MSComm1.Settings = "2400,e,8,1"
		//MSComm1.PortOpen = True
		//
		//Exit Sub
		//End Sub
		//Private Sub delayg1(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(0).PortOpen = False Then
		//    Text19(1).Visible = True
		//    If Chinese = True Then
		//    Text19(1).Text = "通讯口不正常!"
		//    Else
		//    Text19(1).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(1).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(0).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg2(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(1).PortOpen = False Then
		//    Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(2).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(1).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg3(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(2).PortOpen = False Then
		//    Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(3).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(2).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg4(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(3).PortOpen = False Then
		//    Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(4).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(3).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg5(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(4).PortOpen = False Then
		//    Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(5).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(4).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg6(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(5).PortOpen = False Then
		//    Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(6).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(5).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg7(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(6).PortOpen = False Then
		//    Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(7).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(6).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg8(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(7).PortOpen = False Then
		//    Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(8).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(7).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg9(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(8).PortOpen = False Then
		//    Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(9).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(8).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg10(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(9).PortOpen = False Then
		//    Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(10).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(9).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg11(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(10).PortOpen = False Then
		//    Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(11).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(10).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg12(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(11).PortOpen = False Then
		//    Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(12).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(11).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay1(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(0).PortOpen = False
		//MSComm6(0).Settings = "9600,e,8,1"
		//MSComm6(0).PortOpen = True
		//delay_times (0.1)
		//
		//If MSComm6(0).PortOpen = False Then
		//    Text19(1).Visible = True
		//    If Chinese = True Then
		//    Text19(1).Text = "通讯口不正常!"
		//    Else
		//    Text19(1).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(1).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 0
		//         aa1(i) = aa0(i)
		//     Next i
		//     MSComm6(0).Output = aa1
		//   Wend
		//   MSComm6(0).PortOpen = False
		//   MSComm6(0).Settings = "2400,e,8,1"
		//   MSComm6(0).PortOpen = True
		//   delay_times (0.1)
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay2(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(1).PortOpen = False
		//MSComm6(1).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(1).PortOpen = True
		//If MSComm6(1).PortOpen = False Then
		//Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//Else
		//Text19(2).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(1).Output = aa1
		//
		//Wend
		//
		//MSComm6(1).PortOpen = False
		//MSComm6(1).Settings = "2400,e,8,1"
		//MSComm6(1).PortOpen = True
		//delay_times (0.1)
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay3(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(2).PortOpen = False
		//MSComm6(2).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(2).PortOpen = True
		//If MSComm6(2).PortOpen = False Then
		//Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(3).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(2).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(2).PortOpen = False
		//MSComm6(2).Settings = "2400,e,8,1"
		//MSComm6(2).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay4(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(3).PortOpen = False
		//MSComm6(3).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(3).PortOpen = True
		//If MSComm6(3).PortOpen = False Then
		//Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(4).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(3).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(3).PortOpen = False
		//MSComm6(3).Settings = "2400,e,8,1"
		//MSComm6(3).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay5(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(4).PortOpen = False
		//MSComm6(4).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(4).PortOpen = True
		//If MSComm6(4).PortOpen = False Then
		//Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(5).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(4).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(4).PortOpen = False
		//MSComm6(4).Settings = "2400,e,8,1"
		//MSComm6(4).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay6(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(5).PortOpen = False
		//MSComm6(5).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(5).PortOpen = True
		//If MSComm6(5).PortOpen = False Then
		//Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(6).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(5).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(5).PortOpen = False
		//MSComm6(5).Settings = "2400,e,8,1"
		//MSComm6(5).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay7(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(6).PortOpen = False
		//MSComm6(6).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(6).PortOpen = True
		//If MSComm6(6).PortOpen = False Then
		//Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(7).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(6).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(6).PortOpen = False
		//MSComm6(6).Settings = "2400,e,8,1"
		//MSComm6(6).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay8(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(7).PortOpen = False
		//MSComm6(7).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(7).PortOpen = True
		//If MSComm6(7).PortOpen = False Then
		//Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(8).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(7).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(7).PortOpen = False
		//MSComm6(7).Settings = "2400,e,8,1"
		//MSComm6(7).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay9(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(8).PortOpen = False
		//MSComm6(8).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(8).PortOpen = True
		//If MSComm6(8).PortOpen = False Then
		//Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(9).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(8).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(8).PortOpen = False
		//MSComm6(8).Settings = "2400,e,8,1"
		//MSComm6(8).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay10(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(9).PortOpen = False
		//MSComm6(9).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(9).PortOpen = True
		//If MSComm6(9).PortOpen = False Then
		//Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(10).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(9).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(9).PortOpen = False
		//MSComm6(9).Settings = "2400,e,8,1"
		//MSComm6(9).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay11(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(10).PortOpen = False
		//MSComm6(10).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(10).PortOpen = True
		//If MSComm6(10).PortOpen = False Then
		//Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(11).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(10).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(10).PortOpen = False
		//MSComm6(10).Settings = "2400,e,8,1"
		//MSComm6(10).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay12(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(11).PortOpen = False
		//MSComm6(11).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(11).PortOpen = True
		//If MSComm6(11).PortOpen = False Then
		//Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(1).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(11).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(11).PortOpen = False
		//MSComm6(11).Settings = "2400,e,8,1"
		//MSComm6(11).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		public object ComputerSum(double[] Arry, short nStart, short count)
		{
			object returnValue = null;
			double num = 0;
			double num1 = 0;
			short i = 0;
			num = 0;
			for (i = nStart; i <= count + nStart - 1; i++)
			{
				num = Arry[i] + num;
			}
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			num1 = num % 0x100;
			//UPGRADE_WARNING: 未能解析对象 ComputerSum 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			returnValue = num1;
			return returnValue;
		}
		
		private void DataClear()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//                        iTimeOut = 500
			
			//                         If Len(Text11(0).Text) = 14 Then
			//                         data = "6820" & Text11(0).Text & "2403A00E01"
			//                         SendData1 (data)
			//                          Sleep 500
			//                         End If
			//                         If Len(Text11(1).Text) = 14 Then
			//                         data = "6820" & Text11(1).Text & "2403A00E01"
			//                         SendData2 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(2).Text) = 14 Then
			//                         data = "6820" & Text11(2).Text & "2403A00E01"
			//                         SendData3 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(3).Text) = 14 Then
			//                         data = "6820" & Text11(3).Text & "2403A00E01"
			//                         SendData4 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(4).Text) = 14 Then
			//                         data = "6820" & Text11(4).Text & "2403A00E01"
			//                         SendData5 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(5).Text) = 14 Then
			//                         data = "6820" & Text11(5).Text & "2403A00E01"
			//                         SendData6 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(6).Text) = 14 Then
			//                         data = "6820" & Text11(6).Text & "2403A00E01"
			//                         SendData7 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(7).Text) = 14 Then
			//                         data = "6820" & Text11(7).Text & "2403A00E01"
			//                         SendData8 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(8).Text) = 14 Then
			//                          data = "6820" & Text11(8).Text & "2403A00E01"
			//                         SendData9 (data)
			//                          Sleep 500
			//                          End If
			//                         If Len(Text11(9).Text) = 14 Then
			//                         data = "6820" & Text11(9).Text & "2403A00E01"
			//                         SendData10 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(10).Text) = 14 Then
			//                         data = "6820" & Text11(10).Text & "2403A00E01"
			//                         SendData11 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(11).Text) = 14 Then
			//                         data = "6820" & Text11(11).Text & "2403A00E01"
			//                         SendData12 (data)
			//                         Sleep 500
			//                         End If
			//
		}
		private string GetUnit(string data)
		{
			string returnValue = "";
			if (data == "02")
			{
				returnValue = "Wh";
			}
			if (data == "05")
			{
				returnValue = "kWh";
			}
			if (data == "08")
			{
				returnValue = "MWh";
			}
			if (data == "0A")
			{
				returnValue = "MWh×100";
			}
			if (data == "01")
			{
				returnValue = "J";
			}
			if (data == "0B")
			{
				returnValue = "kJ";
			}
			if (data == "0E")
			{
				returnValue = "MJ";
			}
			if (data == "11")
			{
				returnValue = "GJ";
			}
			if (data == "13")
			{
				returnValue = "GJ×100";
			}
			if (data == "14")
			{
				returnValue = "W";
			}
			if (data == "17")
			{
				returnValue = "kW";
			}
			if (data == "1A")
			{
				returnValue = "MW";
			}
			if (data == "29")
			{
				returnValue = "L";
			}
			if (data == "2C")
			{
				returnValue = "m3";
			}
			if (data == "32")
			{
				returnValue = "L/h";
			}
			if (data == "35")
			{
				returnValue = "m3/h";
			}
			return returnValue;
		}
		
		
		public void Timer4_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.wdjs++;
			if (sub_Renamed.wdjs > 190000)
			{
				sub_Renamed.wdjs = 10;
			}
			sub_Renamed.wdcz[sub_Renamed.wdjs] = (float) (Conversion.Val(Text14.Text));
			sub_Renamed.wdzz[sub_Renamed.wdjs] = (float) (Conversion.Val(Text12.Text));
			
			sub_Renamed.jkwd = sub_Renamed.jkwd + sub_Renamed.wdcz[sub_Renamed.wdjs];
			sub_Renamed.ckwd = sub_Renamed.ckwd + sub_Renamed.wdzz[sub_Renamed.wdjs];
			
			sub_Renamed.inlet = float.Parse(((sub_Renamed.jkwd) / sub_Renamed.wdjs), "0.0");
			sub_Renamed.outlet = float.Parse(((sub_Renamed.ckwd) / sub_Renamed.wdjs), "0.0");
		}
		
		public void 读表号一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[0].Text = "";
				Text11[0].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				//    iTimeOut = 1000
				DanJian = true;
				Biao_Xuhao = (short) 0;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[1].Text = "";
				Text11[1].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 1;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号三_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[2].Text = "";
				Text11[2].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 2;
				Timer21.Enabled = true;
				
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号四_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[3].Text = "";
				Text11[3].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 3;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号五_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[4].Text = "";
				Text11[4].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 4;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号六_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[5].Text = "";
				Text11[5].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 5;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号七_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[6].Text = "";
				Text11[6].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 6;
				Timer21.Enabled = true;
				
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号八_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[7].Text = "";
				Text11[7].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 7;
				Timer21.Enabled = true;
				
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号九_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[8].Text = "";
				Text11[8].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 8;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号十_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[9].Text = "";
				Text11[9].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 9;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号十一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[10].Text = "";
				Text11[10].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 10;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号十二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[11].Text = "";
				Text11[11].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//     data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 11;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		private void 读出_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				for ( = ;0; i <= 11); i++;);
				{
					Text1[sub_Renamed.i].Text = "";
					Text11[sub_Renamed.i].Text = "";
				}
				
				//    data = "6820AAAAAAAAAAAAAA0303810A05"
				//    SendData (data)
				Mdlguanfa.Sleep(500);
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读数1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(0).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 0;
			Timer21.Enabled = true;
			
		}
		
		public void 读数10_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(9).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 9;
			Timer21.Enabled = true;
			
		}
		
		public void 读数11_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(10).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 10;
			Timer21.Enabled = true;
			
		}
		
		public void 读数12_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(11).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 11;
			Timer21.Enabled = true;
			
		}
		
		public void 读数2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(1).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 1;
			Timer21.Enabled = true;
			
		}
		
		public void 读数3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(2).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 2;
			Timer21.Enabled = true;
			
		}
		
		public void 读数4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(3).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 3;
			Timer21.Enabled = true;
			
		}
		
		public void 读数5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(4).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 4;
			Timer21.Enabled = true;
			
		}
		
		public void 读数6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(5).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 5;
			Timer21.Enabled = true;
			
		}
		
		public void 读数7_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(6).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 6;
			Timer21.Enabled = true;
			
		}
		
		public void 读数8_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(7).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 7;
			Timer21.Enabled = true;
			
		}
		
		public void 读数9_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(8).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 8;
			Timer21.Enabled = true;
			
		}
		
		public void 状态一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 0;
			Timer21.Enabled = true;
			
		}
		public void 状态二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 1;
			Timer21.Enabled = true;
			
		}
		public void 状态三_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 2;
			Timer21.Enabled = true;
			
		}
		public void 状态四_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 3;
			Timer21.Enabled = true;
			
		}
		
		public void 状态五_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 4;
			Timer21.Enabled = true;
			
		}
		public void 状态六_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 5;
			Timer21.Enabled = true;
			
		}
		
		public void 状态七_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 6;
			Timer21.Enabled = true;
			
		}
		public void 状态八_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 7;
			Timer21.Enabled = true;
			
		}
		public void 状态九_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 8;
			Timer21.Enabled = true;
			
		}
		public void 状态十_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 9;
			Timer21.Enabled = true;
			
		}
		public void 状态十一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 10;
			Timer21.Enabled = true;
			
		}
		public void 状态十二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 11;
			Timer21.Enabled = true;
			
		}
		
		
		
		private void Readingonerror()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Strings.Len(Text11[0].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数1.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第1块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 1. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[1].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数2.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第2块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 2. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[2].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数3.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第3块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 3. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[3].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数4.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第4块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 4. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[4].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数5.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第5块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 5. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[5].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数6.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第6块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 6. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[6].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数7.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第7块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 7. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[7].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数8.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第8块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 8. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[8].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数9.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第9块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 9. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[9].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数10.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第10块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 10. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[10].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数11.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第11块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 11. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[11].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数12.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第12块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 12. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command6.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					sub_Renamed.delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			
		}
		
		private void Printjsqbdz()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			short jd = 0;
			sub_Renamed.Title = "保存数据";
			msg = (short) (Interaction.MsgBox("请你确认输入项是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示"));
			switch (msg)
			{
				case (short) MsgBoxResult.Yes:
					sub_Renamed.StrSql = "select * from jsqbdzn ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					for (jd = 0; jd <= 11; jd++)
					{
						if (Strings.Len(Text1[jd].Text) > 0)
						{
							sub_Renamed.RsZbs.AddNew(null, null);
							sub_Renamed.RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
							sub_Renamed.RsZbs.Fields[1].Value = Text1[jd].Text;
							sub_Renamed.RsZbs.Fields[2].Value = DateAndTime.Today;
							sub_Renamed.RsZbs.Fields[3].Value = sub_Renamed.SongjianDanwei;
							sub_Renamed.RsZbs.Update(null, null);
						}
						
					}
					sub_Renamed.RsZbs.Close();
					
					//            MsgBox "保存完毕！保存路径\lib\jiliang.mdb jcjg", vbInformation, "保存完毕"
					//            MsgBox App.Path & "\report\" & Trim(yibiao_No) & ".xls"
					return;
				case (short) MsgBoxResult.No:
					
					return;
			}
			
		}
	}
}
