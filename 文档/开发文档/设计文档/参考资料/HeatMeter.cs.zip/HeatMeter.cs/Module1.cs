// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;
using System.Runtime.InteropServices;

namespace 热量表
{
	sealed class Module1
	{
		
		public static float[] Jsqbdzwc = new float[4];
		public static float[] Moni = new float[11];
		public static short Sbs;
		public static short Bs;
		
		public static string sFileCanShu;
		public static short Timer4_2S;
		public static short Tp_SJ;
		public static short Closevalve;
		public static bool FlagKaifa;
		public static bool Dengludz;
		public static bool Denglurb;
		public static bool DengludzOK;
		public static bool DenglurbOK;
		public static bool FlagFa;
		public static bool Flagwd;
		public static bool FlagLL;
		public static bool FlagLS;
		public static bool FlagpL;
		public static short Gf;
		//温度
		public static float Intemp;
		public static float Outtemp;
		public static float Intemp1;
		public static float Outtemp1;
		public static bool Flagtemp;
		//照片
		public static bool PhOK;
		public static short The_value_count;
		public static short[] Statudata = new short[5]; //下位机状态数据数组
		public static short[] StatudataPL = new short[5]; //下位机状态数据数组
		public static short[] StatudataBzb = new short[5]; //下位机状态数据数组
		
		//水表参数打印数据变量
		
		
		public const double a0 = 6824.687741;
		public const double a1 = -542.2063673;
		public const double a2 = -20966.66205;
		public const double a3 = 39412.86787;
		public const double a4 = -67332.77739;
		public const double a5 = 99023.81028; //99023.81028000001
		public const double a6 = -109391.1774;
		public const double a7 = 85908.41667; //85908.41667000001
		public const double a8 = -45111.68742;
		public const double a9 = 14181.38926;
		public const double b0 = -2017.271113;
		public const double B1 = 7.982692717;
		public const double B2 = -0.02616571843;
		public const double B3 = 0.00152241179;
		public const double b4 = 0.02284279054;
		public const double b5 = 242.1647003;
		public const double b6 = 1.269716088E-10;
		public const double b7 = 2.074838328E-07;
		public const double b8 = 2.17402035E-08;
		public const double b9 = 1.105710498E-09;
		public const double c0 = 12.93441934;
		public const double c1 = 0.00001308119072;
		public const double c2 = 6.047626338E-14;
		public const double d1 = 0.8438375405;
		public const double d2 = 0.0005362162162;
		public const double d3 = 1.72;
		public const double d4 = 0.07342278489;
		public const double d5 = 4.97585887000001E-02;
		public const double d6 = 0.65371543;
		public const double d7 = 0.00000115;
		public const double d8 = 0.000015108;
		public const double d9 = 0.14188;
		public const double e0 = 7.002753165;
		public const double e1 = 0.00029284926;
		public const double e2 = 0.204;
		public const double tc = 647.3;
		public const double pc = 22120000;
		public const double vc = 0.00317;
		public static short jiandingyuan;
		public static string strSource;
		public static string strDestination;
		public const double Plxz = 1.03;
		//Global Const LK1 = 0.0123
		//Global Const Lb1 = -7.111
		//Global Const LK2 = 0.0034
		//Global Const Lb2 = -1.999
		//Global Const LK3 = 0.0002
		//Global Const Lb3 = -0.1175
		
		//Public LK1 As Double
		//Public LK2 As Double
		//Public LK3 As Double
		
		//Public Lb1 As Double
		//Public Lb2 As Double
		//Public Lb3 As Double
		
		public static float PlZhi;
		
		public static short playmavmark;
		[DllImport("kernel32",EntryPoint="GetWindowsDirectoryA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int GetWindowsDirectory(string lpBuffer, int nSize);
		
		//UPGRADE_WARNING: 结构 OFSTRUCT 可能要求封送处理属性作为此 Declare 语句中的参数传递。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"”
		[DllImport("kernel32", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		private static extern int OpenFile(string lpFileName, ref OFSTRUCT lpReOpenBuff, int wStyle);
		
		private const short OFS_MAXPATHNAME = 128;
		public const short OF_EXIST = 0x4000;
		public const short MAX_PATH = 260;
		public static ADODB.Recordset rszbstmCard;
		public static ADODB.Recordset RstmCard;
		public static ADODB.Recordset Rskucun;
		public static ADODB.Recordset RscheJian;
		public static ADODB.Recordset RsMx;
		public static ADODB.Recordset RsMingX;
		public struct OFSTRUCT
		{
			public byte cBytes;
			public byte fFixedDisk;
			public short nErrCode;
			public short Reserved1;
			public short Reserved2;
			[VBFixedArray(OFS_MAXPATHNAME)]public byte[] szPathName;
			
			//UPGRADE_TODO: 必须调用“Initialize”来初始化此结构的实例。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"”
			public void Initialize()
			{
				szPathName = new byte[OFS_MAXPATHNAME + 1];
			}
		}
		
		static public bool CheckText(System.Windows.Forms.TextBox txtControl, string msgText)
		{
			bool returnValue = default(bool);
			//检查文本框
			//若为空，返回 True
			//若不为空，返回 False
			
			if (txtControl.Text.Trim().Length == 0)
			{
				
				Interaction.MsgBox(msgText + "项不能为空!", (int) MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "提示：");
				txtControl.Focus();
				returnValue = true;
				return returnValue;
			}
			
			returnValue = false;
			
			return returnValue;
		}
		
		public static bool FileExists(string strFileName)
		{
			bool returnValue = default(bool);
			
			//UPGRADE_WARNING: 结构 typOfStruct 中的数组可能需要先初始化才可以使用。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"”
			OFSTRUCT typOfStruct = new OFSTRUCT();
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (strFileName.Length > 0)
			{
				OpenFile(strFileName, ref typOfStruct, OF_EXIST);
				returnValue = typOfStruct.nErrCode != 2;
			}
			
			return returnValue;
		}
		
		
		// VBConversions Note: Former VB static variables moved to class level because they aren't supported in C#.
		static int ShowCalc_RetVal;
		
		public static bool ShowCalc()
		{
			bool returnValue = default(bool);
			try
			{
				// static int RetVal; VBConversions Note: Static variable moved to class level and renamed ShowCalc_RetVal. Local static variables are not supported in C#.
				
				ShowCalc_RetVal = Interaction.Shell("\\CALC.EXE", AppWinStyle.NormalFocus, 0, -1); // 完成Calculator。
				returnValue = true;
			}
			catch
			{
				//nothing to do
			}
			return returnValue;
		}
		
		static public void SaveHistory(string strMsg)
		{
			object gstrOpName = null; //保存历史记录
			try
			{
				int FileID = 0; //文件句柄
				int FileBacked; //
				
				if (FileExists((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\History.lsj"))
				{
					if (FileSystem.FileLen((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\History.lsj") > 60000)
					{
						FileSystem.Kill((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\History.lsj");
					}
				}
				
				FileID = FileSystem.FreeFile();
				FileSystem.FileOpen(FileID, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\History.lsj", OpenMode.Append, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
				//UPGRADE_WARNING: 未能解析对象 gstrOpName 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				FileSystem.PrintLine(FileID, strMsg + "(时间：" + Strings.FormatDateTime(DateAndTime.Today, DateFormat.LongDate) + ")" + "操作者：" + System.Convert.ToString(gstrOpName));
				FileSystem.FileClose(FileID);
			}
			catch
			{
				
			}
		}
		
		static public void PrintCouple()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object x;
			short y;
			//frma.Show
			strSource = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\dianzu.xlt";
			strDestination = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\Temp.xlt";
			FileSystem.FileCopy(strSource, strDestination);
			sub_Renamed.XlApp = new Microsoft.Office.Interop.Excel.Application();
			sub_Renamed.XlApp = () (Interaction.CreateObject("Excel.Application", "")));
			sub_Renamed.XlApp.Visible = true;
			sub_Renamed.Xlbook = sub_Renamed.XlApp.Workbooks.Open(strDestination, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
			sub_Renamed.Xlsheet = () (sub_Renamed.Xlbook.Worksheets[1]));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 3] = frmbdzcssz.Default.shuju[2].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 8] = frmbdzcssz.Default.shuju[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 13] = frmbdzcssz.Default.shuju[7].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 3] = frmbdzcssz.Default.shuju[5].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 8] = frmbdzcssz.Default.shuju[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 13] = frmbdzcssz.Default.shuju[8].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 21] = DateAndTime.Today;
			
			//Xlsheet.Cells(3, 8) = Frmbdzshz.Text30(4).Text
			
			
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 10] = Frmbdzshz.Default.Text31[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 14] = Frmbdzshz.Default.Text31[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 18] = Frmbdzshz.Default.Text31[2].Text;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[7, 10] = Frmbdzshz.Default.Text1[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[7, 14] = Frmbdzshz.Default.Text1[2].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[7, 18] = Frmbdzshz.Default.Text1[3].Text;
			
			
			for ( = ;0; i <= 15); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 1] = Frmbdzshz.Default.Text44[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 2] = Frmbdzshz.Default.Text55[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 3] = Frmbdzshz.Default.Text56[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 4] = Frmbdzshz.Default.Text57[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 5] = Frmbdzshz.Default.Text58[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 6] = Frmbdzshz.Default.Text59[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 7] = Frmbdzshz.Default.Text60[sub_Renamed.i].Text;
				
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 8] = Frmbdzshz.Default.Text17[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 9] = Frmbdzshz.Default.Text26[sub_Renamed.i].Text;
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 10] = Frmbdzshz.Default.Text18[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 11] = Frmbdzshz.Default.Text26[sub_Renamed.i + 16].Text;
				
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 12] = Frmbdzshz.Default.Text19[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 13] = Frmbdzshz.Default.Text26[sub_Renamed.i + 32].Text;
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 14] = Frmbdzshz.Default.Text20[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 15] = Frmbdzshz.Default.Text26[sub_Renamed.i + 48].Text;
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 16] = Frmbdzshz.Default.Text21[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 17] = Frmbdzshz.Default.Text26[sub_Renamed.i + 64].Text;
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 18] = Frmbdzshz.Default.Text22[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 19] = Frmbdzshz.Default.Text26[sub_Renamed.i + 80].Text;
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 20] = Frmbdzshz.Default.Text23[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 21] = Frmbdzshz.Default.Text24[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 22] = Frmbdzshz.Default.Text25[sub_Renamed.i].Text;
				
			}
			//yibiao_No = ""
			//yibiao_No = yibiao_No + Str(yibiaoNo)
			//Call save_execel
			//
			//
			//XlApp.Workbooks(1).SaveAs (App.Path & "\report\" & Trim(yibiao_No) & ".xls")
			
		}
		
		static public void PrintCoupleBJ()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object x;
			short y;
			//frma.Show
			strSource = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\dianzuBJ.xlt";
			strDestination = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\TempBJ.xlt";
			FileSystem.FileCopy(strSource, strDestination);
			sub_Renamed.XlApp = new Microsoft.Office.Interop.Excel.Application();
			sub_Renamed.XlApp = () (Interaction.CreateObject("Excel.Application", "")));
			sub_Renamed.XlApp.Visible = true;
			sub_Renamed.Xlbook = sub_Renamed.XlApp.Workbooks.Open(strDestination, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
			sub_Renamed.Xlsheet = () (sub_Renamed.Xlbook.Worksheets[1]));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 3] = frmbdzcssz.Default.shuju[2].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 8] = frmbdzcssz.Default.shuju[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 13] = frmbdzcssz.Default.shuju[7].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 3] = frmbdzcssz.Default.shuju[5].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 8] = frmbdzcssz.Default.shuju[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 13] = frmbdzcssz.Default.shuju[8].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 21] = DateAndTime.Today;
			
			//Xlsheet.Cells(3, 8) = Frmbdzshz.Text30(4).Text
			
			
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 9] = mainForm.Default.Text31[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 13] = mainForm.Default.Text31[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 17] = mainForm.Default.Text31[2].Text;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 11] = mainForm.Default.Text27[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 15] = mainForm.Default.Text27[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[6, 19] = mainForm.Default.Text27[2].Text;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 9] = mainForm.Default.Text1[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 13] = mainForm.Default.Text1[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 17] = mainForm.Default.Text1[2].Text;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 11] = mainForm.Default.Text2[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 15] = mainForm.Default.Text2[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 19] = mainForm.Default.Text2[2].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 20] = mainForm.Default.Text6[0].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 21] = mainForm.Default.Text6[1].Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[8, 22] = mainForm.Default.Text6[2].Text;
			
			for ( = ;0; i <= 15); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 1] = mainForm.Default.Text44[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 2] = mainForm.Default.Text55[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 3] = mainForm.Default.Text56[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 4] = mainForm.Default.Text57[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 5] = mainForm.Default.Text58[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 6] = mainForm.Default.Text59[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 7] = mainForm.Default.Text60[sub_Renamed.i].Text;
				
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 8] = mainForm.Default.text17[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 9] = (System.Convert.ToDouble(mainForm.Default.text17[sub_Renamed.i].Text)) - System.Convert.ToDouble(mainForm.Default.Text31[0].Text);
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 10] = mainForm.Default.Text18[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 11] = (System.Convert.ToDouble(mainForm.Default.Text18[sub_Renamed.i].Text)) - System.Convert.ToDouble(mainForm.Default.Text27[0].Text);
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 12] = mainForm.Default.Text19[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 13] = (System.Convert.ToDouble(mainForm.Default.Text19[sub_Renamed.i].Text)) - System.Convert.ToDouble(mainForm.Default.Text31[1].Text);
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 14] = mainForm.Default.Text20[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 15] = (System.Convert.ToDouble(mainForm.Default.Text20[sub_Renamed.i].Text)) - System.Convert.ToDouble(mainForm.Default.Text27[1].Text);
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 16] = mainForm.Default.Text21[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 17] = (System.Convert.ToDouble(mainForm.Default.Text21[sub_Renamed.i].Text)) - System.Convert.ToDouble(mainForm.Default.Text31[2].Text);
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 18] = mainForm.Default.Text22[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 19] = (System.Convert.ToDouble(mainForm.Default.Text22[sub_Renamed.i].Text)) - System.Convert.ToDouble(mainForm.Default.Text27[2].Text);
				
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 20] = mainForm.Default.Text23[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 21] = mainForm.Default.Text24[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[11 + sub_Renamed.i, 22] = mainForm.Default.Text25[sub_Renamed.i].Text;
				
			}
			//yibiao_No = ""
			//yibiao_No = yibiao_No + Str(yibiaoNo)
			//Call save_execel
			//XlApp.Workbooks(1).SaveAs (App.Path & "\report\" & Trim(yibiao_No) & ".xls")
			//
		}
		static public void PrintCoupledz()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//Dim X, y As Integer
			//'frma.Show
			//     strSource = App.Path & "\tab\dianzudz.xlt"
			// strDestination = App.Path & "\tab\Temp.xlt"
			// FileCopy strSource, strDestination
			//Set XlApp = New Excel.Application
			//Set XlApp = CreateObject("Excel.Application")
			//XlApp.Visible = True
			//Set Xlbook = XlApp.Workbooks.Open(strDestination)
			//Set Xlsheet = Xlbook.Worksheets(1)
			//
			//Xlsheet.Cells(2, 3) = Frmbdzshz.Text30(0).Text
			//Xlsheet.Cells(2, 8) = Frmbdzshz.Text30(1).Text
			//Xlsheet.Cells(2, 15) = Frmbdzshz.Text30(3).Text
			//Xlsheet.Cells(3, 3) = Frmbdzshz.Text30(2).Text
			//Xlsheet.Cells(3, 8) = Frmbdzshz.Text30(4).Text
			//Xlsheet.Cells(3, 15) = CDate(Date)
			//
			//
			//Xlsheet.Cells(4, 10) = Frmbdzshz.Text1(0).Text
			//Xlsheet.Cells(4, 15) = Frmbdzshz.Text1(1).Text
			//Xlsheet.Cells(4, 19) = Frmbdzshz.Text1(2).Text
			//
			//For i = 0 To 15
			//Xlsheet.Cells(6 + i, 1) = Frmbdzshz.Text44(i).Text
			//Xlsheet.Cells(6 + i, 2) = Frmbdzshz.Text55(i).Text
			//Xlsheet.Cells(6 + i, 3) = Frmbdzshz.Text56(i).Text
			//Xlsheet.Cells(6 + i, 4) = Frmbdzshz.Text57(i).Text
			//Xlsheet.Cells(6 + i, 5) = Frmbdzshz.Text58(i).Text
			//Xlsheet.Cells(6 + i, 6) = Frmbdzshz.Text59(i).Text
			//Xlsheet.Cells(6 + i, 7) = Frmbdzshz.Text60(i).Text
			//
			//
			//Xlsheet.Cells(6 + i, 8) = Frmbdzshz.Text17(i).Text
			//Xlsheet.Cells(6 + i, 9) = Frmbdzshz.Text26(i).Text
			//
			//Xlsheet.Cells(6 + i, 10) = Frmbdzshz.Text18(i).Text
			//Xlsheet.Cells(6 + i, 11) = Frmbdzshz.Text26(i + 16).Text
			//
			//
			//Xlsheet.Cells(6 + i, 12) = Frmbdzshz.Text19(i).Text
			//Xlsheet.Cells(6 + i, 13) = Frmbdzshz.Text26(i + 32).Text
			//
			//Xlsheet.Cells(6 + i, 14) = Frmbdzshz.Text20(i).Text
			//Xlsheet.Cells(6 + i, 15) = Frmbdzshz.Text26(i + 48).Text
			//
			//Xlsheet.Cells(6 + i, 16) = Frmbdzshz.Text21(i).Text
			//Xlsheet.Cells(6 + i, 17) = Frmbdzshz.Text26(i + 64).Text
			//
			//Xlsheet.Cells(6 + i, 18) = Frmbdzshz.Text22(i).Text
			//Xlsheet.Cells(6 + i, 19) = Frmbdzshz.Text26(i + 80).Text
			//
			//Xlsheet.Cells(6 + i, 20) = Frmbdzshz.Text23(i).Text
			//Xlsheet.Cells(6 + i, 21) = Frmbdzshz.Text24(i).Text
			//Xlsheet.Cells(6 + i, 22) = Frmbdzshz.Text25(i).Text
			//
			//Next i
			//yibiao_No = ""
			//yibiao_No = yibiao_No + Str(yibiaoNo)
			//Call save_execel
			//
			//
			//XlApp.Workbooks(1).SaveAs (App.Path & "\report\" & Trim(yibiao_No) & ".xls")
			
			
		}
		static public void PrintCalCular()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object x;
			short y;
			
			
			if (calculator.Default.Option3.Checked == true)
			{
				strSource = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\jisuan.xlt";
			}
			if (calculator.Default.Option4.Checked == true)
			{
				strSource = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\jisuan1.xlt";
			}
			FileSystem.Kill((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\Temp.xlt");
			strDestination = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\Temp.xlt";
			FileSystem.FileCopy(strSource, strDestination);
			sub_Renamed.XlApp = new Microsoft.Office.Interop.Excel.Application();
			sub_Renamed.XlApp = () (Interaction.CreateObject("Excel.Application", "")));
			sub_Renamed.XlApp.Visible = true;
			sub_Renamed.Xlbook = sub_Renamed.XlApp.Workbooks.Open(strDestination, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
			sub_Renamed.Xlsheet = () (sub_Renamed.Xlbook.Worksheets[1]));
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 3] = frmjsqcs.Default.Text1.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[2, 8] = sub_Renamed.ZhizaoDanwei;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 12] = sub_Renamed.GuiGe;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 3] = sub_Renamed.SongjianDanwei;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 8] = sub_Renamed.XingHao;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[3, 12] = sub_Renamed.YouXiaoQi;
			//
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[4, 3] = DateAndTime.Today;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[4, 8] = sub_Renamed.JianCeYuan;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[5, 1] = calculator.Default.Frame12.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[13, 1] = calculator.Default.Frame13.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[17, 1] = calculator.Default.Frame14.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[9, 1] = calculator.Default.Text22.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[10, 1] = calculator.Default.Text23.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[11, 1] = calculator.Default.Text24.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[12, 1] = calculator.Default.Text25.Text;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[14, 1] = calculator.Default.Text28.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[15, 1] = calculator.Default.Text29.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[16, 1] = calculator.Default.Text30.Text;
			
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[18, 1] = calculator.Default.Text31.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[19, 1] = calculator.Default.Text32.Text;
			//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.Xlsheet.Cells[20, 1] = calculator.Default.Text33.Text;
			
			for ( = ;0; i <= 3); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 3] = calculator.Default.text9[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 4] = calculator.Default.Text10[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 5] = calculator.Default.Text11[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 6] = calculator.Default.Text12[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 7] = calculator.Default.Text13[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 8] = calculator.Default.Text14[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 9] = calculator.Default.Text15[sub_Renamed.i + 1].Text;
				//Xlsheet.Cells(9 + i, 10) = calculator.Text16(i + 1).Text
				//Xlsheet.Cells(9 + i, 11) = calculator.Text17(i + 1).Text
				//Xlsheet.Cells(9 + i, 12) = calculator.Text18(i + 1).Text
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 10] = calculator.Default.Text45[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 11] = calculator.Default.Text46[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 12] = calculator.Default.Text19[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 13] = calculator.Default.Text20[sub_Renamed.i + 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 14] = calculator.Default.Text21[sub_Renamed.i + 1].Text;
			}
			for ( = ;5; i <= 7); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 3] = calculator.Default.text9[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 4] = calculator.Default.Text10[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 5] = calculator.Default.Text11[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 6] = calculator.Default.Text12[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 7] = calculator.Default.Text13[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 8] = calculator.Default.Text14[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 9] = calculator.Default.Text15[sub_Renamed.i].Text;
				//Xlsheet.Cells(9 + i, 10) = calculator.Text16(i).Text
				//Xlsheet.Cells(9 + i, 11) = calculator.Text17(i).Text
				//Xlsheet.Cells(9 + i, 12) = calculator.Text18(i).Text
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 10] = calculator.Default.Text45[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 11] = calculator.Default.Text46[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 12] = calculator.Default.Text19[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 13] = calculator.Default.Text20[sub_Renamed.i].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 14] = calculator.Default.Text21[sub_Renamed.i].Text;
			}
			for ( = ;9; i <= 11); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 3] = calculator.Default.text9[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 4] = calculator.Default.Text10[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 5] = calculator.Default.Text11[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 6] = calculator.Default.Text12[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 7] = calculator.Default.Text13[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 8] = calculator.Default.Text14[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 9] = calculator.Default.Text15[sub_Renamed.i - 1].Text;
				//Xlsheet.Cells(9 + i, 10) = calculator.Text16(i - 1).Text
				//Xlsheet.Cells(9 + i, 11) = calculator.Text17(i - 1).Text
				//Xlsheet.Cells(9 + i, 12) = calculator.Text18(i - 1).Text
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 10] = calculator.Default.Text45[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 11] = calculator.Default.Text46[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 12] = calculator.Default.Text19[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 13] = calculator.Default.Text20[sub_Renamed.i - 1].Text;
				//UPGRADE_WARNING: 未能解析对象 Xlsheet.Cells() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Xlsheet.Cells[9 + sub_Renamed.i, 14] = calculator.Default.Text21[sub_Renamed.i - 1].Text;
			}
			//yibiao_No = ""
			//yibiao_No = yibiao_No + Str(yibiaoNo)
			//Call save_execel
			//
			//
			//XlApp.Workbooks(1).SaveAs (App.Path & "\report\" & Trim(yibiao_No) & ".xls")
			
			
		}
		
		
		
		
		static public void PrintVolZj()
		{
			object VolZJcanshu = null;
			object VolZJ = null;
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			short jd = 0;
			if (sub_Renamed.Comopen == false)
			{
				sub_Renamed.Title = "保存数据";
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("请你确认输入项是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
				if (msg == MsgBoxResult.Yes)
				{
					sub_Renamed.StrSql = "select * from zjjc ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					for (jd = 0; jd <= 11; jd++)
					{
						//UPGRADE_WARNING: 未能解析对象 VolZJ.Text1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Strings.Len(VolZJ.Text1(jd).Text) > 0)
						{
							sub_Renamed.RsZbs.AddNew(null, null);
							sub_Renamed.RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
							//UPGRADE_WARNING: 未能解析对象 VolZJ.Text1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.RsZbs.Fields[1].Value = VolZJ.text1(jd).Text;
							sub_Renamed.RsZbs.Fields[2].Value = DateAndTime.Today;
							//UPGRADE_WARNING: 未能解析对象 VolZJcanshu.shuju 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.RsZbs.Fields[3].Value = .;Text(8).Text;
							sub_Renamed.RsZbs.Update(null, null);
						}
					}
					sub_Renamed.RsZbs.Close();
					
					//            MsgBox "保存完毕！保存路径\lib\jiliang.mdb jcjg", vbInformation, "保存完毕"
					//            MsgBox App.Path & "\report\" & Trim(yibiao_No) & ".xls"
					return;
				}
				else if (msg == MsgBoxResult.No)
				{
					
					return;
				}
			}
			else
			{
				sub_Renamed.StrSql = "select * from zjjc ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				for (jd = 0; jd <= 11; jd++)
				{
					//UPGRADE_WARNING: 未能解析对象 VolZJ.Text1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					if (Strings.Len(VolZJ.Text1(jd).Text) > 0)
					{
						sub_Renamed.RsZbs.AddNew(null, null);
						sub_Renamed.RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
						//UPGRADE_WARNING: 未能解析对象 VolZJ.Text1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.RsZbs.Fields[1].Value = VolZJ.text1(jd).Text;
						sub_Renamed.RsZbs.Fields[2].Value = DateAndTime.Today;
						//UPGRADE_WARNING: 未能解析对象 VolZJcanshu.shuju 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.RsZbs.Fields[3].Value = .;Text(8).Text;
						sub_Renamed.RsZbs.Update(null, null);
					}
				}
				sub_Renamed.RsZbs.Close();
			}
		}
		public static void delay()
		{
			object PauseTime = null;
			object start = null;
			//UPGRADE_WARNING: 未能解析对象 PauseTime 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			PauseTime = 0.1; // 设置暂停时间。
			//UPGRADE_WARNING: 未能解析对象 start 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			start = VB.DateAndTime.Timer; // 设置开始暂停的时刻。
			//UPGRADE_WARNING: 未能解析对象 PauseTime 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 start 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			while (VB.DateAndTime.Timer< System.Convert.ToDouble(start) + System.Convert.ToDouble(PauseTime))
			{
				System.Windows.Forms.Application.DoEvents(); // 将控制让给其他程序。
			}
			
		}
	}
}
