// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class comm : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static comm defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static comm Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new comm();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		string Rxd;
		
		public void comm_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			this.MSComm1.CommPort = sub_Renamed.Com1;
			//'MSComm2.CommPort = Com2
			//comm.MSComm3.CommPort = Com3
			this.MSComm4.CommPort = sub_Renamed.Com4;
			//comm.MSComm5.CommPort = Com5
			//MSComm2.InputLen = 200
			//MSComm2.RThreshold = 15
			//comm.MSComm3.InputLen = 30
			//comm.MSComm3.RThreshold = 20
			Timer1.Enabled = false;
		}
	}
}
