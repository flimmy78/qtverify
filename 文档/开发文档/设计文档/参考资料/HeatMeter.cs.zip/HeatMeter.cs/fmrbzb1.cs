// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class fmrbzb1 : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static fmrbzb1 defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static fmrbzb1 Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new fmrbzb1();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short K1 = 0;
			short K2 = 0;
			short K3 = 0;
			short K4;
			short K5;
			short K6;
			K1 = (short) 0;
			K2 = (short) 0;
			K3 = (short) 0;
			K4 = (short) 0;
			K5 = (short) 0;
			K6 = (short) 0;
			
			for ( = ;0; i <= 10); i++;);
			{
				if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
				{
					K1 = sub_Renamed.i;
				}
			}
			for ( = ;11; i <= 21); i++;);
			{
				if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
				{
					K2 = sub_Renamed.i;
				}
			}
			for ( = ;22; i <= 32); i++;);
			{
				if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
				{
					K3 = sub_Renamed.i;
				}
			}
			
			
			if (sub_Renamed.MID2 == 1) //带标准表法
			{
				
				for ( = ;0; i <= K1); i++;);
				{
					if (Text1[sub_Renamed.i].Text == "" || Text2[sub_Renamed.i].Text == "")
					{
						MessageBox.Show("" + Frame1[0].Text + "" + "第" + "" + System.Convert.ToString(sub_Renamed.i + 1) + "" + "行流量点或K系数不能为空值。请重添！");
						return;
					}
				}
				for ( = ;11; i <= K2); i++;);
				{
					if (Text1[sub_Renamed.i].Text == "" || Text2[sub_Renamed.i].Text == "")
					{
						MessageBox.Show("" + Frame1[1].Text + "" + "第" + "" + System.Convert.ToString(sub_Renamed.i + 1) + "" + "行流量点或K系数不能为空值。请重添！");
						return;
					}
				}
				
				for ( = ;22; i <= K3); i++;);
				{
					if (Text1[sub_Renamed.i].Text == "" || Text2[sub_Renamed.i].Text == "")
					{
						MessageBox.Show("" + Frame1[2].Text + "" + "第" + "" + System.Convert.ToString(sub_Renamed.i + 1) + "" + "行流量点或K系数不能为空值。请重添！");
						return;
					}
				}
				
			} //带标准表法
			
			
			sub_Renamed.Title = "保存数据";
			//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			msg = Interaction.MsgBox("请你确认输入项是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
			if (msg == MsgBoxResult.Yes)
			{
				
				sub_Renamed.StrSql = "select * from bzbbd ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				for ( = ;0; i <= 10); i++;);
				{
					sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value = "";
					sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value = "";
				}
				
				for ( = ;0; i <= 10); i++;);
				{
					if (Text1[sub_Renamed.i].Text == "")
					{
						break;
					}
					sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value = Strings.Trim(System.Convert.ToString(Text1[sub_Renamed.i].Text));
					sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value = Strings.Trim(System.Convert.ToString(Text2[sub_Renamed.i].Text));
					sub_Renamed.RsZbs.Fields["bz"].Value = "1";
				}
				sub_Renamed.RsZbs.Fields[22].Value = Strings.Trim(System.Convert.ToString(Text3[0].Text));
				sub_Renamed.RsZbs.Fields[23].Value = Strings.Trim(System.Convert.ToString(Text4[0].Text));
				sub_Renamed.RsZbs.Fields[24].Value = Strings.Trim(System.Convert.ToString(Text5[0].Text));
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
				
				sub_Renamed.StrSql = "select * from bzbbd1 ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.i = (short) 0;
				for ( = ;0; i <= 10); i++;);
				{
					sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value = "";
					sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value = "";
				}
				
				for ( = ;0; i <= 10); i++;);
				{
					if (Text1[sub_Renamed.i + 11].Text == "")
					{
						break;
					}
					sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value = Strings.Trim(System.Convert.ToString(Text1[sub_Renamed.i + 11].Text));
					sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value = Strings.Trim(System.Convert.ToString(Text2[sub_Renamed.i + 11].Text));
					sub_Renamed.RsZbs.Fields["bz"].Value = "2";
				}
				sub_Renamed.RsZbs.Fields[22].Value = Strings.Trim(System.Convert.ToString(Text3[1].Text));
				sub_Renamed.RsZbs.Fields[23].Value = Strings.Trim(System.Convert.ToString(Text4[1].Text));
				sub_Renamed.RsZbs.Fields[24].Value = Strings.Trim(System.Convert.ToString(Text5[1].Text));
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
				
				sub_Renamed.StrSql = "select * from bzbbd2 ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				sub_Renamed.RsZbs.MoveFirst();
				//       RsZbs.Edit
				sub_Renamed.i = (short) 0;
				for ( = ;0; i <= 10); i++;);
				{
					sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value = "";
					sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value = "";
				}
				
				for ( = ;0; i <= 10); i++;);
				{
					if (Text1[sub_Renamed.i + 22].Text == "")
					{
						break;
					}
					sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value = Strings.Trim(System.Convert.ToString(Text1[sub_Renamed.i + 22].Text));
					sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value = Strings.Trim(System.Convert.ToString(Text2[sub_Renamed.i + 22].Text));
					sub_Renamed.RsZbs.Fields["bz"].Value = "3";
				}
				sub_Renamed.RsZbs.Fields[22].Value = Strings.Trim(System.Convert.ToString(Text3[2].Text));
				sub_Renamed.RsZbs.Fields[23].Value = Strings.Trim(System.Convert.ToString(Text4[2].Text));
				sub_Renamed.RsZbs.Fields[24].Value = Strings.Trim(System.Convert.ToString(Text5[2].Text));
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
				
				
				
				
				
				
				sub_Renamed.Ld1 = float.Parse(Strings.Trim(System.Convert.ToString(Text10[3].Text)));
				sub_Renamed.Ld2 = float.Parse(Strings.Trim(System.Convert.ToString(Text10[4].Text)));
				sub_Renamed.Ld3 = float.Parse(Strings.Trim(System.Convert.ToString(Text10[5].Text)));
				
				
				
				if (Option7.Checked == true)
				{
					sub_Renamed.MID1 = (short) 0;
				}
				else if (Option1.Checked == true)
				{
					sub_Renamed.MID1 = (short) 1;
				}
				else if (Option2.Checked == true)
				{
					sub_Renamed.MID1 = (short) 2;
				}
				else if (Option3.Checked == true)
				{
					sub_Renamed.MID1 = (short) 3;
				}
				
				if (Option8.Checked == true)
				{
					sub_Renamed.MID2 = (short) 0;
				}
				else if (Option9.Checked == true)
				{
					sub_Renamed.MID2 = (short) 1;
				}
				
				if (Option12.Checked == true)
				{
					sub_Renamed.MID3 = (short) 1;
				}
				else if (Option11.Checked == true)
				{
					sub_Renamed.MID3 = (short) 2;
				}
				else
				{
					sub_Renamed.MID3 = (short) 0;
				}
				
				if (Option10.Checked == true)
				{
					sub_Renamed.MID4 = (short) 1;
				}
				else if (Option6.Checked == true)
				{
					sub_Renamed.MID4 = (short) 2;
				}
				else
				{
					sub_Renamed.MID4 = (short) 0;
				}
				
				if (Option4.Checked == true)
				{
					sub_Renamed.MID5 = (short) 1;
				}
				else if (Option5.Checked == true)
				{
					sub_Renamed.MID5 = (short) 2;
				}
				else
				{
					sub_Renamed.MID5 = (short) 0;
				}
				
				sub_Renamed.StrSql = "select * from Adminis ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				if (sub_Renamed.RsZbs.BOF == true)
				{
					sub_Renamed.RsZbs.AddNew(null, null);
				}
				else
				{
					sub_Renamed.RsZbs.MoveFirst();
					//       RsZbs.Edit
				}
				
				sub_Renamed.RsZbs.Fields[1].Value = sub_Renamed.Ld1;
				sub_Renamed.RsZbs.Fields["ZhongDiliang"].Value = sub_Renamed.Ld2;
				sub_Renamed.RsZbs.Fields["DaDiliang"].Value = sub_Renamed.Ld3;
				sub_Renamed.RsZbs.Fields["BZBshuliang"].Value = sub_Renamed.MID1;
				sub_Renamed.RsZbs.Fields["BZBfangfa"].Value = sub_Renamed.MID2;
				sub_Renamed.RsZbs.Fields["DaBZB"].Value = sub_Renamed.MID3;
				sub_Renamed.RsZbs.Fields["ZhongBZB"].Value = sub_Renamed.MID4;
				sub_Renamed.RsZbs.Fields["XiaoBZB"].Value = sub_Renamed.MID5;
				
				sub_Renamed.RsZbs.Update(null, null);
				sub_Renamed.RsZbs.Close();
				//           Exit Sub
			}
			else if (msg == MsgBoxResult.No)
			{
				
				return;
			}
		}
		
		public void Command11_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Timer3.Enabled = false;
			for ( = ;0; i <= 5); i++;);
			{
				Text10[sub_Renamed.i].Text = "";
			}
		}
		
		public void Command12_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			Timer3.Enabled = true;
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Option7.Checked == true)
			{
				Frame2[0].Enabled = false;
				Frame2[1].Enabled = false;
				Frame2[2].Enabled = false;
				Frame1[0].Enabled = false;
				Frame1[1].Enabled = false;
				Frame1[2].Enabled = false;
				Frame4[1].Enabled = false;
				Frame6[0].Enabled = false;
				Frame3[0].Enabled = false;
				Option12.Checked = false;
				Option6.Checked = false;
				Option4.Checked = false;
				Option5.Checked = false;
				Option10.Checked = false;
				Option11.Checked = false;
				Label4[4].Enabled = false;
				Label4[5].Enabled = false;
				Label4[3].Enabled = false;
				Label4[6].Enabled = false;
				Label4[7].Enabled = false;
				Label4[8].Enabled = false;
			}
			else if (Option1.Checked == true)
			{
				Frame2[0].Enabled = true;
				Frame2[1].Enabled = false;
				Frame2[2].Enabled = false;
				Frame1[0].Enabled = false;
				Frame1[1].Enabled = false;
				Frame1[2].Enabled = false;
				Frame4[1].Enabled = true;
				Frame6[0].Enabled = true;
				Option12.Enabled = false;
				Option10.Enabled = false;
				Option6.Enabled = false;
				Option4.Enabled = false;
				Option5.Enabled = false;
				Option12.Checked = false;
				Option6.Checked = false;
				Option4.Checked = false;
				Option5.Checked = false;
				Option10.Checked = false;
				Option11.Checked = true;
				Label4[4].Enabled = false;
				Label4[5].Enabled = false;
				Label4[3].Enabled = false;
				Label4[6].Enabled = false;
				Label4[8].Enabled = false;
				Label4[7].Enabled = true;
				if (Option9.Checked == true)
				{
					Frame3[0].Enabled = true;
				}
				
			}
			else if (Option2.Checked == true)
			{
				Frame2[0].Enabled = true;
				Frame2[1].Enabled = true;
				Frame2[2].Enabled = false;
				if (Option9.Checked == true)
				{
					Frame1[0].Enabled = true;
					Frame1[1].Enabled = true;
					Frame1[2].Enabled = false;
					Frame3[0].Enabled = true;
				}
				else
				{
					Frame1[0].Enabled = false;
					Frame1[1].Enabled = false;
					Frame1[2].Enabled = false;
					Frame3[0].Enabled = false;
				}
				Frame4[1].Enabled = true;
				Frame6[0].Enabled = true;
				Option12.Enabled = false;
				Option6.Enabled = false;
				Option4.Enabled = false;
				Option5.Enabled = false;
				Option12.Checked = false;
				Option6.Checked = false;
				Option4.Checked = false;
				Option5.Checked = false;
				Option10.Enabled = true;
				Option10.Checked = true;
				Option11.Checked = true;
				Label4[4].Enabled = false;
				Label4[3].Enabled = false;
				Label4[8].Enabled = false;
				Label4[5].Enabled = false;
				Label4[7].Enabled = true;
				Label4[6].Enabled = true;
				
				if (Option9.Checked == true)
				{
					Frame3[0].Enabled = true;
				}
				
			}
			else if (Option3.Checked == true)
			{
				Frame2[0].Enabled = true;
				Frame2[1].Enabled = true;
				Frame2[2].Enabled = true;
				if (Option9.Checked == true)
				{
					Frame1[0].Enabled = true;
					Frame1[1].Enabled = true;
					Frame1[2].Enabled = true;
					Frame3[0].Enabled = true;
				}
				else
				{
					Frame1[0].Enabled = false;
					Frame1[1].Enabled = false;
					Frame1[2].Enabled = false;
					Frame3[0].Enabled = false;
				}
				Frame4[1].Enabled = true;
				Frame6[0].Enabled = true;
				Option12.Enabled = false;
				Option4.Enabled = false;
				Option10.Enabled = false;
				Option11.Enabled = true;
				Option11.Checked = true;
				Option6.Enabled = true;
				Option6.Checked = true;
				Option5.Enabled = true;
				Option5.Checked = true;
				Label4[4].Enabled = true;
				Label4[7].Enabled = true;
				Label4[3].Enabled = true;
				Label4[6].Enabled = false;
				Label4[5].Enabled = false;
				Label4[8].Enabled = false;
				if (Option9.Checked == true)
				{
					Frame3[0].Enabled = true;
				}
			}
			if (Option8.Checked == true)
			{
				sub_Renamed.MID2 = (short) 0;
			}
			if (Option9.Checked == true)
			{
				sub_Renamed.MID2 = (short) 1;
			}
			//   Option6.value = False
			//   Option12.value = False
			//   Option11.value = False
			//   Option4.value = False
			//   Option5.value = False
			
			Command4.Enabled = true;
			
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Option1.Checked == true)
			{
				if (Option4.Checked == true)
				{
					Frame2[0].Text = "DN2表流速参数";
				}
				else if (Option5.Checked == true)
				{
					Frame2[0].Text = "DN3表流速参数";
				}
				else if (Option10.Checked == true)
				{
					Frame2[0].Text = "DN6表流速参数";
				}
				else if (Option6.Checked == true)
				{
					Frame2[0].Text = "DN10表流速参数";
				}
				else if (Option12.Checked == true)
				{
					Frame2[0].Text = "DN15表流速参数";
				}
				else if (Option11.Checked == true)
				{
					Frame2[0].Text = "DN25表流速参数";
				}
			}
			else if (Option2.Checked == true)
			{
				if (Option4.Checked == true)
				{
					Frame2[0].Text = "DN2表流速参数";
					Frame1[0].Text = "DN2体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN10体积仪表系数";
					}
					else if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
				else if (Option5.Checked == true)
				{
					Frame2[0].Text = "DN3表流速参数";
					Frame1[0].Text = "DN3体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN10体积仪表系数";
					}
					else if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
				else if (Option10.Checked == true)
				{
					Frame2[0].Text = "DN6表流速参数";
					Frame1[0].Text = "DN6体积仪表系数";
					if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
				else if (Option6.Checked == true)
				{
					Frame2[0].Text = "DN10表流速参数";
					Frame1[0].Text = "DN10体积仪表系数";
					if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
			}
			else if (Option3.Checked == true)
			{
				if (Option4.Checked == true)
				{
					Frame2[0].Text = "DN2表流速参数";
					Frame1[0].Text = "DN2体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN10体积仪表系数";
					}
					if (Option12.Checked == true)
					{
						Frame2[2].Text = "DN15表流速参数";
						Frame1[2].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[2].Text = "DN25表流速参数";
						Frame1[2].Text = "DN25体积仪表系数";
					}
				}
				else if (Option5.Checked == true)
				{
					Frame2[0].Text = "DN3表流速参数";
					Frame1[0].Text = "DN3体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN10体积仪表系数";
					}
					if (Option12.Checked == true)
					{
						Frame2[2].Text = "DN15表流速参数";
						Frame1[2].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[2].Text = "DN25表流速参数";
						Frame1[2].Text = "DN25体积仪表系数";
					}
				}
			}
			//设定各流量计上限值
			Text3[0].Text = "";
			Text3[1].Text = "";
			Text3[2].Text = "";
			if (Option1.Checked == true)
			{
				if (Frame2[0].Text == "DN15表流速参数")
				{
					Text3[0].Text = (4).ToString();
				}
				else if (Frame2[0].Text == "DN25表流速参数")
				{
					Text3[0].Text = (7).ToString();
				}
				Text4[1].Text = "";
				Text4[2].Text = "";
			}
			else if (Option2.Checked == true)
			{
				if (Frame2[0].Text == "DN2表流速参数")
				{
					Text3[0].Text = (0.07).ToString();
				}
				else if (Frame2[0].Text == "DN3表流速参数")
				{
					Text3[0].Text = (0.12).ToString();
				}
				else if (Frame2[0].Text == "DN6表流速参数")
				{
					Text3[0].Text = (0.5).ToString();
				}
				else if (Frame2[0].Text == "DN10表流速参数")
				{
					Text3[0].Text = (1.2).ToString();
				}
				
				if (Frame2[1].Text == "DN15表流速参数")
				{
					Text3[1].Text = (4).ToString();
				}
				else if (Frame2[1].Text == "DN25表流速参数")
				{
					Text3[1].Text = (7).ToString();
				}
				Text4[2].Text = "";
			}
			else if (Option3.Checked == true)
			{
				if (Frame2[0].Text == "DN2表流速参数")
				{
					Text3[0].Text = (0.07).ToString();
				}
				else if (Frame2[0].Text == "DN3表流速参数")
				{
					Text3[0].Text = (0.12).ToString();
				}
				if (Frame2[1].Text == "DN6表流速参数")
				{
					Text3[1].Text = (0.5).ToString();
				}
				else if (Frame2[1].Text == "DN10表流速参数")
				{
					Text3[1].Text = (1.2).ToString();
				}
				
				if (Frame2[2].Text == "DN15表流速参数")
				{
					Text3[2].Text = (4).ToString();
				}
				else if (Frame2[2].Text == "DN25表流速参数")
				{
					Text3[2].Text = (7).ToString();
				}
			}
			//  '设定各流量计检定流量点
			for ( = ;0; i <= 32); i++;);
			{
				Text1[sub_Renamed.i].Text = "";
				Text2[sub_Renamed.i].Text = "";
			}
			if (Option9.Checked == true)
			{
				if (Option2.Checked == true) //二个标准表时
				{
					if (Frame1[0].Text == "DN2体积仪表系数") //小流量计
					{
						Text1[0].Text = (0.015).ToString();
						Text1[1].Text = (0.03).ToString();
						Text1[2].Text = (0.04).ToString();
						Text1[3].Text = (0.05).ToString();
						Text1[4].Text = (0.06).ToString();
						Text1[5].Text = (0.07).ToString();
					}
					else if (Frame1[0].Text == "DN3体积仪表系数")
					{
						Text1[0].Text = (0.015).ToString();
						Text1[1].Text = (0.03).ToString();
						Text1[2].Text = (0.04).ToString();
						Text1[3].Text = (0.05).ToString();
						Text1[4].Text = (0.06).ToString();
						Text1[5].Text = (0.07).ToString();
						Text1[6].Text = (0.08).ToString();
						Text1[7].Text = "0.10";
						Text1[8].Text = (0.12).ToString();
					}
					else if (Frame1[0].Text == "DN6体积仪表系数")
					{
						Text1[0].Text = (0.015).ToString();
						Text1[1].Text = (0.03).ToString();
						Text1[2].Text = (0.05).ToString();
						Text1[3].Text = (0.07).ToString();
						Text1[4].Text = "0.10";
						Text1[5].Text = (0.15).ToString();
						Text1[6].Text = (0.25).ToString();
						Text1[7].Text = (0.35).ToString();
						Text1[8].Text = (0.5).ToString();
						Text5[0].Text = (0.001).ToString();
					}
					else if (Frame1[0].Text == "DN10体积仪表系数")
					{
						Text1[0].Text = (0.015).ToString();
						Text1[1].Text = (0.03).ToString();
						Text1[2].Text = (0.05).ToString();
						Text1[3].Text = (0.07).ToString();
						Text1[4].Text = (0.15).ToString();
						Text1[5].Text = (0.25).ToString();
						Text1[6].Text = (0.35).ToString();
						Text1[7].Text = (0.5).ToString();
						Text1[8].Text = (0.7).ToString();
						Text1[9].Text = (1.05).ToString();
						Text1[10].Text = (1.2).ToString();
					}
					
					if (Frame1[1].Text == "DN15体积仪表系数") //中流量计
					{
						if (Frame1[0].Text == "DN2体积仪表系数")
						{
							Text1[11].Text = (0.07).ToString();
							Text1[12].Text = (0.15).ToString();
							Text1[13].Text = (0.25).ToString();
							Text1[14].Text = (0.35).ToString();
							Text1[15].Text = (0.5).ToString();
							Text1[16].Text = (0.7).ToString();
							Text1[17].Text = (1.05).ToString();
							Text1[18].Text = (1.5).ToString();
							Text1[19].Text = (2.5).ToString();
							Text1[20].Text = (3.5).ToString();
							Text1[21].Text = (4).ToString();
						}
						else if (Frame1[0].Text == "DN3体积仪表系数")
						{
							Text1[11].Text = (0.12).ToString();
							Text1[12].Text = (0.15).ToString();
							Text1[13].Text = (0.25).ToString();
							Text1[14].Text = (0.35).ToString();
							Text1[15].Text = (0.5).ToString();
							Text1[16].Text = (0.7).ToString();
							Text1[17].Text = (1.05).ToString();
							Text1[18].Text = (1.5).ToString();
							Text1[19].Text = (2.5).ToString();
							Text1[20].Text = (3.5).ToString();
							Text1[21].Text = (4).ToString();
						}
						else if (Frame1[0].Text == "DN6体积仪表系数")
						{
							Text1[11].Text = (0.4).ToString();
							Text1[12].Text = (0.5).ToString();
							Text1[13].Text = (0.7).ToString();
							Text1[14].Text = (1.05).ToString();
							Text1[15].Text = (1.5).ToString();
							Text1[16].Text = (2.5).ToString();
							Text1[17].Text = (3.5).ToString();
							Text1[18].Text = (4).ToString();
						}
						else if (Frame1[0].Text == "DN10体积仪表系数")
						{
							Text1[11].Text = "1.0";
							Text1[12].Text = (1.25).ToString();
							Text1[13].Text = (1.5).ToString();
							Text1[14].Text = (2.5).ToString();
							Text1[15].Text = (3.5).ToString();
							Text1[16].Text = (4).ToString();
						}
					}
					else if (Frame1[1].Text == "DN25体积仪表系数")
					{
						if (Frame1[0].Text == "DN2体积仪表系数")
						{
							Text1[11].Text = (0.07).ToString();
							Text1[12].Text = (0.15).ToString();
							Text1[13].Text = (0.25).ToString();
							Text1[14].Text = (0.35).ToString();
							Text1[15].Text = (0.7).ToString();
							Text1[16].Text = (1.05).ToString();
							Text1[17].Text = (1.5).ToString();
							Text1[18].Text = (2.5).ToString();
							Text1[19].Text = (3.5).ToString();
							Text1[20].Text = (5).ToString();
							Text1[21].Text = (7).ToString();
						}
						else if (Frame1[0].Text == "DN3体积仪表系数")
						{
							Text1[11].Text = (0.07).ToString();
							Text1[12].Text = (0.15).ToString();
							Text1[13].Text = (0.25).ToString();
							Text1[14].Text = (0.35).ToString();
							Text1[15].Text = (0.7).ToString();
							Text1[16].Text = (1.05).ToString();
							Text1[17].Text = (1.5).ToString();
							Text1[18].Text = (2.5).ToString();
							Text1[19].Text = (3.5).ToString();
							Text1[20].Text = (5).ToString();
							Text1[21].Text = (7).ToString();
						}
						else if (Frame1[0].Text == "DN6体积仪表系数")
						{
							Text1[11].Text = (0.4).ToString();
							Text1[12].Text = (0.5).ToString();
							Text1[13].Text = (0.7).ToString();
							Text1[14].Text = (1.05).ToString();
							Text1[15].Text = (1.5).ToString();
							Text1[16].Text = (2.5).ToString();
							Text1[17].Text = (3.5).ToString();
							Text1[18].Text = (4).ToString();
							Text1[19].Text = (5).ToString();
							Text1[20].Text = (7).ToString();
							Text5[1].Text = (0.01).ToString();
						}
						else if (Frame1[0].Text == "DN10体积仪表系数")
						{
							Text1[11].Text = "1.0";
							Text1[12].Text = (1.25).ToString();
							Text1[13].Text = (1.5).ToString();
							Text1[14].Text = (2.5).ToString();
							Text1[15].Text = (3.5).ToString();
							Text1[16].Text = (4).ToString();
							Text1[17].Text = (5).ToString();
							Text1[18].Text = (7).ToString();
						}
					}
					
					
				}
				else if (Option3.Checked == true) //三个标准表时
				{
					if (Frame1[0].Text == "DN2体积仪表系数") //小流量计
					{
						Text1[0].Text = (0.015).ToString();
						Text1[1].Text = (0.03).ToString();
						Text1[2].Text = (0.04).ToString();
						Text1[3].Text = (0.05).ToString();
						Text1[4].Text = (0.06).ToString();
						Text1[5].Text = (0.07).ToString();
					}
					else if (Frame1[0].Text == "DN3体积仪表系数")
					{
						Text1[0].Text = (0.015).ToString();
						Text1[1].Text = (0.03).ToString();
						Text1[2].Text = (0.04).ToString();
						Text1[3].Text = (0.05).ToString();
						Text1[4].Text = (0.06).ToString();
						Text1[5].Text = (0.07).ToString();
						Text1[6].Text = (0.08).ToString();
						Text1[7].Text = "0.10";
						Text1[8].Text = (0.12).ToString();
						Text5[0].Text = (0.001).ToString();
					}
					if (Frame1[1].Text == "DN6体积仪表系数") //中流量计
					{
						if (Frame1[0].Text == "DN2体积仪表系数")
						{
							Text1[11].Text = (0.06).ToString();
							Text1[12].Text = "0.10";
							Text1[13].Text = (0.15).ToString();
							Text1[14].Text = (0.25).ToString();
							Text1[15].Text = (0.35).ToString();
							Text1[16].Text = (0.45).ToString();
							Text1[17].Text = (0.5).ToString();
						}
						else if (Frame1[0].Text == "DN3体积仪表系数")
						{
							Text1[11].Text = "0.10";
							Text1[12].Text = (0.12).ToString();
							Text1[13].Text = (0.15).ToString();
							Text1[14].Text = (0.25).ToString();
							Text1[15].Text = (0.35).ToString();
							Text1[16].Text = (0.45).ToString();
							Text1[17].Text = (0.5).ToString();
						}
					}
					else if (Frame1[1].Text == "DN10体积仪表系数")
					{
						if (Frame1[0].Text == "DN2体积仪表系数")
						{
							Text1[11].Text = (0.06).ToString();
							Text1[12].Text = "0.10";
							Text1[13].Text = (0.15).ToString();
							Text1[14].Text = (0.25).ToString();
							Text1[15].Text = (0.35).ToString();
							Text1[16].Text = (0.45).ToString();
							Text1[17].Text = (0.5).ToString();
							Text1[18].Text = (0.7).ToString();
							Text1[19].Text = (1.05).ToString();
							Text1[20].Text = (1.2).ToString();
							
						}
						else if (Frame1[0].Text == "DN3体积仪表系数")
						{
							Text1[11].Text = "0.10";
							Text1[12].Text = (0.12).ToString();
							Text1[13].Text = (0.15).ToString();
							Text1[14].Text = (0.25).ToString();
							Text1[15].Text = (0.35).ToString();
							Text1[16].Text = (0.45).ToString();
							Text1[17].Text = (0.5).ToString();
							Text1[18].Text = (0.7).ToString();
							Text1[19].Text = (1.05).ToString();
							Text1[20].Text = (1.2).ToString();
							Text5[1].Text = (0.005).ToString();
						}
					}
					
					if (Frame1[2].Text == "DN15体积仪表系数") //大流量计
					{
						if (Frame1[1].Text == "DN6体积仪表系数")
						{
							Text1[22].Text = (0.4).ToString();
							Text1[23].Text = (0.5).ToString();
							Text1[24].Text = (0.7).ToString();
							Text1[25].Text = (1.05).ToString();
							Text1[26].Text = (1.5).ToString();
							Text1[27].Text = (2.5).ToString();
							Text1[28].Text = (3.5).ToString();
							Text1[29].Text = (4).ToString();
						}
						else if (Frame1[1].Text == "DN10体积仪表系数")
						{
							Text1[22].Text = "1.0";
							Text1[23].Text = (1.25).ToString();
							Text1[24].Text = (1.5).ToString();
							Text1[25].Text = (2.5).ToString();
							Text1[26].Text = (3.5).ToString();
							Text1[27].Text = (4).ToString();
						}
					}
					else if (Frame1[2].Text == "DN25体积仪表系数")
					{
						if (Frame1[1].Text == "DN6体积仪表系数")
						{
							Text1[22].Text = (0.4).ToString();
							Text1[23].Text = (0.5).ToString();
							Text1[24].Text = (0.7).ToString();
							Text1[25].Text = (1.05).ToString();
							Text1[26].Text = (1.5).ToString();
							Text1[27].Text = (2.5).ToString();
							Text1[28].Text = (3.5).ToString();
							Text1[29].Text = (4).ToString();
							Text1[30].Text = (5).ToString();
							Text1[31].Text = (7).ToString();
						}
						else if (Frame1[1].Text == "DN10体积仪表系数")
						{
							Text1[22].Text = "1.0";
							Text1[23].Text = (1.25).ToString();
							Text1[24].Text = (1.5).ToString();
							Text1[25].Text = (2.5).ToString();
							Text1[26].Text = (3.5).ToString();
							Text1[27].Text = (4).ToString();
							Text1[28].Text = (5).ToString();
							Text1[29].Text = (7).ToString();
							Text5[2].Text = (0.01).ToString();
						}
					}
					
				}
			}
			
			if (Option4.Checked == true || Option5.Checked == true)
			{
				Label8[17].Enabled = true;
				if (Option9.Checked == true)
				{
					Label10[7].Enabled = true;
				}
			}
			else if (Option10.Checked == true || Option6.Checked == true)
			{
				Label8[16].Enabled = true;
				if (Option9.Checked == true)
				{
					Label10[4].Enabled = true;
				}
			}
			else if (Option12.Checked == true || Option11.Checked == true)
			{
				Label8[15].Enabled = true;
				if (Option9.Checked == true)
				{
					Label10[9].Enabled = true;
				}
			}
			
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Timer1.Enabled = false;
		}
		
		public void fmrbzb1_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.FmrBzbactive = true;
			
			if (sub_Renamed.MID1 == 0)
			{
				this.Option7.Checked = true;
			}
			else if (sub_Renamed.MID1 == 1)
			{
				this.Option1.Checked = true;
			}
			else if (sub_Renamed.MID1 == 2)
			{
				this.Option2.Checked = true;
			}
			else if (sub_Renamed.MID1 == 3)
			{
				this.Option3.Checked = true;
			}
			if (sub_Renamed.MID2 == 0)
			{
				this.Option8.Checked = true;
			}
			else if (sub_Renamed.MID2 == 1)
			{
				this.Option9.Checked = true;
			}
			if (sub_Renamed.MID3 == 0)
			{
				this.Option12.Checked = false;
				this.Option11.Checked = false;
			}
			else if (sub_Renamed.MID3 == 1)
			{
				this.Option12.Checked = true;
			}
			else if (sub_Renamed.MID3 == 2)
			{
				this.Option11.Checked = true;
			}
			if (sub_Renamed.MID4 == 0)
			{
				this.Option10.Checked = false;
				this.Option6.Checked = false;
			}
			else if (sub_Renamed.MID4 == 1)
			{
				this.Option10.Checked = true;
			}
			else if (sub_Renamed.MID4 == 2)
			{
				this.Option6.Checked = true;
			}
			if (sub_Renamed.MID5 == 0)
			{
				this.Option5.Checked = false;
				this.Option4.Checked = false;
			}
			else if (sub_Renamed.MID5 == 1)
			{
				this.Option4.Checked = true;
			}
			else if (sub_Renamed.MID5 == 2)
			{
				this.Option5.Checked = true;
			}
			
			
			
			if (Option7.Checked == true)
			{
				Frame2[0].Enabled = false;
				Frame2[1].Enabled = false;
				Frame2[2].Enabled = false;
				Frame1[0].Enabled = false;
				Frame1[1].Enabled = false;
				Frame1[2].Enabled = false;
				Frame4[1].Enabled = false;
				Frame6[0].Enabled = false;
				Frame3[0].Enabled = false;
				
			}
			else if (Option1.Checked == true)
			{
				Frame2[0].Enabled = true;
				Frame2[1].Enabled = false;
				Frame2[2].Enabled = false;
				Frame1[0].Enabled = true;
				Frame1[1].Enabled = false;
				Frame1[2].Enabled = false;
				Frame4[1].Enabled = true;
				Frame6[0].Enabled = true;
				Label4[4].Enabled = false;
				Label4[5].Enabled = false;
				Label4[3].Enabled = false;
				Label4[6].Enabled = false;
				if (Option9.Checked == true)
				{
					Frame3[0].Enabled = true;
				}
				
			}
			else if (Option2.Checked == true)
			{
				Frame2[0].Enabled = true;
				Frame2[1].Enabled = true;
				Frame2[2].Enabled = false;
				if (Option9.Checked == true)
				{
					Frame1[0].Enabled = true;
					Frame1[1].Enabled = true;
					Frame1[2].Enabled = false;
					Frame3[0].Enabled = true;
				}
				else
				{
					Frame1[0].Enabled = false;
					Frame1[1].Enabled = false;
					Frame1[2].Enabled = false;
					Frame3[0].Enabled = false;
				}
				Frame4[1].Enabled = true;
				Frame6[0].Enabled = true;
				Label4[4].Enabled = true;
				Label4[5].Enabled = true;
				Label4[3].Enabled = true;
				Label4[6].Enabled = true;
				
				if (Option9.Checked == true)
				{
					Frame3[0].Enabled = true;
				}
				
			}
			else if (Option3.Checked == true)
			{
				Frame2[0].Enabled = true;
				Frame2[1].Enabled = true;
				Frame2[2].Enabled = true;
				if (Option9.Checked == true)
				{
					Frame1[0].Enabled = true;
					Frame1[1].Enabled = true;
					Frame1[2].Enabled = true;
					Frame3[0].Enabled = true;
				}
				else
				{
					Frame1[0].Enabled = false;
					Frame1[1].Enabled = false;
					Frame1[2].Enabled = false;
					Frame3[0].Enabled = false;
				}
				Frame4[1].Enabled = true;
				Frame6[0].Enabled = true;
				Label4[4].Enabled = true;
				Label4[5].Enabled = true;
				Label4[3].Enabled = true;
				Label4[6].Enabled = true;
				if (Option9.Checked == true)
				{
					Frame3[0].Enabled = true;
				}
			}
			
			
			if (Option1.Checked == true)
			{
				if (Option4.Checked == true)
				{
					Frame2[0].Text = "DN2表流速参数";
				}
				else if (Option5.Checked == true)
				{
					Frame2[0].Text = "DN3表流速参数";
				}
				else if (Option10.Checked == true)
				{
					Frame2[0].Text = "DN6表流速参数";
				}
				else if (Option6.Checked == true)
				{
					Frame2[0].Text = "DN10表流速参数";
				}
				else if (Option12.Checked == true)
				{
					Frame2[0].Text = "DN15表流速参数";
				}
				else if (Option11.Checked == true)
				{
					Frame2[0].Text = "DN25表流速参数";
				}
			}
			else if (Option2.Checked == true)
			{
				if (Option4.Checked == true)
				{
					Frame2[0].Text = "DN2表流速参数";
					Frame1[0].Text = "DN2体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN1-体积仪表系数";
					}
					else if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
				else if (Option5.Checked == true)
				{
					Frame2[0].Text = "DN3表流速参数";
					Frame1[0].Text = "DN3体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN10体积仪表系数";
					}
					else if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
				else if (Option10.Checked == true)
				{
					Frame2[0].Text = "DN6表流速参数";
					Frame1[0].Text = "DN6体积仪表系数";
					if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
				else if (Option6.Checked == true)
				{
					Frame2[0].Text = "DN10表流速参数";
					Frame1[0].Text = "DN10体积仪表系数";
					if (Option12.Checked == true)
					{
						Frame2[1].Text = "DN15表流速参数";
						Frame1[1].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[1].Text = "DN25表流速参数";
						Frame1[1].Text = "DN25体积仪表系数";
					}
				}
			}
			else if (Option3.Checked == true)
			{
				if (Option4.Checked == true)
				{
					Frame2[0].Text = "DN2表流速参数";
					Frame1[0].Text = "DN2体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN10体积仪表系数";
					}
					if (Option12.Checked == true)
					{
						Frame2[2].Text = "DN15表流速参数";
						Frame1[2].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[2].Text = "DN25表流速参数";
						Frame1[2].Text = "DN25体积仪表系数";
					}
				}
				else if (Option5.Checked == true)
				{
					Frame2[0].Text = "DN3表流速参数";
					Frame1[0].Text = "DN3体积仪表系数";
					if (Option10.Checked == true)
					{
						Frame2[1].Text = "DN6表流速参数";
						Frame1[1].Text = "DN6体积仪表系数";
					}
					else if (Option6.Checked == true)
					{
						Frame2[1].Text = "DN10表流速参数";
						Frame1[1].Text = "DN10体积仪表系数";
					}
					if (Option12.Checked == true)
					{
						Frame2[2].Text = "DN15表流速参数";
						Frame1[2].Text = "DN15体积仪表系数";
					}
					else if (Option11.Checked == true)
					{
						Frame2[2].Text = "DN25表流速参数";
						Frame1[2].Text = "DN25体积仪表系数";
					}
				}
			}
			
			if (Option4.Checked == true || Option5.Checked == true)
			{
				Label8[17].Enabled = true;
				if (Option9.Checked == true)
				{
					Label10[7].Enabled = true;
				}
			}
			else if (Option10.Checked == true || Option6.Checked == true)
			{
				Label8[16].Enabled = true;
				if (Option9.Checked == true)
				{
					Label10[4].Enabled = true;
				}
			}
			else if (Option12.Checked == true || Option11.Checked == true)
			{
				Label8[15].Enabled = true;
				if (Option9.Checked == true)
				{
					Label10[9].Enabled = true;
				}
			}
			
			if (sub_Renamed.Ld4 == 3)
			{
				Siajin[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1000)));
				Siajin[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1800)));
				Siajin[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240)));
				Siajin[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1000)));
				Siajin[4].Visible = false;
				Siajin[5].Visible = false;
				Lab[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1120)));
				Lab[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1920)));
				Lab[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360)));
				Lab[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1120)));
				Lab[4].Visible = false;
				Lab[5].Visible = false;
				Lab[3].Text = "中流量阀";
				Shapzsd[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1120)));
				Shapzsd[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1920)));
				Shapzsd[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360)));
				Shapzsd[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1120)));
				Shapzsd[4].Visible = false;
				Shapzsd[5].Visible = false;
			}
			else if (sub_Renamed.Ld4 == 4)
			{
				Siajin[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(750)));
				Siajin[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1270)));
				//   Siajin(4).left = 1800
				Siajin[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(240)));
				Siajin[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1000)));
				Siajin[4].Visible = true;
				Siajin[5].Visible = false;
				Lab[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(890)));
				Lab[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1400)));
				//   Lab(4).left = 2460
				Lab[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360)));
				Lab[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1120)));
				Lab[4].Visible = true;
				Lab[5].Visible = false;
				Lab[3].Text = "中流一阀";
				Shapzsd[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(890)));
				Shapzsd[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1400)));
				//   Shapzsd(4).left = 2460
				Shapzsd[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(360)));
				Shapzsd[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1120)));
				Shapzsd[4].Visible = true;
				Shapzsd[5].Visible = false;
			}
			else if (sub_Renamed.Ld4 == 5)
			{
				Siajin[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(750)));
				Siajin[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1270)));
				//   Siajin(4).left = 1270
				//   Siajin(5).left = 1800
				Siajin[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(750)));
				Siajin[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1270)));
				Siajin[4].Visible = true;
				Siajin[5].Visible = true;
				Lab[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(890)));
				Lab[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1400)));
				//   Lab(4).left = 1920
				//   Lab(5).left = 2760
				Lab[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(890)));
				Lab[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1400)));
				Lab[4].Visible = true;
				Lab[5].Visible = true;
				Lab[3].Text = "中流一阀";
				Shapzsd[2].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(890)));
				Shapzsd[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1400)));
				//   Shapzsd(4).left = 1920
				//   Shapzsd(5).left = 2760
				Shapzsd[6].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(890)));
				Shapzsd[7].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1400)));
				Shapzsd[4].Visible = true;
				Shapzsd[5].Visible = true;
			}
			
			Text10[3].Text = (sub_Renamed.Ld1).ToString();
			Text10[4].Text = (sub_Renamed.Ld2).ToString();
			Text10[5].Text = (sub_Renamed.Ld3).ToString();
			if (sub_Renamed.Admins == true)
			{
				Option7.Enabled = true;
				Option1.Enabled = true;
				Option2.Enabled = true;
				Option3.Enabled = true;
				Option8.Enabled = true;
				Option9.Enabled = true;
				Option4.Enabled = true;
				Option5.Enabled = true;
				Option6.Enabled = true;
				Option10.Enabled = true;
				Option11.Enabled = true;
				Option12.Enabled = true;
				
				Text10[3].Enabled = true;
				Text10[4].Enabled = true;
				Text10[5].Enabled = true;
				Text5[0].Enabled = true;
				Text5[1].Enabled = true;
				Text5[2].Enabled = true;
				Command3.Enabled = true;
			}
			else
			{
				Option7.Enabled = false;
				Option1.Enabled = false;
				Option2.Enabled = false;
				Option3.Enabled = false;
				Option8.Enabled = false;
				Option9.Enabled = false;
				Option4.Enabled = false;
				Option5.Enabled = false;
				Option6.Enabled = false;
				Option10.Enabled = false;
				Option11.Enabled = false;
				Option12.Enabled = false;
				Text10[3].Enabled = false;
				Text10[4].Enabled = false;
				Text10[5].Enabled = false;
				Text5[0].Enabled = false;
				Text5[1].Enabled = false;
				Text5[2].Enabled = false;
				Command3.Enabled = false;
			}
			
			sub_Renamed.StrSql = "select * from bzbbd ";
			sub_Renamed.RsZbs = new ADODB.Recordset();
			sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			sub_Renamed.RsZbs.MoveFirst();
			if (Option9.Checked == true)
			{
				for ( = ;0; i <= 10); i++;);
				{
					Text1[sub_Renamed.i].Text = () (sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value));
					sub_Renamed.Lld1[sub_Renamed.i] = (float) (Conversion.Val(Text1[sub_Renamed.i].Text));
					Text2[sub_Renamed.i].Text = () (sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value));
					sub_Renamed.Ks1[sub_Renamed.i] = (float) (Conversion.Val(Text2[sub_Renamed.i].Text));
				}
			}
			Text3[0].Text = () (sub_Renamed.RsZbs.Fields[22].Value));
			Text4[0].Text = () (sub_Renamed.RsZbs.Fields[23].Value));
			Text5[0].Text = () (sub_Renamed.RsZbs.Fields[24].Value));
			sub_Renamed.RsZbs.Close();
			
			sub_Renamed.StrSql = "select * from bzbbd1 ";
			sub_Renamed.RsZbs = new ADODB.Recordset();
			sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			sub_Renamed.RsZbs.MoveFirst();
			if (Option9.Checked == true)
			{
				for ( = ;0; i <= 10); i++;);
				{
					Text1[sub_Renamed.i + 11].Text = sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value;
					sub_Renamed.Lld2[sub_Renamed.i] = (float) (Conversion.Val(Text1[sub_Renamed.i + 11].Text));
					Text2[sub_Renamed.i + 11].Text = sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value;
					sub_Renamed.Ks2[sub_Renamed.i] = (float) (Conversion.Val(Text2[sub_Renamed.i + 11].Text));
				}
			}
			Text3[1].Text = () (sub_Renamed.RsZbs.Fields[22].Value));
			Text4[1].Text = () (sub_Renamed.RsZbs.Fields[23].Value));
			Text5[1].Text = () (sub_Renamed.RsZbs.Fields[24].Value));
			
			sub_Renamed.RsZbs.Close();
			
			sub_Renamed.StrSql = "select * from bzbbd2 ";
			sub_Renamed.RsZbs = new ADODB.Recordset();
			sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			sub_Renamed.RsZbs.MoveFirst();
			if (Option9.Checked == true)
			{
				for ( = ;0; i <= 10); i++;);
				{
					Text1[sub_Renamed.i + 22].Text = sub_Renamed.RsZbs.Fields[sub_Renamed.i].Value;
					sub_Renamed.Lld3[sub_Renamed.i] = (float) (Conversion.Val(Text1[sub_Renamed.i + 22].Text));
					Text2[sub_Renamed.i + 22].Text = sub_Renamed.RsZbs.Fields[sub_Renamed.i + 11].Value;
					sub_Renamed.Ks3[sub_Renamed.i] = (float) (Conversion.Val(Text2[sub_Renamed.i + 22].Text));
				}
			}
			Text3[2].Text = () (sub_Renamed.RsZbs.Fields[22].Value));
			Text4[2].Text = () (sub_Renamed.RsZbs.Fields[23].Value));
			Text5[2].Text = () (sub_Renamed.RsZbs.Fields[24].Value));
			sub_Renamed.RsZbs.Close();
			
			comm.Default.MSComm1.CommPort = sub_Renamed.Com1;
			comm.Default.MSComm4.CommPort = sub_Renamed.Com16;
			//comm.MSComm7.CommPort = Com5
			
			if (comm.Default.MSComm1.PortOpen == true)
			{
				comm.Default.MSComm1.PortOpen = false;
			}
			if (comm.Default.MSComm4.PortOpen == true)
			{
				comm.Default.MSComm4.PortOpen = false;
			}
			
		}
		
		public void fmrbzb1_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Timer1.Enabled = false;
			Timer3.Enabled = false;
			sub_Renamed.delay_times(1);
			
			sub_Renamed.FmrBzbactive = false;
		}
		
		public void mc_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Text12[1].Text = "";
			Text10[6].Text = "0";
			Text10[7].Text = "0";
			Text10[8].Text = "0";
			Text10[9].Text = "0";
			Text10[10].Text = "0";
			Text10[11].Text = "0";
			Timer1.Enabled = true;
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option1.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option1_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				Option8.Checked = true;
				Option9.Checked = false;
				Option8.Enabled = false;
				Option9.Enabled = false;
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option10.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option10_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option1.Checked == true)
				{
					Option4.Checked = false;
					Option5.Checked = false;
					Option12.Checked = false;
					Option11.Checked = false;
				}
				else if (Option2.Checked == true)
				{
					Option4.Checked = false;
					Option5.Checked = false;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option11.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option11_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option1.Checked == true)
				{
					Option4.Checked = false;
					Option5.Checked = false;
					Option6.Checked = false;
					Option10.Checked = false;
				}
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option12.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option12_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option1.Checked == true)
				{
					Option4.Checked = false;
					Option5.Checked = false;
					Option6.Checked = false;
					Option10.Checked = false;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option2.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option2_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				Option8.Checked = true;
				Option9.Checked = false;
				Option8.Enabled = true;
				Option9.Enabled = true;
				Option9.Checked = true;
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option3.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option3_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				Option8.Checked = true;
				Option9.Checked = false;
				Option8.Enabled = true;
				Option9.Enabled = true;
				Option9.Checked = true;
				
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option4.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option4_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option1.Checked == true)
				{
					Option10.Checked = false;
					Option6.Checked = false;
					Option12.Checked = false;
					Option11.Checked = false;
				}
				else if (Option2.Checked == true)
				{
					Option10.Checked = false;
					Option6.Checked = false;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option5.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option5_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option1.Checked == true)
				{
					Option10.Checked = false;
					Option6.Checked = false;
					Option12.Checked = false;
					Option11.Checked = false;
				}
				else if (Option2.Checked == true)
				{
					Option10.Checked = false;
					Option6.Checked = false;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option6.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option6_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				if (Option1.Checked == true)
				{
					Option4.Checked = false;
					Option5.Checked = false;
					Option12.Checked = false;
					Option11.Checked = false;
				}
				else if (Option2.Checked == true)
				{
					Option4.Checked = false;
					Option5.Checked = false;
				}
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option7.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option7_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				Option8.Checked = true;
				Option9.Checked = false;
				Option8.Enabled = false;
				Option9.Enabled = false;
			}
		}}
		
		public void qd_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 249);
			sub_Renamed.delay_times(1);
		}
		
		public void Siajin_Enter(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Siajin.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Command2.Focus();
			if ([Index;].value == true;);
			{
				Mdlguanfa.Zhu_Kai(ref Index);
			}
			else
			{
				Mdlguanfa.Zhu_Guan(ref Index);
			}
			Index = (short) 0;
		}
		
		public void Text1_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text1.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text1[Index + 1].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Text2_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text2.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text2[Index + 1].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short[] s = new short[16];
			short Recount = 0;
			object sss = null;
			string Rxd = "";
			byte[] hh = new byte[1];
			hh[0] = (byte) 253;
			if (comm.Default.MSComm4.PortOpen == false)
			{
				comm.Default.MSComm4.PortOpen = true;
			}
			comm.Default.MSComm4.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(hh);
			sub_Renamed.delay_times((0.5));F;);
			//UPGRADE_WARNING: 未能解析对象 comm.MSComm4.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Rxd = System.Convert.ToString(comm.Default.MSComm4.Input); // Read_int_From_LL()  ' MSComm4.Input
			//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
			Recount = System.Convert.ToInt16(LenB(Rxd));
			Text12[1].Text = "";
			for (i = 1; i <= Recount; i++)
			{
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sss = AscB(MidB(Rxd, sub_Renamed.i, 1));
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				s[sub_Renamed.i] = System.Convert.ToInt16(AscB(MidB(Rxd, sub_Renamed.i, 1)));
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text12[1].Text = Text12[1].Text + Conversion.Str(sss) + ",";
			}
			if (s[1] == 79 && s[8] == 75)
			{
				if (s[2] != 0 || s[3] > 0)
				{
					Text10[10].Text = (Conversion.Val(Text10[10].Text) + s[2] * 256 + s[3]).ToString(); //小流量计
				}
				if (s[4] != 0 || s[5] > 0)
				{
					Text10[6].Text = (Conversion.Val(Text10[6].Text) + s[4] * 256 + s[5]).ToString(); //中流量计
				}
				if (s[6] != 0 || s[7] > 0)
				{
					Text10[11].Text = (Conversion.Val(Text10[11].Text) + s[6] * 256 + s[7]).ToString(); //大流量计
				}
				
				Text10[9].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text10[10].Text) * sub_Renamed.Md1, "0.000"); //小流量
				Text10[8].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text10[6].Text) * sub_Renamed.Md2, "0.000"); //中流量
				Text10[7].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Conversion.Val(Text10[11].Text) * sub_Renamed.Md3, "0.00"); //大流量
				
			}
		}
		
		public void Timer3_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //瞬流
			object[] s = new object[16];
			short Recount = 0;
			object sss = null;
			string Rxd = "";
			
			Mdlguanfa.Send_DataSl((short) 245); //liusu
			sub_Renamed.delay_times((0.4));F;);
			
			Text11.Text = "";
			
			
			
			//UPGRADE_WARNING: 未能解析对象 comm.MSComm1.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Rxd = System.Convert.ToString(comm.Default.MSComm1.Input);
			//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
			Recount = System.Convert.ToInt16(LenB(Rxd));
			
			
			for (i = 1; i <= Recount; i++)
			{
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sss = AscB(MidB(Rxd, sub_Renamed.i, 1));
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_WARNING: 未能解析对象 s(i) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				s[sub_Renamed.i] = AscB(MidB(Rxd, sub_Renamed.i, 1));
				
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text11.Text = Text11.Text + Conversion.Str(sss) + ",";
			}
			//UPGRADE_WARNING: 未能解析对象 s(2) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) s[2] == 245)
			{
				
				if (sub_Renamed.MID1 == 1)
				{
					//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.LjslD[sub_Renamed.JsslD] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[8]) * 256) + System.Convert.ToDouble(s[9]) - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk1); //40m3/h
					sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
					sub_Renamed.JsslD++;
					if (sub_Renamed.JsslD == 3)
					{
						Text10[2].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
						sub_Renamed.JsslD = (short) 0;
						sub_Renamed.ZongslD = 0;
					}
					//UPGRADE_WARNING: 未能解析对象 s(8) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					if ((int) s[8] == 3) //零点数据
					{
						//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Text10[5].Text = s[9];
					}
				}
				else if (sub_Renamed.MID1 == 2)
				{
					if (sub_Renamed.MID5 != 0) //如果最小流量计组
					{
						
						//UPGRADE_WARNING: 未能解析对象 s(5) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.LjslX[sub_Renamed.JsslX] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[4]) * 256) + System.Convert.ToDouble(s[5]) - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Vk1);
						sub_Renamed.ZongslX = sub_Renamed.ZongslX + sub_Renamed.LjslX[sub_Renamed.JsslX];
						sub_Renamed.JsslX++;
						if (sub_Renamed.JsslX == 3)
						{
							Text10[0].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslX / 3, "0.000"); // 小流量
							sub_Renamed.JsslX = (short) 0;
							sub_Renamed.ZongslX = 0;
						}
						//UPGRADE_WARNING: 未能解析对象 s(4) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if ((int) s[4] == 3) //零点数据
						{
							//UPGRADE_WARNING: 未能解析对象 s(5) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text10[3].Text = s[5];
						}
						//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.LjslD[sub_Renamed.JsslD] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[8]) * 256) + System.Convert.ToDouble(s[9]) - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk2); //40m3/h
						sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
						sub_Renamed.JsslD++;
						if (sub_Renamed.JsslD == 3)
						{
							Text10[2].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
							sub_Renamed.JsslD = (short) 0;
							sub_Renamed.ZongslD = 0;
						}
						//UPGRADE_WARNING: 未能解析对象 s(8) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if ((int) s[8] == 3) //零点数据
						{
							//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text10[5].Text = s[9];
						}
					}
					else if (sub_Renamed.MID4 != 0) //如果中流量计组
					{
						//UPGRADE_WARNING: 未能解析对象 s(7) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.LjslZ[sub_Renamed.JsslZ] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[6]) * 256) + System.Convert.ToDouble(s[7]) - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Vk1);
						sub_Renamed.ZongslZ = sub_Renamed.ZongslZ + sub_Renamed.LjslZ[sub_Renamed.JsslZ];
						sub_Renamed.JsslZ++;
						if (sub_Renamed.JsslZ == 3)
						{
							Text10[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslZ / 3, "0.00"); // 中流量
							sub_Renamed.JsslZ = (short) 0;
							sub_Renamed.ZongslZ = 0;
						}
						//UPGRADE_WARNING: 未能解析对象 s(6) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if ((int) s[6] == 3) //零点数据
						{
							//UPGRADE_WARNING: 未能解析对象 s(7) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text10[4].Text = s[7];
						}
						//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.LjslD[sub_Renamed.JsslD] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[8]) * 256) + System.Convert.ToDouble(s[9]) - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk2); //40m3/h
						sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
						sub_Renamed.JsslD++;
						if (sub_Renamed.JsslD == 3)
						{
							Text10[2].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
							sub_Renamed.JsslD = (short) 0;
							sub_Renamed.ZongslD = 0;
						}
						//UPGRADE_WARNING: 未能解析对象 s(8) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if ((int) s[8] == 3) //零点数据
						{
							//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							Text10[5].Text = s[9];
						}
					}
				}
				else if (sub_Renamed.MID1 == 3)
				{
					//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.LjslD[sub_Renamed.JsslD] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[8]) * 256) + System.Convert.ToDouble(s[9]) - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax3 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk3); //40m3/h
					sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
					sub_Renamed.JsslD++;
					if (sub_Renamed.JsslD == 3)
					{
						Text10[2].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
						sub_Renamed.JsslD = (short) 0;
						sub_Renamed.ZongslD = 0;
					}
					//UPGRADE_WARNING: 未能解析对象 s(8) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					if ((int) s[8] == 3) //零点数据
					{
						//UPGRADE_WARNING: 未能解析对象 s(9) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Text10[5].Text = s[9];
					}
					//UPGRADE_WARNING: 未能解析对象 s(7) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.LjslZ[sub_Renamed.JsslZ] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[6]) * 256) + System.Convert.ToDouble(s[7]) - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Vk2);
					sub_Renamed.ZongslZ = sub_Renamed.ZongslZ + sub_Renamed.LjslZ[sub_Renamed.JsslZ];
					sub_Renamed.JsslZ++;
					if (sub_Renamed.JsslZ == 3)
					{
						Text10[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslZ / 3, "0.00"); // 中流量
						sub_Renamed.JsslZ = (short) 0;
						sub_Renamed.ZongslZ = 0;
					}
					//UPGRADE_WARNING: 未能解析对象 s(6) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					if ((int) s[6] == 3) //零点数据
					{
						//UPGRADE_WARNING: 未能解析对象 s(7) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Text10[4].Text = s[7];
					}
					//UPGRADE_WARNING: 未能解析对象 s(5) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 s() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.LjslX[sub_Renamed.JsslX] = System.Convert.ToSingle((System.Convert.ToInt32(System.Convert.ToDouble(s[4]) * 256) + System.Convert.ToDouble(s[5]) - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Vk1);
					sub_Renamed.ZongslX = sub_Renamed.ZongslX + sub_Renamed.LjslX[sub_Renamed.JsslX];
					sub_Renamed.JsslX++;
					if (sub_Renamed.JsslX == 3)
					{
						Text10[0].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslX / 3, "0.000"); // 小流量
						sub_Renamed.JsslX = (short) 0;
						sub_Renamed.ZongslX = 0;
						
					}
					//UPGRADE_WARNING: 未能解析对象 s(4) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					if ((int) s[4] == 3) //零点数据
					{
						//UPGRADE_WARNING: 未能解析对象 s(5) 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Text10[3].Text = s[5];
					}
				}
				//
				
				
				//                   End If
				
				
				//                      If Llxuanze = 0 Then
				//                    Text3(1).Text = Format((s(6) * 256 + s(7) - 888) * Qmax2 / 3210 * Vk2, "0.00")   ' 中流量
				//'                     If Val(Text3(1).Text) < 0.01 Or Val(Text3(1).Text) > 10 Then Text3(1).Text = "超出范围"
				//                        End If
				
			}
			
		}
		
		public void tz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 250);
			sub_Renamed.delay_times(1);
		}
	}
}
