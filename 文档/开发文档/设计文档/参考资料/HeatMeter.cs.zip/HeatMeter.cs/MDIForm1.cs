// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using System.Runtime.InteropServices;
using Microsoft.VisualBasic.CompilerServices;

namespace 热量表
{
	partial class MDIForm1 : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static MDIForm1 defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static MDIForm1 Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new MDIForm1();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		string ss;
		short sp; // 指出当前使用的字符在字符串中的位置。
		[DllImport("shell32.dll",EntryPoint="ShellExecuteA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		private static extern int ShellExecute(int hwnd, string lpOperation, string lpFile, string lpParameters, string lpDirectory, int nShowCmd);
		private const short SW_MAXIMIZE = 3;
		[DllImport("user32", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		private static extern int GetMenu(int hwnd);
		
		[DllImport("user32", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		private static extern int GetSubMenu(int hMenu, int nPos);
		
		[DllImport("user32", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		private static extern int SetMenuItemBitmaps(int hMenu, int nPosition, int wFlags, int hBitmapUnchecked, int hBitmapChecked);
		
		const int MF_BYPOSITION = 0x400;
		
		private void BBSM_Click()
		{
			//frmbanben.Show
		}
		
		private void bcanshu_Click()
		{
			frmzjsj.Default.Show();
		}
		
		public void baaizhuan_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			BZZJ.Default.Show();
		}
		
		public void BCK_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//If DenglurbOK = False Then
			//
			//  Denglurb = True
			//  frmceduankou.Show
			//Else
			//  calculator.Show
			//End If
			calculator.Default.Show();
		}
		
		
		private void BPCKXG_Click()
		{
			//Slider.Show
		}
		
		public void bdzbjf_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			mainForm.Default.Show();
			
		}
		
		private void bdzshz_Click()
		{
			Frmbdzshz.Default.Show();
		}
		
		public void bdzcsjsf_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Frmbdzshz.Default.Show();
		}
		
		public void biaoding_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmbiaoding.Default.Show();
		}
		
		public void biaozhunbfa_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			BZForm1.Default.Show();
		}
		
		public void bjbdz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmbjbdz.Default.Show();
		}
		
		
		
		private void BRK_Click()
		{
			//frmshuibiao.Show
			//frmceduankou.Show
		}
		
		//Private Sub bzb_Click()
		//liuljc.Show
		//End Sub
		
		private void bzbzj_Click()
		{
			//frmzjbzb.Show
		}
		
		private void cdck_Click()
		{
			this.LayoutMdi(System.Windows.Forms.MdiLayout.Cascade);
		}
		
		public void bzbbd_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Frmxs.Default.Show();
		}
		
		public void bzbcs_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			fmrbzb1.Default.Show();
		}
		
		public void chi_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.Chinese = true;
			this.Text = "热量表检定系统-山东省德鲁计量科技有限公司";
			spra.Text = "语言";
			eng.Text = "English";
			chi.Text = "中文";
			mnuSysMain.Text = "系统设置";
			mBAIPICK.Text = "检测项目";
			mnuShuju.Text = "数据查询";
			help.Text = "帮助文件";
			mnuquitb.Text = "退出系统";
			jsbdz.Text = "标准温度计参数";
			bjbdz.Text = "被检铂电阻参数";
			chuankou.Text = "串口设置";
			TP.Text = "天平串口设置";
			biaoding.Text = "数据采集及程序测试";
			mnuprintsetup.Text = "打印机设置";
			BPRKXG.Text = "流量检测";
			zonghe.Text = "总体检测";
			BCK.Text = "计算器检测";
			jcbdz.Text = "温度传感器检测";
			jsqbdz.Text = "计算器与配对温度传感器检测";
			nysy.Text = "耐压试验";
			mnuinku.Text = "流量传感器数据";
			zongticx.Text = "总体检测数据";
			mnuaa.Text = "计算器与温度传感器检测数据";
			khpfdcx.Text = "计算器检测数据";
			cxsm.Text = "检测程序帮助文件";
			zzsm.Text = "检定装置帮助文件";
			
			bdzbjf.Text = "比较法";
			bdzcsjsf.Text = "参数计算法";
			dianzucx.Text = "参数法检测数据";
			mnuclotheditin.Text = "比较法检测数据";
		}
		
		public void chuankou_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmchuankou.Default.Show();
		}
		
		private void czpp_Click()
		{
			this.LayoutMdi(System.Windows.Forms.MdiLayout.TileHorizontal);
		}
		
		
		
		
		
		private void dztj_Click()
		{
			//frmdztj.Show
			
		}
		
		
		private void dyzs_Click()
		{
			frmzjsj.Default.Show();
		}
		
		private void jiare_Click()
		{
			//frmjiare.Show
		}
		
		private void KEHUWH_Click()
		{
			//FRMYH.Show
			
		}
		
		public void cxsm_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Interaction.Shell("c:\\program files\\Adobe\\acrobat 7.0\\reader\\AcroRd32.exe c:\\program files\\检测系统\\检定程序使用说明书.pdf", (Microsoft.VisualBasic.AppWinStyle) 2, 0, -1);
			
		}
		
		public void dianzucx_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmbdzcsjscx.Default.Show();
		}
		
		public void eng_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.Chinese = false;
			this.Text = "Heat Meters Test Facility-Shandong Delu Measurement Technology Co, Ltd,.";
			spra.Text = "Language";
			eng.Text = "English";
			chi.Text = "中文";
			mnuSysMain.Text = "Settings";
			mBAIPICK.Text = "Test programe";
			mnuShuju.Text = "Test data";
			help.Text = "Helps";
			mnuquitb.Text = "Exit";
			jsbdz.Text = "Standard thermometer";
			bjbdz.Text = "Tested Temp.sensor";
			chuankou.Text = "Serial ports";
			TP.Text = "Balance port";
			biaoding.Text = "Program tests";
			mnuprintsetup.Text = "Printer";
			BPRKXG.Text = "Flow sensor";
			zonghe.Text = "Complete meter";
			BCK.Text = "Calculator";
			jcbdz.Text = "Temp.sensors";
			jsqbdz.Text = "Calculator-Temp.sensor pair";
			nysy.Text = "Pressure test";
			mnuinku.Text = "Flow sensor";
			zongticx.Text = "Complete meter";
			mnuaa.Text = "Calculator-Temp.sensor pair";
			khpfdcx.Text = "Calculator";
			cxsm.Text = "Software";
			zzsm.Text = "Test rig";
			//
			bdzbjf.Text = "Value comparison";
			bdzcsjsf.Text = "Characteristic curve";
			mnuclotheditin.Text = "Value comparison";
			dianzucx.Text = "Characteristic curve";
			
		}
		
		public void jcbdz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//mainForm.Show
		}
		
		public void jsbdz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmjsbdz.Default.Show();
		}
		
		public void jsqbdz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmjsqbdz.Default.Show();
		}
		
		public void khpfdcx_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmrebiaocx.Default.Show();
			
		}
		
		
		
		private void lltj_Click()
		{
			//frmlltj.Show
		}
		
		private void mcdl_Click()
		{
			//frmmcdl.Show
		}
		
		
		
		public void MDIForm1_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Module1.Dengludz = false;
			Module1.Denglurb = false;
			
			if (sub_Renamed.MID1 == 0 && sub_Renamed.Admins == false) //无标准表
			{
				bzbcs.Visible = false;
				bzbbd.Visible = false;
			}
			if (sub_Renamed.MID1 == 3) //三个标准表时无打压试验
			{
				nysy.Visible = false;
			}
			if (sub_Renamed.MID2 == 0) //无标准表法
			{
				BPRKXG.Visible = false;
				zonghe.Visible = false;
				flowjc.Visible = true;
				Ztjc.Visible = true;
			}
			else
			{
				BPRKXG.Visible = true;
				zonghe.Visible = true;
				flowjc.Visible = false;
				Ztjc.Visible = false;
			}
			
			this.Text = "热量表检定系统 — 山东省德鲁计量科技有限公司(V2011-" + "" + System.Convert.ToString(sub_Renamed.MID1) + "" + "" + System.Convert.ToString(sub_Renamed.MID2) + "" + "" + System.Convert.ToString(sub_Renamed.MID3) + "" + "" + System.Convert.ToString(sub_Renamed.MID4) + "" + "" + System.Convert.ToString(sub_Renamed.MID5) + "" + "" + System.Convert.ToString(sub_Renamed.MID6) + "" + "" + System.Convert.ToString(sub_Renamed.Ld4) + "" + "" + System.Convert.ToString(sub_Renamed.Ld5) + "" + "" + System.Convert.ToString(sub_Renamed.Ld6) + "" + ")";
			
		}
		
		
		public void MDIForm1_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.db.Close();
			this.Close();
			
			ProjectData.EndApp(); // 退出整个应用程序
		}
		public void flowjc_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Form1.Default.Show();
		}
		public void ztjc_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			FrmZongti.Default.Show();
		}
		public void mnuaa_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Frmbdzjsdcx.Default.Show();
		}
		
		private void mnucaozuo_Click()
		{
			//frmOpAdd.Show
			
		}
		
		public void mnuclotheditin_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmdianzucx.Default.Show();
		}
		
		private void mnufindin_Click()
		{
			//frmdatebiao.Show
			//frmllbb.Show
			
		}
		
		private void mnuhuizong_Click()
		{
			//frmdangdizhi.Show
		}
		
		public void mnuinku_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			datafrm.Default.Show();
		}
		
		private void mnuopper_Click()
		{
			//FRMXGCZY.Show
		}
		
		public void mnuPrintSetup_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			cd2Print.ShowDialog();
		}
		
		public void mnuquitb_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short Cancel;
			if (sub_Renamed.Chinese == true)
			{
				if (Interaction.MsgBox("您确定要退出本系统吗？", (int) MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "退出系统") == MsgBoxResult.Ok)
				{
					sub_Renamed.db.Close();
					this.Close();
					
				}
				else
				{
					Cancel = (short) (-1);
				}
				
			}
			else
			{
				if (Interaction.MsgBox("Are you sure you want to exit this system?", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Exit") == MsgBoxResult.Yes)
				{
					sub_Renamed.db.Close();
					this.Close();
					
				}
				else
				{
					Cancel = (short) (-1);
				}
			}
		}
		
		
		private void mnusepi_Click()
		{
			//frmdianzubb.Show
			
		}
		
		
		
		public void nysy_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmdumo.Default.Show();
		}
		
		private void pltb_Click()
		{
			this.LayoutMdi(System.Windows.Forms.MdiLayout.ArrangeIcons);
		}
		
		
		private void rbtj_Click()
		{
			//frmspcktongji.Show
		}
		
		private void pttz_Click()
		{
			//frmtu.Show
		}
		
		private void SJBF_Click()
		{
			//frmBackupRestore.Show
		}
		
		private void SJXF_Click()
		{
			//frmFixAndCompact.Show
		}
		
		private void SPPP_Click()
		{
			this.LayoutMdi(System.Windows.Forms.MdiLayout.TileVertical);
		}
		
		private void SPRKXG_Click()
		{
			//mainForm.Show
		}
		
		
		private void Toolbar1_ButtonClick(System.Windows.Forms.ToolStripButton Button)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short Cancel;
			switch (Button.Name)
			{
				case "badd":
					break;
					//          frmOpAdd.Show
				case "czygl":
					break;
					//          FRMXGCZY.Show
				case "byh":
					break;
					//          FRMYH.Show
					//    Case "blljc"
					//          liuljc.Show
				case "bztjc":
					Mdlguanfa.Sdzd = false;
					FrmZongti.Default.Show();
					break;
				case "BZBZJ":
					break;
					//          frmzjbzb.Show
					
				case "blljc":
					Mdlguanfa.Sdzd = false;
					Form1.Default.Show();
					break;
				case "bbdz":
					break;
					//
					//             mainForm.Show
					//          End If
				case "brljs":
					//
					calculator.Default.Show();
					break;
					//            End If
				case "lljccx":
					datafrm.Default.Show();
					break;
				case "ZTJCCX":
					frmzongticx.Default.Show();
					break;
				case "rljs":
					frmrebiaocx.Default.Show();
					break;
				case "bdz":
					frmdianzucx.Default.Show();
					break;
				case "bdysz":
					cd2Print.ShowDialog();
					break;
				case "blldy":
					break;
					//            frmllbb.Show
				case "brldy":
					break;
					//            frmdangdizhi.Show
				case "ZTJCDY":
					break;
					//          Frmzongtibbiao.Show
					
				case "bbdzdy":
					break;
					//       frmdianzubb.Show
				case "beifen":
					break;
					//        frmBackupRestore.Show
				case "zhengli":
					break;
					//        frmFixAndCompact.Show
				case "bczpp":
					this.LayoutMdi(System.Windows.Forms.MdiLayout.Cascade);
					break;
				case "bEXIT":
					if (sub_Renamed.Chinese == true)
					{
						if (Interaction.MsgBox("您确定要退出本系统吗？", (int) MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "退出系统") == MsgBoxResult.Ok)
						{
							sub_Renamed.db.Close();
							this.Close();
							ProjectData.EndApp();
						}
						else
						{
							Cancel = (short) (-1);
						}
					}
					else
					{
						if (Interaction.MsgBox("Are you sure you want to exit this system?", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Exit") == MsgBoxResult.Yes)
						{
							sub_Renamed.db.Close();
							this.Close();
							ProjectData.EndApp();
						}
						else
						{
							Cancel = (short) (-1);
						}
					}
					break;
			}
		}
		
		private void Toolbar1_ButtonMenuClick(System.Windows.Forms.ToolStripMenuItem ButtonMenu)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_ISSUE: MSComctlLib.ButtonMenu 属性 ButtonMenu.Key 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
			if ((string)  == )"badd";);
			{
				//          frmOpAdd.Show
			}
			else if ((string) buttonMenu.key == "czygl")
			{
				//          FRMXGCZY.Show
			}
			else if ((string) buttonMenu.key == "byh")
			{
				//          FRMYH.Show
				//    Case "blljc"
				//          flowtest.Show
				//          Case "bztjc"
				//          FrmZongti.Show
			}
			else if ((string) buttonMenu.Key == "bbdz")
			{
				//          If DengludzOK = False Then
				//               Dengludz = True
				//               frmceduankou.Show
				//            Else
				//               mainForm.Show
				//            End If
			}
			else if ((string)  == )"brljs";);
			{
				//            If DenglurbOK = False Then
				//
				//              Denglurb = True
				//              frmceduankou.Show
				//            Else
				calculator.Default.Show();
				//            End If
			}
			else if ((string) ButtonMenu.Key == "bztjc")
			{
				Mdlguanfa.Sdzd = false;
				FrmZongti.Default.Show();
			}
			else if ((string) buttonMenu.key == "blljc")
			{
				//          frmzjbzb.Show
			}
			else if ((string) ButtonMenu.Key == "ZLLL")
			{
				Mdlguanfa.Sdzd = false;
				Form1.Default.Show();
			}
			else if ((string) buttonMenu.Key == "lljccx")
			{
				datafrm.Default.Show();
			}
			else if ((string) buttonMenu.key == "ZTJCCX")
			{
				frmzongticx.Default.Show();
			}
			else if ((string)  == )"rljs";);
			{
				frmrebiaocx.Default.Show();
			}
			else if ((string) ButtonMenu.key == "bdz")
			{
				frmdianzucx.Default.Show();
			}
			else if ((string) ButtonMenu.key == "bdysz")
			{
				cd2Print.ShowDialog();
			}
			else if ((string) buttonMenu.Key == "blldy")
			{
				//            frmllbb.Show
			}
			else if ((string)  == )"ZTJCDY";);
			{
				//          Frmzongtibbiao.Show
			}
			else if ((string) ButtonMenu.key == "brldy")
			{
				//            frmdangdizhi.Show
			}
			else if ((string) ButtonMenu.key == "bbdzdy")
			{
				//       frmdianzubb.Show
			}
			else if ((string) ButtonMenu.key == "beifen")
			{
				//        frmBackupRestore.Show
			}
			else if ((string) buttonMenu.key == "zhengli")
			{
				//        frmFixAndCompact.Show
			}
			else if ((string)  == )"bczpp";);
			{
				this.LayoutMdi(System.Windows.Forms.MdiLayout.Cascade);
			}
		}
		
		private void XTPZ_Click()
		{
			
			//frmSysConfig.Show
			
		}
		private void InitMenus()
		{
			//// Get top level menu handle
			int hMainMenu;
			int hSubMenu;
			//hMainMenu = GetMenu(Me.hwnd)
			//hSubMenu = GetSubMenu(hMainMenu, 0)
			
			//// Register each of our menus
			//RegisterMenu hSubMenu, 0, Me.hwnd, "Owner Drawn Entry #1", pctEntry1
			//RegisterMenu hSubMenu, 1, Me.hwnd, "Owner Drawn Entry #2", pctEntry2
			//RegisterMenu hSubMenu, 2, Me.hwnd, "Owner Drawn Entry #3", pctEntry3
			//RegisterMenu hSubMenu, 3, Me.hwnd, "Owner Drawn Entry #4", pctEntry4
		}
		
		
		
		
		private void zongtibb_Click()
		{
			//Frmzongtibbiao.Show
		}
		
		public void TP_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			TPcomForm.Default.Show();
		}
		
		public void zhilaing_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			FrmZongti.Default.Show();
		}
		
		public void zhiliangfa_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Form1.Default.Show();
		}
		
		
		
		public void zongticx_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			frmzjcx.Default.Show();
		}
		
		private void ztjctj_Click()
		{
			//FRMZTTJ.Show
		}
		
		public void zzsm_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Interaction.Shell("c:\\program files\\Adobe\\acrobat 7.0\\reader\\AcroRd32.exe c:\\program files\\检测系统\\检定装置使用说明书.pdf", (Microsoft.VisualBasic.AppWinStyle) 2, 0, -1);
			
		}
	}
}
