// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;

namespace 热量表
{
	partial class frmzongticx : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmzongticx defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmzongticx Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmzongticx();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		private string strTable;
		ADODB.Recordset Namefind;
		ADODB.Recordset Findph;
		ADODB.Recordset Rsout;
		ADODB.Recordset Findrs;
		string datSD;
		string datFD;
		private int lngRecords;
		ADODB.Recordset rstDecSupt = new ADODB.Recordset();
		short Introw;
		
		private void DataSFD()
		{
			datSD = "#" + System.Convert.ToString(DTPicker1.Month) + "/" + System.Convert.ToString(DTPicker1.Day) + "/" + System.Convert.ToString(DTPicker1.Year) + "#";
			datFD = "#" + System.Convert.ToString(DTPicker2.Month) + "/" + System.Convert.ToString(DTPicker2.Day) + "/" + System.Convert.ToString(DTPicker2.Year) + "#";
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			DataSFD();
			strTable = "tblztcx";
			if (Combo1.Text.Length == 0)
			{
				sub_Renamed.sqlStr = "SELECT zongti.biaohao AS 表号,zongti.liuliangdian AS 流量点," + "zongti.indianzu AS 进口电阻,zongti.outdianzu AS 出口电阻,zongti.inwen as 进口温度," + "zongti.outwen as 出口温度," + "zongti.m0 as m0," + "zongti.m1 as m1," + "zongti.mcha as 重量," + "zongti.wendu as 温度," + "zongti.midu as 密度," + "zongti.biaozhun as 标准," + "zongti.llrz as 理论热量," + "zongti.e0 as e0," + "zongti.e1 as e1," + "zongti.echa as 热量示值," + "zongti.shizhiwucha as 示值误差," + "zongti.yaoqiu as 技术要求," + "zongti.jiancerq as 检测日期," + "zongti.jiancey as 检测员 " + "INTO tblztcx " + "FROM zongti " + "WHERE zongti.jiancerq BETWEEN " + datSD + " and " + datFD + " ";
			}
			else
			{
				sub_Renamed.sqlStr = "SELECT zongti.biaohao AS 表号,zongti.liuliangdian AS 流量点," + "zongti.indianzu AS 进口电阻,zongti.outdianzu AS 出口电阻,zongti.inwen as 进口温度," + "zongti.outwen as 出口温度," + "zongti.m0 as m0," + "zongti.m1 as m1," + "zongti.mcha as 重量," + "zongti.wendu as 温度," + "zongti.midu as 密度," + "zongti.biaozhun as 标准," + "zongti.llrz as 理论热量," + "zongti.e0 as e0," + "zongti.e1 as e1," + "zongti.echa as 热量示值," + "zongti.shizhiwucha as 示值误差," + "zongti.yaoqiu as 技术要求," + "zongti.jiancerq as 检测日期," + "zongti.jiancey as 检测员 " + "INTO tblztcx " + "FROM zongti " + "WHERE zongti.biaohao=\'" + Combo1.Text.Trim() + "\'" + "AND zongti.jiancerq BETWEEN " + datSD + " and " + datFD + " ";
			}
			
			//   Me.MousePointer = vbHourglass
			//   db.Close
			//   db.Open DEFSOURCE
			//
			//    On Error Resume Next
			//        db.Execute "DROP TABLE " & strTable, , adCmdText
			//
			//   On Error GoTo 0
			//
			//      db.Execute sqlstr, lngRecords, adCmdText
			//
			//
			//      With rstDecSupt
			//         If .State = adStateOpen Then
			//            .Close
			//         End If
			//         Set .ActiveConnection = db
			//         .CursorType = adOpenStatic
			//         .Source = strTable
			//'         .MaxRecords = 25
			//         .Open
			//      End With
			//      With hfgRollups
			//         Set .Recordset = rstDecSupt
			//         .Refresh
			//         .Col = .Cols - 1
			//         For Introw = 0 To .Rows - 1
			//            .Row = Introw
			//         Next Introw
			//         .Row = 0
			//      End With
			//      Me.MousePointer = vbDefault
			
			
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			sub_Renamed.db.Close();
			sub_Renamed.db.Open(sub_Renamed.DEFSOURCE, "", "", -1);
			
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object null_object = null;
			sub_Renamed.db.Execute("DROP TABLE " + strTable, out null_object, (System.Int32) ADODB.CommandTypeEnum.adCmdText);
			
			// On Error GoTo 0 VBConversions Note: Statement had no effect.
			
			sub_Renamed.db.Execute(sub_Renamed.sqlStr, out lngRecords, (System.Int32) ADODB.CommandTypeEnum.adCmdText);
			
			
			if (rstDecSupt.State == (int) ADODB.ObjectStateEnum.adStateOpen)
			{
				rstDecSupt.Close();
			}
			rstDecSupt.ActiveConnection = sub_Renamed.db;
			rstDecSupt.CursorType = ADODB.CursorTypeEnum.adOpenStatic;
			rstDecSupt.let_Source(strTable);
			//         .MaxRecords = 25
			rstDecSupt.Open(null, null, (ADODB.CursorTypeEnum) (-1), (ADODB.LockTypeEnum) (-1), -1);
			hfgRollups.Recordset = () );rstDecSupt;
			//UPGRADE_NOTE: Refresh 已升级到 CtlRefresh。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"”
			hfgRollups.ctlRefresh();
			hfgRollups.Col = hfgRollups.get_Cols() - 1;
			for (Introw = 0; Introw <= hfgRollups.Rows - 1; Introw++)
			{
				hfgRollups.Row = Introw;
			}
			hfgRollups.Row = 0;
			this.Cursor = System.Windows.Forms.Cursors.Default;
			
			
		}
		
		private void MakeTables()
		{
			
			
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
			
		}
		
		
		public void frmzongticx_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			DTPicker1.Year = DateAndTime.Year(DateAndTime.Today);
			DTPicker1.Month = DateAndTime.Month(DateAndTime.Today);
			DTPicker1.Day = VB.DateAndTime.Day(DateAndTime.Today);
			DTPicker2.Year = DateAndTime.Year(DateAndTime.Today);
			DTPicker2.Month = DateAndTime.Month(DateAndTime.Today);
			DTPicker2.Day = VB.DateAndTime.Day(DateAndTime.Today);
			this.Height = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(7140));
			this.Width = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(15360));
			
			//    Hnamefind
			
		}
	}
}
