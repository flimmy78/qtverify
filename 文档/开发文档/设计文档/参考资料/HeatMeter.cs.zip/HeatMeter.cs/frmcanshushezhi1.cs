// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmcanshushezhi1 : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmcanshushezhi1 defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmcanshushezhi1 Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmcanshushezhi1();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		ADODB.Recordset Namefind;
		double[] MeterRead = new double[26];
		double[] a0 = new double[2];
		byte[] a1 = new byte[2];
		byte[] MeterRead1 = new byte[26];
		float tstart;
		short i;
		short IIndex;
		bool Zhong;
		bool Ying;
		object tz;
		object cf;
		object bt;
		object cj;
		object zl;
		object gc;
		object mc;
		object bh;
		short Shunxu;
		private void Findguige()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[5].Items.Clear();
			
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Gname from guigek order by Gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[5].Items.Add(Namefind.Fields["Gname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[5].SelectedIndex = 0;
			
		}
		private void FindXinghao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[2].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Xname from xinghaok order by Xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[2].Items.Add(Namefind.Fields["Xname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[2].SelectedIndex = 0;
			
		}
		private void Findsongjian()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[8].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Sname from songjiank order by Sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[8].Items.Add(Namefind.Fields["Sname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[8].SelectedIndex = 0;
			
		}
		private void Findzhizao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[7].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Zname from zhizaok order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[7].Items.Add(Namefind.Fields["Zname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[7].SelectedIndex = 0;
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Combo1.SelectedIndexChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Combo1_SelectedIndexChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Combo1.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			IIndex = Index;
			if (sub_Renamed.Chinese == true)
			{
				if (sub_Renamed.Ld4 == 3)
				{
					ZhongXuan3(IIndex);
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					ZhongXuan4(IIndex);
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					ZhongXuan5(IIndex);
				}
			}
			else
			{
				if (sub_Renamed.Ld4 == 3)
				{
					YingXuan3(IIndex);
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					YingXuan4(IIndex);
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					YingXuan5(IIndex);
				}
				
			}
		}
		private void Zhongwen()
		{
			object j = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			for (j = 0; (int) j <= 4; j = (int) j + 1)
			{
				if (Conversion.Val(Tdian[j].Text) > 7)
				{
					MessageBox.Show("检定流量点 " + Tdian[j].Text + " m3/h 超出数值范围，请重新输入！");
					Tdian[j].Focus();
					return;
				}
			}
			
			if (Conversion.Val(shuju[4].Text) != 1 && Conversion.Val(shuju[4].Text) != 2 && Conversion.Val(shuju[4].Text) != 3)
			{
				MessageBox.Show("计量等级超出范围，请重新输入！");
				return;
			}
			
			if (Combo1[0].Text == "一")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "一")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "一")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "一")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[3].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "一")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[4].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(4).Text)
			}
			if (Combo1[0].Text == "二")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "二")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "二")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "二")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[3].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "二")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[4].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(4).Text)
			}
			
			if (Combo1[0].Text == "三")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[0].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "三")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[1].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "三")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[2].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "三")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[3].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "三")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[4].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(4).Text)
			}
			
			if (Combo1[0].Text == "四")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[0].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "四")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[1].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "四")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[2].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "四")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[3].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "四")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[4].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(4).Text)
			}
			
			if (Combo1[0].Text == "五")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[0].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "五")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[1].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "五")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[2].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "五")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[3].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "五")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[4].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(4).Text)
			}
			
			
			//一个检定点：
			if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[2].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text == "无")
			{
				sub_Renamed.Jd_point = (short) 0;
			}
			else if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[2].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[2].Text == "无" && Combo1[4].Text == "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text == "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[0].Text == "无" && Combo1[2].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text == "无" && Combo1[1].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[1].Text == "无" && Combo1[2].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text == "无" && Combo1[0].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			
			//二个检定点：
			//0no/3no/4no/1yes/2yes
			if (Combo1[0].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text == "无" && Combo1[1].Text != "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//1no/3no/4no/0yes/2yes
			}
			else if (Combo1[1].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text == "无" && Combo1[0].Text != "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//2no/3no/4no/1yes/0yes
			}
			else if (Combo1[2].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text == "无" && Combo1[1].Text != "无" && Combo1[0].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/1no/4no//2yes/3yes
			}
			else if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[4].Text == "无" && Combo1[2].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//1no/2no/4no/0yes/3yes
			}
			else if (Combo1[1].Text == "无" && Combo1[2].Text == "无" && Combo1[4].Text == "无" && Combo1[0].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/2no/4no/1yes/3yes
			}
			else if (Combo1[0].Text == "无" && Combo1[2].Text == "无" && Combo1[4].Text == "无" && Combo1[1].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/2no/3no/1yes/4yes
			}
			else if (Combo1[0].Text == "无" && Combo1[2].Text == "无" && Combo1[3].Text == "无" && Combo1[1].Text != "无" && Combo1[4].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/1no/3no/2yes/4yes
			}
			else if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[3].Text == "无" && Combo1[2].Text != "无" && Combo1[4].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/2no/1no/3yes/4yes
			}
			else if (Combo1[0].Text == "无" && Combo1[2].Text == "无" && Combo1[1].Text == "无" && Combo1[3].Text != "无" && Combo1[4].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				//2no/1no/3no/0yes/4yes
			}
			else if (Combo1[2].Text == "无" && Combo1[1].Text == "无" && Combo1[3].Text == "无" && Combo1[0].Text != "无" && Combo1[4].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
			}
			
			//三个检定点
			//0no/4no/1yes/2yes/3yes
			if (Combo1[0].Text == "无" && Combo1[4].Text == "无" && Combo1[1].Text != "无" && Combo1[2].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//1no/4no/0yes/2yes/3yes
			}
			else if (Combo1[1].Text == "无" && Combo1[4].Text == "无" && Combo1[0].Text != "无" && Combo1[2].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//2no/4no/0yes/1yes/3yes
			}
			else if (Combo1[2].Text == "无" && Combo1[4].Text == "无" && Combo1[0].Text != "无" && Combo1[1].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//3no/4no/0yes/1yes/2yes
			}
			else if (Combo1[3].Text == "无" && Combo1[4].Text == "无" && Combo1[0].Text != "无" && Combo1[1].Text != "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//0no/1no/4yes/2yes/3yes
			}
			else if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[4].Text != "无" && Combo1[2].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//0no/2no/4yes/1yes/3yes
			}
			else if (Combo1[0].Text == "无" && Combo1[2].Text == "无" && Combo1[4].Text != "无" && Combo1[1].Text != "无" && Combo1[3].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//0no/3no/4yes/1yes/2yes
			}
			else if (Combo1[0].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text != "无" && Combo1[1].Text != "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//1no/3no/4yes/0yes/2yes
			}
			else if (Combo1[1].Text == "无" && Combo1[3].Text == "无" && Combo1[4].Text != "无" && Combo1[0].Text != "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//1no/2no/4yes/3yes/0yes
			}
			else if (Combo1[1].Text == "无" && Combo1[2].Text == "无" && Combo1[4].Text != "无" && Combo1[3].Text != "无" && Combo1[0].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
				//3no/2no/4yes/1yes/0yes
			}
			else if (Combo1[3].Text == "无" && Combo1[2].Text == "无" && Combo1[4].Text != "无" && Combo1[1].Text != "无" && Combo1[0].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
			}
			//四个检定点
			//         3210/4
			if (Combo1[3].Text != "无" && Combo1[2].Text != "无" && Combo1[1].Text != "无" && Combo1[0].Text != "无" && Combo1[4].Text == "无")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4210/3
			}
			else if (Combo1[4].Text != "无" && Combo1[2].Text != "无" && Combo1[1].Text != "无" && Combo1[0].Text != "无" && Combo1[3].Text == "无")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4310/2
			}
			else if (Combo1[4].Text != "无" && Combo1[3].Text != "无" && Combo1[1].Text != "无" && Combo1[0].Text != "无" && Combo1[2].Text == "无")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4320/1
			}
			else if (Combo1[4].Text != "无" && Combo1[3].Text != "无" && Combo1[2].Text != "无" && Combo1[0].Text != "无" && Combo1[1].Text == "无")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4321/0
			}
			else if (Combo1[4].Text != "无" && Combo1[3].Text != "无" && Combo1[2].Text != "无" && Combo1[1].Text != "无" && Combo1[0].Text == "无")
			{
				sub_Renamed.Jd_point = (short) 4;
			}
			//五个检定点
			
			if (Combo1[0].Text != "无" && Combo1[1].Text != "无" && Combo1[2].Text != "无" && Combo1[3].Text != "无" && Combo1[4].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 5;
			}
			float Jiandingliang = 0;
			Jiandingliang = 0;
			for (i = 1; i <= sub_Renamed.Jd_point; i++)
			{
				if (Option15.Checked == true) //如连续一次检定
				{
					if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) > 90)
					{
						MessageBox.Show("第 " + System.Convert.ToString(i) + " 检定点的检定量不得大于90kg，请重新输入！");
						//             Tliang(j).SetFocus
						return;
					}
					else if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) < 3)
					{
						MessageBox.Show("第 " + System.Convert.ToString(i) + " 检定点的检定量不得小于3kg，请重新输入！");
						//             Tliang(j).SetFocus
						return;
					}
					Jiandingliang = Jiandingliang + sub_Renamed.Jd_liang[i - 1];
				}
				else
				{
					if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) > 100)
					{
						MessageBox.Show("第 " + System.Convert.ToString(i) + " 检定点的检定量不得大于100kg，请重新输入！");
						//             Tliang(j).SetFocus
						return;
					}
					else if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) < 3)
					{
						MessageBox.Show("第 " + System.Convert.ToString(i) + " 检定点的检定量不得小于3kg，请重新输入！");
						//             Tliang(j).SetFocus
						return;
					}
				}
				
				if (Jiandingliang > 100)
				{
					MessageBox.Show("检定量之和不得大于100kg，请重新输入！");
					return;
				}
			}
			
			Zhong = true;
		}
		private void Yingwen()
		{
			object j = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			for (j = 0; (int) j <= 4; j = (int) j + 1)
			{
				if (Conversion.Val(Tdian[j].Text) > 7)
				{
					MessageBox.Show("Flowrate " + Tdian[j].Text + " m3/h is out of range, please reenter!");
					Tdian[j].Focus();
					return;
				}
			}
			
			if (Conversion.Val(shuju[4].Text) != 1 && Conversion.Val(shuju[4].Text) != 2 && Conversion.Val(shuju[4].Text) != 3)
			{
				MessageBox.Show("The class is out of range,  Please reenter! ");
				return;
			}
			
			if (Combo1[0].Text == "ONE")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "ONE")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "ONE")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "ONE")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[3].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "ONE")
			{
				sub_Renamed.Jd_flow[0] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[4].Text));
				//        Jdtiaojie(0) = Val(Ttiaojie(4).Text)
			}
			if (Combo1[0].Text == "TWO")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "TWO")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "TWO")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "TWO")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[3].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "TWO")
			{
				sub_Renamed.Jd_flow[1] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[4].Text));
				//        Jdtiaojie(1) = Val(Ttiaojie(4).Text)
			}
			
			if (Combo1[0].Text == "THREE")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[0].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "THREE")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[1].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "THREE")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[2].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "THREE")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[3].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "THREE")
			{
				sub_Renamed.Jd_flow[2] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[4].Text));
				//            Jdtiaojie(2) = Val(Ttiaojie(4).Text)
			}
			
			if (Combo1[0].Text == "FOUR")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[0].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "FOUR")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[1].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "FOUR")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[2].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "FOUR")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[3].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "FOUR")
			{
				sub_Renamed.Jd_flow[3] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[3] = (float) (Conversion.Val(Tliang[4].Text));
				//            Jdtiaojie(3) = Val(Ttiaojie(4).Text)
			}
			
			if (Combo1[0].Text == "FIVE")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[0].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[0].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(0).Text)
			}
			else if (Combo1[1].Text == "FIVE")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[1].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[1].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(1).Text)
			}
			else if (Combo1[2].Text == "FIVE")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[2].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[2].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(2).Text)
			}
			else if (Combo1[3].Text == "FIVE")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[3].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[3].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(3).Text)
			}
			else if (Combo1[4].Text == "FIVE")
			{
				sub_Renamed.Jd_flow[4] = (float) (Conversion.Val(Tdian[4].Text));
				sub_Renamed.Jd_liang[4] = (float) (Conversion.Val(Tliang[4].Text));
				//            Jdtiaojie(4) = Val(Ttiaojie(4).Text)
			}
			
			
			//一个检定点：
			if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[2].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text == "NO")
			{
				sub_Renamed.Jd_point = (short) 0;
			}
			else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[2].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[2].Text == "NO" && Combo1[4].Text == "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text == "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[0].Text == "NO" && Combo1[2].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text == "NO" && Combo1[1].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			else if (Combo1[1].Text == "NO" && Combo1[2].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text == "NO" && Combo1[0].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
			}
			
			//TWO个检定点：
			//0no/3no/4no/1yes/2yes
			if (Combo1[0].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text == "NO" && Combo1[1].Text != "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//1no/3no/4no/0yes/2yes
			}
			else if (Combo1[1].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text == "NO" && Combo1[0].Text != "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//2no/3no/4no/1yes/0yes
			}
			else if (Combo1[2].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text == "NO" && Combo1[1].Text != "NO" && Combo1[0].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/1no/4no//2yes/3yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[4].Text == "NO" && Combo1[2].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//1no/2no/4no/0yes/3yes
			}
			else if (Combo1[1].Text == "NO" && Combo1[2].Text == "NO" && Combo1[4].Text == "NO" && Combo1[0].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/2no/4no/1yes/3yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[2].Text == "NO" && Combo1[4].Text == "NO" && Combo1[1].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/2no/3no/1yes/4yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[2].Text == "NO" && Combo1[3].Text == "NO" && Combo1[1].Text != "NO" && Combo1[4].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/1no/3no/2yes/4yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[3].Text == "NO" && Combo1[2].Text != "NO" && Combo1[4].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//0no/2no/1no/3yes/4yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[2].Text == "NO" && Combo1[1].Text == "NO" && Combo1[3].Text != "NO" && Combo1[4].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				//2no/1no/3no/0yes/4yes
			}
			else if (Combo1[2].Text == "NO" && Combo1[1].Text == "NO" && Combo1[3].Text == "NO" && Combo1[0].Text != "NO" && Combo1[4].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
			}
			
			//三个检定点
			//0no/4no/1yes/2yes/3yes
			if (Combo1[0].Text == "NO" && Combo1[4].Text == "NO" && Combo1[1].Text != "NO" && Combo1[2].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//1no/4no/0yes/2yes/3yes
			}
			else if (Combo1[1].Text == "NO" && Combo1[4].Text == "NO" && Combo1[0].Text != "NO" && Combo1[2].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//2no/4no/0yes/1yes/3yes
			}
			else if (Combo1[2].Text == "NO" && Combo1[4].Text == "NO" && Combo1[0].Text != "NO" && Combo1[1].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//3no/4no/0yes/1yes/2yes
			}
			else if (Combo1[3].Text == "NO" && Combo1[4].Text == "NO" && Combo1[0].Text != "NO" && Combo1[1].Text != "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//0no/1no/4yes/2yes/3yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[4].Text != "NO" && Combo1[2].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//0no/2no/4yes/1yes/3yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[2].Text == "NO" && Combo1[4].Text != "NO" && Combo1[1].Text != "NO" && Combo1[3].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//0no/3no/4yes/1yes/2yes
			}
			else if (Combo1[0].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text != "NO" && Combo1[1].Text != "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//1no/3no/4yes/0yes/2yes
			}
			else if (Combo1[1].Text == "NO" && Combo1[3].Text == "NO" && Combo1[4].Text != "NO" && Combo1[0].Text != "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//1no/2no/4yes/3yes/0yes
			}
			else if (Combo1[1].Text == "NO" && Combo1[2].Text == "NO" && Combo1[4].Text != "NO" && Combo1[3].Text != "NO" && Combo1[0].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
				//3no/2no/4yes/1yes/0yes
			}
			else if (Combo1[3].Text == "NO" && Combo1[2].Text == "NO" && Combo1[4].Text != "NO" && Combo1[1].Text != "NO" && Combo1[0].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
			}
			//FOUR个检定点
			//         3210/4
			if (Combo1[3].Text != "NO" && Combo1[2].Text != "NO" && Combo1[1].Text != "NO" && Combo1[0].Text != "NO" && Combo1[4].Text == "NO")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4210/3
			}
			else if (Combo1[4].Text != "NO" && Combo1[2].Text != "NO" && Combo1[1].Text != "NO" && Combo1[0].Text != "NO" && Combo1[3].Text == "NO")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4310/2
			}
			else if (Combo1[4].Text != "NO" && Combo1[3].Text != "NO" && Combo1[1].Text != "NO" && Combo1[0].Text != "NO" && Combo1[2].Text == "NO")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4320/1
			}
			else if (Combo1[4].Text != "NO" && Combo1[3].Text != "NO" && Combo1[2].Text != "NO" && Combo1[0].Text != "NO" && Combo1[1].Text == "NO")
			{
				sub_Renamed.Jd_point = (short) 4;
				//         4321/0
			}
			else if (Combo1[4].Text != "NO" && Combo1[3].Text != "NO" && Combo1[2].Text != "NO" && Combo1[1].Text != "NO" && Combo1[0].Text == "NO")
			{
				sub_Renamed.Jd_point = (short) 4;
			}
			//FIVE个检定点
			
			if (Combo1[0].Text != "NO" && Combo1[1].Text != "NO" && Combo1[2].Text != "NO" && Combo1[3].Text != "NO" && Combo1[4].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 5;
			}
			
			float Jiandingliang = 0;
			Jiandingliang = 0;
			for (i = 1; i <= sub_Renamed.Jd_point; i++)
			{
				if (Option15.Checked == true) //如连续一次检定
				{
					if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) > 90)
					{
						MessageBox.Show("The test volume of the point " + System.Convert.ToString(i) + " shall not be greater than 90kg，please try again!");
						//             Tliang(j).SetFocus
						return;
					}
					else if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) < 3)
					{
						MessageBox.Show("The test volume of the point " + System.Convert.ToString(i) + " shall not be less than 3kg, Please reenter!");
						//             Tliang(j).SetFocus
						return;
					}
					Jiandingliang = Jiandingliang + sub_Renamed.Jd_liang[i - 1];
				}
				else
				{
					if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) > 100)
					{
						MessageBox.Show("The test volume of the point " + System.Convert.ToString(i) + " shall not be greater than 100kg, Please reenter!");
						//             Tliang(j).SetFocus
						return;
					}
					else if (Conversion.Val((sub_Renamed.Jd_liang[i - 1]).ToString()) < 3)
					{
						MessageBox.Show("The test volume of the point " + System.Convert.ToString(i) + " shall not be less than 3kg, Please reenter!");
						//             Tliang(j).SetFocus
						return;
					}
				}
				
				if (Jiandingliang > 100)
				{
					MessageBox.Show("The sum of test volume shall not be greater than 100kg, Please reenter!");
					return;
				}
			}
			
			
			
			Ying = true;
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short j = 0;
			short k;
			short h;
			if (shuju[1].Text == "")
			{
				MessageBox.Show("请首先选择表的规格！");
				Tdian[j].Focus();
				return;
			}
			
			if (Option1.Checked == true)
			{
				if (Metertype.Text == "")
				{
					MessageBox.Show("采集代码不能为空，请选择！");
					return;
				}
			}
			if (sub_Renamed.Chinese == true)
			{
				Zhongwen();
			}
			else //如果是英语
			{
				Yingwen();
			} //中英文
			if (sub_Renamed.Chinese == true)
			{
				if (Zhong == false)
				{
					return;
				}
			}
			else
			{
				if (Ying == false)
				{
					return;
				}
			}
			sub_Renamed.XingHao = Strings.Trim(System.Convert.ToString(shuju[2].Text));
			sub_Renamed.GuiGe = Strings.Trim(System.Convert.ToString(shuju[1].Text));
			sub_Renamed.YouXiaoQi = Strings.Trim(System.Convert.ToString(shuju[4].Text));
			sub_Renamed.JianCeYuan = Strings.Trim(System.Convert.ToString(shuju[5].Text));
			sub_Renamed.ZhizaoDanwei = Strings.Trim(System.Convert.ToString(shuju[7].Text));
			sub_Renamed.SongjianDanwei = Strings.Trim(System.Convert.ToString(shuju[8].Text));
			
			
			if (Option1.Checked == true && sub_Renamed.MID2 == 1) //自动采集且带标准表法
			{
				if (sub_Renamed.Stueck15 == 12)
				{
					sub_Renamed.Stueck15 = (short) 11;
				}
				if (sub_Renamed.Stueck20 == 12)
				{
					sub_Renamed.Stueck20 = (short) 11;
				}
				if (sub_Renamed.Stueck25 == 12)
				{
					sub_Renamed.Stueck25 = (short) 11;
				}
				if (sub_Renamed.Stueck32 == 12)
				{
					sub_Renamed.Stueck32 = (short) 11;
				}
			}
			
			switch (Strings.Trim(System.Convert.ToString(shuju[1].Text)))
			{
				case "DN15":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck15 - 1);
					break;
				case "DN20":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck20 - 1);
					break;
				case "DN25":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck25 - 1);
					break;
				case "DN32":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck32 - 1);
					break;
			}
			
			Mdlguanfa.Qp = (float) (Conversion.Val(Text3.Text));
			sub_Renamed.SicherQ = (float) (Conversion.Val(Text1.Text));
			sub_Renamed.SicherE = (float) (Conversion.Val(Text2.Text));
			
			for (i = 0; i <= 11; i++)
			{
				Form1.Default.Frame2[i].Enabled = false;
				Form1.Default.Frame2[i].Visible = false;
			}
			
			if (sub_Renamed.Ld5 == 2 | sub_Renamed.Ld5 == 3)
			{
				for (i = 0; i <= sub_Renamed.Stueck; i++)
				{
					Form1.Default.Frame2[i].Visible = true;
					Form1.Default.Frame2[i].Enabled = true;
					Form1.Default.Frame2[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 25080 / sub_Renamed.Stueck * i)));
					Form1.Default.Frame2[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2280)));
				}
			}
			else if (sub_Renamed.Ld5 == 1)
			{
				for (i = 0; i <= sub_Renamed.Stueck; i++)
				{
					Form1.Default.Frame2[i].Visible = true;
					Form1.Default.Frame2[i].Enabled = true;
					if (i < (sub_Renamed.Stueck + 1) / 2)
					{
						Form1.Default.Frame2[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 11400 / (sub_Renamed.Stueck - 1) * 2 * i)));
						Form1.Default.Frame2[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(8520)));
						
					}
					else
					{
						Form1.Default.Frame2[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2520)));
						Form1.Default.Frame2[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 11400 / ((sub_Renamed.Stueck - 1) / 2) * (sub_Renamed.Stueck - i))));
					}
				}
			}
			
			
			//
			
			//被检表串口
			short[] meter = new short[21];
			if (sub_Renamed.Flagcom == false) //如果第一次进参数设置
			{
				if (Option1.Checked == true)
				{
					
					for (i = 1; i <= 12; i++)
					{
						meter[i] = (short) 0;
					}
					
					if (Metertype.SelectedIndex == 8) //光大表时
					{
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[0].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[0].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[0].InputLen = 0;
						Form1.Default.MSComm6[0].RTSEnable = true;
						Form1.Default.MSComm6[0].RThreshold = 1;
						Form1.Default.MSComm6[0].InputMode = ;InputMode;
						Form1.Default.MSComm6[0].CommPort = sub_Renamed.Com5;
						if (Form1.Default.MSComm6[0].PortOpen == true)
						{
							Form1.Default.MSComm6[0].PortOpen = false;
						}
						Form1.Default.MSComm6[0].PortOpen = true;
						if (Form1.Default.MSComm6[0].PortOpen == true)
						{
							meter[1] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[1].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[1].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[1].InputLen = 0;
						Form1.Default.MSComm6[1].RTSEnable = true;
						Form1.Default.MSComm6[1].RThreshold = 1;
						Form1.Default.MSComm6[1].InputMode = ;InputMode;
						Form1.Default.MSComm6[1].CommPort = sub_Renamed.Com6;
						if (Form1.Default.MSComm6[1].PortOpen == true)
						{
							Form1.Default.MSComm6[1].PortOpen = false;
						}
						Form1.Default.MSComm6[1].PortOpen = true;
						if (Form1.Default.MSComm6[1].PortOpen == true)
						{
							meter[2] = (short) 1;
						}
						
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[2].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[2].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[2].InputLen = 0;
						Form1.Default.MSComm6[2].RTSEnable = true;
						Form1.Default.MSComm6[2].RThreshold = 1;
						Form1.Default.MSComm6[2].InputMode = ;InputMode;
						Form1.Default.MSComm6[2].CommPort = sub_Renamed.Com7;
						if (Form1.Default.MSComm6[2].PortOpen == true)
						{
							Form1.Default.MSComm6[2].PortOpen = false;
						}
						Form1.Default.MSComm6[2].PortOpen = true;
						if (Form1.Default.MSComm6[2].PortOpen == true)
						{
							meter[3] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[3].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[3].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[3].InputLen = 0;
						Form1.Default.MSComm6[3].RTSEnable = true;
						Form1.Default.MSComm6[3].RThreshold = 1;
						Form1.Default.MSComm6[3].InputMode = ;InputMode;
						Form1.Default.MSComm6[3].CommPort = sub_Renamed.Com8;
						if (Form1.Default.MSComm6[3].PortOpen == true)
						{
							Form1.Default.MSComm6[3].PortOpen = false;
						}
						Form1.Default.MSComm6[3].PortOpen = true;
						if (Form1.Default.MSComm6[3].PortOpen == true)
						{
							meter[4] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[4].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[4].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[4].InputLen = 0;
						Form1.Default.MSComm6[4].RTSEnable = true;
						Form1.Default.MSComm6[4].RThreshold = 1;
						Form1.Default.MSComm6[4].InputMode = ;InputMode;
						Form1.Default.MSComm6[4].CommPort = sub_Renamed.Com9;
						if (Form1.Default.MSComm6[4].PortOpen == true)
						{
							Form1.Default.MSComm6[4].PortOpen = false;
						}
						Form1.Default.MSComm6[4].PortOpen = true;
						if (Form1.Default.MSComm6[4].PortOpen == true)
						{
							meter[5] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[5].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[5].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[5].InputLen = 0;
						Form1.Default.MSComm6[5].RTSEnable = true;
						Form1.Default.MSComm6[5].RThreshold = 1;
						Form1.Default.MSComm6[5].InputMode = ;InputMode;
						Form1.Default.MSComm6[5].CommPort = sub_Renamed.Com10;
						if (Form1.Default.MSComm6[5].PortOpen == true)
						{
							Form1.Default.MSComm6[5].PortOpen = false;
						}
						Form1.Default.MSComm6[5].PortOpen = true;
						if (Form1.Default.MSComm6[5].PortOpen == true)
						{
							meter[6] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[6].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[6].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[6].InputLen = 0;
						Form1.Default.MSComm6[6].RTSEnable = true;
						Form1.Default.MSComm6[6].RThreshold = 1;
						Form1.Default.MSComm6[6].InputMode = ;InputMode;
						Form1.Default.MSComm6[6].CommPort = sub_Renamed.Com11;
						if (Form1.Default.MSComm6[6].PortOpen == true)
						{
							Form1.Default.MSComm6[6].PortOpen = false;
						}
						Form1.Default.MSComm6[6].PortOpen = true;
						if (Form1.Default.MSComm6[6].PortOpen == true)
						{
							meter[7] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[7].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[7].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[7].InputLen = 0;
						Form1.Default.MSComm6[7].RTSEnable = true;
						Form1.Default.MSComm6[7].RThreshold = 1;
						Form1.Default.MSComm6[7].InputMode = ;InputMode;
						Form1.Default.MSComm6[7].CommPort = sub_Renamed.Com12;
						if (Form1.Default.MSComm6[7].PortOpen == true)
						{
							Form1.Default.MSComm6[7].PortOpen = false;
						}
						Form1.Default.MSComm6[7].PortOpen = true;
						if (Form1.Default.MSComm6[7].PortOpen == true)
						{
							meter[8] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[8].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[8].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[8].InputLen = 0;
						Form1.Default.MSComm6[8].RTSEnable = true;
						Form1.Default.MSComm6[8].RThreshold = 1;
						Form1.Default.MSComm6[8].InputMode = ;InputMode;
						Form1.Default.MSComm6[8].CommPort = sub_Renamed.Com13;
						if (Form1.Default.MSComm6[8].PortOpen == true)
						{
							Form1.Default.MSComm6[8].PortOpen = false;
						}
						Form1.Default.MSComm6[8].PortOpen = true;
						if (Form1.Default.MSComm6[8].PortOpen == true)
						{
							meter[9] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[9].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[9].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[9].InputLen = 0;
						Form1.Default.MSComm6[9].RTSEnable = true;
						Form1.Default.MSComm6[9].RThreshold = 1;
						Form1.Default.MSComm6[9].InputMode = ;InputMode;
						Form1.Default.MSComm6[9].CommPort = sub_Renamed.Com14;
						if (Form1.Default.MSComm6[9].PortOpen == true)
						{
							Form1.Default.MSComm6[9].PortOpen = false;
						}
						Form1.Default.MSComm6[9].PortOpen = true;
						if (Form1.Default.MSComm6[9].PortOpen == true)
						{
							meter[10] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[10].Settings = "2400,N,8,1";
						}
						else
						{
							Form1.Default.MSComm6[10].Settings = "1200,N,8,1";
						}
						Form1.Default.MSComm6[10].InputLen = 0;
						Form1.Default.MSComm6[10].RTSEnable = true;
						Form1.Default.MSComm6[10].RThreshold = 1;
						Form1.Default.MSComm6[10].InputMode = ;InputMode;
						Form1.Default.MSComm6[10].CommPort = sub_Renamed.Com15;
						if (Form1.Default.MSComm6[10].PortOpen == true)
						{
							Form1.Default.MSComm6[10].PortOpen = false;
						}
						Form1.Default.MSComm6[10].PortOpen = true;
						if (Form1.Default.MSComm6[10].PortOpen == true)
						{
							meter[11] = (short) 1;
						}
						
						if (sub_Renamed.MID2 == 0) //无标准表法时空出此串口
						{
							if (Option3.Checked == true)
							{
								Form1.Default.MSComm6[11].Settings = "2400,N,8,1";
							}
							else
							{
								Form1.Default.MSComm6[11].Settings = "1200,N,8,1";
							}
							Form1.Default.MSComm6[11].InputLen = 0;
							Form1.Default.MSComm6[11].RTSEnable = true;
							Form1.Default.MSComm6[11].RThreshold = 1;
							Form1.Default.MSComm6[11].InputMode = ;InputMode;
							Form1.Default.MSComm6[11].CommPort = sub_Renamed.Com16;
							if (Form1.Default.MSComm6[11].PortOpen == true)
							{
								Form1.Default.MSComm6[11].PortOpen = false;
							}
							Form1.Default.MSComm6[11].PortOpen = true;
							if (Form1.Default.MSComm6[11].PortOpen == true)
							{
								meter[12] = (short) 1;
							}
						}
					}
					else
					{
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[0].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[0].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[0].InputLen = 0;
						Form1.Default.MSComm6[0].RTSEnable = true;
						Form1.Default.MSComm6[0].RThreshold = 1;
						Form1.Default.MSComm6[0].InputMode = ;InputMode;
						Form1.Default.MSComm6[0].CommPort = sub_Renamed.Com5;
						if (Form1.Default.MSComm6[0].PortOpen == true)
						{
							Form1.Default.MSComm6[0].PortOpen = false;
						}
						Form1.Default.MSComm6[0].PortOpen = true;
						if (Form1.Default.MSComm6[0].PortOpen == true)
						{
							meter[1] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[1].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[1].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[1].InputLen = 0;
						Form1.Default.MSComm6[1].RTSEnable = true;
						Form1.Default.MSComm6[1].RThreshold = 1;
						Form1.Default.MSComm6[1].InputMode = ;InputMode;
						Form1.Default.MSComm6[1].CommPort = sub_Renamed.Com6;
						if (Form1.Default.MSComm6[1].PortOpen == true)
						{
							Form1.Default.MSComm6[1].PortOpen = false;
						}
						Form1.Default.MSComm6[1].PortOpen = true;
						if (Form1.Default.MSComm6[1].PortOpen == true)
						{
							meter[2] = (short) 1;
						}
						
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[2].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[2].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[2].InputLen = 0;
						Form1.Default.MSComm6[2].RTSEnable = true;
						Form1.Default.MSComm6[2].RThreshold = 1;
						Form1.Default.MSComm6[2].InputMode = ;InputMode;
						Form1.Default.MSComm6[2].CommPort = sub_Renamed.Com7;
						if (Form1.Default.MSComm6[2].PortOpen == true)
						{
							Form1.Default.MSComm6[2].PortOpen = false;
						}
						Form1.Default.MSComm6[2].PortOpen = true;
						if (Form1.Default.MSComm6[2].PortOpen == true)
						{
							meter[3] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[3].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[3].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[3].InputLen = 0;
						Form1.Default.MSComm6[3].RTSEnable = true;
						Form1.Default.MSComm6[3].RThreshold = 1;
						Form1.Default.MSComm6[3].InputMode = ;InputMode;
						Form1.Default.MSComm6[3].CommPort = sub_Renamed.Com8;
						if (Form1.Default.MSComm6[3].PortOpen == true)
						{
							Form1.Default.MSComm6[3].PortOpen = false;
						}
						Form1.Default.MSComm6[3].PortOpen = true;
						if (Form1.Default.MSComm6[3].PortOpen == true)
						{
							meter[4] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[4].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[4].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[4].InputLen = 0;
						Form1.Default.MSComm6[4].RTSEnable = true;
						Form1.Default.MSComm6[4].RThreshold = 1;
						Form1.Default.MSComm6[4].InputMode = ;InputMode;
						Form1.Default.MSComm6[4].CommPort = sub_Renamed.Com9;
						if (Form1.Default.MSComm6[4].PortOpen == true)
						{
							Form1.Default.MSComm6[4].PortOpen = false;
						}
						Form1.Default.MSComm6[4].PortOpen = true;
						if (Form1.Default.MSComm6[4].PortOpen == true)
						{
							meter[5] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[5].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[5].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[5].InputLen = 0;
						Form1.Default.MSComm6[5].RTSEnable = true;
						Form1.Default.MSComm6[5].RThreshold = 1;
						Form1.Default.MSComm6[5].InputMode = ;InputMode;
						Form1.Default.MSComm6[5].CommPort = sub_Renamed.Com10;
						if (Form1.Default.MSComm6[5].PortOpen == true)
						{
							Form1.Default.MSComm6[5].PortOpen = false;
						}
						Form1.Default.MSComm6[5].PortOpen = true;
						if (Form1.Default.MSComm6[5].PortOpen == true)
						{
							meter[6] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[6].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[6].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[6].InputLen = 0;
						Form1.Default.MSComm6[6].RTSEnable = true;
						Form1.Default.MSComm6[6].RThreshold = 1;
						Form1.Default.MSComm6[6].InputMode = ;InputMode;
						Form1.Default.MSComm6[6].CommPort = sub_Renamed.Com11;
						if (Form1.Default.MSComm6[6].PortOpen == true)
						{
							Form1.Default.MSComm6[6].PortOpen = false;
						}
						Form1.Default.MSComm6[6].PortOpen = true;
						if (Form1.Default.MSComm6[6].PortOpen == true)
						{
							meter[7] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[7].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[7].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[7].InputLen = 0;
						Form1.Default.MSComm6[7].RTSEnable = true;
						Form1.Default.MSComm6[7].RThreshold = 1;
						Form1.Default.MSComm6[7].InputMode = ;InputMode;
						Form1.Default.MSComm6[7].CommPort = sub_Renamed.Com12;
						if (Form1.Default.MSComm6[7].PortOpen == true)
						{
							Form1.Default.MSComm6[7].PortOpen = false;
						}
						Form1.Default.MSComm6[7].PortOpen = true;
						if (Form1.Default.MSComm6[7].PortOpen == true)
						{
							meter[8] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[8].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[8].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[8].InputLen = 0;
						Form1.Default.MSComm6[8].RTSEnable = true;
						Form1.Default.MSComm6[8].RThreshold = 1;
						Form1.Default.MSComm6[8].InputMode = ;InputMode;
						Form1.Default.MSComm6[8].CommPort = sub_Renamed.Com13;
						if (Form1.Default.MSComm6[8].PortOpen == true)
						{
							Form1.Default.MSComm6[8].PortOpen = false;
						}
						Form1.Default.MSComm6[8].PortOpen = true;
						if (Form1.Default.MSComm6[8].PortOpen == true)
						{
							meter[9] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[9].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[9].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[9].InputLen = 0;
						Form1.Default.MSComm6[9].RTSEnable = true;
						Form1.Default.MSComm6[9].RThreshold = 1;
						Form1.Default.MSComm6[9].InputMode = ;InputMode;
						Form1.Default.MSComm6[9].CommPort = sub_Renamed.Com14;
						if (Form1.Default.MSComm6[9].PortOpen == true)
						{
							Form1.Default.MSComm6[9].PortOpen = false;
						}
						Form1.Default.MSComm6[9].PortOpen = true;
						if (Form1.Default.MSComm6[9].PortOpen == true)
						{
							meter[10] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							Form1.Default.MSComm6[10].Settings = "2400,E,8,1";
						}
						else
						{
							Form1.Default.MSComm6[10].Settings = "1200,E,8,1";
						}
						Form1.Default.MSComm6[10].InputLen = 0;
						Form1.Default.MSComm6[10].RTSEnable = true;
						Form1.Default.MSComm6[10].RThreshold = 1;
						Form1.Default.MSComm6[10].InputMode = ;InputMode;
						Form1.Default.MSComm6[10].CommPort = sub_Renamed.Com15;
						if (Form1.Default.MSComm6[10].PortOpen == true)
						{
							Form1.Default.MSComm6[10].PortOpen = false;
						}
						Form1.Default.MSComm6[10].PortOpen = true;
						if (Form1.Default.MSComm6[10].PortOpen == true)
						{
							meter[11] = (short) 1;
						}
						
						if (sub_Renamed.MID2 == 0) //无标准表法时空出此串口
						{
							if (Option3.Checked == true)
							{
								Form1.Default.MSComm6[11].Settings = "2400,E,8,1";
							}
							else
							{
								Form1.Default.MSComm6[11].Settings = "1200,E,8,1";
							}
							Form1.Default.MSComm6[11].InputLen = 0;
							Form1.Default.MSComm6[11].RTSEnable = true;
							Form1.Default.MSComm6[11].RThreshold = 1;
							Form1.Default.MSComm6[11].InputMode = ;InputMode;
							Form1.Default.MSComm6[11].CommPort = sub_Renamed.Com16;
							if (Form1.Default.MSComm6[11].PortOpen == true)
							{
								Form1.Default.MSComm6[11].PortOpen = false;
							}
							Form1.Default.MSComm6[11].PortOpen = true;
							if (Form1.Default.MSComm6[11].PortOpen == true)
							{
								meter[12] = (short) 1;
							}
						}
						
					} //If Metertype.ListIndex = 8  Then
					
					for (i = 1; i <= 12; i++)
					{
						if (meter[i] == 0)
						{
							Form1.Default.Text19[i].Visible = true;
							if (sub_Renamed.Chinese == true)
							{
								Form1.Default.Text19[i].Text = "通讯口不正常!";
							}
							else
							{
								Form1.Default.Text19[i].Text = "Comport false!";
							}
						}
					}
					
					
					sub_Renamed.Comopen = true;
					Form1.Default.Command8.Visible = false;
				} //自动采集结束
				sub_Renamed.Flagcom = true;
			} //第一次进入参数结束
			
			if (Option1.Checked == true)
			{
				if (Option12.Checked == true) //不总检时
				{
					for (i = 0; i <= 11; i++)
					{
						Form1.Default.Text6[i].Visible = false;
						Form1.Default.Text8[i].Visible = false;
						Form1.Default.Text9[i].Visible = false;
						Form1.Default.Label6[i].Visible = false;
						Form1.Default.Label9[i].Visible = false;
						Form1.Default.Label11[i].Visible = false;
						Form1.Default.Label13[i].Visible = false;
						Form1.Default.Label15[i].Visible = false;
						Form1.Default.Label17[i].Visible = false;
						Form1.Default.Text2[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1320)));
						Form1.Default.Text4[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2150)));
						Form1.Default.Label4[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420)));
						Form1.Default.Label5[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2250)));
					}
				}
				
				Form1.Default.读表号一.Enabled = true;
				Form1.Default.读表号二.Enabled = true;
				Form1.Default.读表号三.Enabled = true;
				Form1.Default.读表号四.Enabled = true;
				Form1.Default.读表号五.Enabled = true;
				Form1.Default.读表号六.Enabled = true;
				Form1.Default.读表号七.Enabled = true;
				Form1.Default.读表号八.Enabled = true;
				Form1.Default.读表号九.Enabled = true;
				Form1.Default.读表号十.Enabled = true;
				Form1.Default.读表号十一.Enabled = true;
				Form1.Default.读表号十二.Enabled = true;
				
				switch (Metertype.SelectedIndex)
				{
					case 1:
					case 2:
					case 7:
						Form1.Default.Chu1.Enabled = true;
						Form1.Default.Chu2.Enabled = true;
						Form1.Default.Chu3.Enabled = true;
						Form1.Default.Chu4.Enabled = true;
						Form1.Default.Chu5.Enabled = true;
						Form1.Default.Chu6.Enabled = true;
						Form1.Default.Chu7.Enabled = true;
						Form1.Default.Chu8.Enabled = true;
						Form1.Default.Chu9.Enabled = true;
						Form1.Default.Chu10.Enabled = true;
						Form1.Default.Chu11.Enabled = true;
						Form1.Default.Chu12.Enabled = true;
						Form1.Default.状态一.Enabled = true;
						Form1.Default.状态二.Enabled = true;
						Form1.Default.状态三.Enabled = true;
						Form1.Default.状态四.Enabled = true;
						Form1.Default.状态五.Enabled = true;
						Form1.Default.状态六.Enabled = true;
						Form1.Default.状态七.Enabled = true;
						Form1.Default.状态八.Enabled = true;
						Form1.Default.状态九.Enabled = true;
						Form1.Default.状态十.Enabled = true;
						Form1.Default.状态十一.Enabled = true;
						Form1.Default.状态十二.Enabled = true;
						break;
					case 5:
						Form1.Default.状态一.Enabled = true;
						Form1.Default.状态二.Enabled = true;
						Form1.Default.状态三.Enabled = true;
						Form1.Default.状态四.Enabled = true;
						Form1.Default.状态五.Enabled = true;
						Form1.Default.状态六.Enabled = true;
						Form1.Default.状态七.Enabled = true;
						Form1.Default.状态八.Enabled = true;
						Form1.Default.状态九.Enabled = true;
						Form1.Default.状态十.Enabled = true;
						Form1.Default.状态十一.Enabled = true;
						Form1.Default.状态十二.Enabled = true;
						break;
				}
				
				
				if (sub_Renamed.Chinese == true)
				{
					Form1.Default.pq.Text = "开始";
					Form1.Default.Command6.Text = "退出";
					Form1.Default.Command6.Image = System.Drawing.Image.FromFile((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\3.ico");
				}
				else
				{
					Form1.Default.pq.Text = " Start";
					Form1.Default.Command6.Text = "Exit";
					Form1.Default.Command6.Image = System.Drawing.Image.FromFile((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\3.ico");
				}
				if (sub_Renamed.Jdks2 == true)
				{
					Form1.Default.pq.Enabled = true;
				}
				Form1.Default.pq.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(3960));
				Form1.Default.Command2.Visible = false;
				Form1.Default.Combc.Visible = false;
				
				if (sub_Renamed.Chinese == true)
				{
					if (sub_Renamed.Pqschutz == false)
					{
						Form1.Default.Text13.Visible = true;
						Form1.Default.Text13.Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4080)));
						if (Option12.Checked == true)
						{
							Form1.Default.Labt.Text = "请设定排气时间    秒，观察天平、温度采集是否正常。然后点击《开始》进行检定！";
						}
						else
						{
							Form1.Default.Labt.Text = "请设定排气时间    秒，观察天平、标准温度、温度采集是否正常。然后点击《开始》进行检定！";
						}
					}
				}
				else
				{
					if (sub_Renamed.Pqschutz == false)
					{
						Form1.Default.Text13.Visible = true;
						Form1.Default.Text13.Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(6280)));
						if (Option12.Checked == true)
						{
							Form1.Default.Labt.Text = "Please confirm exhaust time. Balance and temperature reading shall be function correctly. Then click on <<start>> testing!";
						}
						else
						{
							Form1.Default.Labt.Text = "Please confirm exhaust time. Balance, standard thermometer and temperature reading shall be function correctly. Then click on <<start>> testing!";
						}
					}
				}
				
			}
			else //不是自动采集时
			{
				Form1.Default.Frame8.Visible = false;
				Form1.Default.Command2.Visible = true;
				Form1.Default.Combc.Visible = true;
				if (sub_Renamed.Chinese == true)
				{
					Form1.Default.pq.Text = "排气";
					Form1.Default.Command6.Text = "退出";
					Form1.Default.Command6.Image = System.Drawing.Image.FromFile((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\5.ico");
				}
				else
				{
					Form1.Default.pq.Text = "Exhaust";
					Form1.Default.Command6.Text = " Exit";
					Form1.Default.Command6.Image = System.Drawing.Image.FromFile((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tab\\5.ico");
				}
				Form1.Default.pq.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2280));
				if (sub_Renamed.Chinese == true)
				{
					if (sub_Renamed.Pqschutz == false)
					{
						Form1.Default.Text13.Visible = true;
						Form1.Default.Text13.Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4080)));
						if (Option12.Checked == true)
						{
							Form1.Default.Labt.Text = "请设定排气时间    秒，观察天平、温度采集是否正常。然后点击《排气》！";
						}
						else
						{
							Form1.Default.Labt.Text = "请设定排气时间    秒，观察天平、标准温度、温度采集是否正常。然后点击《排气》！";
						}
						Form1.Default.pq.Enabled = true;
					}
				}
				else
				{
					if (sub_Renamed.Pqschutz == false)
					{
						Form1.Default.Text13.Visible = true;
						Form1.Default.Text13.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(6280));
						if (Option12.Checked == true)
						{
							Form1.Default.Labt.Text = "Please confirm exhaust time. balance and temperature reading is functioning correctly. Then click on <<start>> test!";
						}
						else
						{
							Form1.Default.Labt.Text = "Please confirm exhaust time. balance, standard thermometer and temperature reading is functioning correctly. Then click on <<start>> test!";
						}
						Form1.Default.pq.Enabled = true;
					}
					
				}
				for (i = 0; i <= 23; i++)
				{
					Form1.Default.Text10[i].Visible = false;
				}
				
				for (i = 0; i <= 11; i++)
				{
					Form1.Default.Label6[i].Text = "P0";
					Form1.Default.Label9[i].Text = "P1";
					Form1.Default.Label13[i].Text = "个";
					Form1.Default.Label11[i].Text = "个";
					Form1.Default.Label17[i].Visible = false;
					Form1.Default.Label15[i].Visible = false;
					Form1.Default.Text9[i].Visible = false;
					
					//   Form1.Frame2(i).Height = 3900
					Form1.Default.Frame6[8].Visible = false;
					Form1.Default.Frame6[9].Visible = false;
					Form1.Default.Frame3[2].Visible = false;
					Form1.Default.Frame7.Visible = false;
				}
				
				Form1.Default.Chu1.Visible = false;
				Form1.Default.Chu2.Visible = false;
				Form1.Default.Chu3.Visible = false;
				Form1.Default.Chu4.Visible = false;
				Form1.Default.Chu5.Visible = false;
				Form1.Default.Chu6.Visible = false;
				Form1.Default.Chu7.Visible = false;
				Form1.Default.Chu8.Visible = false;
				Form1.Default.Chu9.Visible = false;
				Form1.Default.Chu10.Visible = false;
				Form1.Default.Chu11.Visible = false;
				Form1.Default.Chu12.Visible = false;
				
				if (Option5.Checked == true) //不记录脉冲数
				{
					for (i = 0; i <= 11; i++)
					{
						Form1.Default.Text6[i].Visible = false;
						Form1.Default.Text8[i].Visible = false;
						Form1.Default.Text9[i].Visible = false;
						Form1.Default.Label6[i].Visible = false;
						Form1.Default.Label9[i].Visible = false;
						Form1.Default.Label11[i].Visible = false;
						Form1.Default.Label13[i].Visible = false;
						Form1.Default.Label15[i].Visible = false;
						Form1.Default.Label17[i].Visible = false;
						Form1.Default.Text2[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1320)));
						Form1.Default.Text4[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2150)));
						Form1.Default.Label4[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420)));
						Form1.Default.Label5[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2250)));
						
					}
				}
				
				
			} //自动采集结束
			
			if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7)
			{
				Form1.Default.Option3.Checked = true; //初值回零
			}
			else
			{
				Form1.Default.Option4.Checked = true; //初值不回零
			}
			
			//
			
			Form1.Default.Text13.Text = (45).ToString();
			
			
			//If Option14.value = True Then Form1.Text13.Visible = False '不排气时
			
			if (Option12.Checked == true) //不检总量
			{
				Form1.Default.Frame3[2].Visible = false;
				Form1.Default.Frame6[8].Visible = false;
				Form1.Default.Frame6[9].Visible = false;
				Form1.Default.Frame7.Visible = false;
				Form1.Default.Frame8.Visible = false;
				Form1.Default.Label7[1].Visible = false;
				Form1.Default.Label18.Visible = false;
				
				if (Option5.Checked == true)
				{
					for (i = 0; i <= 11; i++)
					{
						Form1.Default.Text6[i].Visible = false;
						Form1.Default.Text8[i].Visible = false;
						Form1.Default.Text9[i].Visible = false;
						Form1.Default.Label6[i].Visible = false;
						Form1.Default.Label9[i].Visible = false;
						Form1.Default.Label11[i].Visible = false;
						Form1.Default.Label13[i].Visible = false;
						Form1.Default.Label15[i].Visible = false;
						Form1.Default.Label17[i].Visible = false;
						Form1.Default.Text2[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1320)));
						Form1.Default.Text4[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2150)));
						Form1.Default.Label4[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420)));
						Form1.Default.Label5[i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2250)));
					}
					Form1.Default.Chu1.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu2.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu3.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu4.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu5.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu6.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu7.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu8.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu9.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu10.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu11.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
					Form1.Default.Chu12.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1420));
				}
				
			}
			else
			{
				Form1.Default.Frame8.Enabled = true;
			}
			
			for (i = 0; i <= sub_Renamed.Ld4 - 1; i++)
			{
				sub_Renamed.LLQmax[i] = (float) (Conversion.Val(Tqmax[i].Text));
			}
			
			Form1.Default.Metertype.SelectedIndex = Metertype.SelectedIndex;
			Form1.Default.Image2.Enabled = true;
			Form1.Default.Image1.Enabled = true;
			
			if (Option10.Checked == true && Option1.Checked == true)
			{
				FileSystem.FileClose(3);
				FileSystem.FileOpen(3, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Order.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
				FileSystem.Input(3, ref Shunxu);
				FileSystem.FileClose(3);
				if (Shunxu == 1)
				{
					Option17.Checked = true;
				}
				else if (Shunxu == 2)
				{
					Option18.Checked = true;
				}
				else if (Shunxu == 3)
				{
					Option19.Checked = true;
				}
				Frame13.Visible = true;
				Command1.Enabled = false;
				Text5.Text = sub_Renamed.Biaobianhao;
			}
			else
			{
				this.Hide();
			}
		}
		
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Hide();
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT gname from guigek where gname=\'" + Strings.Trim(System.Convert.ToString(shuju[5].Text)) + " \' order by gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["gname"].Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT Zname from zhizaok where Zname=\'" + Strings.Trim(System.Convert.ToString(shuju[7].Text)) + " \' order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["Zname"].Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT sname from songjiank where sname=\'" + Strings.Trim(System.Convert.ToString(shuju[8].Text)) + " \' order by sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["sname"].Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT xname from xinghaok where xname=\'" + Strings.Trim(System.Convert.ToString(shuju[2].Text)) + " \' order by xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["xname"].Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			//保存流量上限值
			
			sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst(0).OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
			sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from llqmax ", null, null, null);
			sub_Renamed.rsK.AddNew();
			
			sub_Renamed.rsK("gg").Value = Strings.Trim(System.Convert.ToString(shuju[1].Text));
			sub_Renamed.rsK("llq0").Value = Strings.Trim(System.Convert.ToString(Tqmax[0].Text));
			sub_Renamed.rsK("llq1").Value = Strings.Trim(System.Convert.ToString(Tqmax[1].Text));
			sub_Renamed.rsK("llq2").Value = Strings.Trim(System.Convert.ToString(Tqmax[2].Text));
			sub_Renamed.rsK("llq3").Value = Strings.Trim(System.Convert.ToString(Tqmax[3].Text));
			sub_Renamed.rsK("llq4").Value = Strings.Trim(System.Convert.ToString(Tqmax[4].Text));
			
			for (i = 0; i <= sub_Renamed.Ld4 - 1; i++)
			{
				sub_Renamed.LLQmax[i] = (float) (Conversion.Val(Tqmax[i].Text));
				Tqmax[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008); //将字体改为黑色
			}
			
			sub_Renamed.rsK.Update(1, 0);
			sub_Renamed.rsK.Close();
			sub_Renamed.dbK.Close();
			
			//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.rsK = null;
			//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.dbK = null;
			
			
			
			if (Option1.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cj = 1;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cj = 2;
			}
			if (Option11.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				zl = 1;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				zl = 2;
			}
			if (Option4.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bt = 1;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bt = 2;
			}
			if (Option15.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				gc = 1;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				gc = 2;
			}
			//If Option13.value = True Then
			//   cf = 1
			//Else
			//   cf = 2
			//End If
			if (Option6.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				mc = 1;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				mc = 2;
			}
			if (Option7.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				tz = 1;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				tz = 2;
			}
			if (Option10.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bh = 1;
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bh = 2;
			}
			
			
			if (sub_Renamed.Ld4 == 3) //三阀门
			{
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst(0).OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh ", null, null, null);
				sub_Renamed.rsK.AddNew();
				sub_Renamed.rsK("gg").Value = Strings.Trim(System.Convert.ToString(shuju[1].Text));
				sub_Renamed.rsK("Xh").Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
				sub_Renamed.rsK("jcy").Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
				sub_Renamed.rsK("yxq").Value = Strings.Trim(System.Convert.ToString(shuju[4].Text));
				//rsK!jb = Trim(shuju(3).Text)
				sub_Renamed.rsK("zz").Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
				sub_Renamed.rsK("sj").Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
				
				sub_Renamed.rsK("ld0").Value = Strings.Trim(System.Convert.ToString(Tdian[0].Text));
				sub_Renamed.rsK("Ld1").Value = Strings.Trim(System.Convert.ToString(Tdian[1].Text));
				sub_Renamed.rsK("Ld2").Value = Strings.Trim(System.Convert.ToString(Tdian[2].Text));
				
				sub_Renamed.rsK("jl0").Value = Strings.Trim(System.Convert.ToString(Tliang[0].Text));
				sub_Renamed.rsK("jl1").Value = Strings.Trim(System.Convert.ToString(Tliang[1].Text));
				sub_Renamed.rsK("jl2").Value = Strings.Trim(System.Convert.ToString(Tliang[2].Text));
				
				//rsK!fm0 = trim((Ttiaojie(0).Text))
				//rsK!fm2 = trim((Ttiaojie(1).Text))
				//rsK!fm3 = trim((Ttiaojie(2).Text))
				sub_Renamed.rsK("sx0").Value = Strings.Trim(System.Convert.ToString(Combo1[0].Text));
				sub_Renamed.rsK("sx1").Value = Strings.Trim(System.Convert.ToString(Combo1[1].Text));
				sub_Renamed.rsK("sx2").Value = Strings.Trim(System.Convert.ToString(Combo1[2].Text));
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("cj").Value = cj;
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("zl").Value = zl;
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("bt").Value = bt;
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("gc").Value = gc;
				//rsK!cf = cf
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("mc").Value = mc;
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("tz").Value = tz;
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("bh").Value = bh;
				sub_Renamed.rsK("aqv").Value = Text1.Text.Trim();
				sub_Renamed.rsK("aqe").Value = Text2.Text.Trim();
				
			}
			else if (sub_Renamed.Ld4 == 4)
			{
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst(0).OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh ", null, null, null);
				sub_Renamed.rsK.AddNew();
				sub_Renamed.rsK("gg").Value = Strings.Trim(System.Convert.ToString(shuju[1].Text));
				sub_Renamed.rsK("Xh").Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
				sub_Renamed.rsK("jcy").Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
				sub_Renamed.rsK("yxq").Value = Strings.Trim(System.Convert.ToString(shuju[4].Text));
				//rsK!jb = Trim(shuju(3).Text)
				sub_Renamed.rsK("zz").Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
				sub_Renamed.rsK("sj").Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
				
				sub_Renamed.rsK("ld0").Value = Strings.Trim(System.Convert.ToString(Tdian[0].Text));
				sub_Renamed.rsK("Ld1").Value = Strings.Trim(System.Convert.ToString(Tdian[1].Text));
				sub_Renamed.rsK("Ld2").Value = Strings.Trim(System.Convert.ToString(Tdian[2].Text));
				sub_Renamed.rsK("Ld3").Value = Strings.Trim(System.Convert.ToString(Tdian[3].Text));
				
				sub_Renamed.rsK("jl0").Value = Strings.Trim(System.Convert.ToString(Tliang[0].Text));
				sub_Renamed.rsK("jl1").Value = Strings.Trim(System.Convert.ToString(Tliang[1].Text));
				sub_Renamed.rsK("jl2").Value = Strings.Trim(System.Convert.ToString(Tliang[2].Text));
				sub_Renamed.rsK("jl3").Value = Strings.Trim(System.Convert.ToString(Tliang[3].Text));
				
				//rsK!fm0 = trim((Ttiaojie(0).Text))
				//rsK!fm1 = trim((Ttiaojie(1).Text))
				//rsK!fm2 = trim((Ttiaojie(2).Text))
				//rsK!fm3 = trim((Ttiaojie(3).Text))
				sub_Renamed.rsK("sx0").Value = Strings.Trim(System.Convert.ToString(Combo1[0].Text));
				sub_Renamed.rsK("sx1").Value = Strings.Trim(System.Convert.ToString(Combo1[1].Text));
				sub_Renamed.rsK("sx2").Value = Strings.Trim(System.Convert.ToString(Combo1[2].Text));
				sub_Renamed.rsK("sx3").Value = Strings.Trim(System.Convert.ToString(Combo1[3].Text));
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("cj").Value = cj;
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("zl").Value = zl;
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("bt").Value = bt;
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("gc").Value = gc;
				//rsK!cf = cf
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("mc").Value = mc;
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("tz").Value = tz;
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("bh").Value = bh;
				sub_Renamed.rsK("aqv").Value = Text1.Text.Trim();
				sub_Renamed.rsK("aqe").Value = Text2.Text.Trim();
			}
			else if (sub_Renamed.Ld4 == 5)
			{
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst(0).OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh ", null, null, null);
				sub_Renamed.rsK.AddNew();
				sub_Renamed.rsK("gg").Value = Strings.Trim(System.Convert.ToString(shuju[1].Text));
				sub_Renamed.rsK("Xh").Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
				sub_Renamed.rsK("jcy").Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
				sub_Renamed.rsK("yxq").Value = Strings.Trim(System.Convert.ToString(shuju[4].Text));
				//rsK!jb = Trim(shuju(3).Text)
				sub_Renamed.rsK("zz").Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
				sub_Renamed.rsK("sj").Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
				
				sub_Renamed.rsK("ld0").Value = Strings.Trim(System.Convert.ToString(Tdian[0].Text));
				sub_Renamed.rsK("Ld1").Value = Strings.Trim(System.Convert.ToString(Tdian[1].Text));
				sub_Renamed.rsK("Ld2").Value = Strings.Trim(System.Convert.ToString(Tdian[2].Text));
				sub_Renamed.rsK("Ld3").Value = Strings.Trim(System.Convert.ToString(Tdian[3].Text));
				sub_Renamed.rsK("Ld4").Value = Strings.Trim(System.Convert.ToString(Tdian[4].Text));
				
				sub_Renamed.rsK("jl0").Value = Strings.Trim(System.Convert.ToString(Tliang[0].Text));
				sub_Renamed.rsK("jl1").Value = Strings.Trim(System.Convert.ToString(Tliang[1].Text));
				sub_Renamed.rsK("jl2").Value = Strings.Trim(System.Convert.ToString(Tliang[2].Text));
				sub_Renamed.rsK("jl3").Value = Strings.Trim(System.Convert.ToString(Tliang[3].Text));
				sub_Renamed.rsK("jl4").Value = Strings.Trim(System.Convert.ToString(Tliang[4].Text));
				//rsK!fm0 = trim((Ttiaojie(0).Text))
				//rsK!fm1 = trim((Ttiaojie(1).Text))
				//rsK!fm2 = trim((Ttiaojie(2).Text))
				//rsK!fm3 = trim((Ttiaojie(3).Text))
				sub_Renamed.rsK("sx0").Value = Strings.Trim(System.Convert.ToString(Combo1[0].Text));
				sub_Renamed.rsK("sx1").Value = Strings.Trim(System.Convert.ToString(Combo1[1].Text));
				sub_Renamed.rsK("sx2").Value = Strings.Trim(System.Convert.ToString(Combo1[2].Text));
				sub_Renamed.rsK("sx3").Value = Strings.Trim(System.Convert.ToString(Combo1[3].Text));
				sub_Renamed.rsK("sx4").Value = Strings.Trim(System.Convert.ToString(Combo1[4].Text));
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("cj").Value = cj;
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("zl").Value = zl;
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("bt").Value = bt;
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("gc").Value = gc;
				//rsK!cf = cf
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("mc").Value = mc;
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("tz").Value = tz;
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.rsK("bh").Value = bh;
				sub_Renamed.rsK("aqv").Value = Text1.Text.Trim();
				sub_Renamed.rsK("aqe").Value = Text2.Text.Trim();
				
			}
			sub_Renamed.rsK.Update(1, 0);
			sub_Renamed.rsK.Close();
			sub_Renamed.dbK.Close();
			
			//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.rsK = null;
			//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.dbK = null;
			//Me.Hide
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.MID1 != 0)
			{
				MessageBox.Show("默认值中红色字体为标准表上限流量值，改动后可能会使流量测量准确度有所降低！");
			}
			if (sub_Renamed.MID1 == 0 | sub_Renamed.MID1 == 1) //如果不用标准表采瞬流
			{
				if (sub_Renamed.Ld4 == 3)
				{
					Tqmax[0].Text = "0.12";
					Tqmax[1].Text = "1.25";
					Tqmax[2].Text = "8.0";
					Tqmax[2].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					Tqmax[0].Text = "0.12";
					Tqmax[1].Text = "0.4";
					Tqmax[2].Text = "1.25";
					Tqmax[3].Text = "8";
					Tqmax[3].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					Tqmax[0].Text = "0.12";
					Tqmax[1].Text = "0.4";
					Tqmax[2].Text = "0.85";
					Tqmax[3].Text = "1.4";
					Tqmax[4].Text = "8";
					Tqmax[4].Enabled = false;
				}
			}
			else if (sub_Renamed.MID1 == 2) //如二个标准表时采瞬流
			{
				if (sub_Renamed.Ld4 == 3)
				{
					Tqmax[0].Text = "0.12";
					Tqmax[1].Text = (sub_Renamed.Qmax1).ToString();
					Tqmax[2].Text = (sub_Renamed.Qmax2).ToString();
					Tqmax[1].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[2].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					Tqmax[0].Text = "0.12";
					Tqmax[1].Text = (sub_Renamed.Qmax1).ToString();
					Tqmax[1].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[2].Text = "1.25";
					Tqmax[3].Text = (sub_Renamed.Qmax2).ToString();
					Tqmax[3].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					Tqmax[0].Text = "0.12";
					Tqmax[1].Text = (sub_Renamed.Qmax1).ToString();
					Tqmax[1].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[2].Text = "0.85";
					Tqmax[3].Text = "1.5";
					Tqmax[4].Text = (sub_Renamed.Qmax2).ToString();
					Tqmax[4].Enabled = false;
				}
			}
			else if (sub_Renamed.MID1 == 3) //如果三个标准表采瞬流
			{
				if (sub_Renamed.Ld4 == 3)
				{
					Tqmax[0].Text = (sub_Renamed.Qmax1).ToString();
					Tqmax[0].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[1].Text = (sub_Renamed.Qmax2).ToString();
					Tqmax[1].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[2].Text = (sub_Renamed.Qmax3).ToString();
					Tqmax[2].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					Tqmax[0].Text = (sub_Renamed.Qmax1).ToString();
					Tqmax[0].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[1].Text = "0.5";
					Tqmax[2].Text = (sub_Renamed.Qmax2).ToString();
					Tqmax[2].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[3].Text = (sub_Renamed.Qmax3).ToString();
					Tqmax[3].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					Tqmax[0].Text = (sub_Renamed.Qmax1).ToString();
					Tqmax[0].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[1].Text = "0.5";
					Tqmax[2].Text = "0.75";
					Tqmax[3].Text = (sub_Renamed.Qmax2).ToString();
					Tqmax[3].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
					Tqmax[4].Text = (sub_Renamed.Qmax3).ToString();
					Tqmax[4].Enabled = false;
				}
			}
			
			for (i = 0; i <= sub_Renamed.Ld4 - 1; i++)
			{
				sub_Renamed.LLQmax[i] = (float) (Conversion.Val(Tqmax[i].Text));
				Tdian[i].Text = "";
			}
			
			sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst(0).OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
			sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh where gg=\'" + Strings.Trim(System.Convert.ToString(shuju[1].Text)) + "\'", null, null, null);
			
			sub_Renamed.rsK.MoveLast(0);
			
			Tdian[0].Text = sub_Renamed.rsK("ld0").Value;
			Tdian[1].Text = sub_Renamed.rsK("Ld1").Value;
			Tdian[2].Text = sub_Renamed.rsK("Ld2").Value;
			Tdian[3].Text = sub_Renamed.rsK("Ld3").Value;
			Tdian[4].Text = sub_Renamed.rsK("Ld4").Value;
			
			sub_Renamed.rsK.Close();
			sub_Renamed.dbK.Close();
			//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.rsK = null;
			//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.dbK = null;
			
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//    Title = "保存数据"
			//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			msg = Interaction.MsgBox("请你确认更改数据是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
			if (msg == MsgBoxResult.Yes)
			{
				
				for (i = 0; i <= sub_Renamed.Ld4 - 1; i++)
				{
					sub_Renamed.LLQmax[i] = (float) (Conversion.Val(Tqmax[i].Text));
					Tqmax[i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x80000008); //将字体改为黑色
					Tdian[i].Text = "";
				}
				
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst(0).OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh where gg=\'" + Strings.Trim(System.Convert.ToString(shuju[1].Text)) + "\'", null, null, null);
				
				sub_Renamed.rsK.MoveLast(0);
				
				Tdian[0].Text = sub_Renamed.rsK("ld0").Value;
				Tdian[1].Text = sub_Renamed.rsK("Ld1").Value;
				Tdian[2].Text = sub_Renamed.rsK("Ld2").Value;
				Tdian[3].Text = sub_Renamed.rsK("Ld3").Value;
				Tdian[4].Text = sub_Renamed.rsK("Ld4").Value;
				
				sub_Renamed.rsK.Close();
				sub_Renamed.dbK.Close();
				//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
				sub_Renamed.rsK = null;
				//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
				sub_Renamed.dbK = null;
			}
			else if (msg == MsgBoxResult.No)
			{
				
				return;
			}
		}
		
		public void Command6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Option17.Checked == true || Option18.Checked == true)
			{
				Text5.Text = ((double.Parse(Text5.Text)) + 2).ToString();
			}
			else
			{
				Text5.Text = ((double.Parse(Text5.Text)) + 1).ToString();
			}
		}
		
		public void Command7_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Option17.Checked == true || Option18.Checked == true)
			{
				Text5.Text = ((double.Parse(Text5.Text)) - 2).ToString();
			}
			else
			{
				Text5.Text = ((double.Parse(Text5.Text)) - 1).ToString();
			}
		}
		
		public void Command8_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.Biaobianhao = Text5.Text;
			if (sub_Renamed.Biaobianhao.Length != 8)
			{
				MessageBox.Show("起始表号应为八位数，请更正！");
				return;
			}
			if (Option17.Checked == true)
			{
				if ((double.Parse(sub_Renamed.Biaobianhao)) % 2 == 1)
				{
					MessageBox.Show("起始表号末位不是偶数，请更正！");
					return;
				}
			}
			else if (Option18.Checked == true)
			{
				if ((double.Parse(sub_Renamed.Biaobianhao)) % 2 == 0)
				{
					MessageBox.Show("起始表号末位不是奇数，请更正！");
					return;
				}
			}
			
			sub_Renamed.Biaobianhao = Text5.Text;
			Frame13.Visible = false;
			Command1.Enabled = true;
			
			FileSystem.FileClose(3);
			FileSystem.FileOpen(3, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Order.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			if (Option17.Checked == true)
			{
				Shunxu = (short) 1;
			}
			else if (Option18.Checked == true)
			{
				Shunxu = (short) 2;
			}
			else if (Option19.Checked == true)
			{
				Shunxu = (short) 3;
			}
			FileSystem.WriteLine(3, Shunxu);
			FileSystem.FileClose(3);
			
			
			this.Hide();
		}
		
		public void frmcanshushezhi1_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Zhong = false;
			Ying = false;
			this.Height = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(13100));
			this.Width = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(13500));
			Findguige();
			Findsongjian();
			FindXinghao();
			Findzhizao();
			for (i = 1; i <= (sub_Renamed.Meter_Type0.Length - 1); i++)
			{
				Metertype.Items.Add(sub_Renamed.Meter_Type0[i]);
			}
			
			if (sub_Renamed.Chinese == true)
			{
				if (sub_Renamed.Ld4 == 3)
				{
					Combo1[0].Items.Add("一");
					Combo1[0].Items.Add("二");
					Combo1[0].Items.Add("三");
					Combo1[0].Items.Add("无");
					Combo1[1].Items.Add("一");
					Combo1[1].Items.Add("二");
					Combo1[1].Items.Add("三");
					Combo1[1].Items.Add("无");
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
					Combo1[0].Text = "一";
					Combo1[1].Text = "二";
					Combo1[2].Text = "三";
					Combo1[3].Text = "无"; //将不检定点设置为无
					Combo1[4].Text = "无"; //将不检定点设置为无
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					Combo1[0].Items.Add("一");
					Combo1[0].Items.Add("二");
					Combo1[0].Items.Add("三");
					Combo1[0].Items.Add("四");
					Combo1[0].Items.Add("无");
					Combo1[1].Items.Add("一");
					Combo1[1].Items.Add("二");
					Combo1[1].Items.Add("三");
					Combo1[1].Items.Add("四");
					Combo1[1].Items.Add("无");
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
					Combo1[0].Text = "一";
					Combo1[1].Text = "二";
					Combo1[2].Text = "三";
					Combo1[3].Text = "四";
					Combo1[4].Text = "无"; //将不检定点设置为无
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					Combo1[0].Items.Add("一");
					Combo1[0].Items.Add("二");
					Combo1[0].Items.Add("三");
					Combo1[0].Items.Add("四");
					Combo1[0].Items.Add("五");
					Combo1[0].Items.Add("无");
					Combo1[1].Items.Add("一");
					Combo1[1].Items.Add("二");
					Combo1[1].Items.Add("三");
					Combo1[1].Items.Add("四");
					Combo1[1].Items.Add("五");
					Combo1[1].Items.Add("无");
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
					Combo1[4].Items.Add("一");
					Combo1[4].Items.Add("二");
					Combo1[4].Items.Add("三");
					Combo1[4].Items.Add("四");
					Combo1[4].Items.Add("五");
					Combo1[4].Items.Add("无");
					Combo1[0].Text = "一";
					Combo1[1].Text = "二";
					Combo1[2].Text = "三";
					Combo1[3].Text = "四";
					Combo1[4].Text = "五";
				}
				
				for (i = 0; i <= sub_Renamed.Ld4 - 1; i++)
				{
					Tqmax[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2160 + (8880 - 2160) / (sub_Renamed.Ld4 - 1) * i)));
					Tdian[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2160 + (8880 - 2160) / (sub_Renamed.Ld4 - 1) * i)));
					Tliang[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2160 + (8880 - 2160) / (sub_Renamed.Ld4 - 1) * i)));
					Combo1[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2160 + (8880 - 2160) / (sub_Renamed.Ld4 - 1) * i)));
					Valve[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2160 + (8880 - 2160) / (sub_Renamed.Ld4 - 1) * i)));
					Tqmax[i].Visible = true;
					Tdian[i].Visible = true;
					Tliang[i].Visible = true;
					Combo1[i].Visible = true;
					Valve[i].Visible = true;
				}
				
				Frame1[0].Text = "检定参数";
				Frame1[1].Text = "参数设置";
				Frame2.Text = "自动采集";
				Frame7.Text = "总量检定";
				Frame8.Text = "安全系数";
				Frame9.Text = "重复检测时";
				Label2[1].Text = "送检单位";
				Label2[3].Text = "常用流量";
				Label2[5].Text = "规    格";
				Label2[7].Text = "型    号";
				Label2[2].Text = "制造单位";
				Label2[6].Text = "计量等级";
				Label2[8].Text = "检 测 员";
				Label12[0].Text = "检定次序";
				Label12[1].Text = "流 量 点";
				Label12[2].Text = "检 定 量";
				Label12[5].Text = "控 制 阀";
				Label12[3].Text = "流量:";
				Label12[4].Text = "总量:";
				Label5.Text = "是否进行排气:";
				
				
				Option1.Text = "是";
				Option2.Text = "否";
				Option11.Text = "是";
				Option12.Text = "否";
				Option13.Text = "是";
				Option14.Text = "否";
				Option13.Checked = false;
				Option14.Checked = false;
				Command1.Text = "确认";
				Command2.Text = "确认";
				Command3.Text = "保存";
			}
			else
			{
				if (sub_Renamed.Ld4 == 3)
				{
					Combo1[0].Items.Add("ONE");
					Combo1[0].Items.Add("TWO");
					Combo1[0].Items.Add("THREE");
					Combo1[0].Items.Add("NO");
					Combo1[1].Items.Add("ONE");
					Combo1[1].Items.Add("TWO");
					Combo1[1].Items.Add("THREE");
					Combo1[1].Items.Add("NO");
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
					Combo1[0].Text = "ONE";
					Combo1[1].Text = "TWO";
					Combo1[2].Text = "THREE";
					Combo1[3].Text = "NO";
					Combo1[4].Text = "NO";
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					Combo1[0].Items.Add("ONE");
					Combo1[0].Items.Add("TWO");
					Combo1[0].Items.Add("THREE");
					Combo1[0].Items.Add("FOUR");
					Combo1[0].Items.Add("NO");
					Combo1[1].Items.Add("ONE");
					Combo1[1].Items.Add("TWO");
					Combo1[1].Items.Add("THREE");
					Combo1[1].Items.Add("FOUR");
					Combo1[1].Items.Add("NO");
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
					Combo1[0].Text = "ONE";
					Combo1[1].Text = "TWO";
					Combo1[2].Text = "THREE";
					Combo1[3].Text = "FOUR";
					Combo1[4].Text = "NO";
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					Combo1[0].Items.Add("ONE");
					Combo1[0].Items.Add("TWO");
					Combo1[0].Items.Add("THREE");
					Combo1[0].Items.Add("FOUR");
					Combo1[0].Items.Add("FIVE");
					Combo1[0].Items.Add("NO");
					Combo1[1].Items.Add("ONE");
					Combo1[1].Items.Add("TWO");
					Combo1[1].Items.Add("THREE");
					Combo1[1].Items.Add("FOUR");
					Combo1[1].Items.Add("FIVE");
					Combo1[1].Items.Add("NO");
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
					Combo1[4].Items.Add("ONE");
					Combo1[4].Items.Add("TWO");
					Combo1[4].Items.Add("THREE");
					Combo1[4].Items.Add("FOUR");
					Combo1[4].Items.Add("FIVE");
					Combo1[4].Items.Add("NO");
					Combo1[0].Text = "ONE";
					Combo1[1].Text = "TWO";
					Combo1[2].Text = "THREE";
					Combo1[3].Text = "FOUR";
					Combo1[4].Text = "FIVE";
					
				}
				
				Frame1[0].Text = "Informations";
				Frame1[1].Text = "Parameters";
				Frame2.Text = "Auto.reading";
				Frame7.Text = "Plus test";
				Frame8.Text = "Safety factor";
				Frame9.Text = "Duplicate test";
				Label2[1].Text = "Applicant";
				Label2[3].Text = "Qp";
				Label2[5].Text = "Dimension";
				Label2[7].Text = "Type";
				Label2[2].Text = "Producer";
				Label2[6].Text = "Class";
				Label2[8].Text = "Tester";
				Label12[0].Text = "Sequence";
				Label12[1].Text = "Flowrate";
				Label12[2].Text = "Volume";
				Label12[5].Text = "Reg.valve ";
				Label12[3].Text = "Volume:";
				Label12[4].Text = "Energy:";
				Label5.Text = "Exhaust wenn repeat-test:";
				
				Option1.Text = "Yes";
				Option2.Text = "No";
				Option11.Text = "Yes";
				Option12.Text = "No";
				Option13.Text = "Yes";
				Option14.Text = "No";
				Option13.Checked = false;
				Option14.Checked = false;
				Command1.Text = "Ok";
				Command2.Text = "Ok";
				Command3.Text = "Save";
				
			}
			
			
			if (sub_Renamed.MID1 == 0 | sub_Renamed.MID1 == 1) //如果不用标准表采瞬流
			{
				if (sub_Renamed.Ld4 == 3)
				{
					Tqmax[2].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					Tqmax[3].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					Tqmax[4].Enabled = false;
				}
			}
			else if (sub_Renamed.MID1 == 2) //如二个标准表时采瞬流
			{
				if (sub_Renamed.Ld4 == 3)
				{
					//              Tqmax(1).Enabled = False-------'已改为红色表示，下累同
					Tqmax[2].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					//              Tqmax(1).Enabled = False
					Tqmax[3].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					//              Tqmax(1).Enabled = False
					Tqmax[4].Enabled = false;
				}
			}
			else if (sub_Renamed.MID1 == 3) //如果三个标准表采瞬流
			{
				if (sub_Renamed.Ld4 == 3)
				{
					//              Tqmax(0).Enabled = False
					//              Tqmax(1).Enabled = False
					Tqmax[2].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					//              Tqmax(0).Enabled = False
					//              Tqmax(2).Enabled = False
					Tqmax[3].Enabled = false;
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					//              Tqmax(0).Enabled = False
					//              Tqmax(3).Enabled = False
					Tqmax[4].Enabled = false;
				}
			}
			
			
			
			
			
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Metertype.SelectedIndexChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Metertype_SelectedIndexChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			
			//shuju(1) = ""
			switch (Metertype.SelectedIndex)
			{
				case -1:
					Interaction.MsgBox("请选择热能表的类型！", (int) MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "错误");
					Metertype.Focus();
					break;
				case 1: //超声表,光大可检
				case 2:
				case 3:
				case 5:
				case 6:
				case 7:
				case 9:
					Option5.Enabled = false;
					Option6.Enabled = false;
					Option11.Enabled = false;
					Option12.Enabled = false;
					Option12.Checked = true;
					break;
				case 0:
				case 4:
					if (Option1.Checked == false) //如不自动采集
					{
						Option5.Enabled = true;
						Option6.Enabled = true;
					}
					else
					{
						Option11.Enabled = true;
						Option12.Enabled = true;
					}
					break;
				//case 5:
				//case 6:
				//case 9:
				case 10:
					Option8.Checked = true;
					Option9.Checked = true;
					break;
				case 8:
					Option4.Checked = true; //1200波特率
					Option8.Checked = true;
					Option9.Checked = true;
					break;
			}
			
			
			switch (Metertype.SelectedIndex)
			{
				
			case 6: //超声表
			case 9:
				MessageBox.Show("暂不具务此功能，请选择手动检定！");
				Option2.Checked = true;
				break;
			default:
				Option1.Checked = true;
				break;
		}
		
		
	}
	
	//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option1.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
	public void Option1_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
	{
		if (eventSender.checked);
		{
			switch (Metertype.SelectedIndex)
			{
				case 0: //机械表
				case 4:
					Frame4.Enabled = true;
					break;
			}
			Frame3.Enabled = true;
			Frame5.Enabled = true;
			Frame6.Enabled = true;
			Frame7.Enabled = true;
		}
	}}
	
	//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option13.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
	public void Option13_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
	{
		if (eventSender.checked);
		{
			Frame9.Enabled = true;
			Option14.Checked = false;
		}
	}}
	
	//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option14.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
	public void Option14_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
	{
		if (eventSender.checked);
		{
			Frame9.Enabled = true;
			Option13.Checked = false;
		}
	}
	
	//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option2.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
	public void Option2_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
	{
		if (eventSender.checked);
		{
			
			Option5.Checked = true;
			Option8.Checked = true;
			Option9.Checked = true;
			Option12.Checked = true;
			Frame3.Enabled = false;
			Frame4.Enabled = false;
			Frame5.Enabled = false;
			Frame6.Enabled = false;
			Frame7.Enabled = false;
		}
	}}
	
	
	//UPGRADE_WARNING: 初始化窗体时可能激发事件 shuju.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
	//UPGRADE_WARNING: ComboBox 事件 shuju.Change 被升级为具有新行为的 shuju.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"”
	public void shuju_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
	{
		short Index = shuju.GetIndex(eventSender);
		object KeyAscii;
		if (Index == 1)
		{
			//UPGRADE_WARNING: 未能解析对象 KeyAscii 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			KeyAscii = 0;
		}
	}
	
	//UPGRADE_WARNING: 初始化窗体时可能激发事件 shuju.SelectedIndexChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
	public void shuju_SelectedIndexChanged(System.Object eventSender, System.EventArgs eventArgs)
	{
		short Index = shuju.GetIndex(eventSender);
		//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
		if (Index == 1)
		{
			
			sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst[0].OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
			sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from llqmax where gg=\'" + Strings.Trim(System.Convert.ToString(shuju[1].Text)) + "\'", null, null, null);
			sub_Renamed.rsK.MoveLast(0);
			for (i = 0; i <= sub_Renamed.Ld4 - 1; i++)
			{
				Tqmax[i].Text = "";
			}
			shuju[1].Text = sub_Renamed.rsK["gg"].Value;
			Tqmax[0].Text = sub_Renamed.rsK["llq0"].Value;
			Tqmax[1].Text = sub_Renamed.rsK["llq1"].Value;
			Tqmax[2].Text = sub_Renamed.rsK["llq2"].Value;
			Tqmax[3].Text = sub_Renamed.rsK["llq3"].Value;
			Tqmax[4].Text = sub_Renamed.rsK["llq4"].Value;
			
			for (i = 0; i <= sub_Renamed.Ld4 - 1; i++)
			{
				sub_Renamed.LLQmax[i] = (float) (Conversion.Val(Tqmax[i].Text));
			}
			
			sub_Renamed.rsK.Close();
			sub_Renamed.dbK.Close();
			
			//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.rsK = null;
			//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.dbK = null;
			
			sub_Renamed.delay_times((0.1));F;);
			
			
			if (sub_Renamed.Ld4 == 3)
			{
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst[0].OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh where gg=\'" + Strings.Trim(System.Convert.ToString(shuju[1].Text)) + "\'", null, null, null);
				
				sub_Renamed.rsK.MoveLast(0);
				shuju[1].Text = sub_Renamed.rsK["gg"].Value;
				shuju[2].Text = sub_Renamed.rsK["Xh"].Value;
				shuju[5].Text = sub_Renamed.rsK["jcy"].Value;
				shuju[4].Text = sub_Renamed.rsK["yxq"].Value;
				//        shuju(3).Text = rsK!jb
				shuju[7].Text = sub_Renamed.rsK["zz"].Value;
				shuju[8].Text = sub_Renamed.rsK["sj"].Value;
				
				Tdian[0].Text = sub_Renamed.rsK["ld0"].Value;
				Tdian[1].Text = sub_Renamed.rsK["Ld1"].Value;
				Tdian[2].Text = sub_Renamed.rsK["Ld2"].Value;
				
				
				Tliang[0].Text = sub_Renamed.rsK["jl0"].Value;
				Tliang[1].Text = sub_Renamed.rsK["jl1"].Value;
				Tliang[2].Text = sub_Renamed.rsK["jl2"].Value;
				
				//'        Ttiaojie(0).Text = rsK!fm0
				//'        Ttiaojie(1).Text = rsK!fm2
				//'        Ttiaojie(2).Text = rsK!fm3
				
				Combo1[0].Text = sub_Renamed.rsK["sx0"].Value;
				Combo1[1].Text = sub_Renamed.rsK["sx1"].Value;
				Combo1[2].Text = sub_Renamed.rsK["sx2"].Value;
				
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cj = sub_Renamed.rsK["cj"].Value;
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				zl = sub_Renamed.rsK["zl"].Value;
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bt = sub_Renamed.rsK["bt"].Value;
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				gc = sub_Renamed.rsK["gc"].Value;
				//        cf = rsK!cf
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				mc = sub_Renamed.rsK["mc"].Value;
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bh = sub_Renamed.rsK["bh"].Value;
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				tz = sub_Renamed.rsK["tz"].Value;
				Text1.Text = System.Convert.ToString(sub_Renamed.rsK["aqv"].Value);
				Text2.Text = System.Convert.ToString(sub_Renamed.rsK["aqe"].Value);
				
			}
			else if (sub_Renamed.Ld4 == 4)
			{
				//
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst[0].OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh where gg=\'" + Strings.Trim(System.Convert.ToString(shuju[1].Text)) + "\'", null, null, null);
				
				sub_Renamed.rsK.MoveLast(0);
				shuju[1].Text = sub_Renamed.rsK["gg"].Value;
				shuju[2].Text = sub_Renamed.rsK["Xh"].Value;
				shuju[5].Text = sub_Renamed.rsK["jcy"].Value;
				shuju[4].Text = sub_Renamed.rsK["yxq"].Value;
				//        shuju(3).Text = rsK!jb
				shuju[7].Text = sub_Renamed.rsK["zz"].Value;
				shuju[8].Text = sub_Renamed.rsK["sj"].Value;
				
				Tdian[0].Text = sub_Renamed.rsK["ld0"].Value;
				Tdian[1].Text = sub_Renamed.rsK["Ld1"].Value;
				Tdian[2].Text = sub_Renamed.rsK["Ld2"].Value;
				Tdian[3].Text = sub_Renamed.rsK["Ld3"].Value;
				
				Tliang[0].Text = sub_Renamed.rsK["jl0"].Value;
				Tliang[1].Text = sub_Renamed.rsK["jl1"].Value;
				Tliang[2].Text = sub_Renamed.rsK["jl2"].Value;
				Tliang[3].Text = sub_Renamed.rsK["jl3"].Value;
				
				//        Ttiaojie(0).Text = rsK!fm0
				//        Ttiaojie(1).Text = rsK!fm1
				//        Ttiaojie(2).Text = rsK!fm2
				//        Ttiaojie(3).Text = rsK!fm3
				Combo1[0].Text = sub_Renamed.rsK["sx0"].Value;
				Combo1[1].Text = sub_Renamed.rsK["sx1"].Value;
				Combo1[2].Text = sub_Renamed.rsK["sx2"].Value;
				Combo1[3].Text = sub_Renamed.rsK["sx3"].Value;
				
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cj = sub_Renamed.rsK["cj"].Value;
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				zl = sub_Renamed.rsK["zl"].Value;
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bt = sub_Renamed.rsK["bt"].Value;
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				gc = sub_Renamed.rsK["gc"].Value;
				//        cf = rsK!cf
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				mc = sub_Renamed.rsK["mc"].Value;
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bh = sub_Renamed.rsK["bh"].Value;
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				tz = sub_Renamed.rsK["tz"].Value;
				Text1.Text = System.Convert.ToString(sub_Renamed.rsK["aqv"].Value);
				Text2.Text = System.Convert.ToString(sub_Renamed.rsK["aqe"].Value);
				
			}
			else if (sub_Renamed.Ld4 == 5)
			{
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst[0].OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from dzh where gg=\'" + Strings.Trim(System.Convert.ToString(shuju[1].Text)) + "\'", null, null, null);
				
				sub_Renamed.rsK.MoveLast(0);
				shuju[1].Text = sub_Renamed.rsK["gg"].Value;
				shuju[2].Text = sub_Renamed.rsK["Xh"].Value;
				shuju[5].Text = sub_Renamed.rsK["jcy"].Value;
				shuju[4].Text = sub_Renamed.rsK["yxq"].Value;
				//        shuju(3).Text = rsK!jb
				shuju[7].Text = sub_Renamed.rsK["zz"].Value;
				shuju[8].Text = sub_Renamed.rsK["sj"].Value;
				
				Tdian[0].Text = sub_Renamed.rsK["ld0"].Value;
				Tdian[1].Text = sub_Renamed.rsK["Ld1"].Value;
				Tdian[2].Text = sub_Renamed.rsK["Ld2"].Value;
				Tdian[3].Text = sub_Renamed.rsK["Ld3"].Value;
				Tdian[4].Text = sub_Renamed.rsK["Ld4"].Value;
				
				Tliang[0].Text = sub_Renamed.rsK["jl0"].Value;
				Tliang[1].Text = sub_Renamed.rsK["jl1"].Value;
				Tliang[2].Text = sub_Renamed.rsK["jl2"].Value;
				Tliang[3].Text = sub_Renamed.rsK["jl3"].Value;
				Tliang[4].Text = sub_Renamed.rsK["jl4"].Value;
				
				//        Ttiaojie(0).Text = rsK!fm0
				//        Ttiaojie(1).Text = rsK!fm1
				//        Ttiaojie(2).Text = rsK!fm2
				//        Ttiaojie(3).Text = rsK!fm3
				Combo1[0].Text = sub_Renamed.rsK["sx0"].Value;
				Combo1[1].Text = sub_Renamed.rsK["sx1"].Value;
				Combo1[2].Text = sub_Renamed.rsK["sx2"].Value;
				Combo1[3].Text = sub_Renamed.rsK["sx3"].Value;
				Combo1[4].Text = sub_Renamed.rsK["sx4"].Value;
				
				//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cj = sub_Renamed.rsK["cj"].Value;
				//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				zl = sub_Renamed.rsK["zl"].Value;
				//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bt = sub_Renamed.rsK["bt"].Value;
				//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				gc = sub_Renamed.rsK["gc"].Value;
				//        cf = rsK!cf
				//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				mc = sub_Renamed.rsK["mc"].Value;
				//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				bh = sub_Renamed.rsK["bh"].Value;
				//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				tz = sub_Renamed.rsK["tz"].Value;
				Text1.Text = System.Convert.ToString(sub_Renamed.rsK["aqv"].Value);
				Text2.Text = System.Convert.ToString(sub_Renamed.rsK["aqe"].Value);
			}
			
			if (shuju[1].Text == "DN15")
			{
				Text3.Text = (1.5).ToString();
			}
			else if (shuju[1].Text == "DN20")
			{
				Text3.Text = (2.5).ToString();
			}
			else if (shuju[1].Text == "DN25")
			{
				Text3.Text = (3.5).ToString();
			}
			else if (shuju[1].Text == "DN32")
			{
				Text3.Text = "6.0";
			}
			sub_Renamed.rsK.Close();
			sub_Renamed.dbK.Close();
			
			//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.rsK = null;
			//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.dbK = null;
			//UPGRADE_WARNING: 未能解析对象 cj 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) cj == 1)
			{
				Option1.Checked = true;
			}
			else
			{
				Option2.Checked = true;
			}
			//UPGRADE_WARNING: 未能解析对象 zl 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) zl == 1)
			{
				Option11.Checked = true;
			}
			else
			{
				Option12.Checked = true;
			}
			//UPGRADE_WARNING: 未能解析对象 bt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) bt == 1)
			{
				Option4.Checked = true;
			}
			else
			{
				Option3.Checked = true;
			}
			//UPGRADE_WARNING: 未能解析对象 gc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) gc == 1)
			{
				Option15.Checked = true;
			}
			else
			{
				Option16.Checked = true;
			}
			//    If cf = 1 Then
			//      Option13.value = True
			//    Else
			//      Option14.value = True
			//    End If
			//UPGRADE_WARNING: 未能解析对象 mc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) mc == 1)
			{
				Option6.Checked = true;
			}
			else
			{
				Option5.Checked = true;
			}
			//UPGRADE_WARNING: 未能解析对象 tz 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) tz == 1)
			{
				Option7.Checked = true;
			}
			else
			{
				Option8.Checked = true;
			}
			//UPGRADE_WARNING: 未能解析对象 bh 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if ((int) bh == 1)
			{
				Option10.Checked = true;
			}
			else
			{
				Option9.Checked = true;
			}
			
		}
	}
	
	public void Tdian_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
	{
		short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
		short Index = Tdian.GetIndex(eventSender);
		//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
		if (KeyAscii == 13)
		{
			Tdian[Index + 1].Focus();
		}
		eventArgs.KeyChar = Strings.Chr(KeyAscii);
		if (KeyAscii == 0)
		{
			eventArgs.Handled = true;
		}
	}
	//UPGRADE_WARNING: 初始化窗体时可能激发事件 Tdian.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
	public void Tdian_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
	{
		short Index = Tdian.GetIndex(eventSender);
		//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
		
		if (sub_Renamed.Chinese == true)
		{
			if (sub_Renamed.Ld4 == 3)
			{
				if (Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[0])
				{
					Valve[Index].Text = "小";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[0] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[1])
				{
					Valve[Index].Text = "中";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[1] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[2])
				{
					Valve[Index].Text = "大";
				}
			}
			else if (sub_Renamed.Ld4 == 4)
			{
				if (Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[0])
				{
					Valve[Index].Text = "小";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[0] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[1])
				{
					Valve[Index].Text = "中一";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[1] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[2])
				{
					Valve[Index].Text = "中二";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[2] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[3])
				{
					Valve[Index].Text = "大";
				}
			}
			else if (sub_Renamed.Ld4 == 5)
			{
				if (Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[0])
				{
					Valve[Index].Text = "小";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[0] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[1])
				{
					Valve[Index].Text = "中一";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[1] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[2])
				{
					Valve[Index].Text = "中二";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[2] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[3])
				{
					Valve[Index].Text = "中三";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[3] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[4])
				{
					Valve[Index].Text = "大";
				}
			}
		}
		else //English
		{
			if (sub_Renamed.Ld4 == 3)
			{
				if (Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[0])
				{
					Valve[Index].Text = "Small";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[0] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[1])
				{
					Valve[Index].Text = "Middle";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[1] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[2])
				{
					Valve[Index].Text = "Large";
				}
			}
			else if (sub_Renamed.Ld4 == 4)
			{
				if (Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[0])
				{
					Valve[Index].Text = "Small";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[0] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[1])
				{
					Valve[Index].Text = "Middle1";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[1] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[2])
				{
					Valve[Index].Text = "Middle2";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[2] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[3])
				{
					Valve[Index].Text = "Large";
				}
			}
			else if (sub_Renamed.Ld4 == 5)
			{
				if (Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[0])
				{
					Valve[Index].Text = "Small";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[0] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[1])
				{
					Valve[Index].Text = "Middle1";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[1] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[2])
				{
					Valve[Index].Text = "Middle2";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[2] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[3])
				{
					Valve[Index].Text = "Middle3";
				}
				else if (Conversion.Val(Tdian[Index].Text) > sub_Renamed.LLQmax[3] && Conversion.Val(Tdian[Index].Text) <= sub_Renamed.LLQmax[4])
				{
					Valve[Index].Text = "Large";
				}
			}
			
		}
		
	}
	
	
	private void Timer1_Timer()
	{
		
	}
	
	public void Tliang_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
	{
		short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
		short Index = Tliang.GetIndex(eventSender);
		//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
		if (KeyAscii == 13)
		{
			Tliang[Index + 1].Focus();
		}
		eventArgs.KeyChar = Strings.Chr(KeyAscii);
		if (KeyAscii == 0)
		{
			eventArgs.Handled = true;
		}
	}
	private void ZhongXuan5(short Index)
	{
		object Funf;
		object Drei;
		object Eins;
		object Zwei;
		object Vier;
		object Zero = null;
		if (Index == 0)
		{
			if (Combo1[0].Text == "一")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("四");
				Combo1[1].Items.Add("五");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "二")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("四");
				Combo1[1].Items.Add("五");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "三")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("四");
				Combo1[1].Items.Add("五");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "四")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("五");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "五")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("四");
			}
			else if (Combo1[0].Text == "无")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("四");
				Combo1[1].Items.Add("无");
			}
		}
		else if (Index == 1)
		{
			if (Combo1[1].Text == "一")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "五")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
			}
			else if (Combo1[1].Text == "二")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "五")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
			}
			else if (Combo1[1].Text == "三")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "五")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
				}
			}
			else if (Combo1[1].Text == "四")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("五");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "五")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
				}
			}
			else if (Combo1[1].Text == "五")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
				}
				else if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
				}
			}
			else if (Combo1[1].Text == "无")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
			}
			
			
		}
		else if (Index == 2)
		{
			if (Combo1[2].Text == "一")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "二" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
			}
			else if (Combo1[2].Text == "二")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
			}
			else if (Combo1[2].Text == "三")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
			}
			else if (Combo1[2].Text == "四")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("五");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "五")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "五" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
			}
			else if (Combo1[2].Text == "五")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
			}
			else if (Combo1[2].Text == "无")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("无");
				}
			}
		}
		else if (Index == 3)
		{
			//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Eins = 0;
			//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Zwei = 0;
			//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Drei = 0;
			//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Vier = 0;
			//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Funf = 0;
			//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Zero = 0;
			
			for (i = 0; i <= 2; i++)
			{
				if (Combo1[i].Text == "一")
				{
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Eins = 1;
				}
				else if (Combo1[i].Text == "二")
				{
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Zwei = 1;
				}
				else if (Combo1[i].Text == "三")
				{
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Drei = 1;
				}
				else if (Combo1[i].Text == "四")
				{
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Vier = 1;
				}
				else if (Combo1[i].Text == "五")
				{
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Funf = 1;
				}
				else if (Combo1[i].Text == "无")
				{
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Zero = System.Convert.ToInt32(Zero) + 1;
				}
			}
			
			if (Combo1[3].Text == "一")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 3)
				{
					Combo1[4].Items.Add("二");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Zwei == 1)
				{
					Combo1[4].Items.Add("三");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("四");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Drei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("三");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Vier == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("三");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("四");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("五");
					Combo1[4].Items.Add("无");
				}
				
			}
			else if (Combo1[3].Text == "二")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 3)
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Eins == 1)
				{
					Combo1[4].Items.Add("三");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("四");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Drei == 1 & (int) Vier == 1) //
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Vier == 1) //
				{
					Combo1[4].Items.Add("三");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Funf == 1) //
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Vier == 1 & (int) Funf == 1) //
				{
					Combo1[4].Items.Add("三");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("四");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("五");
					Combo1[4].Items.Add("无");
				}
				
			}
			else if (Combo1[3].Text == "三")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 2 & (int) Eins == 1) //001
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Zwei == 1) //002
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Zwei == 1) //012
				{
					Combo1[4].Items.Add("四");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Vier == 1) //024
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Vier == 1) //124
				{
					Combo1[4].Items.Add("五");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Funf == 1) //125
				{
					Combo1[4].Items.Add("四");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Vier == 1 & (int) Funf == 1) //145
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Vier == 1 & (int) Funf == 1) //245
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zero == 1 & (int) Vier == 1) //104
				{
					Combo1[4].Items.Add("二");
				}
				
			}
			else if (Combo1[3].Text == "四")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 1 & (int) Eins == 1 & (int) Zwei == 1) //012
				{
					Combo1[4].Items.Add("三");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Drei == 1) //013
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Drei == 1) //023
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Drei == 1) //123
				{
					Combo1[4].Items.Add("五");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Funf == 1) //125
				{
					Combo1[4].Items.Add("四");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Funf == 1) //135
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Funf == 1) //235
				{
					Combo1[4].Items.Add("一");
				}
			}
			else if (Combo1[3].Text == "五")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Eins == 1 & (int) Zwei == 1 & (int) Drei == 1) //123
				{
					Combo1[4].Items.Add("四");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Vier == 1) //124
				{
					Combo1[4].Items.Add("三");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Vier == 1) //134
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Vier == 1) //234
				{
					Combo1[4].Items.Add("一");
				}
			}
			else if (Combo1[3].Text == "无")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 3) //000
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Eins == 1) //001
				{
					Combo1[4].Items.Add("二");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Zwei == 1) //002
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Zero == 1) //012
				{
					Combo1[4].Items.Add("三");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Drei == 1) //013
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Drei == 1) //023
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Eins == 1) //123
				{
					Combo1[4].Items.Add("四");
					Combo1[4].Items.Add("无");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Vier == 1 & (int) Eins == 1) //124
				{
					Combo1[4].Items.Add("三");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Eins == 1) //134
				{
					Combo1[4].Items.Add("二");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Zwei == 1) //234
				{
					Combo1[4].Items.Add("一");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Funf == 1) //345
				{
					Combo1[4].Items.Add("二");
				}
			} //If Combo1(3).Text = "一" Then
		}
		
	}
	private void YingXuan5(short Index)
	{
		object Funf;
		object Drei;
		object Eins;
		object Zwei;
		object Vier;
		object Zero = null;
		if (Index == 0)
		{
			if (Combo1[0].Text == "ONE")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("FOUR");
				Combo1[1].Items.Add("FIVE");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "TWO")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("FOUR");
				Combo1[1].Items.Add("FIVE");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "THREE")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("FOUR");
				Combo1[1].Items.Add("FIVE");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "FOUR")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("FIVE");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "FIVE")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("FOUR");
			}
			else if (Combo1[0].Text == "NO")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("FOUR");
				Combo1[1].Items.Add("NO");
			}
		}
		else if (Index == 1)
		{
			if (Combo1[1].Text == "ONE")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FIVE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
			}
			else if (Combo1[1].Text == "TWO")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FIVE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
			}
			else if (Combo1[1].Text == "THREE")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FIVE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
				}
			}
			else if (Combo1[1].Text == "FOUR")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FIVE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FIVE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
				}
			}
			else if (Combo1[1].Text == "FIVE")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
				}
			}
			else if (Combo1[1].Text == "NO")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
			}
			
			
		}
		else if (Index == 2)
		{
			if (Combo1[2].Text == "ONE")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "TWO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
			}
			else if (Combo1[2].Text == "TWO")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
			}
			else if (Combo1[2].Text == "THREE")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
			}
			else if (Combo1[2].Text == "FOUR")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FIVE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FIVE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FIVE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
			}
			else if (Combo1[2].Text == "FIVE")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
			}
			else if (Combo1[2].Text == "NO")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("NO");
				}
			}
		}
		else if (Index == 3)
		{
			//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Eins = 0;
			//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Zwei = 0;
			//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Drei = 0;
			//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Vier = 0;
			//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Funf = 0;
			//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Zero = 0;
			
			for (i = 0; i <= 2; i++)
			{
				if (Combo1[i].Text == "ONE")
				{
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Eins = 1;
				}
				else if (Combo1[i].Text == "TWO")
				{
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Zwei = 1;
				}
				else if (Combo1[i].Text == "THREE")
				{
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Drei = 1;
				}
				else if (Combo1[i].Text == "FOUR")
				{
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Vier = 1;
				}
				else if (Combo1[i].Text == "FIVE")
				{
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Funf = 1;
				}
				else if (Combo1[i].Text == "NO")
				{
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Zero = System.Convert.ToInt32(Zero) + 1;
				}
			}
			
			if (Combo1[3].Text == "ONE")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 3)
				{
					Combo1[4].Items.Add("TWO");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Zwei == 1)
				{
					Combo1[4].Items.Add("THREE");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("FOUR");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Drei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("THREE");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Vier == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("THREE");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("FOUR");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("FIVE");
					Combo1[4].Items.Add("NO");
				}
				
			}
			else if (Combo1[3].Text == "TWO")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 3)
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Eins == 1)
				{
					Combo1[4].Items.Add("THREE");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("FOUR");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Drei == 1)
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Drei == 1 & (int) Vier == 1) //
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Vier == 1) //
				{
					Combo1[4].Items.Add("THREE");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Funf == 1) //
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Vier == 1 & (int) Funf == 1) //
				{
					Combo1[4].Items.Add("THREE");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Funf == 1)
				{
					Combo1[4].Items.Add("FOUR");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Vier == 1)
				{
					Combo1[4].Items.Add("FIVE");
					Combo1[4].Items.Add("NO");
				}
				
			}
			else if (Combo1[3].Text == "THREE")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 2 & (int) Eins == 1) //001
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Zwei == 1) //002
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Zwei == 1) //012
				{
					Combo1[4].Items.Add("FOUR");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Vier == 1) //024
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Vier == 1) //124
				{
					Combo1[4].Items.Add("FIVE");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Funf == 1) //125
				{
					Combo1[4].Items.Add("FOUR");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Vier == 1 & (int) Funf == 1) //145
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Vier == 1 & (int) Funf == 1) //245
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zero == 1 & (int) Vier == 1) //104
				{
					Combo1[4].Items.Add("TWO");
				}
				
			}
			else if (Combo1[3].Text == "FOUR")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 1 & (int) Eins == 1 & (int) Zwei == 1) //012
				{
					Combo1[4].Items.Add("THREE");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Drei == 1) //013
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Drei == 1) //023
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Drei == 1) //123
				{
					Combo1[4].Items.Add("FIVE");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Funf == 1) //125
				{
					Combo1[4].Items.Add("FOUR");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Funf == 1) //135
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Funf == 1) //235
				{
					Combo1[4].Items.Add("ONE");
				}
			}
			else if (Combo1[3].Text == "FIVE")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Eins == 1 & (int) Zwei == 1 & (int) Drei == 1) //123
				{
					Combo1[4].Items.Add("FOUR");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Vier == 1) //124
				{
					Combo1[4].Items.Add("THREE");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Drei == 1 & (int) Vier == 1) //134
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Vier == 1) //234
				{
					Combo1[4].Items.Add("ONE");
				}
			}
			else if (Combo1[3].Text == "NO")
			{
				Combo1[4].Items.Clear();
				//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Zero == 3) //000
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Eins == 1) //001
				{
					Combo1[4].Items.Add("TWO");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 2 & (int) Zwei == 1) //002
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Eins == 1 & (int) Zwei == 1 & (int) Zero == 1) //012
				{
					Combo1[4].Items.Add("THREE");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Eins == 1 & (int) Drei == 1) //013
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zero 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zero == 1 & (int) Zwei == 1 & (int) Drei == 1) //023
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Drei == 1 & (int) Eins == 1) //123
				{
					Combo1[4].Items.Add("FOUR");
					Combo1[4].Items.Add("NO");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Zwei == 1 & (int) Vier == 1 & (int) Eins == 1) //124
				{
					Combo1[4].Items.Add("THREE");
					//UPGRADE_WARNING: 未能解析对象 Eins 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Eins == 1) //134
				{
					Combo1[4].Items.Add("TWO");
					//UPGRADE_WARNING: 未能解析对象 Zwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Zwei == 1) //234
				{
					Combo1[4].Items.Add("ONE");
					//UPGRADE_WARNING: 未能解析对象 Funf 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Vier 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 Drei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				}
				else if ((int) Drei == 1 & (int) Vier == 1 & (int) Funf == 1) //345
				{
					Combo1[4].Items.Add("TWO");
				}
			} //If Combo1(3).Text = "ONE" Then
		}
	}
	private void ZhongXuan4(short Index)
	{
		if (Index == 0)
		{
			if (Combo1[0].Text == "一")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("四");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "二")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("四");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "三")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("四");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "四")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
			}
			else if (Combo1[0].Text == "无")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("无");
			}
		}
		else if (Index == 1)
		{
			if (Combo1[1].Text == "一")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
			}
			else if (Combo1[1].Text == "二")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
			}
			else if (Combo1[1].Text == "三")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("四");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "四")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
				}
			}
			else if (Combo1[1].Text == "四")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
				}
				else if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
				}
			}
			else if (Combo1[1].Text == "无")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("无");
				}
			}
			
		}
		else if (Index == 2)
		{
			
			if (Combo1[2].Text == "一")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "二" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("无");
				}
			}
			else if (Combo1[2].Text == "二")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("四");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
				}
			}
			else if (Combo1[2].Text == "三")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("四");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "四")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "四" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
				}
			}
			else if (Combo1[2].Text == "四")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
				}
			}
			else if (Combo1[2].Text == "无")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "一" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("三");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "三")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "二" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
				}
				else if (Combo1[0].Text == "三" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "一")
				{
					Combo1[3].Items.Add("二");
					Combo1[3].Items.Add("无");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "二")
				{
					Combo1[3].Items.Add("一");
				}
				else if (Combo1[0].Text == "无" && Combo1[1].Text == "无")
				{
					Combo1[3].Items.Add("一");
					Combo1[3].Items.Add("无");
				}
			} //
		}
		
	}
	private void ZhongXuan3(short Index)
	{
		if (Index == 0)
		{
			if (Combo1[0].Text == "一")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "二")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "三")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("无");
			}
			else if (Combo1[0].Text == "无")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("一");
				Combo1[1].Items.Add("二");
				Combo1[1].Items.Add("三");
				Combo1[1].Items.Add("无");
			}
		}
		else if (Index == 1)
		{
			if (Combo1[1].Text == "一")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
			}
			else if (Combo1[1].Text == "二")
			{
				Combo1[2].Items.Clear();
				
				if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
			}
			else if (Combo1[1].Text == "三")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("无");
				}
			}
			else if (Combo1[1].Text == "无")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "一")
				{
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "二")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "三")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("无");
				}
				else if (Combo1[0].Text == "无")
				{
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
				}
			}
		}
		
	}
	private void YingXuan4(short Index)
	{
		if (Index == 0)
		{
			if (Combo1[0].Text == "ONE")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("FOUR");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "TWO")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("FOUR");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "THREE")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("FOUR");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "FOUR")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
			}
			else if (Combo1[0].Text == "NO")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("NO");
			}
		}
		else if (Index == 1)
		{
			if (Combo1[1].Text == "ONE")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
			}
			else if (Combo1[1].Text == "TWO")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
			}
			else if (Combo1[1].Text == "THREE")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("FOUR");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "FOUR")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
				}
			}
			else if (Combo1[1].Text == "FOUR")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
				}
			}
			else if (Combo1[1].Text == "NO")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("NO");
				}
			}
			
		}
		else if (Index == 2)
		{
			
			if (Combo1[2].Text == "ONE")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "TWO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("NO");
				}
			}
			else if (Combo1[2].Text == "TWO")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("FOUR");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
				}
			}
			else if (Combo1[2].Text == "THREE")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("FOUR");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "FOUR")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "FOUR" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
				}
			}
			else if (Combo1[2].Text == "FOUR")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
				}
			}
			else if (Combo1[2].Text == "NO")
			{
				Combo1[3].Items.Clear();
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "ONE" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("THREE");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "THREE")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "TWO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
				}
				else if (Combo1[0].Text == "THREE" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "ONE")
				{
					Combo1[3].Items.Add("TWO");
					Combo1[3].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "TWO")
				{
					Combo1[3].Items.Add("ONE");
				}
				else if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO")
				{
					Combo1[3].Items.Add("ONE");
					Combo1[3].Items.Add("NO");
				}
			} //
		}
		
		
	}
	private void YingXuan3(short Index)
	{
		if (Index == 0)
		{
			if (Combo1[0].Text == "ONE")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "TWO")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "THREE")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("NO");
			}
			else if (Combo1[0].Text == "NO")
			{
				Combo1[1].Items.Clear();
				Combo1[1].Items.Add("ONE");
				Combo1[1].Items.Add("TWO");
				Combo1[1].Items.Add("THREE");
				Combo1[1].Items.Add("NO");
			}
		}
		else if (Index == 1)
		{
			if (Combo1[1].Text == "ONE")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
			}
			else if (Combo1[1].Text == "TWO")
			{
				Combo1[2].Items.Clear();
				
				if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
			}
			else if (Combo1[1].Text == "THREE")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("NO");
				}
			}
			else if (Combo1[1].Text == "NO")
			{
				Combo1[2].Items.Clear();
				if (Combo1[0].Text == "ONE")
				{
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "TWO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "THREE")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("NO");
				}
				else if (Combo1[0].Text == "NO")
				{
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
				}
			}
		}
		
	}
}
}
