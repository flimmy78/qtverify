// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmshz : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmshz defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmshz Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmshz();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		ADODB.Recordset Namefind;
		double[] MeterRead = new double[26];
		double[] a0 = new double[2];
		byte[] a1 = new byte[2];
		byte[] MeterRead1 = new byte[26];
		float tstart;
		short i;
		short IIndex;
		bool Zhong;
		bool Ying;
		private void Findguige()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[5].Items.Clear();
			
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Gname from guigek order by Gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[5].Items.Add(Namefind.Fields["Gname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[5].SelectedIndex = 0;
			
		}
		private void FindXinghao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[2].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Xname from xinghaok order by Xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[2].Items.Add(Namefind.Fields["Xname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[2].SelectedIndex = 0;
			
		}
		private void Findsongjian()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[8].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Sname from songjiank order by Sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[8].Items.Add(Namefind.Fields["Sname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[8].SelectedIndex = 0;
			
		}
		private void Findzhizao()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			shuju[7].Items.Clear();
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT DISTINCT Zname from zhizaok order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
				Namefind.MoveFirst();
				while (!Namefind.EOF)
				{
					shuju[7].Items.Add(Namefind.Fields["Zname"].Value);
					Namefind.MoveNext();
				}
			}
			Namefind.Close();
			shuju[7].SelectedIndex = 0;
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Combo1.SelectedIndexChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Combo1_SelectedIndexChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Combo1.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Chinese == true)
			{
				if (Label12[3].Text == "多 点") //多点检测
				{
					
					if (Index == 0)
					{
						if (Combo1[0].Text == "一")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("二");
							Combo1[1].Items.Add("三");
							Combo1[1].Items.Add("无");
						}
						else if (Combo1[0].Text == "二")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("一");
							Combo1[1].Items.Add("三");
							Combo1[1].Items.Add("无");
						}
						else if (Combo1[0].Text == "三")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("一");
							Combo1[1].Items.Add("二");
							Combo1[1].Items.Add("无");
						}
						else if (Combo1[0].Text == "无")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("一");
							Combo1[1].Items.Add("二");
							Combo1[1].Items.Add("三");
							Combo1[1].Items.Add("无");
						}
					}
					else if (Index == 1)
					{
						if (Combo1[1].Text == "一")
						{
							Combo1[2].Items.Clear();
							if (Combo1[0].Text == "二")
							{
								Combo1[2].Items.Add("三");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "三")
							{
								Combo1[2].Items.Add("二");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "无")
							{
								Combo1[2].Items.Add("二");
								Combo1[2].Items.Add("三");
								Combo1[2].Items.Add("无");
							}
						}
						else if (Combo1[1].Text == "二")
						{
							Combo1[2].Items.Clear();
							
							if (Combo1[0].Text == "一")
							{
								Combo1[2].Items.Add("三");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "三")
							{
								Combo1[2].Items.Add("一");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "无")
							{
								Combo1[2].Items.Add("一");
								Combo1[2].Items.Add("三");
								Combo1[2].Items.Add("无");
							}
						}
						else if (Combo1[1].Text == "三")
						{
							Combo1[2].Items.Clear();
							if (Combo1[0].Text == "二")
							{
								Combo1[2].Items.Add("一");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "一")
							{
								Combo1[2].Items.Add("二");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "无")
							{
								Combo1[2].Items.Add("一");
								Combo1[2].Items.Add("二");
								Combo1[2].Items.Add("无");
							}
						}
						else if (Combo1[1].Text == "无")
						{
							Combo1[2].Items.Clear();
							if (Combo1[0].Text == "一")
							{
								Combo1[2].Items.Add("二");
								Combo1[2].Items.Add("三");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "二")
							{
								Combo1[2].Items.Add("一");
								Combo1[2].Items.Add("三");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "三")
							{
								Combo1[2].Items.Add("一");
								Combo1[2].Items.Add("二");
								Combo1[2].Items.Add("无");
							}
							else if (Combo1[0].Text == "无")
							{
								Combo1[2].Items.Add("一");
								Combo1[2].Items.Add("二");
								Combo1[2].Items.Add("三");
								Combo1[2].Items.Add("无");
							}
						}
					} //ElseIf Index = 1 Then
				}
				else //单点检测
				{
					
					if (Index == 0)
					{
						Combo1[1].Items.Clear();
						Combo1[1].Items.Add("一");
						Combo1[1].Items.Add("无");
						if (Combo1[0].Text == "一")
						{
							Combo1[1].Text = "无";
							Combo1[2].Text = "无";
						}
					}
					else if (Index == 1)
					{
						Combo1[2].Items.Clear();
						Combo1[2].Items.Add("一");
						Combo1[2].Items.Add("无");
						if (Combo1[1].Text == "一")
						{
							Combo1[0].Text = "无";
							Combo1[2].Text = "无";
						}
					}
					else if (Index == 2)
					{
						if (Combo1[2].Text == "一")
						{
							Combo1[0].Text = "无";
							Combo1[1].Text = "无";
						}
					}
					
				} //多点结束
			}
			else //英文
			{
				if (Label12[3].Text == "Multipoint") //多点检测
				{
					if (Index == 0)
					{
						if (Combo1[0].Text == "ONE")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("TWO");
							Combo1[1].Items.Add("THREE");
							Combo1[1].Items.Add("NO");
						}
						else if (Combo1[0].Text == "TWO")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("ONE");
							Combo1[1].Items.Add("THREE");
							Combo1[1].Items.Add("NO");
						}
						else if (Combo1[0].Text == "THREE")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("ONE");
							Combo1[1].Items.Add("TWO");
							Combo1[1].Items.Add("NO");
						}
						else if (Combo1[0].Text == "NO")
						{
							Combo1[1].Items.Clear();
							Combo1[1].Items.Add("ONE");
							Combo1[1].Items.Add("TWO");
							Combo1[1].Items.Add("THREE");
							Combo1[1].Items.Add("NO");
						}
					}
					else if (Index == 1)
					{
						if (Combo1[1].Text == "ONE")
						{
							Combo1[2].Items.Clear();
							if (Combo1[0].Text == "TWO")
							{
								Combo1[2].Items.Add("THREE");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "THREE")
							{
								Combo1[2].Items.Add("TWO");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "NO")
							{
								Combo1[2].Items.Add("TWO");
								Combo1[2].Items.Add("THREE");
								Combo1[2].Items.Add("NO");
							}
						}
						else if (Combo1[1].Text == "TWO")
						{
							Combo1[2].Items.Clear();
							
							if (Combo1[0].Text == "ONE")
							{
								Combo1[2].Items.Add("THREE");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "THREE")
							{
								Combo1[2].Items.Add("ONE");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "NO")
							{
								Combo1[2].Items.Add("ONE");
								Combo1[2].Items.Add("THREE");
								Combo1[2].Items.Add("NO");
							}
						}
						else if (Combo1[1].Text == "THREE")
						{
							Combo1[2].Items.Clear();
							if (Combo1[0].Text == "TWO")
							{
								Combo1[2].Items.Add("ONE");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "ONE")
							{
								Combo1[2].Items.Add("TWO");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "NO")
							{
								Combo1[2].Items.Add("ONE");
								Combo1[2].Items.Add("TWO");
								Combo1[2].Items.Add("NO");
							}
						}
						else if (Combo1[1].Text == "NO")
						{
							Combo1[2].Items.Clear();
							if (Combo1[0].Text == "ONE")
							{
								Combo1[2].Items.Add("TWO");
								Combo1[2].Items.Add("THREE");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "TWO")
							{
								Combo1[2].Items.Add("ONE");
								Combo1[2].Items.Add("THREE");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "THREE")
							{
								Combo1[2].Items.Add("ONE");
								Combo1[2].Items.Add("TWO");
								Combo1[2].Items.Add("NO");
							}
							else if (Combo1[0].Text == "NO")
							{
								Combo1[2].Items.Add("ONE");
								Combo1[2].Items.Add("TWO");
								Combo1[2].Items.Add("THREE");
								Combo1[2].Items.Add("NO");
							}
						}
					} //ElseIf Index = 1 Then
				}
				else //单点
				{
					if (Index == 0)
					{
						Combo1[1].Items.Clear();
						Combo1[1].Items.Add("ONE");
						Combo1[1].Items.Add("NO");
						if (Combo1[0].Text == "ONE")
						{
							Combo1[1].Text = "NO";
							Combo1[2].Text = "NO";
						}
					}
					else if (Index == 1)
					{
						Combo1[2].Items.Clear();
						Combo1[2].Items.Add("ONE");
						Combo1[2].Items.Add("NO");
						if (Combo1[1].Text == "ONE")
						{
							Combo1[0].Text = "NO";
							Combo1[2].Text = "NO";
						}
					}
					else if (Index == 2)
					{
						if (Combo1[2].Text == "ONE")
						{
							Combo1[0].Text = "NO";
							Combo1[1].Text = "NO";
						}
					}
					
				} //单点结束
			} //中文结束
			
		}
		private void Zhongwen()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (Conversion.Val(shuju[4].Text) != 1 && Conversion.Val(shuju[4].Text) != 2 && Conversion.Val(shuju[4].Text) != 3)
			{
				MessageBox.Show("计量等级超出范围，请重新输入！");
				return;
			}
			
			if (Combo1[0].Text == "一")
			{
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
			}
			else if (Combo1[1].Text == "一")
			{
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
			}
			else if (Combo1[2].Text == "一")
			{
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
			}
			if (Combo1[0].Text == "二")
			{
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[0].Text));
			}
			else if (Combo1[1].Text == "二")
			{
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[1].Text));
			}
			else if (Combo1[2].Text == "二")
			{
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[2].Text));
			}
			
			if (Combo1[0].Text == "三")
			{
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[2] = (float) (Conversion.Val(Twc[0].Text));
			}
			else if (Combo1[1].Text == "三")
			{
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[2] = (float) (Conversion.Val(Twc[1].Text));
			}
			else if (Combo1[2].Text == "三")
			{
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[2] = (float) (Conversion.Val(Twc[2].Text));
			}
			
			if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[2].Text == "无")
			{
				sub_Renamed.Jd_point = (short) 0;
				
				
			}
			if (Combo1[0].Text == "无" && Combo1[1].Text == "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
			}
			if (Combo1[0].Text == "无" && Combo1[2].Text == "无" && Combo1[1].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
			}
			if (Combo1[1].Text == "无" && Combo1[2].Text == "无" && Combo1[0].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 1;
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
			}
			if (Combo1[0].Text == "无" && Combo1[1].Text != "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				if (Combo1[1].Text == "一" && Combo1[2].Text == "二")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[2].Text));
				}
				if (Combo1[1].Text == "二" && Combo1[2].Text == "一")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[1].Text));
				}
			}
			if (Combo1[1].Text == "无" && Combo1[0].Text != "无" && Combo1[2].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				if (Combo1[0].Text == "一" && Combo1[2].Text == "二")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[2].Text));
				}
				if (Combo1[0].Text == "二" && Combo1[2].Text == "一")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[0].Text));
				}
			}
			if (Combo1[2].Text == "无" && Combo1[1].Text != "无" && Combo1[0].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 2;
				if (Combo1[0].Text == "一" && Combo1[1].Text == "二")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[1].Text));
				}
				if (Combo1[0].Text == "二" && Combo1[1].Text == "一")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[0].Text));
				}
			}
			if (Combo1[2].Text != "无" && Combo1[1].Text != "无" && Combo1[0].Text != "无")
			{
				sub_Renamed.Jd_point = (short) 3;
			}
			
			
			Zhong = true;
		}
		private void Yingwen()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (Conversion.Val(shuju[4].Text) != 1 && Conversion.Val(shuju[4].Text) != 2 && Conversion.Val(shuju[4].Text) != 3)
			{
				MessageBox.Show("The class is out of range,  Please reenter! ");
				return;
			}
			
			if (Combo1[0].Text == "ONE")
			{
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
			}
			else if (Combo1[1].Text == "ONE")
			{
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
			}
			else if (Combo1[2].Text == "ONE")
			{
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
			}
			if (Combo1[0].Text == "TWO")
			{
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[0].Text));
			}
			else if (Combo1[1].Text == "TWO")
			{
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[1].Text));
			}
			else if (Combo1[2].Text == "TWO")
			{
				sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[2].Text));
			}
			
			if (Combo1[0].Text == "THREE")
			{
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[2] = (float) (Conversion.Val(Twc[0].Text));
			}
			else if (Combo1[1].Text == "THREE")
			{
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[2] = (float) (Conversion.Val(Twc[1].Text));
			}
			else if (Combo1[2].Text == "THREE")
			{
				sub_Renamed.Jd_liang[2] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[2] = (float) (Conversion.Val(Twc[2].Text));
			}
			
			if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[2].Text == "NO")
			{
				sub_Renamed.Jd_point = (short) 0;
				
				
			}
			if (Combo1[0].Text == "NO" && Combo1[1].Text == "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
			}
			if (Combo1[0].Text == "NO" && Combo1[2].Text == "NO" && Combo1[1].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
			}
			if (Combo1[1].Text == "NO" && Combo1[2].Text == "NO" && Combo1[0].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 1;
				sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
				sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
			}
			if (Combo1[0].Text == "NO" && Combo1[1].Text != "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				if (Combo1[1].Text == "ONE" && Combo1[2].Text == "TWO")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[2].Text));
				}
				if (Combo1[1].Text == "TWO" && Combo1[2].Text == "ONE")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[1].Text));
				}
			}
			if (Combo1[1].Text == "NO" && Combo1[0].Text != "NO" && Combo1[2].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				if (Combo1[0].Text == "ONE" && Combo1[2].Text == "TWO")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[2].Text));
				}
				if (Combo1[0].Text == "TWO" && Combo1[2].Text == "ONE")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[2].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[2].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[0].Text));
				}
			}
			if (Combo1[2].Text == "NO" && Combo1[1].Text != "NO" && Combo1[0].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 2;
				if (Combo1[0].Text == "ONE" && Combo1[1].Text == "TWO")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[0].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[1].Text));
				}
				if (Combo1[0].Text == "TWO" && Combo1[1].Text == "ONE")
				{
					sub_Renamed.Jd_liang[0] = (float) (Conversion.Val(Tliang[1].Text));
					sub_Renamed.Jd_liang[1] = (float) (Conversion.Val(Tliang[0].Text));
					sub_Renamed.Jd_wc[0] = (float) (Conversion.Val(Twc[1].Text));
					sub_Renamed.Jd_wc[1] = (float) (Conversion.Val(Twc[0].Text));
				}
			}
			if (Combo1[2].Text != "NO" && Combo1[1].Text != "NO" && Combo1[0].Text != "NO")
			{
				sub_Renamed.Jd_point = (short) 3;
			}
			
			
			
			Ying = true;
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short j;
			short k;
			short h;
			if (shuju[1].Text == "")
			{
				MessageBox.Show("请首先选择表的规格！");
				return;
			}
			
			if (Option1.Checked == true)
			{
				if (Metertype.Text == "")
				{
					MessageBox.Show("采集代码不能为空，请选择！");
					return;
				}
			}
			if (sub_Renamed.Chinese == true)
			{
				Zhongwen();
			}
			else //如果是英语
			{
				Yingwen();
			} //中英文
			if (sub_Renamed.Chinese == true)
			{
				if (Zhong == false)
				{
					return;
				}
			}
			else
			{
				if (Ying == false)
				{
					return;
				}
			}
			sub_Renamed.XingHao = Strings.Trim(System.Convert.ToString(shuju[2].Text));
			sub_Renamed.GuiGe = Strings.Trim(System.Convert.ToString(shuju[1].Text));
			sub_Renamed.YouXiaoQi = Strings.Trim(System.Convert.ToString(shuju[4].Text));
			sub_Renamed.JianCeYuan = Strings.Trim(System.Convert.ToString(shuju[5].Text));
			sub_Renamed.ZhizaoDanwei = Strings.Trim(System.Convert.ToString(shuju[7].Text));
			sub_Renamed.SongjianDanwei = Strings.Trim(System.Convert.ToString(shuju[8].Text));
			
			if (Option1.Checked == true && sub_Renamed.MID2 == 1) //自动采集且带标准表法
			{
				if (sub_Renamed.Stueck15 == 12)
				{
					sub_Renamed.Stueck15 = (short) 11;
				}
				if (sub_Renamed.Stueck20 == 12)
				{
					sub_Renamed.Stueck20 = (short) 11;
				}
				if (sub_Renamed.Stueck25 == 12)
				{
					sub_Renamed.Stueck25 = (short) 11;
				}
				if (sub_Renamed.Stueck32 == 12)
				{
					sub_Renamed.Stueck32 = (short) 11;
				}
			}
			
			switch (Strings.Trim(System.Convert.ToString(shuju[1].Text)))
			{
				case "DN15":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck15 - 1);
					break;
				case "DN20":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck20 - 1);
					break;
				case "DN25":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck25 - 1);
					break;
				case "DN32":
					sub_Renamed.Stueck = (short) (sub_Renamed.Stueck32 - 1);
					break;
			}
			Mdlguanfa.Qp = (float) (Conversion.Val(Text3.Text));
			
			//    SicherQ = Val(Text1.Text)
			//    SicherE = Val(Text2.Text)
			//shuju(1).Enabled = False
			//shuju(2).Enabled = False
			//shuju(4).Enabled = False
			//shuju(5).Enabled = False
			//shuju(7).Enabled = False
			//shuju(8).Enabled = False
			
			for (i = 0; i <= 11; i++)
			{
				frmjsqbdz.Default.Frame2[i].Enabled = false;
				frmjsqbdz.Default.Frame2[i].Visible = false;
			}
			
			for (i = 0; i <= sub_Renamed.Stueck; i++)
			{
				frmjsqbdz.Default.Frame2[i].Visible = true;
				frmjsqbdz.Default.Frame2[i].Enabled = true;
				frmjsqbdz.Default.Frame2[i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(600 + 25080 / sub_Renamed.Stueck * i)));
			}
			
			
			
			//
			
			//被检表串口
			short[] meter = new short[21];
			if (sub_Renamed.Flagcom == false) //如果第一次进参数设置
			{
				if (Option1.Checked == true)
				{
					
					for (i = 1; i <= 12; i++)
					{
						meter[i] = (short) 0;
					}
					
					
					if (Metertype.SelectedIndex == 8) //光大表时
					{
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[0].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[0].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[0].InputLen = 0;
						frmjsqbdz.Default.MSComm6[0].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[0].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[0].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[0].CommPort = sub_Renamed.Com5;
						if (frmjsqbdz.Default.MSComm6[0].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[0].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[0].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[0].PortOpen == true)
						{
							meter[1] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[1].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[1].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[1].InputLen = 0;
						frmjsqbdz.Default.MSComm6[1].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[1].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[1].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[1].CommPort = sub_Renamed.Com6;
						if (frmjsqbdz.Default.MSComm6[1].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[1].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[1].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[1].PortOpen == true)
						{
							meter[2] = (short) 1;
						}
						
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[2].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[2].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[2].InputLen = 0;
						frmjsqbdz.Default.MSComm6[2].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[2].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[2].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[2].CommPort = sub_Renamed.Com7;
						if (frmjsqbdz.Default.MSComm6[2].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[2].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[2].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[2].PortOpen == true)
						{
							meter[3] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[3].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[3].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[3].InputLen = 0;
						frmjsqbdz.Default.MSComm6[3].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[3].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[3].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[3].CommPort = sub_Renamed.Com8;
						if (frmjsqbdz.Default.MSComm6[3].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[3].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[3].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[3].PortOpen == true)
						{
							meter[4] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[4].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[4].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[4].InputLen = 0;
						frmjsqbdz.Default.MSComm6[4].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[4].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[4].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[4].CommPort = sub_Renamed.Com9;
						if (frmjsqbdz.Default.MSComm6[4].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[4].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[4].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[4].PortOpen == true)
						{
							meter[5] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[5].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[5].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[5].InputLen = 0;
						frmjsqbdz.Default.MSComm6[5].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[5].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[5].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[5].CommPort = sub_Renamed.Com10;
						if (frmjsqbdz.Default.MSComm6[5].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[5].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[5].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[5].PortOpen == true)
						{
							meter[6] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[6].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[6].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[6].InputLen = 0;
						frmjsqbdz.Default.MSComm6[6].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[6].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[6].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[6].CommPort = sub_Renamed.Com11;
						if (frmjsqbdz.Default.MSComm6[6].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[6].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[6].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[6].PortOpen == true)
						{
							meter[7] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[7].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[7].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[7].InputLen = 0;
						frmjsqbdz.Default.MSComm6[7].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[7].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[7].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[7].CommPort = sub_Renamed.Com12;
						if (frmjsqbdz.Default.MSComm6[7].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[7].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[7].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[7].PortOpen == true)
						{
							meter[8] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[8].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[8].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[8].InputLen = 0;
						frmjsqbdz.Default.MSComm6[8].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[8].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[8].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[8].CommPort = sub_Renamed.Com13;
						if (frmjsqbdz.Default.MSComm6[8].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[8].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[8].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[8].PortOpen == true)
						{
							meter[9] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[9].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[9].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[9].InputLen = 0;
						frmjsqbdz.Default.MSComm6[9].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[9].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[9].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[9].CommPort = sub_Renamed.Com14;
						if (frmjsqbdz.Default.MSComm6[9].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[9].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[9].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[9].PortOpen == true)
						{
							meter[10] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[10].Settings = "2400,N,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[10].Settings = "1200,N,8,1";
						}
						frmjsqbdz.Default.MSComm6[10].InputLen = 0;
						frmjsqbdz.Default.MSComm6[10].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[10].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[10].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[10].CommPort = sub_Renamed.Com15;
						if (frmjsqbdz.Default.MSComm6[10].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[10].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[10].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[10].PortOpen == true)
						{
							meter[11] = (short) 1;
						}
						
						if (sub_Renamed.MID2 == 0) //无标准表法时空出此串口
						{
							if (Option3.Checked == true)
							{
								frmjsqbdz.Default.MSComm6[11].Settings = "2400,N,8,1";
							}
							else
							{
								frmjsqbdz.Default.MSComm6[11].Settings = "1200,N,8,1";
							}
							frmjsqbdz.Default.MSComm6[11].InputLen = 0;
							frmjsqbdz.Default.MSComm6[11].RTSEnable = true;
							Frmjsqbdz.MSComm6(11).RThreshold = 1;
							frmjsqbdz.Default.MSComm6[11].InputMode = ;InputMode;
							frmjsqbdz.Default.MSComm6[11].CommPort = sub_Renamed.Com16;
							if (frmjsqbdz.Default.MSComm6[11].PortOpen == true)
							{
								frmjsqbdz.Default.MSComm6[11].PortOpen = false;
							}
							frmjsqbdz.Default.MSComm6[11].PortOpen = true;
							if (frmjsqbdz.Default.MSComm6[11].PortOpen == true)
							{
								meter[12] = (short) 1;
							}
						}
					}
					else
					{
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[0].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[0].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[0].InputLen = 0;
						frmjsqbdz.Default.MSComm6[0].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[0].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[0].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[0].CommPort = sub_Renamed.Com5;
						if (frmjsqbdz.Default.MSComm6[0].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[0].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[0].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[0].PortOpen == true)
						{
							meter[1] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[1].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[1].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[1].InputLen = 0;
						frmjsqbdz.Default.MSComm6[1].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[1].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[1].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[1].CommPort = sub_Renamed.Com6;
						if (frmjsqbdz.Default.MSComm6[1].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[1].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[1].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[1].PortOpen == true)
						{
							meter[2] = (short) 1;
						}
						
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[2].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[2].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[2].InputLen = 0;
						frmjsqbdz.Default.MSComm6[2].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[2].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[2].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[2].CommPort = sub_Renamed.Com7;
						if (frmjsqbdz.Default.MSComm6[2].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[2].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[2].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[2].PortOpen == true)
						{
							meter[3] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[3].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[3].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[3].InputLen = 0;
						frmjsqbdz.Default.MSComm6[3].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[3].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[3].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[3].CommPort = sub_Renamed.Com8;
						if (frmjsqbdz.Default.MSComm6[3].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[3].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[3].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[3].PortOpen == true)
						{
							meter[4] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[4].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[4].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[4].InputLen = 0;
						frmjsqbdz.Default.MSComm6[4].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[4].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[4].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[4].CommPort = sub_Renamed.Com9;
						if (frmjsqbdz.Default.MSComm6[4].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[4].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[4].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[4].PortOpen == true)
						{
							meter[5] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[5].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[5].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[5].InputLen = 0;
						frmjsqbdz.Default.MSComm6[5].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[5].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[5].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[5].CommPort = sub_Renamed.Com10;
						if (frmjsqbdz.Default.MSComm6[5].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[5].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[5].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[5].PortOpen == true)
						{
							meter[6] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[6].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[6].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[6].InputLen = 0;
						frmjsqbdz.Default.MSComm6[6].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[6].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[6].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[6].CommPort = sub_Renamed.Com11;
						if (frmjsqbdz.Default.MSComm6[6].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[6].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[6].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[6].PortOpen == true)
						{
							meter[7] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[7].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[7].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[7].InputLen = 0;
						frmjsqbdz.Default.MSComm6[7].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[7].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[7].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[7].CommPort = sub_Renamed.Com12;
						if (frmjsqbdz.Default.MSComm6[7].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[7].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[7].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[7].PortOpen == true)
						{
							meter[8] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[8].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[8].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[8].InputLen = 0;
						frmjsqbdz.Default.MSComm6[8].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[8].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[8].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[8].CommPort = sub_Renamed.Com13;
						if (frmjsqbdz.Default.MSComm6[8].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[8].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[8].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[8].PortOpen == true)
						{
							meter[9] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[9].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[9].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[9].InputLen = 0;
						frmjsqbdz.Default.MSComm6[9].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[9].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[9].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[9].CommPort = sub_Renamed.Com14;
						if (frmjsqbdz.Default.MSComm6[9].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[9].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[9].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[9].PortOpen == true)
						{
							meter[10] = (short) 1;
						}
						
						if (Option3.Checked == true)
						{
							frmjsqbdz.Default.MSComm6[10].Settings = "2400,E,8,1";
						}
						else
						{
							frmjsqbdz.Default.MSComm6[10].Settings = "1200,E,8,1";
						}
						frmjsqbdz.Default.MSComm6[10].InputLen = 0;
						frmjsqbdz.Default.MSComm6[10].RTSEnable = true;
						frmjsqbdz.Default.MSComm6[10].RThreshold = 1;
						frmjsqbdz.Default.MSComm6[10].InputMode = ;InputMode;
						frmjsqbdz.Default.MSComm6[10].CommPort = sub_Renamed.Com15;
						if (frmjsqbdz.Default.MSComm6[10].PortOpen == true)
						{
							frmjsqbdz.Default.MSComm6[10].PortOpen = false;
						}
						frmjsqbdz.Default.MSComm6[10].PortOpen = true;
						if (frmjsqbdz.Default.MSComm6[10].PortOpen == true)
						{
							meter[11] = (short) 1;
						}
						
						if (sub_Renamed.MID2 == 0) //无标准表法时空出此串口
						{
							if (Option3.Checked == true)
							{
								frmjsqbdz.Default.MSComm6[11].Settings = "2400,E,8,1";
							}
							else
							{
								frmjsqbdz.Default.MSComm6[11].Settings = "1200,E,8,1";
							}
							frmjsqbdz.Default.MSComm6[11].InputLen = 0;
							frmjsqbdz.Default.MSComm6[11].RTSEnable = true;
							frmjsqbdz.Default.MSComm6[11].RThreshold = 1;
							frmjsqbdz.Default.MSComm6[11].InputMode = ;InputMode;
							frmjsqbdz.Default.MSComm6[11].CommPort = sub_Renamed.Com16;
							if (frmjsqbdz.Default.MSComm6[11].PortOpen == true)
							{
								frmjsqbdz.Default.MSComm6[11].PortOpen = false;
							}
							frmjsqbdz.Default.MSComm6[11].PortOpen = true;
							if (frmjsqbdz.Default.MSComm6[11].PortOpen == true)
							{
								meter[12] = (short) 1;
							}
						}
						
					} //If Metertype.ListIndex = 8  Then
					for (i = 1; i <= 12; i++)
					{
						if (meter[i] == 0)
						{
							frmjsqbdz.Default.Text19[i].Visible = true;
							if (sub_Renamed.Chinese == true)
							{
								frmjsqbdz.Default.Text19[i].Text = "通讯口不正常!";
							}
							else
							{
								frmjsqbdz.Default.Text19[i].Text = "Comport false!";
							}
						}
					}
					sub_Renamed.Comopen = true;
					//frmjsqbdz.Command8.Visible = False
				} //自动采集结束
				sub_Renamed.Flagcom = true;
			} //第一次进入参数结束
			
			if (Option1.Checked == true)
			{
				
				frmjsqbdz.Default.读表号一.Enabled = true;
				frmjsqbdz.Default.读表号二.Enabled = true;
				frmjsqbdz.Default.读表号三.Enabled = true;
				frmjsqbdz.Default.读表号四.Enabled = true;
				frmjsqbdz.Default.读表号五.Enabled = true;
				frmjsqbdz.Default.读表号六.Enabled = true;
				frmjsqbdz.Default.读表号七.Enabled = true;
				frmjsqbdz.Default.读表号八.Enabled = true;
				frmjsqbdz.Default.读表号九.Enabled = true;
				frmjsqbdz.Default.读表号十.Enabled = true;
				frmjsqbdz.Default.读表号十一.Enabled = true;
				frmjsqbdz.Default.读表号十二.Enabled = true;
				
				switch (Metertype.SelectedIndex)
				{
					case 1:
					case 2:
					case 5:
					case 7:
						frmjsqbdz.Default.状态一.Enabled = true;
						frmjsqbdz.Default.状态二.Enabled = true;
						frmjsqbdz.Default.状态三.Enabled = true;
						frmjsqbdz.Default.状态四.Enabled = true;
						frmjsqbdz.Default.状态五.Enabled = true;
						frmjsqbdz.Default.状态六.Enabled = true;
						frmjsqbdz.Default.状态七.Enabled = true;
						frmjsqbdz.Default.状态八.Enabled = true;
						frmjsqbdz.Default.状态九.Enabled = true;
						frmjsqbdz.Default.状态十.Enabled = true;
						frmjsqbdz.Default.状态十一.Enabled = true;
						frmjsqbdz.Default.状态十二.Enabled = true;
						break;
				}
				
				
			}
			else //不是自动采集时
			{
				
				
				for (i = 0; i <= 23; i++)
				{
					frmjsqbdz.Default.Text10[i].Visible = false;
				}
				
				
				
			} //自动采集结束
			
			
			
			//
			
			//If Option14.value = True Then frmjsqbdz.Text13.Visible = False
			
			frmjsqbdz.Default.Metertype.SelectedIndex = Metertype.SelectedIndex;
			frmjsqbdz.Default.kaishi.Enabled = true;
			
			this.Hide();
		}
		
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Hide();
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT gname from guigek where gname=\'" + Strings.Trim(System.Convert.ToString(shuju[5].Text)) + " \' order by gname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["gname"].Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT Zname from zhizaok where Zname=\'" + Strings.Trim(System.Convert.ToString(shuju[7].Text)) + " \' order by Zname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["Zname"].Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT sname from songjiank where sname=\'" + Strings.Trim(System.Convert.ToString(shuju[8].Text)) + " \' order by sname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["sname"].Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			Namefind = new ADODB.Recordset();
			sub_Renamed.sqlStr = "SELECT xname from xinghaok where xname=\'" + Strings.Trim(System.Convert.ToString(shuju[2].Text)) + " \' order by xname";
			Namefind.Open(sub_Renamed.sqlStr, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
			if (Namefind.RecordCount != 0)
			{
			}
			else
			{
				//        Namefind.MoveLast
				Namefind.AddNew(null, null);
				Namefind.Fields["xname"].Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
				Namefind.Update(null, null);
			}
			Namefind.Close();
			
			//Close #8
			//Open App.Path + "\Qua_xishu.dll" For Output As #8
			//SicherQ = Val(Text1.Text)
			//SicherE = Val(Text2.Text)
			//Write #8, SicherQ
			//Write #8, SicherE
			//Close #8
			
			
			sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst(0).OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
			sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from jsqbdz ", null, null, null);
			sub_Renamed.rsK.AddNew();
			sub_Renamed.rsK("gg").Value = Strings.Trim(System.Convert.ToString(shuju[1].Text));
			sub_Renamed.rsK("Xh").Value = Strings.Trim(System.Convert.ToString(shuju[2].Text));
			sub_Renamed.rsK("jcy").Value = Strings.Trim(System.Convert.ToString(shuju[5].Text));
			sub_Renamed.rsK("yxq").Value = Strings.Trim(System.Convert.ToString(shuju[4].Text));
			//rsK!jb = Trim(shuju(3).Text)
			sub_Renamed.rsK("zz").Value = Strings.Trim(System.Convert.ToString(shuju[7].Text));
			sub_Renamed.rsK("sj").Value = Strings.Trim(System.Convert.ToString(shuju[8].Text));
			
			sub_Renamed.rsK("ld0").Value = Strings.Trim(System.Convert.ToString(Twc[0].Text));
			sub_Renamed.rsK("Ld1").Value = Strings.Trim(System.Convert.ToString(Twc[1].Text));
			sub_Renamed.rsK("Ld2").Value = Strings.Trim(System.Convert.ToString(Twc[2].Text));
			
			sub_Renamed.rsK("jl0").Value = Strings.Trim(System.Convert.ToString(Tliang[0].Text));
			sub_Renamed.rsK("jl1").Value = Strings.Trim(System.Convert.ToString(Tliang[1].Text));
			sub_Renamed.rsK("jl2").Value = Strings.Trim(System.Convert.ToString(Tliang[2].Text));
			
			sub_Renamed.rsK.Update(1, 0);
			sub_Renamed.rsK.Close();
			sub_Renamed.dbK.Close();
			
			//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.rsK = null;
			//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.dbK = null;
			//Me.Hide
		}
		
		
		
		public void frmshz_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Option14 = null;
			object Option13 = null;
			object Option12 = null;
			object Option11 = null;
			object Label6 = null;
			object Frame9 = null;
			object Frame8 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Findguige();
			Findsongjian();
			FindXinghao();
			Findzhizao();
			for (i = 1; i <= (sub_Renamed.Meter_Type0.Length - 1); i++)
			{
				Metertype.Items.Add(sub_Renamed.Meter_Type0[i]);
			}
			
			
			if (sub_Renamed.Chinese == true)
			{
				
				Combo1[0].Items.Add("一");
				//       Combo1(0).AddItem "二"
				//       Combo1(0).AddItem "三"
				Combo1[0].Items.Add("无");
				Combo1[1].Items.Add("一");
				//       Combo1(1).AddItem "二"
				//       Combo1(1).AddItem "三"
				Combo1[1].Items.Add("无");
				Combo1[2].Items.Add("一");
				//       Combo1(2).AddItem "二"
				//       Combo1(2).AddItem "三"
				Combo1[2].Items.Add("无");
				Combo1[0].Text = "一";
				Combo1[1].Text = "无";
				Combo1[2].Text = "无";
				
				Frame1[0].Text = "检定参数";
				Frame1[1].Text = "参数设置";
				Frame2.Text = "自动采集";
				//UPGRADE_WARNING: 未能解析对象 Frame8.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Frame8.Caption = "安全系数";
				//UPGRADE_WARNING: 未能解析对象 Frame9.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				frame9.Caption = "重复检测时";
				Label2[1].Text = "送检单位";
				Label2[3].Text = "常用流量";
				Label2[5].Text = "规    格";
				Label2[7].Text = "型    号";
				Label2[2].Text = "制造单位";
				Label2[6].Text = "计量等级";
				Label2[8].Text = "检 测 员";
				Label12[0].Text = "温 差 点";
				Label12[1].Text = "流 量 点";
				Label12[2].Text = "检 定 量";
				Label12[3].Text = "单 点";
				Image1.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1680));
				Label12[6].Text = "控 制 阀";
				//Label12(3).Caption = "流量:"
				//Label12(4).Caption = "总量:"
				//UPGRADE_WARNING: 未能解析对象 Label6.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Label6.Caption = "是否进行排气:";
				
				
				Option1.Text = "是";
				Option2.Text = "否";
				//UPGRADE_WARNING: 未能解析对象 Option11.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Option11.Caption = "是";
				//UPGRADE_WARNING: 未能解析对象 Option12.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				option12.Caption = "否";
				//UPGRADE_WARNING: 未能解析对象 Option13.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				option13.Caption = "是";
				//UPGRADE_WARNING: 未能解析对象 Option14.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				option14.Caption = "否";
				//UPGRADE_WARNING: 未能解析对象 Option13.value 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				option13.value = false;
				//UPGRADE_WARNING: 未能解析对象 Option14.value 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				option14.value = false;
				Command1.Text = "确认";
				Command2.Text = "确认";
				Command3.Text = "保存";
			}
			else
			{
				
				Combo1[0].Items.Add("ONE");
				//       Combo1(0).AddItem "TWO"
				//       Combo1(0).AddItem "THREE"
				Combo1[0].Items.Add("NO");
				Combo1[1].Items.Add("ONE");
				//       Combo1(1).AddItem "TWO"
				//       Combo1(1).AddItem "THREE"
				Combo1[1].Items.Add("NO");
				Combo1[2].Items.Add("ONE");
				//       Combo1(2).AddItem "TWO"
				//       Combo1(2).AddItem "THREE"
				Combo1[2].Items.Add("NO");
				Combo1[0].Text = "ONE";
				Combo1[1].Text = "NO";
				Combo1[2].Text = "NO";
				Frame1[0].Text = "Informations";
				Frame1[1].Text = "Parameters";
				Frame2.Text = "Auto.reading";
				//UPGRADE_WARNING: 未能解析对象 Frame8.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				frame8.Caption = "Safety factor";
				//UPGRADE_WARNING: 未能解析对象 Frame9.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				frame9.Caption = "Duplicate test";
				Label2[1].Text = "Applicant";
				Label2[3].Text = "Qp";
				Label2[5].Text = "Dimension";
				Label2[7].Text = "Type";
				Label2[2].Text = "Producer";
				Label2[6].Text = "Class";
				Label2[8].Text = "Tester";
				Label12[0].Text = "Δθ";
				Label12[1].Text = "Flowrate";
				Label12[2].Text = "Volume";
				Label12[6].Text = "Reg.valve ";
				Label12[3].Text = "One point";
				Image1.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(2520));
				//Label12(4).Caption = "Energy:"
				//UPGRADE_WARNING: 未能解析对象 Label6.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				label6.Caption = "Exhaust wenn repeat-test:";
				
				Option1.Text = "Yes";
				Option2.Text = "No";
				//UPGRADE_WARNING: 未能解析对象 Option11.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				option11.Caption = "Yes";
				//UPGRADE_WARNING: 未能解析对象 Option12.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Option12.Caption = "No";
				//UPGRADE_WARNING: 未能解析对象 Option13.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Option13.Caption = "Yes";
				//UPGRADE_WARNING: 未能解析对象 Option14.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Option14.Caption = "No";
				
				Command1.Text = "Ok";
				Command2.Text = "Ok";
				Command3.Text = "Save";
				
			}
			
			
			
			Option1.Checked = true; //自动采集是
			Option3.Checked = true; //2400
			Image1.Enabled = true;
			
			//Close #8
			//Open App.Path + "\Qua_xishu.dll" For Input As #8
			//Input #8, SicherQ
			//Input #8, SicherE
			//Close #8
			
			//Text1.Text = Format(SicherQ, "0.00")
			//Text2.Text = Format(SicherE, "0.00")
			
			
			
			
			
		}
		
		public void Image1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (sub_Renamed.Chinese == true)
			{
				if (Label12[3].Text == "单 点")
				{
					Label12[3].Text = "多 点";
					Combo1[0].Items.Clear();
					Combo1[1].Items.Clear();
					Combo1[2].Items.Clear();
					Combo1[0].Items.Add("一");
					Combo1[0].Items.Add("二");
					Combo1[0].Items.Add("三");
					Combo1[0].Items.Add("无");
					Combo1[1].Items.Add("一");
					Combo1[1].Items.Add("二");
					Combo1[1].Items.Add("三");
					Combo1[1].Items.Add("无");
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("二");
					Combo1[2].Items.Add("三");
					Combo1[2].Items.Add("无");
					Combo1[0].Text = "一";
					Combo1[1].Text = "二";
					Combo1[2].Text = "三";
				}
				else if (Label12[3].Text == "多 点")
				{
					Label12[3].Text = "单 点";
					Combo1[0].Items.Clear();
					Combo1[1].Items.Clear();
					Combo1[2].Items.Clear();
					Combo1[0].Items.Add("一");
					Combo1[0].Items.Add("无");
					Combo1[1].Items.Add("一");
					Combo1[1].Items.Add("无");
					Combo1[2].Items.Add("一");
					Combo1[2].Items.Add("无");
					
					
					
					Combo1[0].Text = "一";
					Combo1[1].Text = "无";
					Combo1[2].Text = "无";
				}
			}
			else //English
			{
				if (Label12[3].Text == "One point")
				{
					Label12[3].Text = "Multipoint";
					
					Combo1[0].Items.Clear();
					Combo1[1].Items.Clear();
					Combo1[2].Items.Clear();
					Combo1[0].Items.Add("ONE");
					Combo1[0].Items.Add("TWO");
					Combo1[0].Items.Add("THREE");
					Combo1[0].Items.Add("NO");
					Combo1[1].Items.Add("ONE");
					Combo1[1].Items.Add("TWO");
					Combo1[1].Items.Add("THREE");
					Combo1[1].Items.Add("NO");
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("TWO");
					Combo1[2].Items.Add("THREE");
					Combo1[2].Items.Add("NO");
					Combo1[0].Text = "ONE";
					Combo1[1].Text = "TWO";
					Combo1[2].Text = "THREE";
				}
				else if (Label12[3].Text == "Multipoint")
				{
					Label12[3].Text = "One point";
					Combo1[0].Items.Clear();
					Combo1[1].Items.Clear();
					Combo1[2].Items.Clear();
					Combo1[0].Items.Add("ONE");
					Combo1[0].Items.Add("NO");
					Combo1[1].Items.Add("ONE");
					Combo1[1].Items.Add("NO");
					Combo1[2].Items.Add("ONE");
					Combo1[2].Items.Add("NO");
					
					
					
					Combo1[0].Text = "ONE";
					Combo1[1].Text = "NO";
					Combo1[2].Text = "NO";
				}
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Metertype.SelectedIndexChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Metertype_SelectedIndexChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			//shuju(1) = ""
			switch (Metertype.SelectedIndex)
			{
				case -1:
					Interaction.MsgBox("请选择热能表的类型！", (int) MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "错误");
					Metertype.Focus();
					break;
					
					
				case 6: //迈拓，HY
				case 9:
					MessageBox.Show("暂不具务此功能，请选择手动检定！");
					Option2.Checked = true;
					break;
				case 8:
					Option4.Checked = true;
					break;
				default:
					Option1.Checked = true;
					break;
					
			}
			
			
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option1.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option1_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				//Select Case Metertype.ListIndex
				//Case 0, 4 '机械表
				// Option11.Enabled = True
				// Option12.Enabled = True
				//End Select
				
				
				//Option5.Enabled = False
				//Option6.Enabled = False
				//
				// Option9.Enabled = True
				// Option10.value = True
				// Option10.Enabled = True
			}
		}}
		
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option2.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option2_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				//Select Case Metertype.ListIndex
				//Case 0, 4  '德鲁机械表
				//Option5.Enabled = True
				//Option6.Enabled = True
				//End Select
				//Option9.value = True
				//Option9.Enabled = False
				//Option10.Enabled = False
				//Option11.Enabled = False
				//Option12.value = True
				//'Option9.value = True
				//Option12.Enabled = False
			}
		}}
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 shuju.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		//UPGRADE_WARNING: ComboBox 事件 shuju.Change 被升级为具有新行为的 shuju.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"”
		public void shuju_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = shuju.GetIndex(eventSender);
			object KeyAscii;
			if (Index == 1)
			{
				//UPGRADE_WARNING: 未能解析对象 KeyAscii 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				KeyAscii = 0;
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 shuju.SelectedIndexChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void shuju_SelectedIndexChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = shuju.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Index == 1)
			{
				
				
				sub_Renamed.dbK = UpgradeSupport.DAODBEngine_definst[0].OpenDatabase((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\base.mdb", false, false, null);
				sub_Renamed.rsK = sub_Renamed.dbK.OpenRecordset("select * from jsqbdz where gg=\'" + Strings.Trim(System.Convert.ToString(shuju[1].Text)) + "\'", null, null, null);
				
				sub_Renamed.rsK.MoveLast(0);
				shuju[1].Text = sub_Renamed.rsK["gg"].Value;
				shuju[2].Text = sub_Renamed.rsK["Xh"].Value;
				shuju[5].Text = sub_Renamed.rsK["jcy"].Value;
				shuju[4].Text = sub_Renamed.rsK["yxq"].Value;
				//        shuju(3).Text = rsK!jb
				shuju[7].Text = sub_Renamed.rsK["zz"].Value;
				shuju[8].Text = sub_Renamed.rsK["sj"].Value;
				
				Twc[0].Text = sub_Renamed.rsK["ld0"].Value;
				Twc[1].Text = sub_Renamed.rsK["Ld1"].Value;
				Twc[2].Text = sub_Renamed.rsK["Ld2"].Value;
				
				
				Tliang[0].Text = sub_Renamed.rsK["jl0"].Value;
				Tliang[1].Text = sub_Renamed.rsK["jl1"].Value;
				Tliang[2].Text = sub_Renamed.rsK["jl2"].Value;
				
				//'        Ttiaojie(0).Text = rsK!fm0
				//'        Ttiaojie(1).Text = rsK!fm2
				//'        Ttiaojie(2).Text = rsK!fm3
				
				if (shuju[1].Text == "DN15")
				{
					Text3.Text = (1.5).ToString();
				}
				else if (shuju[1].Text == "DN20")
				{
					Text3.Text = (2.5).ToString();
				}
				else if (shuju[1].Text == "DN25")
				{
					Text3.Text = (3.5).ToString();
				}
				else if (shuju[1].Text == "DN32")
				{
					Text3.Text = "6.0";
				}
				sub_Renamed.rsK.Close();
				sub_Renamed.dbK.Close();
				
				//UPGRADE_NOTE: 在对对象 rsK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
				sub_Renamed.rsK = null;
				//UPGRADE_NOTE: 在对对象 dbK 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
				sub_Renamed.dbK = null;
			}
		}
		
		
		
		public void Tliang_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Tliang.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Tliang[Index + 1].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
	}
}
