// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;

namespace 热量表
{
	partial class frmjsqbdzcx : System.Windows.Forms.Form
	{
		
		private string strTable;
		ADODB.Recordset Namefind;
		ADODB.Recordset Findph;
		ADODB.Recordset Rsout;
		ADODB.Recordset Findrs;
		string datSD;
		string datFD;
		private int lngRecords;
		ADODB.Recordset rstDecSupt = new ADODB.Recordset();
		short Introw;
		//Private Sub Findhuhao()
		//On Error Resume Next
		//Combo1.Clear
		//Set NameFind = New ADODB.Recordset
		//   sqlstr = "SELECT DISTINCT huhao from dhuhao where huhao like '%" & Trim(Text2.Text) & "%' order by huhao"
		//   NameFind.Open sqlstr, DB, adOpenStatic, adLockOptimistic
		//   If NameFind.RecordCount <> 0 Then
		//            NameFind.MoveFirst
		//            Do Until NameFind.EOF
		//                  Combo1.AddItem NameFind.Fields("huhao")
		//                  NameFind.MoveNext
		//             Loop
		//   End If
		//   NameFind.Close
		//   Combo1.ListIndex = 0
		//
		//End Sub
		//Private Sub Hnamefind()
		//'Dim Sqlstr As String
		//On Error Resume Next
		//Comfind(0).Clear
		//Set NameFind = New ADODB.Recordset
		//'   sqlstr = "SELECT DISTINCT iname from win "
		//   sqlstr = "SELECT DISTINCT iname from win where iname like '%" & Trim(Text1.Text) & "%' order by iname"
		//   NameFind.Open sqlstr, DB, adOpenStatic, adLockOptimistic
		//   If NameFind.RecordCount <> 0 Then
		//            NameFind.MoveFirst
		//            Do Until NameFind.EOF
		//
		//                  Comfind(0).AddItem NameFind.Fields("iname")
		//                  NameFind.MoveNext
		//             Loop
		//   End If
		//   NameFind.Close
		//   Comfind(0).ListIndex = 0
		//End Sub
		private void DataSFD()
		{
			datSD = "#" + System.Convert.ToString(DTPicker1.Month) + "/" + System.Convert.ToString(DTPicker1.Day) + "/" + System.Convert.ToString(DTPicker1.Year) + "#";
			datFD = "#" + System.Convert.ToString(DTPicker2.Month) + "/" + System.Convert.ToString(DTPicker2.Day) + "/" + System.Convert.ToString(DTPicker2.Year) + "#";
			
		}
		//
		//Private Sub Combo1_Change()
		//Text2.Text = Combo1.Text
		//
		//End Sub
		//
		//Private Sub Combo1_KeyPress(KeyAscii As Integer)
		//If KeyAscii = 13 Then
		//   Findhuhao
		//End If
		//
		//
		//End Sub
		
		//Private Sub Comfind_Change(Index As Integer)
		// If Index = 0 Then
		//   Text1.Text = Comfind(0).Text
		//   Combo1.Text = ""
		//
		//  End If
		//
		//End Sub
		
		//Private Sub Comfind_KeyPress(Index As Integer, KeyAscii As Integer)
		//If Index = 0 Then
		//   If KeyAscii = 13 Then
		//   Hnamefind
		//   End If
		//End If
		//
		//End Sub
		
		
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next
			
			
			DataSFD();
			//II III
			strTable = "tbldzcx";
			if (Combo1.Text.Length == 0)
			{
				sub_Renamed.sqlStr = "SELECT jsqbdz.biaohao1 AS 表号,jsqbdz.jinkou1 AS 进口温度," + "jsqbdz.chukou1 AS 出口温度,jsqbdz.moni1 AS 模拟流量," + "jsqbdz.e01 as e0," + "jsqbdz.e11 as e1," + "jsqbdz.wucha1 as 误差," + "jsqbdz.guige1 as 表规格," + "jsqbdz.jiancerq1 as 检测日期 " + "INTO tbldzcx " + "FROM jsqbdz " + "WHERE jsqbdz.jiancerq1 BETWEEN " + datSD + " and " + datFD + " ";
				
			}
			else
			{
				sub_Renamed.sqlStr = "SELECT jsqbdz.biaohao1 AS 表号,jsqbdz.jinkou1 AS 进口温度," + "jsqbdz.chukou1 AS 出口温度,jsqbdz.moni1 AS 模拟流量," + "jsqbdz.e01 as e0," + "jsqbdz.e11 as e1," + "jsqbdz.wucha1 as 误差," + "jsqbdz.guige1 as 表规格," + "jsqbdz.jiancerq1 as 检测日期 " + "INTO tbldzcx " + "FROM jsqbdz " + "WHERE jsqbdz.biaohao1=\'" + Combo1.Text.Trim() + "\'" + "AND jsqbdz.jiancerq1 BETWEEN " + datSD + " and " + datFD + " ";
				
			}
			
			
			this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			sub_Renamed.db.Close();
			sub_Renamed.db.Open(sub_Renamed.DEFSOURCE, "", "", -1);
			
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object null_object = null;
			sub_Renamed.db.Execute("DROP TABLE " + strTable, out null_object, (System.Int32) ADODB.CommandTypeEnum.adCmdText);
			
			// On Error GoTo 0 VBConversions Note: Statement had no effect.
			
			sub_Renamed.db.Execute(sub_Renamed.sqlStr, out lngRecords, (System.Int32) ADODB.CommandTypeEnum.adCmdText);
			
			
			if (rstDecSupt.State == (int) ADODB.ObjectStateEnum.adStateOpen)
			{
				rstDecSupt.Close();
			}
			rstDecSupt.ActiveConnection = sub_Renamed.db;
			rstDecSupt.CursorType = ADODB.CursorTypeEnum.adOpenStatic;
			rstDecSupt.let_Source(strTable);
			//         .MaxRecords = 25
			rstDecSupt.Open(null, null, (ADODB.CursorTypeEnum) (-1), (ADODB.LockTypeEnum) (-1), -1);
			hfgRollups.Recordset = () );rstDecSupt;
			//UPGRADE_NOTE: Refresh 已升级到 CtlRefresh。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"”
			hfgRollups.ctlRefresh();
			hfgRollups.Col = hfgRollups.get_Cols() - 1;
			for (Introw = 0; Introw <= hfgRollups.Rows - 1; Introw++)
			{
				hfgRollups.Row = Introw;
			}
			hfgRollups.Row = 0;
			this.Cursor = System.Windows.Forms.Cursors.Default;
			
			
		}
		
		private void MakeTables()
		{
			
			
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
			
		}
		
		
		public void frmjsqbdzcx_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			DTPicker1.Year = DateAndTime.Year(DateAndTime.Today);
			DTPicker1.Month = DateAndTime.Month(DateAndTime.Today);
			DTPicker1.Day = VB.DateAndTime.Day(DateAndTime.Today);
			DTPicker2.Year = DateAndTime.Year(DateAndTime.Today);
			DTPicker2.Month = DateAndTime.Month(DateAndTime.Today);
			DTPicker2.Day = VB.DateAndTime.Day(DateAndTime.Today);
			this.Height = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(7100));
			this.Width = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(11115));
			
			//    Hnamefind
			
		}
	}
}
