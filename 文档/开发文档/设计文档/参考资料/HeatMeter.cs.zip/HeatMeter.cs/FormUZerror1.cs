// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class FormUZerror : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static FormUZerror defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static FormUZerror Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new FormUZerror();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object s;
			object data;
			object s0;
			string s1;
			object s2;
			string s3;
			object i;
			short n;
			
			//    data = "6820AAAAAAAAAAAAAA360CA0190600"
			//
			//    For i = 0 To 3
			//
			//        n = InStr(1 / (1 + Text1(i).Text / 100), ".")
			//        Select Case n
			//        Case 0
			//            s0 = Right("00" & Hex(1 / (1 + Text1(i).Text / 100)), 3)
			//            s1 = "00"
			//        Case 1
			//            s0 = "0"
			//            s1 = Right("00" & Hex(Int(Mid(1 / (1 + Val(Text1(i).Text) / 100), n, 4) * 256 * 16)), 3)
			//            s2 = Mid(s1, 2)
			//            s3 = left(s1, 1)
			//        Case Is > 1
			//            s0 = Right("00" & Hex(Mid(1 / (1 + Val(Text1(i).Text) / 100), 1, n)), 1)
			//            s1 = Right("00" & Hex(Int(Mid(1 / (1 + Val(Text1(i).Text) / 100), n, 4) * 256 * 16)), 3)
			//            s2 = Mid(s1, 2)
			//            s3 = left(s1, 1)
			//        End Select
			//
			//        data = data & s2 & s0 & s3
			//    Next i
			//
			//    SendData (data)
			//    MSComm1.InputLen = 0
			//    iTimeOut = 1200
			
			
			
			
			
			
			
			
		}
		
		public void FormUZerror_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			for ( = ;0; i <= sub_Renamed.End_biaowei); i++;);
			{
				if (sub_Renamed.Firstmal == sub_Renamed.i + 1)
				{
					this.Text = "第" + "" + System.Convert.ToString(sub_Renamed.i + 1) + "" + "号表误差";
					this.Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(this.Font, 12);
					Text1[0].Text = Text1(sub_Renamed.Llfaktor[1, sub_Renamed.i], "0.0");
					Text1[1].Text = Text1(sub_Renamed.Llfaktor[2, sub_Renamed.i], "0.0");
					Text1[2].Text = Text1(sub_Renamed.Llfaktor[3, sub_Renamed.i], "0.0");
					Text1[3].Text = Text1(sub_Renamed.Llfaktor[4, sub_Renamed.i], "0.0");
					
					Text1[4].Text = Text1(sub_Renamed.Edfaktor[1, sub_Renamed.i], "0.000");
					Text1[5].Text = Text1(sub_Renamed.Edfaktor[2, sub_Renamed.i], "0.000");
					Text1[6].Text = Text1(sub_Renamed.Edfaktor[3, sub_Renamed.i], "0.000");
					Text1[7].Text = Text1(sub_Renamed.Edfaktor[4, sub_Renamed.i], "0.000");
				}
			}
		}
	}
}
