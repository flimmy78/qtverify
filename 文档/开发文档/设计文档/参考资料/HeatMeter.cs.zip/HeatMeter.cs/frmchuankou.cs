// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmchuankou : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmchuankou defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmchuankou Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmchuankou();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		
		public void combo1_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//KeyAscii = 0
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Combo2_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//KeyAscii = 0
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Combo3_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//KeyAscii = 0
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Combo4_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//KeyAscii = 0
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("请您确认输入项是否正确，并保存？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
				if (msg == MsgBoxResult.Yes)
				{
					if (Combo1.Text == "" || Combo2.Text == "" || Combo3.Text == "" || Combo4.Text == "")
					{
						Interaction.MsgBox("数据不能为空值！请重新输入", MsgBoxStyle.Information, "提示");
						return;
					}
					sub_Renamed.Com1 = (short) (Conversion.Val(Combo1.Text));
					sub_Renamed.Com2 = (short) (Conversion.Val(Combo2.Text));
					sub_Renamed.Com3 = (short) (Conversion.Val(Combo3.Text));
					sub_Renamed.Com4 = (short) (Conversion.Val(Combo4.Text));
					sub_Renamed.Com5 = (short) (Conversion.Val(Combo5.Text));
					sub_Renamed.Com6 = (short) (Conversion.Val(Combo6.Text));
					sub_Renamed.Com7 = (short) (Conversion.Val(Combo7.Text));
					sub_Renamed.Com8 = (short) (Conversion.Val(Combo8.Text));
					sub_Renamed.Com9 = (short) (Conversion.Val(Combo9.Text));
					sub_Renamed.Com10 = (short) (Conversion.Val(Combo10.Text));
					sub_Renamed.Com11 = (short) (Conversion.Val(Combo11.Text));
					sub_Renamed.Com12 = (short) (Conversion.Val(Combo12.Text));
					sub_Renamed.Com13 = (short) (Conversion.Val(Combo13.Text));
					sub_Renamed.Com14 = (short) (Conversion.Val(Combo14.Text));
					sub_Renamed.Com15 = (short) (Conversion.Val(Combo15.Text));
					sub_Renamed.Com16 = (short) (Conversion.Val(Combo16.Text));
					
					FileSystem.FileClose(13);
					
					FileSystem.FileOpen(13, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\COM_canshu.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
					FileSystem.WriteLine(13, sub_Renamed.Com1);
					FileSystem.WriteLine(13, sub_Renamed.Com2);
					FileSystem.WriteLine(13, sub_Renamed.Com3);
					FileSystem.WriteLine(13, sub_Renamed.Com4);
					FileSystem.WriteLine(13, sub_Renamed.Com5);
					FileSystem.WriteLine(13, sub_Renamed.Com6);
					FileSystem.WriteLine(13, sub_Renamed.Com7);
					FileSystem.WriteLine(13, sub_Renamed.Com8);
					FileSystem.WriteLine(13, sub_Renamed.Com9);
					FileSystem.WriteLine(13, sub_Renamed.Com10);
					FileSystem.WriteLine(13, sub_Renamed.Com11);
					FileSystem.WriteLine(13, sub_Renamed.Com12);
					FileSystem.WriteLine(13, sub_Renamed.Com13);
					FileSystem.WriteLine(13, sub_Renamed.Com14);
					FileSystem.WriteLine(13, sub_Renamed.Com15);
					FileSystem.WriteLine(13, sub_Renamed.Com16);
					
					FileSystem.FileClose(13);
					comm.Default.MSComm1.CommPort = sub_Renamed.Com1;
					//MSComm2.CommPort = Com2
					//'comm.MSComm3.CommPort = Com3
					//comm.MSComm4.CommPort = Com4
					//
					//MSComm2.InputLen = 400
					//'MSComm2.RThreshold = 15
					//comm.MSComm3.InputLen = 400
					this.Close();
				}
				else if (msg == MsgBoxResult.No)
				{
					this.Close();
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("Please confirm the saved data are correct？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "Note");
				if (msg == MsgBoxResult.Yes)
				{
					
					if (Combo1.Text == "" || Combo2.Text == "" || Combo3.Text == "" || Combo4.Text == "")
					{
						Interaction.MsgBox("数据不能为空值！请重新输入", MsgBoxStyle.Information, "提示");
						return;
					}
					sub_Renamed.Com1 = (short) (Conversion.Val(Combo1.Text));
					sub_Renamed.Com2 = (short) (Conversion.Val(Combo2.Text));
					sub_Renamed.Com3 = (short) (Conversion.Val(Combo3.Text));
					sub_Renamed.Com4 = (short) (Conversion.Val(Combo4.Text));
					sub_Renamed.Com5 = (short) (Conversion.Val(Combo5.Text));
					sub_Renamed.Com6 = (short) (Conversion.Val(Combo6.Text));
					sub_Renamed.Com7 = (short) (Conversion.Val(Combo7.Text));
					sub_Renamed.Com8 = (short) (Conversion.Val(Combo8.Text));
					sub_Renamed.Com9 = (short) (Conversion.Val(Combo9.Text));
					sub_Renamed.Com10 = (short) (Conversion.Val(Combo10.Text));
					sub_Renamed.Com11 = (short) (Conversion.Val(Combo11.Text));
					sub_Renamed.Com12 = (short) (Conversion.Val(Combo12.Text));
					sub_Renamed.Com13 = (short) (Conversion.Val(Combo13.Text));
					sub_Renamed.Com14 = (short) (Conversion.Val(Combo14.Text));
					sub_Renamed.Com15 = (short) (Conversion.Val(Combo15.Text));
					sub_Renamed.Com16 = (short) (Conversion.Val(Combo16.Text));
					
					FileSystem.FileClose(13);
					
					FileSystem.FileOpen(13, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\COM_canshu.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
					FileSystem.WriteLine(13, sub_Renamed.Com1);
					FileSystem.WriteLine(13, sub_Renamed.Com2);
					FileSystem.WriteLine(13, sub_Renamed.Com3);
					FileSystem.WriteLine(13, sub_Renamed.Com4);
					FileSystem.WriteLine(13, sub_Renamed.Com5);
					FileSystem.WriteLine(13, sub_Renamed.Com6);
					FileSystem.WriteLine(13, sub_Renamed.Com7);
					FileSystem.WriteLine(13, sub_Renamed.Com8);
					FileSystem.WriteLine(13, sub_Renamed.Com9);
					FileSystem.WriteLine(13, sub_Renamed.Com10);
					FileSystem.WriteLine(13, sub_Renamed.Com11);
					FileSystem.WriteLine(13, sub_Renamed.Com12);
					FileSystem.WriteLine(13, sub_Renamed.Com13);
					FileSystem.WriteLine(13, sub_Renamed.Com14);
					FileSystem.WriteLine(13, sub_Renamed.Com15);
					FileSystem.WriteLine(13, sub_Renamed.Com16);
					
					FileSystem.FileClose(13);
					comm.Default.MSComm1.CommPort = sub_Renamed.Com1;
					//MSComm2.CommPort = Com2
					//'comm.MSComm3.CommPort = Com3
					//comm.MSComm4.CommPort = Com4
					//
					//MSComm2.InputLen = 400
					//'MSComm2.RThreshold = 15
					//comm.MSComm3.InputLen = 400
					this.Close();
				}
				else if (msg == MsgBoxResult.No)
				{
					this.Close();
				}
				
			}
			
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		public void frmchuankou_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Chinese == true)
			{
				this.Text = "串口选择";
				Label1.Text = "阀门控制";
				Label2[0].Text = "天平采集";
				Label2[1].Text = "温度采集";
				Label2[6].Text = "标准温度";
				Label6.Text = "被检表一";
				Label2[3].Text = "被检表二";
				Label2[2].Text = "被检表三";
				Label3[0].Text = "被检表四";
				Label5.Text = "被检表五";
				Label2[5].Text = "被检表六";
				Label2[4].Text = "被检表七";
				Label3[1].Text = "被检表八";
				Label8.Text = "被检表九";
				Label2[8].Text = "被检表十";
				Label2[9].Text = "被检表11";
				if (sub_Renamed.MID2 == 0)
				{
					Label3[4].Text = "被检表12";
				}
				else
				{
					Label3[4].Text = "标 准 表";
				}
				Command1.Text = "确认";
				Command2.Text = "退出";
			}
			else
			{
				this.Text = "Serial ports ";
				Label1.Text = "Valves";
				Label2[0].Text = "Balance";
				Label2[1].Text = "Temp.";
				Label2[6].Text = "Standard thermometer";
				Label6.Text = "Meter 1";
				Label2[3].Text = "Meter 2";
				Label2[2].Text = "Meter 3";
				Label3[0].Text = "Meter 4";
				Label5.Text = "Meter 5";
				Label2[5].Text = "Meter 6";
				Label2[4].Text = "Meter 7";
				Label3[1].Text = "Meter 8";
				Label8.Text = "Meter 9";
				Label2[8].Text = "Meter 10";
				Label2[9].Text = "Meter 11";
				if (sub_Renamed.MID2 == 0)
				{
					Label3[4].Text = "Meter 12";
				}
				else
				{
					Label3[4].Text = "N.Meter";
				}
				Command1.Text = "Ok";
				Command2.Text = "Quit";
			}
			
			FileSystem.FileClose(12);
			FileSystem.FileOpen(12, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\COM_canshu.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(12, ref sub_Renamed.Com1);
			FileSystem.Input(12, ref sub_Renamed.Com2);
			FileSystem.Input(12, ref sub_Renamed.Com3);
			FileSystem.Input(12, ref sub_Renamed.Com4);
			FileSystem.Input(12, ref sub_Renamed.Com5);
			FileSystem.Input(12, ref sub_Renamed.Com6);
			FileSystem.Input(12, ref sub_Renamed.Com7);
			FileSystem.Input(12, ref sub_Renamed.Com8);
			FileSystem.Input(12, ref sub_Renamed.Com9);
			FileSystem.Input(12, ref sub_Renamed.Com10);
			FileSystem.Input(12, ref sub_Renamed.Com11);
			FileSystem.Input(12, ref sub_Renamed.Com12);
			FileSystem.Input(12, ref sub_Renamed.Com13);
			FileSystem.Input(12, ref sub_Renamed.Com14);
			FileSystem.Input(12, ref sub_Renamed.Com15);
			FileSystem.Input(12, ref sub_Renamed.Com16);
			
			FileSystem.FileClose(12);
			Combo1.Text = (sub_Renamed.Com1).ToString();
			Combo2.Text = (sub_Renamed.Com2).ToString();
			Combo3.Text = (sub_Renamed.Com3).ToString();
			Combo4.Text = (sub_Renamed.Com4).ToString();
			Combo5.Text = (sub_Renamed.Com5).ToString();
			Combo6.Text = (sub_Renamed.Com6).ToString();
			Combo7.Text = (sub_Renamed.Com7).ToString();
			Combo8.Text = (sub_Renamed.Com8).ToString();
			Combo9.Text = (sub_Renamed.Com9).ToString();
			Combo10.Text = (sub_Renamed.Com10).ToString();
			Combo11.Text = (sub_Renamed.Com11).ToString();
			Combo12.Text = (sub_Renamed.Com12).ToString();
			Combo13.Text = (sub_Renamed.Com13).ToString();
			Combo14.Text = (sub_Renamed.Com14).ToString();
			Combo15.Text = (sub_Renamed.Com15).ToString();
			Combo16.Text = (sub_Renamed.Com16).ToString();
			
			if (sub_Renamed.MID2 == 1) //带标准表法时
			{
				Label3[4].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(480))); //标准表
				Label3[4].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(3600)));
				Combo16.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4680));
				Combo16.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360));
				Label6.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(960)); //1
				Combo5.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(840));
				Label2[3].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1440))); //2
				Combo6.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1320));
				Label2[2].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1920))); //3
				Combo7.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1800));
				Label3[0].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(480))); //4
				Label3[0].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(6000)));
				Combo8.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360));
				Combo8.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(7080));
				Label5.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(960)); //5
				Combo9.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(840));
				Label2[5].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1440))); //6
				Combo10.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1320));
				Label2[4].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1920))); //7
				Combo11.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1800));
				Label3[1].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(480))); //8
				Label3[1].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(8520)));
				Combo12.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(360));
				Combo12.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(9600));
				Label8.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(960)); //9
				Combo13.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(840));
				Label2[8].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1440))); //10
				Combo14.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1320));
				Label2[9].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1920))); //7
				Combo15.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1800));
			}
			
		}
	}
}
