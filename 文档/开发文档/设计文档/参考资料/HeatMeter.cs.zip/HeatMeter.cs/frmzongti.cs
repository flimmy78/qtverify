// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports

using VB = Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace 热量表
{
	partial class FrmZongti : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static FrmZongti defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static FrmZongti Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new FrmZongti();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		float Pinlvsz1;
		object Dtpc;
		float Dtpm;
		short Jsz;
		object Chuzhijs;
		float Mozhijs;
		bool kaishi;
		short Pt_XH;
		short Pinlvjs;
		bool[] stateFa = new bool[16];
		bool[] stateQi = new bool[16];
		float[] mi = new float[9];
		bool Flagpinlv;
		bool FlagpinlvQ;
		float Dtianping;
		float Dliuliang;
		object gas_volume;
		object venturi_diameter;
		float pipe_diameter; //容积类中的，用户输入;节流孔径，管道孔径
		short xx;
		short yy;
		short zz;
		short Tianping2;
		object Tianping3;
		float maxLL;
		float minLL;
		object Tianping5;
		object Tianping6;
		//'dim fs(5) As Byte
		short Tjs;
		object s;
		string s0;
		object s2;
		object s1;
		object s3;
		string s4;
		object s6;
		object s5;
		object s7;
		string s8;
		string data;
		
		bool Gaicanshu;
		short Biao_Xuhao;
		bool Gaibiaohao;
		bool Yanshi;
		bool DanJian;
		bool Wancheng;
		bool Sendend;
		object Ds2;
		object Ds3;
		string Ds;
		short[] Dss = new short[16];
		
		short Fdizhi;
		short Fzhi;
		short Fzhi1;
		short Fzhi2;
		byte[] Fd = new byte[7];
		short k;
		short j;
		bool FlagLLd;
		object[] Dif_errorresult = new object[9];
		object[] Result_repeatability = new object[9];
		float[] Fundmental_error = new float[9]; //容积类最终示值误差
		
		short t6;
		short Pqtime;
		
		float[] Pulseanfang = new float[25];
		float[] Pulseend = new float[25];
		bool[] Readover = new bool[12];
		
		bool FlagX;
		float[] Keybiao = new float[21];
		short Jssl;
		float[] Ljsl = new float[11];
		float Zongsl;
		float MAxsl;
		float Minsl;
		float[] Liuliangdian = new float[4];
		bool FlagDa;
		short Llxuanze;
		short[] Fkd = new short[3];
		bool Zdtfm;
		float[] Tpjs = new float[90001];
		float Kxs;
		float Kxishu;
		
		
		float tstart;
		double[] aa0 = new double[2];
		byte[] aa1 = new byte[2];
		float ssLL;
		int llJs;
		float[] llCZ = new float[90001];
		float Llds;
		
		byte[] MeterTime1 = new byte[33];
		double[] MeterTime = new double[33];
		byte[] MeterRead1 = new byte[26];
		double[] MeterRead = new double[26];
		byte[] jiance = new byte[18];
		
		short Wendujisuan;
		short Js;
		
		
		bool Flagfirst;
		bool Flagsc;
		object[] steam_diferror = new object[11];
		float[] steam_repeatabilityresult = new float[11]; //热水流量计示值误差.最终重复性
		float[,] steam_repeatability = new float[9, 9]; //热水流量计重复性
		object steam_teampa;
		float steam_teampb; //
		float[] steam_volume = new float[11]; //热水流量计标准流量累计
		float[] steam_gas = new float[11]; // 热水流量计输入通热水量
		float[,] repeatability = new float[9, 9]; //重复性
		float[,,] dif_error = new float[9, 11, 9]; //相对示值误差--第三类用
		float[,] dif_errormax = new float[9, 9]; //相对示值误差极大值第三类用
		float[,] dif_errormin = new float[9, 9]; //相对示值误差极小值第三类用
		object a;
		short b;
		object aa;
		short bb;
		//Dim j As Integer
		short ii;
		object Response;
		float commom_z; //
		object filenamey;
		float[] Wendujin = new float[4];
		float[] Wenduchu = new float[4];
		float Wcll; //计算误差时的流量
		short Tpjs1;
		bool Fsbz;
		
		private void cmdqd_Click()
		{
			Mdlguanfa.Send_Data((short) 249);
			delay_times((0.1));F;);
		}
		
		private void Cmdtz_Click()
		{
			Mdlguanfa.Send_Data((short) 250);
			delay_times((0.1));F;);
		}
		
		
		private void Cmdbz_Click()
		{
			object RetVal;
			//UPGRADE_WARNING: 未能解析对象 RetVal 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			RetVal = Interaction.Shell((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\手动流量检测.pdf", (Microsoft.VisualBasic.AppWinStyle) 2, 0, -1);
		}
		
		public void Chu1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[0].Text = Text6((System.Convert.ToDouble(Text22[0].Text)) * 1000, "0.00");
		}
		public void Chu2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[1].Text = Text6((System.Convert.ToDouble(Text22[1].Text)) * 1000, "0.00");
		}
		
		public void Chu3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[2].Text = Text6((System.Convert.ToDouble(Text22[2].Text)) * 1000, "0.00");
		}
		
		public void Chu4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[3].Text = Text6((System.Convert.ToDouble(Text22[3].Text)) * 1000, "0.00");
		}
		
		public void Chu5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[4].Text = Text6((System.Convert.ToDouble(Text22[4].Text)) * 1000, "0.00");
		}
		
		public void Chu6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[5].Text = Text6((System.Convert.ToDouble(Text22[5].Text)) * 1000, "0.00");
		}
		
		public void Chu7_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[6].Text = Text6((System.Convert.ToDouble(Text22[6].Text)) * 1000, "0.00");
		}
		
		public void Chu8_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[7].Text = Text6((System.Convert.ToDouble(Text22[7].Text)) * 1000, "0.00");
		}
		
		public void Chu9_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[8].Text = Text6((System.Convert.ToDouble(Text22[8].Text)) * 1000, "0.00");
		}
		public void Chu10_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[9].Text = Text6((System.Convert.ToDouble(Text22[9].Text)) * 1000, "0.00");
		}
		
		public void Chu11_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[10].Text = Text6((System.Convert.ToDouble(Text22[10].Text)) * 1000, "0.00");
		}
		
		public void Chu12_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text6[11].Text = Text6((System.Convert.ToDouble(Text22[11].Text)) * 1000, "0.00");
		}
		public void Cmdexit_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Flagtuichu;
			object t = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Chinese == true)
			{
				Labt.Text = "正在关闭相关阀门。等退出程序后，方可开始拆装被检表";
			}
			else
			{
				Labt.Text = "Closing valves. wenn exited program,then you can start removing meters";
			}
			Timerpq.Enabled = false;
			Timer10.Enabled = false;
			Label12.Visible = false;
			Text13.Visible = false;
			Label7[3].Visible = false;
			Mdlguanfa.Send_Data((short) 250);
			delay_times((0.5));F;);
			System.Int32 temp_i = 1;
			Mdlguanfa.Zhu_Guan(ref temp_i); //关进水阀
			delay_times((0.5));F;);
			System.Int32 temp_i2 = 2;
			Mdlguanfa.Zhu_Guan(ref temp_i2); //关小
			delay_times((0.5));F;);
			System.Int32 temp_i3 = 3;
			Mdlguanfa.Zhu_Guan(ref temp_i3); //关中1
			delay_times((0.5));F;);
			if (sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i4 = 5;
				Mdlguanfa.Zhu_Guan(ref temp_i4);
				delay_times((0.5));F;);
			}
			if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i5 = 4;
				Mdlguanfa.Zhu_Guan(ref temp_i5);
				delay_times((0.5));F;);
			}
			System.Int32 temp_i6 = 6;
			Mdlguanfa.Zhu_Guan(ref temp_i6); //关中2
			delay_times((0.5));F;);
			System.Int32 temp_i7 = 7;
			Mdlguanfa.Zhu_Kai(ref temp_i7); //称放水开
			delay_times((0.5));F;);
			System.Int32 temp_i8 = 8;
			Mdlguanfa.Zhu_Kai(ref temp_i8); //开打压阀
			delay_times((0.5));F;);
			
			
			
			sub_Renamed.Flagcom = false;
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer3.Enabled = false;
			Timer4.Enabled = false;
			Timer5.Enabled = false;
			Timer6.Enabled = false;
			Timer7.Enabled = false;
			Timer8.Enabled = false;
			Timer9.Enabled = false;
			Timer15.Enabled = false; //瞬流
			Timer14.Enabled = false; //标温采集（唯立）
			Timer16.Enabled = false; //标温采集（唯立）
			Timer18.Enabled = false; //标温采集（华易）
			Timer19.Enabled = false; //标温采集（华易）
			Timer17.Enabled = false; //标温采集平均
			
			Timer11.Enabled = false;
			
			
			
			//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Flagtuichu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Flagtuichu = t;
			FlagpinlvQ = true;
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			
			//将最后一位表号记录下来。
			
			//If frmzjsz.Option10.value = True Then
			//
			//   For i = 0 To 11
			//       If Len(Text1(i).Text) = 8 And Text1(i).Text <> "FFFFFFFF" And Text1(i).Text <> "00000000" Then
			//      Biaobianhao = Text1(i).Text
			//      End If
			//       If Len(Text1(i).Text) = 9 And Text1(i).Text <> "FFFFFFFFF" And Text1(i).Text <> "000000000" Then
			//      Biaobianhao9 = Text1(i).Text
			//      End If
			//
			//
			//   Next i
			//
			//Close #1
			//Open App.Path + "\biaohao.dll" For Output As #1
			//Write #1, Biaobianhao
			//Close #1
			//
			//Close #11
			//Open App.Path + "\biaohaon.dll" For Output As #11
			//Write #11, Biaobianhao9
			//Close #11
			//
			//End If
			sub_Renamed.Comopen = false;
			sub_Renamed.Zongtiactive = false;
			this.Close();
		}
		
		
		private void Cmdjt_Click()
		{
			FlagX = false;
		}
		
		private void Cmdxiao_Click()
		{
			//FlagX = True
		}
		
		public void Combc_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.yibiao_No = int.Parse("");
			
			sub_Renamed.yibiao_No = int.Parse(Conversion.Str(Mdlguanfa.yibiaoNo).Trim());
			sub_Renamed.save_execel();
			//Set objExcel = New Excel.Application
			//objExcel.SheetsInNewWorkbook = 1
			sub_Renamed.objExcel.Workbooks(1).SaveAs((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\report\\" + (sub_Renamed.yibiao_No).ToString().Trim() + ".xls");
			//objExcela.Workbooks.Close
			//Set objExcel = Nothing
			PrintZong();
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.Jdks1 = false;
			frmzjsz.Default.Show();
			sub_Renamed.Jdks = true;
		}
		
		
		public void Command10_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option4.Checked == true)
			{
				Timer14.Enabled = false;
				Timer16.Enabled = false;
				Text12.Text = "";
				Text14.Text = "";
				Text15.Text = "";
				Text16.Text = "";
				Text16.Visible = true;
				Text15.Visible = true;
			}
			else if (frmjsbdz.Default.Option5.Checked == true)
			{
				Text12.Text = "";
				Text14.Text = "";
				Text15.Text = "";
				Text16.Text = "";
				Timer18.Enabled = false;
				Timer19.Enabled = false;
			}
			else if (frmjsbdz.Default.Option3.Checked == true)
			{
				
			}
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
		}
		
		public void Command11_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Mdlguanfa.Send_Data((short) 250);
			delay_times(1);
			System.Int32 temp_i = 1;
			Mdlguanfa.Zhu_Guan(ref temp_i);
			delay_times(1);
			System.Int32 temp_i2 = 7;
			Mdlguanfa.Zhu_Kai(ref temp_i2); //称放水开
			delay_times(1);
			System.Int32 temp_i3 = 6;
			Mdlguanfa.Zhu_Guan(ref temp_i3);
			delay_times(1);
			if (sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i4 = 5;
				Mdlguanfa.Zhu_Guan(ref temp_i4);
				delay_times(1);
			}
			if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i5 = 4;
				Mdlguanfa.Zhu_Guan(ref temp_i5);
				delay_times(1);
			}
			System.Int32 temp_i6 = 3;
			Mdlguanfa.Zhu_Guan(ref temp_i6);
			delay_times(1);
			System.Int32 temp_i7 = 2;
			Mdlguanfa.Zhu_Guan(ref temp_i7);
			delay_times(1);
			ProjectData.EndApp();
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //
			Fsbz = true;
			
			
			if (Strings.Len(Text3[0].Text) <= 0)
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("注意：请检查天平采集是否正常！");
				}
				else
				{
MessageBox.Show("Note: Please check balance reading is normal!");
				}
				return;
			}
			
			if (Text12.Text.Length == 0 || Text14.Text.Length == 0)
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请采集或输入标准温度值！");
				}
				else
				{
					MessageBox.Show("Please read or enter standard temperature value !");
				}
				Text14.Focus();
				return;
			}
			
			
			short h = 0;
			for (i = 0; i <= 11; i++)
			{
				h = (short) (h + Strings.Len(Text1[sub_Renamed.i].Text));
			}
			
			if (h == 0)
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先输入被检表编号！");
				}
				else
				{
					MessageBox.Show("Please enter the meter number first!");
				}
				Text1[0].Focus();
				return;
			}
			
			Command2.Enabled = false;
			
			读表号一.Enabled = false;
			读表号二.Enabled = false;
			读表号三.Enabled = false;
			读表号四.Enabled = false;
			读表号五.Enabled = false;
			读表号六.Enabled = false;
			读表号七.Enabled = false;
			读表号八.Enabled = false;
			读表号九.Enabled = false;
			读表号十.Enabled = false;
			读表号十一.Enabled = false;
			读表号十二.Enabled = false;
			
			状态一.Enabled = false;
			状态二.Enabled = false;
			状态三.Enabled = false;
			状态四.Enabled = false;
			状态五.Enabled = false;
			状态六.Enabled = false;
			状态七.Enabled = false;
			状态八.Enabled = false;
			状态九.Enabled = false;
			状态十.Enabled = false;
			状态十一.Enabled = false;
			状态十二.Enabled = false;
			
			读数1.Enabled = false;
			读数2.Enabled = false;
			读数3.Enabled = false;
			读数4.Enabled = false;
			读数5.Enabled = false;
			读数6.Enabled = false;
			读数7.Enabled = false;
			读数8.Enabled = false;
			读数9.Enabled = false;
			读数10.Enabled = false;
			读数11.Enabled = false;
			读数12.Enabled = false;
			
			if (sub_Renamed.Chinese == true)
			{
				Labt.Text = "正在打开检定记录表格，请稍候...";
			}
			else
			{
				Labt.Text = "Opening test record form, please wait ... ";
			}
			
			
			delay_times(1);
			
			
			
			//计算每个表位上的检表数量
			
			sub_Renamed.End_biaowei = (short) 0;
			sub_Renamed.Jd_number = (short) 0;
			for (i = 0; i <= 11; i++)
			{
				sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 0;
				if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
				{
					sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 1;
					sub_Renamed.End_biaowei = sub_Renamed.i;
				}
				sub_Renamed.Jd_number = sub_Renamed.Jd_number + sub_Renamed.Jd_biaowei[sub_Renamed.i];
			}
			
			sub_Renamed.Jd_meter = sub_Renamed.Jd_number;
			
			//UPGRADE_NOTE: 在对对象 objExcel 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.objExcel = null;
			sub_Renamed.gain_fileNO();
			sub_Renamed.objExcel = new Microsoft.Office.Interop.Excel.Application();
			sub_Renamed.objExcel.SheetsInNewWorkbook = 1;
			sub_Renamed.objExcel.Workbooks.Add();
			//objExcel.Sheets.Application.DisplayFullScreen = True
			sub_Renamed.objExcel.Application.WindowState = Microsoft.Office.Interop.Excel.XlWindowState.xlMinimized;
			sub_Renamed.objExcel.Application.Visible = true;
			
			yy = (short) 0;
			zz = (short) 0;
			listene();
			
			if (sub_Renamed.MID1 == 2 | sub_Renamed.MID1 == 3) //带二个以上标准表采瞬流
			{
				Timer15.Enabled = true;
			}
			
			short k = 0;
			for (xx = 1; xx <= sub_Renamed.Jd_point; xx++) //流程： 逐个流量点进行
			{
				
				Label10.Visible = true;
				Label7[0].Visible = true;
				Label7[2].Visible = true;
				Label7[2].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Jd_flow[xx - 1], "0.0##");
				Label18.Visible = true;
				Label7[1].Visible = true;
				Label7[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format((double.Parse(Text14.Text)) - double.Parse(Text12.Text), "0.00");
				
				if (xx == 1)
				{
					if (Option3.Checked == true) //如果初值回零
					{
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							if (Strings.Len(Text1[sub_Renamed.i].Text) > 0) //对无表号表位不赋0值
							{
								sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
								Text6[sub_Renamed.i].Text = (0).ToString();
							}
							else
							{
								Text6[sub_Renamed.i].Text = "";
							}
						}
						
					}
					else //如果初值不回零
					{
						
						
						sub_Renamed.Flagnext = false;
						Command5.Visible = true;
						
						if (sub_Renamed.Chinese == true)
						{
							if (Option6.Checked == true)
							{
								Labt.Text = "请填写被检表热量初值（kWh）,并点击《下一步》确认";
							}
							else
							{
								Labt.Text = "请填写被检表热量初值（MJ）,并点击《下一步》确认";
							}
						}
						else
						{
							if (Option6.Checked == true)
							{
								Labt.Text = "Please enter Eo(kWh) of meters, and then click on 《next》 to continue ";
							}
							else
							{
								Labt.Text = "Please enter Eo(MJ) of meters, and then click on 《next》 to continue ";
							}
						}
						
						for (i = 0; i <= 11; i++)
						{
							sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
							Text6[sub_Renamed.i].Text = "";
						}
						// 找第一个装表的表位
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
							{
								goto ss;
							}
						}
ss:
						Text6[sub_Renamed.i].Focus();
						
						do
						{
							System.Windows.Forms.Application.DoEvents();
							delay_times((0.5));F;);
						} while (!(sub_Renamed.Flagnext == true));
						
						
					} //回零结束
				}
				else //如果不是第一遍
				{
					if (frmzjsz.Default.Option16.Checked == true) //如果不是连续检定
					{
						if ((Conversion.Val(Text3[0].Text) + sub_Renamed.Jd_liang[xx - 1]) >= 100)
						{
							System.Int32 temp_i = 7;
							Mdlguanfa.Zhu_Kai(ref temp_i); //量器放水
							delay_times(1);
							
							Labt.Text = "天平正在放水，请等候...";
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
								delay_times(1);
							} while (!(Conversion.Val(Text3[0].Text) + sub_Renamed.Jd_liang[xx - 1] < 95));
							
							System.Int32 temp_i2 = 7;
							Mdlguanfa.Zhu_Guan(ref temp_i2); //放水关
							delay_times(3);
						}
					}
					
					if (Option3.Checked == true) //如果初值回零
					{
						
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							if (Strings.Len(Text1[sub_Renamed.i].Text) > 0) //对无表号表位不赋0值
							{
								sub_Renamed.lLChuzhi[sub_Renamed.i] = 0;
								Text6[sub_Renamed.i].Text = (0).ToString();
							}
							else
							{
								Text6[sub_Renamed.i].Text = "";
							}
							//                               Text8(i).Text = ""
						}
						
					}
					else //如果初值不回零
					{
						//
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							Text6[sub_Renamed.i].Text = Text8[sub_Renamed.i].Text;
							sub_Renamed.lLChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text8[sub_Renamed.i].Text));
							sub_Renamed.llZhongzhi[sub_Renamed.i] = 0;
							//                        Text4(i).Text = ""
						}
						
						
					} //回零结束
					
				} //第一遍结束
				
				sub_Renamed.Zlm0 = (float) (Conversion.Val(Text3[0].Text));
				
				if (Timer13.Enabled == true)
				{
					Labt.Text = "正在等待自动回零时间...";
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.5));F;);
					} while (!(Timer13.Enabled == false)); //等待10秒钟，初值自动回零。
				}
				
				if (sub_Renamed.Ld4 == 3)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i3 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i3); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i4 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i4); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i5 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i5); //
					}
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i6 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i6); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i7 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i7); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i8 = 4;
						Mdlguanfa.Zhu_Kai(ref temp_i8); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[2] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[3])
					{
						Llxuanze = (short) 4;
						System.Int32 temp_i9 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i9); //
					}
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i10 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i10); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i11 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i11); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i12 = 4;
						Mdlguanfa.Zhu_Kai(ref temp_i12); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[2] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[3])
					{
						Llxuanze = (short) 4;
						System.Int32 temp_i13 = 5;
						Mdlguanfa.Zhu_Kai(ref temp_i13); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[3] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[4])
					{
						Llxuanze = (short) 5;
						System.Int32 temp_i14 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i14); //
					}
				}
				delay_times(1);
				sub_Renamed.zeit = 0;
				Text7.Text = (0).ToString();
				//               Textjs.Text = 0
				Timer10.Enabled = true;
				
				
				
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "正在通水检测，请等待约     秒";
				}
				else
				{
					Labt.Text = "Testing now, wait about     seconds ";
				}
				
				
				//采温度
				sub_Renamed.jkwd = 0;
				sub_Renamed.ckwd = 0;
				sub_Renamed.wdjs = 0;
				Timer11.Enabled = true;
				
				//采标准温度平均
				sub_Renamed.Njkwd = 0;
				sub_Renamed.Nckwd = 0;
				sub_Renamed.Nwdjs = 0;
				Timer17.Enabled = true;
				
				if (sub_Renamed.MID1 == 0 | sub_Renamed.MID1 == 1)
				{
					sub_Renamed.jsjs = 0;
					sub_Renamed.Leiji = 0;
					Tianping2 = (short) 0;
					Timer9.Enabled = true; //开始计算瞬流
				}
				
				Jsz = (short) 0;
				llJs = 0;
				ssLL = 0;
				Timer12.Enabled = true; //计六秒后开始采集平均瞬流
				
				Dtianping = 0;
				Caiji();
				
				Timer11.Enabled = false; //温度采集结束
				Timer12.Enabled = false; //流量采集结束
				Timer17.Enabled = false;
				
				for (j = 0; j <= sub_Renamed.End_biaowei; j++) //计算每个表温度及密度
				{
					sub_Renamed.Zlwendu[j] = (float) (System.Math.Round(sub_Renamed.inlet - (sub_Renamed.inlet - sub_Renamed.outlet) / (sub_Renamed.Stueck + 2) * (j + 1), 2));
					//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.ZlMiDu[j] = float.Parse(Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(mdlyingpanxuliehao.MiDu(Conversion.Str(sub_Renamed.Zlwendu[j])), "0.0000"));
				}
				
				Text14.Text = (sub_Renamed.Ninlet).ToString();
				Text12.Text = (sub_Renamed.Noutlet).ToString();
				
				
				if (sub_Renamed.Ld4 == 3) //三管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i15 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i15); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i16 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i16); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i17 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i17); //
						delay_times(1);
					}
				}
				else if (sub_Renamed.Ld4 == 4) //四管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i18 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i18); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i19 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i19); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i20 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i20); //
						delay_times(1);
					}
					else if (Llxuanze == 4)
					{
						System.Int32 temp_i21 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i21); //
						delay_times(1);
					}
				}
				else if (sub_Renamed.Ld4 == 5) //五管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i22 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i22); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i23 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i23); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i24 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i24); //
						delay_times(1);
					}
					else if (Llxuanze == 4)
					{
						System.Int32 temp_i25 = 5;
						Mdlguanfa.Zhu_Guan(ref temp_i25); //
						delay_times(1);
					}
					else if (Llxuanze == 5)
					{
						System.Int32 temp_i26 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i26); //
						delay_times(1);
					}
				}
				
				
				Label12.Visible = false;
				Timer10.Enabled = false;
				
				Timer9.Enabled = false;
				Text3[1].Text = (0).ToString();
				Timer7.Enabled = true;
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "通水检测结束，正等待稳定时间...";
				}
				else
				{
					Labt.Text = "Testing is over, waiting for the stable time of balance ...";
				}
				
				if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7) //天罡延时归零
				{
					//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Chuzhijs = 0;
					Timer13.Enabled = true;
				}
				
				delay_times(5);
				
				sub_Renamed.Zlm1 = (float) (Conversion.Val(Text3[0].Text));
				if (sub_Renamed.Chinese == true)
				{
					if (Option6.Checked == true)
					{
						Labt.Text = "通水检测结束，请输入被检表热量终值（kWh）";
					}
					else
					{
						Labt.Text = "通水检测结束，请输入被检表热量终值（MJ）";
					}
				}
				else
				{
					if (Option6.Checked == true)
					{
						Labt.Text = "Testing is over, Please enter E1（kWh） of meters";
					}
					else
					{
						Labt.Text = "Testing is over, Please enter E1（MJ） of meters";
					}
				}
				for (i = 0; i <= sub_Renamed.End_biaowei; i++)
				{
					sub_Renamed.ZlZhongzhi[sub_Renamed.i] = 0;
					Text8[sub_Renamed.i].Text = "";
				}
				// 找第一个装表的表位
				for (i = 0; i <= sub_Renamed.End_biaowei; i++)
				{
					if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
					{
						goto UM;
					}
				}
UM:
				Text8[sub_Renamed.i].Focus();
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.ZlZhongzhi[sub_Renamed.End_biaowei] > 0));
				
				
				
				k = (short) 0;
				for (j = 0; j <= sub_Renamed.End_biaowei; j++)
				{
					
					if (Strings.Len(Text1[j].Text) > 0)
					{
						if (j == 0)
						{
							k = (short) 1;
						}
						else if (j == 1)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
						}
						else if (j == 2)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
						}
						else if (j == 3)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
						}
						else if (j == 4)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
						}
						else if (j == 5)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
						}
						else if (j == 6)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
						}
						else if (j == 7)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
						}
						else if (j == 8)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
						}
						else if (j == 9)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
						}
						else if (j == 10)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
						}
						else if (j == 11)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
						}
						
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 1) = "q:" + "" + System.Convert.ToString(Llds) + "" + "、" + "Δθ:" + "" + System.Convert.ToString(Text14.Text) - double.Parse(Text12.Text);); //平均流量点
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 2) = Text1[j].Text; //表号
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 3) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlChuzhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 4) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlZhongzhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 5) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlShizhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 6) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm0, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 7) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm1, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 8) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm1 - sub_Renamed.Zlm0, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 9) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlwendu[j], "###0.##");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 10) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlMiDu[j], "###0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 11) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.BiaozhunzhiE[j], "###0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 12) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Text9[j].Text, "0.0");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 13) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE, "0.00");
						
						
						if (System.Math.Abs(System.Convert.ToDouble(Text9[j].Text)) > sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE)
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14) = "不合格";
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14).Font.Color = 0xFF;
						}
						else
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14) = "合格";
						}
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 15) = j + 1;
						
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14).Font.Color == 0xFF)
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 15).Font.Color = 0xFF;
						}
						
					} //If Len(Text1(j).Text) > 0
					
				}
				zz = 5 + sub_Renamed.Jd_number * (xx - 1) + k;
				if (xx != sub_Renamed.Jd_point)
				{
					MessageBox.Show("请将恒温浴槽调到第" + "" + System.Convert.ToString(xx + 1) + "" + "检定点的" + "" + System.Convert.ToString(sub_Renamed.Jd_wc[xx]) + "" + "K 温差点!  点击《确定》将开始下一点检定!");
				}
				
			}
			
			yy = zz;
			
			Protokol1();
			
			
			if (frmzjsz.Default.Frame9.Enabled == true) //重复检测时
			{
				if (frmzjsz.Default.Option13.Checked == true) //重新排气时
				{
					Mdlguanfa.Send_Data((short) 250);
					delay_times(1);
					System.Int32 temp_i27 = 1;
					Mdlguanfa.Zhu_Guan(ref temp_i27); //关进水阀
					delay_times(1);
					System.Int32 temp_i28 = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i28); //称放水开
					delay_times(1);
					System.Int32 temp_i29 = 8;
					Mdlguanfa.Zhu_Kai(ref temp_i29); //开打压阀
				}
				else if (frmzjsz.Default.Option14.Checked == true) //不重新排气时
				{
					System.Int32 temp_i30 = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i30); //称放水开
					delay_times(1);
				}
			}
			else
			{
				Mdlguanfa.Send_Data((short) 250);
				delay_times(1);
				System.Int32 temp_i31 = 1;
				Mdlguanfa.Zhu_Guan(ref temp_i31); //关进水阀
				delay_times(1);
				System.Int32 temp_i32 = 7;
				Mdlguanfa.Zhu_Kai(ref temp_i32); //称放水开
				delay_times(1);
				System.Int32 temp_i33 = 8;
				Mdlguanfa.Zhu_Kai(ref temp_i33); //开打压阀
			}
			
			Timer15.Enabled = false;
			
			
			//'全部结束处理
			
			
			//yibiao_No = ""
			//yibiao_No = Trim(Str(yibiaoNo))
			//Call save_execel
			//objExcel.Workbooks(1).SaveAs (App.Path & "\report\" & Trim(yibiao_No) & ".xls")
			//Call PrintZong
			
			if (frmzjsz.Default.Frame9.Enabled == true) //如重新排气
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "检定完毕，点击《保存》数据。重复本次检定点击《重复检测》。重新开始下次检定点击《退出》！";
				}
				else
				{
					Labt.Text = "Test is complete,the duplicate test clicks on the《Repeat》. Restart the new test you click on the 《Exit》 ! ";
				}
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "检定完毕，点击《保存》数据。重新开始下次检定点击《退出》！";
				}
				else
				{
					Labt.Text = "Test is complete, Restart the new test you click on the 《Exit》 ! ";
				}
			}
			
			Label7[0].Visible = false;
			Label10.Visible = false;
			Label18.Visible = false;
			Label7[1].Visible = false;
			Label7[2].Visible = false;
			
			sub_Renamed.Jdks = false;
			
			if (frmzjsz.Default.Frame9.Enabled == true)
			{
				wiederpruf.Enabled = true;
			}
			
			//    Unload frmzjsz
		}
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.Jdks2 = false;
			frmzjsz.Default.Show();
			frmzjsz.Default.Frame1[0].Enabled = false;
			frmzjsz.Default.Frame1[1].Enabled = false;
			frmzjsz.Default.Frame2.Enabled = false;
			frmzjsz.Default.Frame3.Enabled = false;
			//  frmzjsz.Frame4.Enabled = False
			//  frmzjsz.Frame6.Enabled = False
			//  frmzjsz.Frame7.Enabled = False
			frmzjsz.Default.Frame8.Enabled = false;
			
			frmzjsz.Default.Command1.Visible = false;
			frmzjsz.Default.Command2.Visible = true;
			frmzjsz.Default.Command3.Enabled = false;
			frmzjsz.Default.Command2.Focus();
			
		}
		
		public void Command4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Wendu_js1;
			object Kk1;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			MSComm1.PortOpen = true;
			
			if (frmjsbdz.Default.Option4.Checked == true) //唯立
			{
				
				MSComm1.Settings = "9600,n,8,1";
				MSComm1.InputLen = (short) 0; //串口清空
				Timer14.Enabled = true;
				delay_times((0.5));F;);
				Timer16.Enabled = true;
				
			}
			else if (frmjsbdz.Default.Option5.Checked == true) //华易
			{
				MSComm1.Settings = "4800,n,8,1";
				MSComm1.InputLen = (short) 0;
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = 0;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
				Timer18.Enabled = true;
				//Timer19.Enabled = True
				
			}
			else if (frmjsbdz.Default.Option3.Checked == true) //计量院
			{
				MessageBox.Show("请将标准温度显示仪选择为其它型号！");
				
			}
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			sub_Renamed.Flagnext = true;
			Command5.Visible = false;
			if (sub_Renamed.Comopen == false)
			{
				for ( = ;0; i <= sub_Renamed.Jd_meter - 1); i++;);
				{
					sub_Renamed.ZlChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text6[sub_Renamed.i].Text));
				}
			}
		}
		
		public void Command6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Flagtuichu;
			object t = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Chinese == true)
			{
				Labt.Text = "正在关闭相关阀门。等退出程序后，方可开始拆装被检表";
			}
			else
			{
				Labt.Text = "Closing valves. wenn exitied program,then you can start removing meters";
			}
			Timerpq.Enabled = false;
			Timer10.Enabled = false;
			Label12.Visible = false;
			Text13.Visible = false;
			Label7[3].Visible = false;
			Mdlguanfa.Send_Data((short) 250);
			delay_times((0.5));F;);
			System.Int32 temp_i = 1;
			Mdlguanfa.Zhu_Guan(ref temp_i); //关进水阀
			delay_times((0.5));F;);
			System.Int32 temp_i2 = 2;
			Mdlguanfa.Zhu_Guan(ref temp_i2); //关小
			delay_times((0.5));F;);
			System.Int32 temp_i3 = 3;
			Mdlguanfa.Zhu_Guan(ref temp_i3); //关中1
			delay_times((0.5));F;);
			if (sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i4 = 5;
				Mdlguanfa.Zhu_Guan(ref temp_i4);
				delay_times((0.5));F;);
			}
			if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i5 = 4;
				Mdlguanfa.Zhu_Guan(ref temp_i5);
				delay_times((0.5));F;);
			}
			System.Int32 temp_i6 = 6;
			Mdlguanfa.Zhu_Guan(ref temp_i6); //关中2
			delay_times((0.5));F;);
			System.Int32 temp_i7 = 7;
			Mdlguanfa.Zhu_Kai(ref temp_i7); //称放水开
			delay_times((0.5));F;);
			System.Int32 temp_i8 = 8;
			Mdlguanfa.Zhu_Kai(ref temp_i8); //开打压阀
			delay_times((0.5));F;);
			
			
			
			sub_Renamed.Flagcom = false;
			Timer1.Enabled = false;
			Timer2.Enabled = false;
			Timer3.Enabled = false;
			Timer4.Enabled = false;
			Timer5.Enabled = false;
			Timer6.Enabled = false;
			Timer7.Enabled = false;
			Timer8.Enabled = false;
			Timer9.Enabled = false;
			Timer15.Enabled = false; //瞬流
			Timer14.Enabled = false; //标温采集（唯立）
			Timer16.Enabled = false; //标温采集（唯立）
			Timer18.Enabled = false; //标温采集（华易）
			Timer19.Enabled = false; //标温采集（华易）
			Timer17.Enabled = false; //标温采集平均
			
			Timer11.Enabled = false;
			
			
			
			//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Flagtuichu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Flagtuichu = t;
			FlagpinlvQ = true;
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			
			//将最后一位表号记录下来。
			
			//If frmzjsz.Option10.value = True Then
			//
			//   For i = 0 To 11
			//       If Len(Text1(i).Text) = 8 And Text1(i).Text <> "FFFFFFFF" And Text1(i).Text <> "00000000" Then
			//      Biaobianhao = Text1(i).Text
			//      End If
			//       If Len(Text1(i).Text) = 9 And Text1(i).Text <> "FFFFFFFFF" And Text1(i).Text <> "000000000" Then
			//      Biaobianhao9 = Text1(i).Text
			//      End If
			//
			//
			//   Next i
			//
			//Close #1
			//Open App.Path + "\biaohao.dll" For Output As #1
			//Write #1, Biaobianhao
			//Close #1
			//
			//Close #11
			//Open App.Path + "\biaohaon.dll" For Output As #11
			//Write #11, Biaobianhao9
			//Close #11
			//
			//End If
			sub_Renamed.Comopen = false;
			sub_Renamed.Zongtiactive = false;
			this.Close();
		}
		
		private void Cwd_Click()
		{
			Js = (short) 0;
			Timer8.Enabled = true;
		}
		
		private void fkgbz_Click()
		{
			FlagX = true;
		}
		
		
		
		
		public void Command8_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			for ( = ;0; i <= sub_Renamed.Stueck); i++;);
			{
				Text1[sub_Renamed.i].Text = (sub_Renamed.i + 1).ToString();
			}
			Command8.Visible = false;
			Command9.Visible = true;
		}
		
		public void Command9_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			for ( = ;0; i <= sub_Renamed.Stueck); i++;);
			{
				Text1[sub_Renamed.i].Text = "";
			}
			Command8.Visible = true;
			Command9.Visible = false;
		}
		
		public void FrmZongti_FormClosing(System.Object eventSender, System.Windows.Forms.FormClosingEventArgs eventArgs)
		{
			bool Cancel = eventArgs.Cancel;
			System.Windows.Forms.CloseReason UnloadMode = eventArgs.CloseReason;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If Pqschutz = False Then
			//MsgBox "排气过程未结束!", vbOKOnly, "操作错误！"
			//Cancel = True
			//End If
			eventArgs.Cancel = Cancel;
		}
		
		public void FrmZongti_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (MSComm6[0].PortOpen == true)
			{
				MSComm6[0].PortOpen = false;
			}
			if (MSComm6[1].PortOpen == true)
			{
				MSComm6[1].PortOpen = false;
			}
			if (MSComm6[2].PortOpen == true)
			{
				MSComm6[2].PortOpen = false;
			}
			if (MSComm6[3].PortOpen == true)
			{
				MSComm6[3].PortOpen = false;
			}
			if (MSComm6[4].PortOpen == true)
			{
				MSComm6[4].PortOpen = false;
			}
			if (MSComm6[5].PortOpen == true)
			{
				MSComm6[5].PortOpen = false;
			}
			if (MSComm6[6].PortOpen == true)
			{
				MSComm6[6].PortOpen = false;
			}
			if (MSComm6[7].PortOpen == true)
			{
				MSComm6[7].PortOpen = false;
			}
			if (MSComm6[8].PortOpen == true)
			{
				MSComm6[8].PortOpen = false;
			}
			if (MSComm6[9].PortOpen == true)
			{
				MSComm6[9].PortOpen = false;
			}
			if (MSComm6[10].PortOpen == true)
			{
				MSComm6[10].PortOpen = false;
			}
			if (MSComm6[11].PortOpen == true)
			{
				MSComm6[11].PortOpen = false;
			}
			sub_Renamed.Zongtiactive = false;
			frmzjsz.Default.Close();
			
		}
		
		public void Image1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Image1.Visible = false;
			Image2.Visible = true;
			for ( = ;0; i <= sub_Renamed.Stueck); i++;);
			{
				//  Frame2(i).Visible = True
				Frame2[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 25080 / sub_Renamed.Stueck * sub_Renamed.i)));
			}
		}
		
		public void Image2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Image2.Visible = false;
			Image1.Visible = true;
			for ( = ;0; i <= sub_Renamed.Stueck); i++;);
			{
				//  Frame2(Stueck - i).Visible = True
				Frame2[sub_Renamed.Stueck - sub_Renamed.i].Left = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 25080 / sub_Renamed.Stueck * sub_Renamed.i);
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option1.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option1_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				//Send_Data (232)
				// delay_times (0.5)
				// Send_Data (233)
				//
				// delay_times (0.5)
				Zdtfm = false;
				//Command3.Visible = True
				//Command4.Visible = True
			}
		}}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option2.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option2_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.checked);
			{
				//Send_Data (232)
				// delay_times (0.5)
				// Send_Data (234)
				//
				// delay_times (0.5)
				Zdtfm = true;
				//Zdtfm = False
				//Command3.Visible = False
				//Command4.Visible = False
			}
		}}
		
		private void PL_Click()
		{
			object Txtpl = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short Fdizhi;
			short Fzhi = 0;
			short Fzhi1 = 0;
			float Fzhi2 = 0;
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			//If Pinlv(0) = True Then
			//     Fzhi2 = Val(Txtpl(0).Text)
			//     If Fzhi2 > 50 Then Fzhi2 = 50
			//      Fzhi = Int(Fzhi2 / 50 / 256 * 4095)
			//      Fzhi1 = (Fzhi2 / 50 * 4095) Mod 256
			//'   End If
			//End If
			//If Pinlv(1) = True Then
			//     Fzhi2 = Val(Txtpl(1).Text)
			//     If Fzhi2 > 50 Then Fzhi2 = 50
			//      Fzhi = Int(Fzhi2 / 50 / 256 * 4095)
			//      Fzhi1 = (Fzhi2 / 50 * 4095) Mod 256
			//End If
			//If Pinlv(2) = True Then
			//      Fzhi2 = Val(Txtpl(2).Text)
			//     If Fzhi2 > 50 Then Fzhi2 = 50
			//      Fzhi = Int(Fzhi2 / 50 / 256 * 4095)
			//      Fzhi1 = (Fzhi2 / 50 * 4095) Mod 256
			//End If
			//If Pinlv(3) = True Then
			//UPGRADE_WARNING: 未能解析对象 Txtpl.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Fzhi2 = (float) (Conversion.Val(Txtpl.text));
			if (Fzhi2 > 50)
			{
				Fzhi2 = 50;
			}
			Fzhi = (short) (Conversion.Int(Fzhi2 / 50 / 256 * 4095));
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			Fzhi1 = System.Convert.ToInt16((Fzhi2 / 50 * 4095) % 256);
			//End If
			byte[] Fd = new byte[7];
			Fd[0] = (byte) 255;
			Fd[1] = (byte) 248;
			Fd[2] = Fzhi;
			Fd[3] = Fzhi1;
			Fd[4] = (byte) 254;
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Fd);
			
		}
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option5.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option5_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (EventSender.Checked)
			{
				for ( = ;0; i <= 11); i++;);
				{
					Label11[sub_Renamed.i].Text = "MJ";
					Label13[sub_Renamed.i].Text = "MJ";
				}
			}
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Option6.CheckedChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Option6_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (EventSender.Checked)
			{
				for ( = ;0; i <= 11); i++;);
				{
					Label11[sub_Renamed.i].Text = "kWh";
					Label13[sub_Renamed.i].Text = "kWh";
				}
			}
		}
		
		public void pq_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Jd_flow[0] == 0)
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先设定检定参数！");
				}
				else
				{
					MessageBox.Show("First click on <<Setup>>  please!");
				}
				return;
			}
			
			if (Strings.Len(Text3[0].Text) <= 0)
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("注意：请检查天平采集是否正常！");
				}
				else
				{
MessageBox.Show("Note: Please check balance reading is normal!");
				}
				return;
			}
			
			
			if (Text12.Text.Length == 0 || Text14.Text.Length == 0)
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请采集或输入标准温度值！");
				}
				else
				{
					MessageBox.Show("Please read out or enter standard temperature value !");
				}
				Text14.Focus();
				return;
			}
			
			
			Llxuanze = (short) 0;
			if (sub_Renamed.MID1 == 2 | sub_Renamed.MID1 == 3) //带二个以上标准表采瞬流
			{
				Timer15.Enabled = true;
				ii = (short) 0;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times(1);
					ii++;
					if (ii >= 8)
					{
						Timer15.Enabled = false;
						MessageBox.Show("标准表瞬时流量采集不正常，请查找原因！");
						return;
					}
				} while (!(Strings.Len(Text3[1].Text) >= 1));
			}
			
			System.Int32 temp_i = 8;
			Mdlguanfa.Zhu_Guan(ref temp_i); //关打压阀
			delay_times(1);
			
			Command1.Visible = false;
			Command3.Visible = true;
			pq.Enabled = false;
			sub_Renamed.Pqschutz = true;
			
			
			if (sub_Renamed.Chinese == true)
			{
				Text13.Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4000)));
				Label2[0].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4000)));
				Labt.Text = "正在排气..约需    秒";
			}
			else
			{
				Text13.Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4360)));
				Label2[0].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4360)));
				Labt.Text = "Exhaust now,wait    s";
			}
			
			System.Int32 temp_i2 = 1;
			Mdlguanfa.Zhu_Kai(ref temp_i2); //进水开
			delay_times(1);
			System.Int32 temp_i3 = 2;
			Mdlguanfa.Zhu_Kai(ref temp_i3); //小流量开
			delay_times(1);
			System.Int32 temp_i4 = 3;
			Mdlguanfa.Zhu_Kai(ref temp_i4); //中流量开1
			delay_times(1);
			if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i5 = 4;
				Mdlguanfa.Zhu_Kai(ref temp_i5); //中流量开2
				delay_times(1);
			}
			if (sub_Renamed.Ld4 == 5)
			{
				System.Int32 temp_i6 = 5;
				Mdlguanfa.Zhu_Kai(ref temp_i6); //大流量开
				delay_times(1);
			}
			System.Int32 temp_i7 = 6;
			Mdlguanfa.Zhu_Kai(ref temp_i7); //大流量开
			delay_times(1);
			System.Int32 temp_i8 = 7;
			Mdlguanfa.Zhu_Kai(ref temp_i8); //称放水开
			delay_times(1);
			Mdlguanfa.Send_Data((short) 249); //启动水泵
			delay_times(1);
			
			t6 = (short) 0;
			Timerpq.Enabled = true;
			Pqtime = (short) (Conversion.Val(Text13.Text));
			
			if (sub_Renamed.Comopen == true)
			{
				//读表号过程
				for ( = ;0; i <= 11); i++;);
				{
					Text1[sub_Renamed.i].Text = "";
					Text11[sub_Renamed.i].Text = "";
				}
				sub_Renamed.cmd_type = "RD_NUM";
				Biao_Xuhao = (short) 0;
				Timer21.Enabled = true;
				Wancheng = false;
				
				do
				{
					System.Windows.Forms.Application.DoEvents();
					if (Conversion.Val(Text13.Text) == 0)
					{
						if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xC000)
						{
							System.Int32 temp_i9 = 6;
							Mdlguanfa.Zhu_Guan(ref temp_i9); //当大阀开时
						}
						Labt.Text = "正在读取表号，请稍候...";
					}
				} while (!(Timer21.Enabled == false));
				
				if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7) //天罡超声表进入检定状态
				{
					
					delay_times(1);
					//        cmd_type = "WR_INPUT_JIANDING" '检定状态
					Biao_Xuhao = (short) 0;
					Timer23.Enabled = true;
					Wancheng = false;
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
						if (Conversion.Val(Text13.Text) == 0)
						{
							if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xC000)
							{
								System.Int32 temp_i10 = 6;
								Mdlguanfa.Zhu_Guan(ref temp_i10); //当大阀开时
							}
							Labt.Text = "正在进入检定状态，请稍候...";
						}
					} while (!(Timer23.Enabled == false));
					
				}
				else if (Metertype.SelectedIndex == 5) //超声表进入检定状态
				{
					delay_times(1);
					sub_Renamed.cmd_type = "WR_INPUT_JIANDING"; //检定状态
					
					Biao_Xuhao = (short) 0;
					Timer21.Enabled = true;
					Wancheng = false;
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
						if (Conversion.Val(Text13.Text) == 0)
						{
							if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xC000)
							{
								System.Int32 temp_i11 = 6;
								Mdlguanfa.Zhu_Guan(ref temp_i11); //当大阀开时
							}
							Labt.Text = "正在进入检定状态，请稍候...";
						}
					} while (!(Timer21.Enabled == false));
				}
				
				
			}
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
			} while (!(Timerpq.Enabled == false));
			//       delay_times (Val(Text13.Text))
			
			if (sub_Renamed.Chinese == true)
			{
				Labt.Text = "判断天平是否满足检定用量";
			}
			else
			{
				Labt.Text = "Judge balance meets test volume";
			}
			if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xFF)
			{
				System.Int32 temp_i12 = 6;
				Mdlguanfa.Zhu_Kai(ref temp_i12);
			}
			TPVorbereitung();
			
			if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7) //天罡延时归零
			{
				//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Chuzhijs = 0;
				Timer13.Enabled = true;
			}
			
			
			if (sub_Renamed.Comopen == true) //如果自动采集
			{
				Autoeich();
				
			}
			else // 如果手动
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "排气结束,输入表号后点击《开始》检测";
					Text1[0].Focus();
				}
				else
				{
					Labt.Text = "Exhaust end, first enter meter No., and then click on <<start>> testing ";
					Text1[0].Focus();
				}
				
				this.Command2.Enabled = true;
				sub_Renamed.Pqschutz = true;
				Timer15.Enabled = false;
			}
		}
		
		public void qd_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If comm.MSComm1.PortOpen = False Then comm.MSComm1.PortOpen = True
			//
			//'dim fs(5) As Byte
			//    fs(0) = 255
			//    fs(1) = 249
			//    fs(2) = 0
			//    fs(3) = 0
			//    fs(4) = 254
			//
			//  comm.MSComm1.Output = fs
			Mdlguanfa.Send_Data((short) 249); //启动水泵
			delay_times(1);
		}
		
		private void listvol()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //
			short ii;
			
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(1), ;4;) = "热能表流量（质量法）检定记录 ";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(1), ;4;) = "data record for volume test  ";
			}
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3)), ;sub_Renamed.objExcel.ActiveSheet.Cells(1, 10);).Merge();
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3)), ;sub_Renamed.objExcel.ActiveSheet.Cells(1, 14);).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Bold = true;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Size = 13;
			
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(2), ;1;) = "型号：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(2, 1) = "Model：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(2, 2) = sub_Renamed.XingHao;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 1), sub_Renamed.objExcel.ActiveSheet.Cells(2, 2)).Font.Size = 10;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 1), objExcel.ActiveSheet.Cells(2, 2)).Borders.Weight = xlThin
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(2), ;3;) = "规格：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(2), ;3;) = "Dimension：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(2), ;4;) = sub_Renamed.GuiGe;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 3), sub_Renamed.objExcel.ActiveSheet.Cells(2, 4)).Font.Size = 10;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 3), objExcel.ActiveSheet.Cells(2, 4)).Borders.Weight = xlThin
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(2, 5) = "计量等级：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(2), ;5;) = "Class：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(2, 6) = sub_Renamed.YouXiaoQi;
			//       objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 6), objExcel.ActiveSheet.Cells(2, 8)).Merge
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 5), sub_Renamed.objExcel.ActiveSheet.Cells(2, 6)).Font.Size = 10;
			//     objExcel.ActiveSheet.Cells(2, 15) = "检表统计数量："
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(2, 15).Font.Color = 0xFF;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(2, 15)), ;sub_Renamed.objExcel.ActiveSheet.Cells(2, 16);).Merge();
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(2), ;17;).Font.Color = 0xFF;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(2, 17) = "";
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(3, 1) = "制造单位：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(3, 1) = "Producer：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(3, 2) = sub_Renamed.ZhizaoDanwei;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(objExcel.ActiveSheet.Cells(3, 3)), ;objExcel.ActiveSheet.Cells(3, 4);).Merge();
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(3, 1), sub_Renamed.objExcel.ActiveSheet.Cells(3, 4)).Font.Size = 10;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(3, 5) = "送检单位：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(3, 5) = "Applicant：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(3), ;6;) = sub_Renamed.SongjianDanwei;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(objExcel.ActiveSheet.Cells(3, 7)), ;objExcel.ActiveSheet.Cells(3, 10);).Merge();
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(3, 5)), ;sub_Renamed.objExcel.ActiveSheet.Cells(3, 10);).Font.Size = 10;
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(4), ;1;) = "检定日期：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(4), ;1;) = "Date：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Cells(4, 2) = DateAndTime.Today;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 1), sub_Renamed.objExcel.ActiveSheet.Cells(4, 2)).Font.Size = 10;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(4, 3) = "检定员：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(4, 3) = "Tester：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(4), ;4;) = "";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 3), sub_Renamed.objExcel.ActiveSheet.Cells(4, 4)).Font.Size = 10;
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(4, 5) = "核验员：";
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(4, 5) = "Verifier：";
			}
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(4), ;6;) = "";
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 5), sub_Renamed.objExcel.ActiveSheet.Cells(4, 6)).Font.Size = 10;
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(7, 4), objExcel.ActiveSheet.Cells(7, 4)).Borders.Weight = xlThin
			
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point + yy, 17)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1)), ;sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point + yy, 17);).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Rows 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Rows(5).WrapText = true;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point + yy, 17)).Font.Size = 10;
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 1) = "流量点";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 2) = "表  号";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 3) = "初值 (L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;4;) = "终值 (L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 5) = "示值 (L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;6;) = "m0 (kg)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 7) = "m1 (kg)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;8;) = "m1-m0     (kg)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;9;) = "温  度    (℃)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;10;) = "密  度    (kg/L)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;11;) = "标准值   (L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;12;) = "示值误差  (%)  ";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 13) = "要求±%";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;14;) = "检定结果";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 15) = "表 位 号";
				//         objExcel.ActiveSheet.Cells(5, 16) = "流量系数"
				//         objExcel.ActiveSheet.Cells(5, 17) = "分段系数"
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 1) = "Flowrate";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(5, 2) = "Meter no.";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;3;) = "V0 (L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;4;) = "V1 (L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 5) = "Indicated value(L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;6;) = "m0 (kg)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 7) = "m1 (kg)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;8;) = "m1-m0     (kg)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(5, 9) = "Temp.    (℃)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;10;) = "Density  (kg/L)";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 11) = "True value (L)";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 12) = "Error   (%)  ";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 13) = "MPE ±%";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				(5), ;14;) = "Satisfied";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.Cells(5, 15) = "Position";
				//         objExcel.ActiveSheet.Cells(5, 16) = "流量系数"
				//         objExcel.ActiveSheet.Cells(5, 17) = "分段系数"
			}
			//    For ii = 1 To Jd_point Step 1
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6 + yy + (ii - 1) * Jd_number, 1), objExcel.ActiveSheet.Cells(5 + yy + ii * Jd_number, 1)).Merge
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6 + yy + (ii - 1) * Jd_number, 13), objExcel.ActiveSheet.Cells(5 + yy + ii * Jd_number, 13)).Merge
			//       objExcel.ActiveSheet.Cells(6 + Jd_number * (xx - 1) + j, 13) = Format(Jsyq(xx - 1), "0.00")
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(4 + (ii - 1) * Jd_number, 11), objExcel.ActiveSheet.Cells(3 + ii * Jd_number, 11)).Merge
			//     Next ii
			//     yy = yy + Jd_meter * Jd_point
			//     objExcel.ActiveSheet.Cells(5 + Jd_number * Jd_point, 1) = "检定结果   说   明"
			
			//--------------以上 部分表格处理-------------
			
		}
		private void listene()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			short ii;
			if (sub_Renamed.Chinese == true)
			{
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(1, 4) = "热能表总量(质量法)检定记录";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 10)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Bold = true;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Size = 13;
				//
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 1) = "型号：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 2) = sub_Renamed.XingHao;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 1), sub_Renamed.objExcel.ActiveSheet.Cells(2, 2)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 1), objExcel.ActiveSheet.Cells(2, 2)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 3) = "规格：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 4) = sub_Renamed.GuiGe;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 3), sub_Renamed.objExcel.ActiveSheet.Cells(2, 4)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 3), objExcel.ActiveSheet.Cells(2, 4)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 5) = "计量等级：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 6) = sub_Renamed.YouXiaoQi;
				//       objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 6), objExcel.ActiveSheet.Cells(2, 8)).Merge
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 5), sub_Renamed.objExcel.ActiveSheet.Cells(2, 6)).Font.Size = 10;
				//     objExcel.ActiveSheet.Cells(2, 15) = "检表统计数量："
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 15).Font.Color = 0xFF;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 15), sub_Renamed.objExcel.ActiveSheet.Cells(2, 16)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 17).Font.Color = 0xFF;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 17) = "";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(3, 1) = "制造单位：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(3, 2) = sub_Renamed.ZhizaoDanwei;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(3, 2), objExcel.ActiveSheet.Cells(3, 4)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(3, 1), sub_Renamed.objExcel.ActiveSheet.Cells(3, 4)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(3, 5) = "送检单位：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(3, 6) = sub_Renamed.SongjianDanwei;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(3, 6), objExcel.ActiveSheet.Cells(3, 10)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(3, 5), sub_Renamed.objExcel.ActiveSheet.Cells(3, 10)).Font.Size = 10;
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(4, 1) = "检定日期：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(4, 2) = DateAndTime.Today;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 1), sub_Renamed.objExcel.ActiveSheet.Cells(4, 2)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(4, 3) = "检定员：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(4, 4) = sub_Renamed.JianCeYuan;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 3), sub_Renamed.objExcel.ActiveSheet.Cells(4, 4)).Font.Size = 10;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(4, 5) = "核验员：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(4, 6) = "";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 5), sub_Renamed.objExcel.ActiveSheet.Cells(4, 6)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(7, 4), objExcel.ActiveSheet.Cells(7, 4)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point + yy, 17)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point + yy, 17)).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Rows 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Rows(5 + yy).WrapText = true;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * sub_Renamed.Jd_point + yy, 17)).Font.Size = 10;
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(5, 1) = "检定点";
				//      objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 1), objExcel.ActiveSheet.Cells(6 + Jd_number, 1)).WrapText = True
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range("A1").ColumnWidth = 16;
				
				if (Option5.Checked == true)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 2) = "表  号";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 3) = "E0 (MJ)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 4) = "E1 (MJ)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 5) = "E1-E0 (MJ)";
					
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 6) = "m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 7) = "m1 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 8) = "m1-m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 9) = "温  度 (℃)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 10) = "密  度 (kg/L)";
					
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 11) = "标准值 (MJ)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 12) = "示值误差 (%)  ";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 13) = "要求±%";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 14) = "检定结果";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 15) = "表 位 号";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 16) = "进口温度";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 17) = "出口温度";
				}
				else if (Option6.Checked == true)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 2) = "表  号";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 3) = "E0 (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 4) = "E1 (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 5) = "E1-E0 (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 6) = "m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 7) = "m1 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 8) = "m1-m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 9) = "温  度 (℃)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 10) = "密  度 (kg/L)";
					
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 11) = "标准值 (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 12) = "示值误差 (%)  ";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 13) = "要求±%";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 14) = "检定结果";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 15) = "表 位 号";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 16) = "进口温度";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 17) = "出口温度";
				}
				
				
				
				yy = () (2 + yy + sub_Renamed.Jd_meter * sub_Renamed.Jd_point));
				
				//     For ii = 1 To Jd_point Step 1
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6 + (xx - 1) * Jd_number, 1), objExcel.ActiveSheet.Cells(5 + xx * Jd_number, 1)).Merge
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6 + (xx - 1) * Jd_number, 13), objExcel.ActiveSheet.Cells(5 + xx * Jd_number, 13)).Merge
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(4 + (ii - 1) * Jd_number, 11), objExcel.ActiveSheet.Cells(3 + ii * Jd_number, 11)).Merge
				//     Next ii
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(1, 4) = "data record for volume and energy test";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 10)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Bold = true;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(1, 3), sub_Renamed.objExcel.ActiveSheet.Cells(1, 14)).Font.Size = 13;
				//
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 1) = "Type：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 2) = sub_Renamed.XingHao;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 1), sub_Renamed.objExcel.ActiveSheet.Cells(2, 2)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 1), objExcel.ActiveSheet.Cells(2, 2)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 3) = "Dimension：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 4) = sub_Renamed.GuiGe;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 3), sub_Renamed.objExcel.ActiveSheet.Cells(2, 4)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 3), objExcel.ActiveSheet.Cells(2, 4)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 5) = "Class：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 6) = sub_Renamed.YouXiaoQi;
				//       objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(2, 6), objExcel.ActiveSheet.Cells(2, 8)).Merge
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 5), sub_Renamed.objExcel.ActiveSheet.Cells(2, 6)).Font.Size = 10;
				//     objExcel.ActiveSheet.Cells(2, 15) = "检表统计数量："
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 15).Font.Color = 0xFF;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(2, 15), sub_Renamed.objExcel.ActiveSheet.Cells(2, 16)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(2, 17).Font.Color = 0xFF;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(2, 17) = "";
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(3, 1) = "Producer：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(3, 2) = sub_Renamed.ZhizaoDanwei;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(3, 2), objExcel.ActiveSheet.Cells(3, 4)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(3, 1), sub_Renamed.objExcel.ActiveSheet.Cells(3, 4)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(3, 5) = "Applicant：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(3, 6) = sub_Renamed.SongjianDanwei;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(3, 6), objExcel.ActiveSheet.Cells(3, 10)).Merge();
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(3, 5), sub_Renamed.objExcel.ActiveSheet.Cells(3, 10)).Font.Size = 10;
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(4, 1) = "Date：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(4, 2) = DateAndTime.Today;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 1), sub_Renamed.objExcel.ActiveSheet.Cells(4, 2)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 11), objExcel.ActiveSheet.Cells(6, 11)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(4, 3) = "Tester：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(4, 4) = sub_Renamed.JianCeYuan;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 3), sub_Renamed.objExcel.ActiveSheet.Cells(4, 4)).Font.Size = 10;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(4, 5) = "Verifier：";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Cells(4, 6) = "";
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(4, 5), sub_Renamed.objExcel.ActiveSheet.Cells(4, 6)).Font.Size = 10;
				//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(7, 4), objExcel.ActiveSheet.Cells(7, 4)).Borders.Weight = xlThin
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(6 + sub_Renamed.Jd_number * (sub_Renamed.Jd_point + 1) + yy, 17)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(6 + sub_Renamed.Jd_number * (sub_Renamed.Jd_point + 1) + yy, 17)).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Rows 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Rows(5 + yy).WrapText = true;
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(5, 1), sub_Renamed.objExcel.ActiveSheet.Cells(6 + sub_Renamed.Jd_number * (sub_Renamed.Jd_point + 1) + yy, 17)).Font.Size = 10;
				
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.cells(5, 1) = "Point";
				//      objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(6, 1), objExcel.ActiveSheet.Cells(6 + Jd_number, 1)).WrapText = True
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.objExcel.ActiveSheet.range("A1").ColumnWidth = 16;
				
				if (Option5.Checked == true)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 2) = "Meter No";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 3) = "E0 (MJ)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 4) = "E1 (MJ)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 5) = "E1-E0 (MJ)";
					
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 6) = "m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 7) = "m1 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 8) = "m1-m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 9) = "Temp[℃]";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 10) = "Density (kg/L)";
					
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 11) = "True value (MJ)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 12) = "Error (%)  ";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 13) = "MPE ±%";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 14) = "Satisfied";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 15) = "Position";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 16) = "F.temp.";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 17) = "R.temp.";
				}
				else if (Option6.Checked == true)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 2) = "Meter No";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 3) = "E0 (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 4) = "E1 (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 5) = "E1-E0 (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 6) = "m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 7) = "m1 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 8) = "m1-m0 (kg)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 9) = "Temp.  (℃)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 10) = "Density (kg/L)";
					
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 11) = "True value (kWh)";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 12) = "Error (%)  ";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 13) = "MPE ±%";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.cells(5 + yy, 14) = "Satisfied";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 15) = "Position";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 16) = "F.temp.";
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.Cells(5 + yy, 17) = "R.temp.";
				}
				
				
				
				yy = () (2 + yy + sub_Renamed.Jd_meter * sub_Renamed.Jd_point));
				
			}
		}
		
		
		public void FrmZongti_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			object count1;
			object n = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.Zongtiactive = true;
			
			if (sub_Renamed.Ld5 == 2 | sub_Renamed.Ld5 == 3)
			{
				for ( = ;0; i <= 11); i++;);
				{
					Frame2[sub_Renamed.i].Enabled = false;
					Frame2[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 25080 / 11 * sub_Renamed.i)));
					Frame2[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2280)));
				}
				Frame3[1].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(8160)));
				Frame3[1].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720)));
				Frame3[1].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(5415)));
				//  Frame3(1).Width = 7335
				//  Frame3(3).Top = 8160
				//  Frame3(3).Left = 8520
				Frame6[0].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(8160)));
				Frame6[0].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(12720)));
				//  Frame6(0).Width = 8895
				Frame1.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(8160));
				Frame1.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(22800));
				Frame9.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(8160));
				Frame9.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(8520));
				Frame4.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(12000));
				Frame4.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(8520));
				Frame5[1].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(12000)));
				Frame5[1].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(18840)));
				
			}
			else if (sub_Renamed.Ld5 == 1)
			{
				for ( = ;0; i <= 11); i++;);
				{
					Frame2[sub_Renamed.i].Enabled = false;
					if (sub_Renamed.i < (11 + 1) / 2)
					{
						Frame2[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 11400 / (11 - 1) * 2 * sub_Renamed.i)));
						Frame2[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(8520)));
						
					}
					else
					{
						Frame2[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2520)));
						Frame2[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(720 + 11400 / ((11 - 1) / 2) * (11 - sub_Renamed.i))));
					}
				}
				Frame3[1].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2400)));
				Frame3[1].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(20400)));
				Frame3[1].Height = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(3255)));
				//  Frame3(1).Width = 7335
				//  Frame3(3).Top = 2400
				//  Frame3(3).Left = 25200
				Frame6[0].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(6120)));
				Frame6[0].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(18840)));
				//  Frame6(0).Width = 8895
				Frame1.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2400));
				Frame1.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(14880));
				Frame9.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(6120));
				Frame9.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(14880));
				Frame4.Top = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(12000));
				Frame4.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(14880));
				Frame5[1].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(9840)));
				Frame5[1].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(14880)));
				
			}
			
			for ( = ;1; i <= (sub_Renamed.Meter_Type0.Length - 1)); i++;);
			{
				Metertype.Items.Add(sub_Renamed.Meter_Type0[sub_Renamed.i]);
			}
			
			if (sub_Renamed.Chinese == true)
			{
				this.Text = "总量检测-质量法";
				Frame6[8].Text = "安装位置";
				Frame3[2].Text = "热量单位";
				Frame6[9].Text = "最小温差";
				
				for ( = ;0; i <= 11); i++;);
				{
					Label1[sub_Renamed.i].Text = "表号";
					Text10[2 * sub_Renamed.i].Text = "进口温度";
					Text10[2 * sub_Renamed.i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC0C0FF);
					Text10[2 * sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
					Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i].Font, 9);
					Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i].Font, false);
					Text10[2 * sub_Renamed.i].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(3360);
					
					Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i + 1].Font, false);
					Text10[2 * sub_Renamed.i + 1].Text = "出口温度";
					Text10[2 * sub_Renamed.i + 1].BackColor = System.Drawing.ColorTranslator.FromOle(0xFFFF80);
					Text10[2 * sub_Renamed.i + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
					Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i + 1].Font, 9);
					Text10[2 * sub_Renamed.i + 1].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(3840);
				}
				
				Frame7.Text = "标准温度计";
				Frame9.Text = "工具选项";
				Frame3[1].Text = "阀门状态";
				Frame3[3].Text = "工具选项";
				Frame6[0].Text = "流程提示";
				Frame1.Text = "数据采集";
				Frame5[1].Text = "操作步骤";
				
				Label19.Text = "总检数据";
				Option1.Text = "进口";
				Option2.Text = "出口";
				Command4.Text = "采集";
				Command10.Text = "停止";
				
				Label3[1].Text = "进口            (Ω)        ℃";
				Label3[2].Text = "出口            (Ω)         ℃";
				//Command13.Caption = "读表号"
				Label22.Text = " 初值  回零";
				Option3.Text = "是";
				Option4.Text = "否";
				Command8.Text = "加序号";
				Command9.Text = "去序号";
				Command5.Text = "下一步";
				//Lab(0).Caption = "水"
				//Lab(9).Caption = "水"
				//Lab(0).Visible = True
				//Lab(9).Visible = True
				//Lab(1).Caption = "进     阀"
				//Lab(2).Caption = "小流量阀"
				//Lab(3).Caption = "中流量阀"
				//Lab(4).Caption = "大流量阀"
				//Lab(5).Caption = "放     阀"
				//Lab(1).FontSize = 14
				//Lab(2).FontSize = 14
				//Lab(3).FontSize = 14
				//Lab(4).FontSize = 14
				//Lab(5).FontSize = 14
				状态.Text = "检定状态";
				时间.Text = "同步时间";
				
				
				Label8[0].Text = "天平质量";
				Label8[4].Text = "瞬时流量";
				Label8[7].Text = "进口温度";
				Label8[5].Text = "出口温度";
				Label20.Text = "检定点：";
				Label7[0].Text = "流量点     m/h";
				Label21.Text = "流  程：";
				Label18.Text = "温差点      K";
				Command3.Text = "参数";
				Command1.Text = "参数";
				pq.Text = "排气";
				Combc.Text = "保存";
				Command2.Text = "开始";
				Command6.Text = "退出";
				wiederpruf.Text = "重复检测";
				Command11.Text = "终止检测";
				qd.Text = "启动水泵";
				tz.Text = "关闭水泵";
				Labt.Text = "请首先进行参数设置!";
				读表号一.Text = "读取表号";
				读表号二.Text = "读取表号";
				读表号三.Text = "读取表号";
				读表号四.Text = "读取表号";
				读表号五.Text = "读取表号";
				读表号六.Text = "读取表号";
				读表号七.Text = "读取表号";
				读表号八.Text = "读取表号";
				读表号九.Text = "读取表号";
				读表号十.Text = "读取表号";
				读表号十一.Text = "读取表号";
				读表号十二.Text = "读取表号";
				
				状态一.Text = "检定状态";
				状态二.Text = "检定状态";
				状态三.Text = "检定状态";
				状态四.Text = "检定状态";
				状态五.Text = "检定状态";
				状态六.Text = "检定状态";
				状态七.Text = "检定状态";
				状态八.Text = "检定状态";
				状态九.Text = "检定状态";
				状态十.Text = "检定状态";
				状态十一.Text = "检定状态";
				状态十二.Text = "检定状态";
				
				读数1.Text = "读表数据";
				读数2.Text = "读表数据";
				读数3.Text = "读表数据";
				读数4.Text = "读表数据";
				读数5.Text = "读表数据";
				读数6.Text = "读表数据";
				读数7.Text = "读表数据";
				读数8.Text = "读表数据";
				读数9.Text = "读表数据";
				读数10.Text = "读表数据";
				读数11.Text = "读表数据";
				读数12.Text = "读表数据";
				
				Text13.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4080));
				Label7[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4050)));
				Label12.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(5250));
				Label10.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(3720));
			}
			else
			{
				this.Text = "Complete test";
				Frame6[8].Text = "Insta.Position";
				Frame3[2].Text = "Unit";
				Frame6[9].Text = "Min. Tem. differ.";
				
				for ( = ;0; i <= 11); i++;);
				{
					Label1[sub_Renamed.i].Text = "NO.";
					Text10[2 * sub_Renamed.i].Text = "In.Temp";
					Text10[2 * sub_Renamed.i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC0C0FF);
					Text10[2 * sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
					Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i].Font, 9);
					Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i].Font, false);
					Text10[2 * sub_Renamed.i].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(3360);
					Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i + 1].Font, false);
					Text10[2 * sub_Renamed.i + 1].Text = "Ou.Temp";
					Text10[2 * sub_Renamed.i + 1].BackColor = System.Drawing.ColorTranslator.FromOle(0xFFFF80);
					Text10[2 * sub_Renamed.i + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
					Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i + 1].Font, 9);
					Text10[2 * sub_Renamed.i + 1].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(3840);
				}
				
				Frame7.Text = "Standard thermometer";
				Frame9.Text = "Operation";
				Frame3[1].Text = "Valves";
				Frame3[3].Text = "Tools";
				Frame6[0].Text = "Information";
				Frame1.Text = "data";
				Frame5[1].Text = "Steps";
				
				Label19.Text = "";
				Option1.Text = "Flow";
				Option2.Text = "Return";
				Command4.Text = "Reading";
				Command10.Text = "Stop";
				
				Label3[1].Text = "Inl.            (Ω)        ℃";
				Label3[2].Text = "Out.            (Ω)         ℃";
				//Command13.Caption = "No. read"
				Label22.Text = " Vo-> Zero";
				Option3.Text = "Yes";
				Option4.Text = "No";
				Command8.Text = "NO. add";
				Command9.Text = "NO. clear";
				Command5.Text = "Next";
				
				//Lab(1).Caption = "I n l e t"
				//Lab(2).Caption = "Q m i n"
				//Lab(3).Caption = "Q m i d"
				//Lab(4).Caption = "Q m a x"
				//Lab(5).Caption = "O u t l e t"
				//Lab(1).FontSize = 11
				//Lab(2).FontSize = 11
				//Lab(3).FontSize = 11
				//Lab(4).FontSize = 11
				//Lab(5).FontSize = 11
				
				状态.Text = "Status";
				时间.Text = "Time";
				
				
				Label8[0].Text = "Mass";
				Label8[4].Text = "Flowrate";
				Label8[7].Text = "F.temp.";
				Label8[5].Text = "R.temp.";
				Label20.Text = " Q: ";
				Label7[0].Text = "     .point     m/h";
				Label21.Text = "Process：";
				Label18.Text = "Δθ:       K";
				Command3.Text = "Setup";
				Command1.Text = "Setup";
				pq.Text = "Exhaust";
				Combc.Text = "Save";
				Command2.Text = "Start";
				Command6.Text = "Exit";
				wiederpruf.Text = "Repeat";
				Command11.Text = "Cancel";
				qd.Text = "Pump On";
				tz.Text = "Pump Off";
				Labt.Text = "Please first click on <<Setup>>! ";
				读表号一.Text = "No. Read";
				读表号二.Text = "No. Read";
				读表号三.Text = "No. Read";
				读表号四.Text = "No. Read";
				读表号五.Text = "No. Read";
				读表号六.Text = "No. Read";
				读表号七.Text = "No. Read";
				读表号八.Text = "No. Read";
				读表号九.Text = "No. Read";
				读表号十.Text = "No. Read";
				读表号十一.Text = "No. Read";
				读表号十二.Text = "No. Read";
				
				状态一.Text = "Status";
				状态二.Text = "Status";
				状态三.Text = "Status";
				状态四.Text = "Status";
				状态五.Text = "Status";
				状态六.Text = "Status";
				状态七.Text = "Status";
				状态八.Text = "Status";
				状态九.Text = "Status";
				状态十.Text = "Status";
				状态十一.Text = "Status";
				状态十二.Text = "Status";
				
				读数1.Text = "Read";
				读数2.Text = "Read";
				读数3.Text = "Read";
				读数4.Text = "Read";
				读数5.Text = "Read";
				读数6.Text = "Read";
				读数7.Text = "Read";
				读数8.Text = "Read";
				读数9.Text = "Read";
				读数10.Text = "Read";
				读数11.Text = "Read";
				读数12.Text = "Read";
				
				Text13.Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4560)));
				Label7[3].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(4530)));
				Label12.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(5650));
				Label10.Left = (int) (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(3720));
			}
			
			
			
			Timer1.Enabled = false;
			//Timer2.Enabled = False
			Timer11.Enabled = false;
			//Timer3.Enabled = False
			Timer7.Enabled = false; //误差限计算
			Timer8.Enabled = false; //温度采集
			Timer9.Enabled = false; //瞬流计算
			Timer10.Enabled = false;
			Timer12.Enabled = false;
			Timer13.Enabled = false; //等待初值自动回零计时
			Timer15.Enabled = false; //瞬流采集
			Timer14.Enabled = false; //标温采集（唯立）
			Timer16.Enabled = false; //标温采集（唯立）
			Timer18.Enabled = false; //标温采集（华易）
			Timer19.Enabled = false; //标温采集（华易）
			Timer17.Enabled = false; //标温采集平均
			TimerEne.Enabled = false; //热量与流量检定表格
			
			Command1.Focus();
			for ( = ;0; i <= 11); i++;);
			{
				Frame2[sub_Renamed.i].Enabled = false;
				Text19[sub_Renamed.i + 1].Visible = false;
			}
			
			Image1.Enabled = false;
			Image2.Enabled = false;
			
			
			读表号一.Enabled = false;
			读表号二.Enabled = false;
			读表号三.Enabled = false;
			读表号四.Enabled = false;
			读表号五.Enabled = false;
			读表号六.Enabled = false;
			读表号七.Enabled = false;
			读表号八.Enabled = false;
			读表号九.Enabled = false;
			读表号十.Enabled = false;
			读表号十一.Enabled = false;
			读表号十二.Enabled = false;
			
			状态一.Enabled = false;
			状态二.Enabled = false;
			状态三.Enabled = false;
			状态四.Enabled = false;
			状态五.Enabled = false;
			状态六.Enabled = false;
			状态七.Enabled = false;
			状态八.Enabled = false;
			状态九.Enabled = false;
			状态十.Enabled = false;
			状态十一.Enabled = false;
			状态十二.Enabled = false;
			
			读数1.Enabled = false;
			读数2.Enabled = false;
			读数3.Enabled = false;
			读数4.Enabled = false;
			读数5.Enabled = false;
			读数6.Enabled = false;
			读数7.Enabled = false;
			读数8.Enabled = false;
			读数9.Enabled = false;
			读数10.Enabled = false;
			读数11.Enabled = false;
			读数12.Enabled = false;
			
			Chu1.Enabled = false;
			Chu2.Enabled = false;
			Chu3.Enabled = false;
			Chu4.Enabled = false;
			Chu5.Enabled = false;
			Chu6.Enabled = false;
			Chu7.Enabled = false;
			Chu8.Enabled = false;
			Chu9.Enabled = false;
			Chu10.Enabled = false;
			Chu11.Enabled = false;
			Chu12.Enabled = false;
			
			//Chu1.Visible = False
			//Chu2.Visible = False
			//Chu3.Visible = False
			//Chu4.Visible = False
			//Chu5.Visible = False
			//Chu6.Visible = False
			//Chu7.Visible = False
			//Chu8.Visible = False
			//Chu9.Visible = False
			//Chu10.Visible = False
			//Chu11.Visible = False
			//Chu12.Visible = False
			
			
			if (sub_Renamed.Ld5 == 2 | sub_Renamed.Ld5 == 3)
			{
				for ( = ;1; i <= 7); i++;);
				{
					if (sub_Renamed.Ld4 == 3)
					{
						Siajin[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1200)));
						Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (sub_Renamed.i - 1) * 5100 / 4)));
						if (sub_Renamed.i == 6)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (4 - 1) * 5100 / 4)));
						}
						if (sub_Renamed.i == 7)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (5 - 1) * 5100 / 4)));
						}
						Lab[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2355)));
						Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 4)));
						if (sub_Renamed.i == 6)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (4 - 1) * 5100 / 4)));
						}
						if (sub_Renamed.i == 7)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 4)));
						}
						Shapzsd[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(4035)));
						Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 4)));
						if (sub_Renamed.i == 6)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (4 - 1) * 5100 / 4)));
						}
						if (sub_Renamed.i == 7)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 4)));
						}
						Siajin[4].Visible = false;
						Siajin[5].Visible = false;
						Lab[4].Visible = false;
						Lab[5].Visible = false;
						Shapzsd[4].Visible = false;
						Shapzsd[5].Visible = false;
						Lab[3].Text = "中流量阀";
					}
					else if (sub_Renamed.Ld4 == 4)
					{
						Siajin[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1200)));
						Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (sub_Renamed.i - 1) * 5100 / 5)));
						if (sub_Renamed.i == 6)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (5 - 1) * 5100 / 5)));
						}
						if (sub_Renamed.i == 7)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (6 - 1) * 5100 / 5)));
						}
						Lab[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2355)));
						Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 5)));
						if (sub_Renamed.i == 6)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 5)));
						}
						if (sub_Renamed.i == 7)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (6 - 1) * 5100 / 5)));
						}
						Shapzsd[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(4035)));
						Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 5)));
						if (sub_Renamed.i == 6)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 5)));
						}
						if (sub_Renamed.i == 7)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (6 - 1) * 5100 / 5)));
						}
						Siajin[4].Visible = true;
						Siajin[5].Visible = false;
						Lab[4].Visible = true;
						Lab[5].Visible = false;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = false;
					}
					else if (sub_Renamed.Ld4 == 5)
					{
						Siajin[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1200)));
						Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (sub_Renamed.i - 1) * 5100 / 6)));
						Lab[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2355)));
						Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 6)));
						Shapzsd[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(4035)));
						Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 6)));
						Siajin[4].Visible = true;
						Siajin[5].Visible = true;
						Lab[4].Visible = true;
						Lab[5].Visible = true;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = true;
					}
				}
				
				
			}
			else if (sub_Renamed.Ld5 == 1)
			{
				
				for ( = ;1; i <= 7); i++;);
				{
					if (sub_Renamed.Ld4 == 3)
					{
						Siajin[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(480)));
						Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (sub_Renamed.i - 1) * 5100 / 4)));
						if (sub_Renamed.i == 6)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (4 - 1) * 5100 / 4)));
						}
						if (sub_Renamed.i == 7)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (5 - 1) * 5100 / 4)));
						}
						Lab[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1395)));
						Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 4)));
						if (sub_Renamed.i == 6)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (4 - 1) * 5100 / 4)));
						}
						if (sub_Renamed.i == 7)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 4)));
						}
						Shapzsd[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2715)));
						Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 4)));
						if (sub_Renamed.i == 6)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (4 - 1) * 5100 / 4)));
						}
						if (sub_Renamed.i == 7)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 4)));
						}
						Siajin[4].Visible = false;
						Siajin[5].Visible = false;
						Lab[4].Visible = false;
						Lab[5].Visible = false;
						Shapzsd[4].Visible = false;
						Shapzsd[5].Visible = false;
						Lab[3].Text = "中流量阀";
					}
					else if (sub_Renamed.Ld4 == 4)
					{
						Siajin[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(480)));
						Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (sub_Renamed.i - 1) * 5100 / 5)));
						if (sub_Renamed.i == 6)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (5 - 1) * 5100 / 5)));
						}
						if (sub_Renamed.i == 7)
						{
							Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (6 - 1) * 5100 / 5)));
						}
						Lab[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1395)));
						Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 5)));
						if (sub_Renamed.i == 6)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 5)));
						}
						if (sub_Renamed.i == 7)
						{
							Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (6 - 1) * 5100 / 5)));
						}
						Shapzsd[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2715)));
						Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 5)));
						if (sub_Renamed.i == 6)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (5 - 1) * 5100 / 5)));
						}
						if (sub_Renamed.i == 7)
						{
							Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (6 - 1) * 5100 / 5)));
						}
						Siajin[4].Visible = true;
						Siajin[5].Visible = false;
						Lab[4].Visible = true;
						Lab[5].Visible = false;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = false;
					}
					else if (sub_Renamed.Ld4 == 5)
					{
						Siajin[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(480)));
						Siajin[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(900 + (sub_Renamed.i - 1) * 5100 / 6)));
						Lab[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(1395)));
						Lab[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 6)));
						Shapzsd[sub_Renamed.i].Top = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(2715)));
						Shapzsd[sub_Renamed.i].Left = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1020 + (sub_Renamed.i - 1) * 5100 / 6)));
						Siajin[4].Visible = true;
						Siajin[5].Visible = true;
						Lab[4].Visible = true;
						Lab[5].Visible = true;
						Lab[3].Text = "中流一阀";
						Shapzsd[4].Visible = true;
						Shapzsd[5].Visible = true;
					}
				}
				
			}
			
			
			sub_Renamed.Jdks2 = true;
			kaishi = false;
			Zdtfm = true;
			sub_Renamed.Jbqschutz = false;
			sub_Renamed.Comopen = false; //串口打开标识
			sub_Renamed.Firstmal = (short) 0;
			sub_Renamed.Tem = false;
			sub_Renamed.Readone = true;
			if (sub_Renamed.Jbqschutz == false)
			{
				System.Int32 temp_i = 1;
				Mdlguanfa.Zhu_Guan(ref temp_i);
			}
			sub_Renamed.Flagnext = false;
			Command5.Visible = false;
			Text13.Visible = false;
			Timerpq.Enabled = false;
			//Caption = "自动热量检测"
			
			this.Command2.Enabled = false;
			pq.Enabled = false;
			sub_Renamed.Pqschutz = false;
			Command3.Visible = false;
			wiederpruf.Enabled = false;
			sub_Renamed.Flagcom = false;
			sub_Renamed.Rechen = false;
			
			TPcom();
			delay_times(1);
			
			Label12.Visible = false;
			Label10.Visible = false;
			Label18.Visible = false;
			Label7[0].Visible = false;
			Label7[1].Visible = false;
			
			Option3.Checked = false; //初值回零否
			
			
			comm.Default.MSComm1.CommPort = sub_Renamed.Com1;
			MSComm1.CommPort = sub_Renamed.Com4; //标温
			MSComm2.CommPort = sub_Renamed.Com2; //天平
			MSComm2.RThreshold = (short) 30;
			if (sub_Renamed.Bizerba == true || sub_Renamed.Mettler == true)
			{
				MSComm2.InputMode = ;;
			}
			else
			{
				MSComm2.InputMode = ;;
			}
			MSComm5.CommPort = sub_Renamed.Com3; //温度测量
			
			MSComm5.InputMode = ;;
			MSComm5.Settings = "9600,n,8,2"; //strCommPara
			//   MSComm5.PortOpen = True
			MSComm5.RThreshold = (short) 10;
			
			//MSComm3.InputLen = 400
			if (MSComm5.PortOpen == true)
			{
				MSComm5.PortOpen = false;
			}
			if (MSComm2.PortOpen == true)
			{
				MSComm2.PortOpen = false;
			}
			if (MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			if (comm.Default.MSComm1.PortOpen == true)
			{
				MSComm1.PortOpen = false;
			}
			delay_times(1);
			if (comm.Default.MSComm1.PortOpen == false)
			{
				MSComm1.PortOpen = true;
			}
			if (MSComm2.PortOpen == false)
			{
				MSComm2.PortOpen = true;
			}
			
			
			
			Wendujisuan = (short) 0;
			Js = (short) 0;
			Timer8.Enabled = true;
			Llxuanze = (short) 0;
			//Timer15.Enabled = True
			
			
			//    Close #2
			//    Open App.Path + "\Biaohao.dll" For Input As #2
			//    Input #2, Biaobianhao
			//    Close #2
			
			FileSystem.FileClose(23);
			Module1.sFileCanShu = (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\pt_canshu.dll";
			FileSystem.FileOpen(23, Module1.sFileCanShu, OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			for (n = 1; (int) n <= 7; n = (int) n + 1)
			{
				//UPGRADE_WARNING: 未能解析对象 n 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				FileSystem.Input(23, ref mi[(int) n]);
			}
			FileSystem.FileClose(23);
			
			FileSystem.FileClose(11);
			FileSystem.FileOpen(11, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\Pt_xinghao.dll", OpenMode.Input, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
			FileSystem.Input(11, ref Pt_XH);
			FileSystem.FileClose(11);
			
			
			//zhu_guan(8) '关排水
			
			for ( = ;0; i <= 11; i++;);
			{
				Text1[sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0); //将需进行流量参数修正标识的红色返回到黑色。
				Text1[sub_Renamed.i].Text = "";
				Text1[sub_Renamed.i].Width = () (Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsX(1410)));
				Text6[sub_Renamed.i].Text = "";
				Text8[sub_Renamed.i].Text = "";
				Text9[sub_Renamed.i].Text = "";
				sub_Renamed.TemVor[sub_Renamed.i] = 0;
				sub_Renamed.TemRuc[sub_Renamed.i] = 0;
			}
			
			//For i = 0 To 23
			//Text10(i).Font.SIZE = 12 '温度显示大小。
			//Next i
			
			for ( = ;0; i <= 11; i++;);
			{
				Text33[sub_Renamed.i].Text = "";
				Text44[sub_Renamed.i].Text = "";
				Text22[sub_Renamed.i].Text = "";
				Text11[sub_Renamed.i].Text = "";
				Text11[sub_Renamed.i].Visible = false;
				//Text22(i).Visible = False
				Text33[sub_Renamed.i].Visible = false;
				Text44[sub_Renamed.i].Visible = false;
				Text10[2 * sub_Renamed.i].Text = "进口温度";
				Text10[2 * sub_Renamed.i].BackColor = System.Drawing.ColorTranslator.FromOle(0xC0C0FF);
				Text10[2 * sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
				Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i].Font, 10);
				Text10[2 * sub_Renamed.i].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(3360);
				Text10[2 * sub_Renamed.i + 1].Text = "出口温度";
				Text10[2 * sub_Renamed.i + 1].BackColor = System.Drawing.ColorTranslator.FromOle(0xFFFF80);
				Text10[2 * sub_Renamed.i + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
				Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i + 1].Font, 10);
				Text10[2 * sub_Renamed.i + 1].Top = Microsoft.VisualBasic.Compatibility.VB6.Support.TwipsToPixelsY(3840);
			}
			
			aa0[0] = 0xFE;
			//UPGRADE_WARNING: 未能解析对象 count1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			count1 = 0;
			
			//   '*  设置接收缓冲区的大小，当收到10个字节开始响应事件
			
		}
		
		
		
		public void Siajin_Enter(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Siajin.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//If Jbqschutz = False Then
			//Siajin(1).value = False       '开关状态
			//Lab(1).ForeColor = &HFF& '深蓝
			//Shapzsd(1).BackColor = &HFF& '天蓝
			//End If
			//
			Command1.Focus();
			if ([Index;].value == true;);
			{
				Mdlguanfa.Zhu_Kai(ref Index);
				//
				//      If Index = 1 Then 'Or Index = 3 Or Index = 4 Then
				//       Jbqschutz = True
				//       Send_Data (235)
				//       delay_times (15)
				//      Send_Data (234)
				//       End If
				//
				//Siajin(0).value = False       '开关状态
				//Lab(0).ForeColor = &HFF& '深蓝
				//Shapzsd(0).BackColor = &HFF& '天蓝
				//End If
				//If kaishi = True Then
				//Jsz = 0
				//Llds = 0
				//Timer1.Enabled = True
				//End If
				//End If
				//
				//    If Index = 5 Then
				//     MsgBox "注意：排空水后不能立即开始检定，应先向天平注水2kg左右！"
				//    End If
				
			}
			else
			{
				Mdlguanfa.Zhu_Guan(ref Index);
				//     If Index = 0 Then Or Index = 3 Or Index = 4 Then
				
				
				//    Timer1.Enabled = False
				//    If Index = 2 Or Index = 3 Or Index = 4 Then
				//     Wcll = Text3(1).Text
				//    End If
				//
				//    End If
			}
		}
		
		
		public void Text1_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text1.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text1[Index + 1].Focus();
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		
		
		
		private void Text2_KeyPress(short Index, short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//If KeyAscii = 13 Then
			//   ZlChuzhi(Index) = Val(Text2(Index).Text)
			//     If frmzjsz.Option6.value = True Then
			//       Text6(Index).SetFocus
			//     Else
			//     Text2(Index + 1).SetFocus
			//     If Len(Text1(End_biaowei).Text) > 0 And Len(Text2(End_biaowei).Text) > 0 Then Command5.SetFocus
			//     End If
			//End If
		}
		public void text15_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				//           Text15.SetFocus
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text15.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text15_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option1.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_Rpt = mi[4];
				//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_a8 = mi[5];
				//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_b8 = mi[6];
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text15.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 20 & sub_Renamed.pt_om <= 40)
				{
					pt_centgrade();
					Text12.Text = Text12.Text(sub_Renamed.centgrade, "0.000");
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text15.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 99 & sub_Renamed.pt_om <= 140)
				{
					Text12.Text = Text12.Text(standom_t1((float) (Conversion.Val(Text15.Text))), "0.000");
				}
			}
		}
		public void text16_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				Text15.Focus();
			}
			
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text16.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text16_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (frmjsbdz.Default.Option1.Checked == true)
			{
				//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_Rpt = mi[1];
				//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_a8 = mi[2];
				//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_b8 = mi[3];
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text16.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 20 & sub_Renamed.pt_om <= 40)
				{
					pt_centgrade();
					Text14.Text = Text14.Text(sub_Renamed.centgrade, "0.000");
				}
				
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.pt_om = Conversion.Val(Text16.Text);
				//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.pt_om > 99 & sub_Renamed.pt_om <= 140)
				{
					Text14.Text = Text14.Text(standom_t((float) (Conversion.Val(Text16.Text))), "0.000");
				}
			}
		}
		
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text3.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text3_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text3.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Index == 0)
			{
				
				if (Conversion.Val(Text3[0].Text) >= 105)
				{
					System.Int32 temp_i = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i);
					delay_times(1);
					
					System.Int32 temp_i2 = 6;
					Mdlguanfa.Zhu_Guan(ref temp_i2);
					delay_times(1);
					if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
					{
						System.Int32 temp_i3 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i3); //中流量开2
						delay_times(1);
					}
					if (sub_Renamed.Ld4 == 5)
					{
						System.Int32 temp_i4 = 5;
						Mdlguanfa.Zhu_Guan(ref temp_i4); //中流量开3
						delay_times(1);
					}
					System.Int32 temp_i5 = 3;
					Mdlguanfa.Zhu_Guan(ref temp_i5);
					delay_times(1);
					System.Int32 temp_i6 = 2;
					Mdlguanfa.Zhu_Guan(ref temp_i6);
					delay_times(1);
					Mdlguanfa.Send_Data((short) 250); //
					delay_times(1);
					
					if (Fsbz == true)
					{
						if (sub_Renamed.Chinese == true)
						{
							MessageBox.Show("超出天平最大秤量，本次检定数据无效，请退出子程序并重新开始检定");
						}
						else
						{
							MessageBox.Show("Beyond the largest weighing scale, the test was terminated, please exit and restart the program");
						}
					}
					return;
				}
			}
		}
		
		private void Caiji()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			delay_times(1);
			do
			{
				Dtianping = (float) (Conversion.Val(Text3[0].Text));
				System.Windows.Forms.Application.DoEvents();
				delay_times((0.5));F;);
			} while (!(Dtianping >= sub_Renamed.Jd_liang[xx - 1] + sub_Renamed.Zlm0));
			
		}
		
		
		private void Text4_KeyPress(short Index, short KeyAscii)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//If Comopen = False Then
			//   If KeyAscii = 13 Then
			//         If Len(Text1(Index).Text) > 0 Then
			//          ZlShizhi(Index) = Val(Text4(Index).Text - Text2(Index).Text)     '体积示值
			//         Text5(Index).Text = Format((ZlShizhi(Index) - (Zlm1 - Zlm0) / ZlMiDu(Index) * 0.9971) / ((Zlm1 - Zlm0) / ZlMiDu(Index) * 0.9971) * 100, "0.0")
			//            If Abs(Text5(Index).Text) > JsyqV(xx - 1) * 0.75 Then
			//              Text5(Index).ForeColor = &HFF& ' 红
			//              Text1(Index).ForeColor = &HFF& '将表号变红，表示该表需进行流量参数修正。
			//             Else
			//              Text5(Index).ForeColor = &H0&
			//             End If
			//
			//         ZlZhongzhi(Index) = Val(Text4(Index).Text)
			//        End If
			//        If frmzjsz.Option6.value = True Then
			//        Text8(Index).SetFocus
			//        Else
			//         Text4(Index + 1).SetFocus
			//        End If
			//
			//'           If Len(Text1(Index).Text) > 0 And Len(Text4(Index).Text) > 0 Then Sbs = Sbs + 1
			//    End If
			//End If
		}
		
		
		private void Text4_Change(short Index)
		{
			//On Error Resume Next
			//
			//If Val(Text4(Index).Text) <> 0 Then
			//If Comopen = True And Rechen = True Then
			//llZhongzhi(Index) = Val(Text4(Index).Text)
			//lLChuzhi(Index) = Val(Text2(Index).Text)
			//        If Len(Text1(Index).Text) = 8 Then
			//            LlShizhi(Index) = Val(Text4(Index).Text - Text2(Index).Text)     '体积示值
			//         Text5(Index).Text = Format((LlShizhi(Index) / ((Zlm1 - Zlm0) / ZlMiDu(Index) * 0.9971) - 1) * 100, "0.0")
			//
			//            If Abs(Text5(Index).Text) > JsyqV(xx - 1) * 0.75 Then
			//              Text5(Index).ForeColor = &HFF& ' 红
			//              Text1(Index).ForeColor = &HFF& '将表号变红，表示该表需进行流量参数修正。
			//             Else
			//              Text5(Index).ForeColor = &H0&
			//             End If
			//        End If
			//End If
			//End If
		}
		
		public void Text6_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text6.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				if (sub_Renamed.Comopen == false)
				{
					
					sub_Renamed.ZlChuzhi[Index] = (float) (Conversion.Val(Text6[Index].Text));
					for ( = ;Index; i <= sub_Renamed.End_biaowei - 1); i++;);
					{
						if (Strings.Len(Text1[sub_Renamed.i + 1].Text) > 0)
						{
							goto ss;
						}
					}
ss:
					Text6[sub_Renamed.i + 1].Focus();
					
					if (Strings.Len(Text1[sub_Renamed.End_biaowei].Text) > 0 && Strings.Len(Text6[sub_Renamed.End_biaowei].Text) > 0)
					{
						Command5.Focus();
					}
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text8.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text8_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Text8.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Strings.Len(Text8[Index].Text) != 0)
			{
				if (sub_Renamed.Comopen == true && sub_Renamed.Rechen == true)
				{
					
					
					//计算热量示值误差
					
					stb();
					sub_Renamed.JsyqE[xx - 1] = float.Parse((1 + System.Math.Abs(sub_Renamed.JsyqV[xx - 1] + 4 * Conversion.Val(Twcd.Text) / ((double.Parse(Text14.Text)) - double.Parse(Text12.Text)))), "0.00");
					
					//      For i = 0 To End_biaowei
					if (Strings.Len(Text1[Index].Text) == 8)
					{
						sub_Renamed.ZlZhongzhi[Index] = (float) (Conversion.Val(Text8[Index].Text));
						sub_Renamed.ZlChuzhi[Index] = (float) (Conversion.Val(Text6[Index].Text));
						
						sub_Renamed.ZlShizhi[Index] = sub_Renamed.ZlZhongzhi[Index] - sub_Renamed.ZlChuzhi[Index]; //热量示值
						sub_Renamed.BiaozhunzhiE[Index] = (float) ((sub_Renamed.Zlm1 - sub_Renamed.Zlm0) / sub_Renamed.ZlMiDu[Index] * Kxs * 0.9971);
						Text9[Index].Text = Text9((sub_Renamed.ZlShizhi[Index] / sub_Renamed.BiaozhunzhiE[Index] - 1) * 100, "0.0");
						if (System.Math.Abs(System.Convert.ToDouble(Text9[Index].Text)) > sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE)
						{
							Text9[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); // 红
							Text1[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //将表号变红，表示该表需进行流量参数修正。
						}
						else
						{
							Text9[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
						}
					}
					//      Next i
					
					
				}
			}
		}
		public void Text8_KeyPress(System.Object eventSender, System.Windows.Forms.KeyPressEventArgs eventArgs)
		{
			short KeyAscii = (short) (Strings.Asc(eventArgs.KeyChar));
			short Index = Text8.GetIndex(eventSender);
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (KeyAscii == 13)
			{
				if (sub_Renamed.Comopen == false)
				{
					
					
					sub_Renamed.ZlChuzhi[Index] = (float) (Conversion.Val(Text6[Index].Text));
					sub_Renamed.ZlZhongzhi[Index] = (float) (Conversion.Val(Text8[Index].Text));
					stb();
					sub_Renamed.JsyqE[xx - 1] = float.Parse(JsyqE(1 + System.Math.Abs(sub_Renamed.JsyqV[xx - 1] + 4 * Conversion.Val(Twcd.Text) / ((double.Parse(Text14.Text)) - double.Parse(Text12.Text))), "0.00"));
					
					if (Strings.Len(Text1[Index].Text) > 0)
					{
						sub_Renamed.ZlShizhi[Index] = sub_Renamed.ZlZhongzhi[Index] - sub_Renamed.ZlChuzhi[Index]; //热量示值
						sub_Renamed.BiaozhunzhiE[Index] = (float) ((sub_Renamed.Zlm1 - sub_Renamed.Zlm0) / sub_Renamed.ZlMiDu[Index] * Kxs * 0.9971);
						Text9[Index].Text = Text9((sub_Renamed.ZlShizhi[Index] / sub_Renamed.BiaozhunzhiE[Index] - 1) * 100, "0.0");
						if (System.Math.Abs(System.Convert.ToDouble(Text9[Index].Text)) > sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE)
						{
							Text9[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); // 红
							Text1[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF); //将表号变红，表示该表需进行流量参数修正。
						}
						else
						{
							Text9[Index].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
							
						}
					}
					
					for ( = ;Index; i <= sub_Renamed.End_biaowei - 1); i++;);
					{
						if (Strings.Len(Text1[sub_Renamed.i + 1].Text) > 0)
						{
							goto ss;
						}
					}
ss:
					Text8[sub_Renamed.i + 1].Focus();
					
				}
			}
			eventArgs.KeyChar = Strings.Chr(KeyAscii);
			if (KeyAscii == 0)
			{
				eventArgs.Handled = true;
			}
		}
		public void Timer1_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//  Jsz = Jsz + 1
			//
			//  If Jsz >= 8 Then
			//
			//                          Llds = Val(Text3(1).Text)
			//'                           If Llds <= 0.01 Then Llds = Jd_flow(xx - 1)
			//'                            If YouXiaoQi = 1 Then  '确保流量不为零
			//'                               Jsyq(xx - 1) = 1 + 0.01 * Val(frmzjsz.Tdian(2).Text) / Llds '误差限Eq
			//'                            ElseIf YouXiaoQi = 2 Then
			//'                               Jsyq(xx - 1) = 2 + 0.02 * Val(frmzjsz.Tdian(2).Text) / Llds
			//'                            ElseIf YouXiaoQi = 3 Then
			//'                               Jsyq(xx - 1) = 3 + 0.05 * Val(frmzjsz.Tdian(2).Text) / Llds
			//'                            End If
			//'                            If Jsyq(xx - 1) > 5 Then Jsyq(xx - 1) = 5
			//                            Jsz = 0
			//                            Timer1.Enabled = False
			//  End If
		}
		
		public void Timer10_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Label12.Visible = true;
			
			Text7.Text = (Conversion.Val(Text7.Text) + 1).ToString();
			
			if (double.Parse(Text7.Text) > 10)
			{
				if (Conversion.Val(Text3[1].Text) == 0)
				{
					Label12.Text = "???";
				}
				else
				{
					Label12.Text = Label12.Text((sub_Renamed.Jd_liang[xx - 1] + sub_Renamed.Zlm0 - Conversion.Val(Text3[0].Text)) / Conversion.Val(Text3[1].Text) * 3.6, "0");
				}
			}
			else
			{
				sub_Renamed.zeit = (float) (sub_Renamed.Jd_liang[xx - 1] / sub_Renamed.Jd_flow[xx - 1] * 3.6);
				Label12.Text = Label12.Text(sub_Renamed.zeit - double.Parse(Text7.Text), "0");
			}
			
			if (Conversion.Val(Label12.Text) <= 1 && Label12.Text != "???")
			{
				delay_times(2);
				Label12.Visible = false;
				Timer10.Enabled = false;
			}
		}
		
		public void Timer11_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//     Textjs.Text = Val(Textjs.Text) + 0.01
			
			sub_Renamed.wdjs++;
			if (sub_Renamed.wdjs > 190000)
			{
				sub_Renamed.wdjs = 10;
			}
			sub_Renamed.wdcz[sub_Renamed.wdjs] = (float) (Conversion.Val(Text3[4].Text));
			sub_Renamed.wdzz[sub_Renamed.wdjs] = (float) (Conversion.Val(Text3[5].Text));
			
			sub_Renamed.jkwd = sub_Renamed.jkwd + sub_Renamed.wdcz[sub_Renamed.wdjs];
			sub_Renamed.ckwd = sub_Renamed.ckwd + sub_Renamed.wdzz[sub_Renamed.wdjs];
			
			sub_Renamed.inlet = float.Parse(((sub_Renamed.jkwd) / sub_Renamed.wdjs), "0.0");
			sub_Renamed.outlet = float.Parse(((sub_Renamed.ckwd) / sub_Renamed.wdjs), "0.0");
		}
		
		public void Timer12_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Jsz++;
			if (Jsz >= 8)
			{
				
				llJs++;
				if (llJs > 190000)
				{
					llJs = 10;
				}
				llCZ[llJs] = (float) (Conversion.Val(Text3[1].Text));
				ssLL = ssLL + llCZ[llJs];
				Llds = float.Parse(Llds(ssLL / llJs, "0.000"));
				
			}
		}
		
		public void Timer13_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Chuzhijs = System.Convert.ToInt32(Chuzhijs) + 1;
			//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Chuzhijs >= 20)
			{
				//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Chuzhijs = 0;
				
				Timer13.Enabled = false;
			}
		}
		
		public void Timer14_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text16.Visible = false;
			MSComm1.Output = "FETC? (@2)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text16.Text = System.Convert.ToString(MSComm1.Input);
			if (Text16.Text == "")
			{
				Text14.Text = Text14.Text;
			}
			else
			{
				Text14.Text = Text14.Text(Conversion.Val(Text16.Text), "0.000");
			}
		}
		
		public void Timer15_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //瞬流
			short[] s = new short[23];
			short Recount = 0;
			object sss = null;
			string Rxd = "";
			Mdlguanfa.Send_DataSl((short) 245); //liusu
			delay_times((0.4));F;);
			
			Text17.Text = "";
			Shape1[0].Visible = true;
			//UPGRADE_ISSUE: Shape 属性 Shape1.FillColor 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
			if (Shape1[0].FillColor == 0xC00000)
			{
				//UPGRADE_ISSUE: Shape 属性 Shape1.FillColor 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
				Shape1[0].FillColor = 0xC000;
				//UPGRADE_ISSUE: Shape 属性 Shape1.FillColor 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
			}
			else if (Shape1[0].FillColor == 0xC000)
			{
				//UPGRADE_ISSUE: Shape 属性 Shape1.FillColor 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
				Shape1[0].FillColor = 0xC00000;
			}
			
			Timer15.Enabled = false;
			//UPGRADE_WARNING: 未能解析对象 comm.MSComm1.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Rxd = System.Convert.ToString(comm.Default.MSComm1.Input);
			//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
			Recount = System.Convert.ToInt16(LenB(Rxd));
			
			
			for (i = 1; i <= Recount; i++)
			{
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sss = AscB(MidB(Rxd, sub_Renamed.i, 1));
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				s[sub_Renamed.i] = System.Convert.ToInt16(AscB(MidB(Rxd, sub_Renamed.i, 1)));
				
				//UPGRADE_WARNING: 未能解析对象 sss 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text17.Text = Text17.Text + Conversion.Str(sss) + ",";
			}
			if (s[2] == 245)
			{
				
				//
				//                  If MID1 = 1 Then '如果一个标准表
				//                          LjslD(JsslD) = (s(8) * 256 + s(9) - (3 * 256 + Ld3)) * Qmax1 / (4095 - (3 * 256 + Ld3)) * Vk1 '40m3/h
				//                          ZongslD = ZongslD + LjslD(JsslD)
				//                          JsslD = JsslD + 1
				//                          If JsslD = 3 Then
				//                              Text3(1).Text = Format(ZongslD / 3, "0.00") ' 大流量
				//                              JsslD = 0
				//                              ZongslD = 0
				//                          End If
				if (sub_Renamed.MID1 == 2) //如果二个标准表
				{
					if (sub_Renamed.MID5 != 0) //如果最小流量计组
					{
						if (Llxuanze == 3 | Llxuanze == 0 | Llxuanze == 4 | Llxuanze == 5)
						{
							sub_Renamed.LjslD[sub_Renamed.JsslD] = (s[8] * 256 + s[9] - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk2; //40m3/h
							sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
							sub_Renamed.JsslD++;
							if (sub_Renamed.JsslD == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
								sub_Renamed.JsslD = (short) 0;
								sub_Renamed.ZongslD = 0;
							}
						}
						else if (Llxuanze == 1 | Llxuanze == 2)
						{
							sub_Renamed.LjslX[sub_Renamed.JsslX] = (s[4] * 256 + s[5] - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Vk1;
							sub_Renamed.ZongslX = sub_Renamed.ZongslX + sub_Renamed.LjslX[sub_Renamed.JsslX];
							sub_Renamed.JsslX++;
							if (sub_Renamed.JsslX == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslX / 3, "0.000"); // 小流量
								sub_Renamed.JsslX = (short) 0;
								sub_Renamed.ZongslX = 0;
							}
						}
					}
					else if (sub_Renamed.MID4 != 0) //如果中流量计组
					{
						if (Llxuanze == 3 | Llxuanze == 0 | Llxuanze == 4 | Llxuanze == 5)
						{
							sub_Renamed.LjslD[sub_Renamed.JsslD] = (s[8] * 256 + s[9] - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk2; //40m3/h
							sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
							sub_Renamed.JsslD++;
							if (sub_Renamed.JsslD == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
								sub_Renamed.JsslD = (short) 0;
								sub_Renamed.ZongslD = 0;
							}
						}
						else if (Llxuanze == 1 | Llxuanze == 2)
						{
							sub_Renamed.LjslX[sub_Renamed.JsslX] = (s[6] * 256 + s[7] - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Vk1;
							sub_Renamed.ZongslX = sub_Renamed.ZongslX + sub_Renamed.LjslX[sub_Renamed.JsslX];
							sub_Renamed.JsslX++;
							if (sub_Renamed.JsslX == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslX / 3, "0.000"); // 小流量
								sub_Renamed.JsslX = (short) 0;
								sub_Renamed.ZongslX = 0;
							}
						}
					}
					
				}
				else if (sub_Renamed.MID1 == 3) //如果三个标准表
				{
					if (sub_Renamed.Ld4 == 3) //三管路
					{
						if (Llxuanze == 0 | Llxuanze == 3)
						{
							sub_Renamed.LjslD[sub_Renamed.JsslD] = (s[8] * 256 + s[9] - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax3 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk3; //40m3/h
							sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
							sub_Renamed.JsslD++;
							if (sub_Renamed.JsslD == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
								sub_Renamed.JsslD = (short) 0;
								sub_Renamed.ZongslD = 0;
							}
						}
						else if (Llxuanze == 2)
						{
							sub_Renamed.LjslZ[sub_Renamed.JsslZ] = (s[6] * 256 + s[7] - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Vk2;
							sub_Renamed.ZongslZ = sub_Renamed.ZongslZ + sub_Renamed.LjslZ[sub_Renamed.JsslZ];
							sub_Renamed.JsslZ++;
							if (sub_Renamed.JsslZ == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslZ / 3, "0.00"); // 中流量
								sub_Renamed.JsslZ = (short) 0;
								sub_Renamed.ZongslZ = 0;
							}
						}
						else if (Llxuanze == 1)
						{
							sub_Renamed.LjslX[sub_Renamed.JsslX] = (s[4] * 256 + s[5] - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Vk1;
							sub_Renamed.ZongslX = sub_Renamed.ZongslX + sub_Renamed.LjslX[sub_Renamed.JsslX];
							sub_Renamed.JsslX++;
							if (sub_Renamed.JsslX == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslX / 3, "0.000"); // 小流量
								sub_Renamed.JsslX = (short) 0;
								sub_Renamed.ZongslX = 0;
							}
						}
					}
					else if (sub_Renamed.Ld4 == 4) //四管路
					{
						if (Llxuanze == 0 | Llxuanze == 4 | Llxuanze == 5)
						{
							sub_Renamed.LjslD[sub_Renamed.JsslD] = (s[8] * 256 + s[9] - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax3 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk3; //40m3/h
							sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
							sub_Renamed.JsslD++;
							if (sub_Renamed.JsslD == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
								sub_Renamed.JsslD = (short) 0;
								sub_Renamed.ZongslD = 0;
							}
						}
						else if (Llxuanze == 2 | Llxuanze == 3)
						{
							sub_Renamed.LjslZ[sub_Renamed.JsslZ] = (s[6] * 256 + s[7] - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Vk2;
							sub_Renamed.ZongslZ = sub_Renamed.ZongslZ + sub_Renamed.LjslZ[sub_Renamed.JsslZ];
							sub_Renamed.JsslZ++;
							if (sub_Renamed.JsslZ == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslZ / 3, "0.00"); // 中流量
								sub_Renamed.JsslZ = (short) 0;
								sub_Renamed.ZongslZ = 0;
							}
						}
						else if (Llxuanze == 1)
						{
							sub_Renamed.LjslX[sub_Renamed.JsslX] = (s[4] * 256 + s[5] - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Vk1;
							sub_Renamed.ZongslX = sub_Renamed.ZongslX + sub_Renamed.LjslX[sub_Renamed.JsslX];
							sub_Renamed.JsslX++;
							if (sub_Renamed.JsslX == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslX / 3, "0.000"); // 小流量
								sub_Renamed.JsslX = (short) 0;
								sub_Renamed.ZongslX = 0;
							}
						}
					}
					else if (sub_Renamed.Ld4 == 5) //五管路
					{
						if (Llxuanze == 0 | Llxuanze == 5)
						{
							sub_Renamed.LjslD[sub_Renamed.JsslD] = (s[8] * 256 + s[9] - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Qmax3 / (4095 - (3 * 256 + sub_Renamed.Ld3)) * sub_Renamed.Vk3; //40m3/h
							sub_Renamed.ZongslD = sub_Renamed.ZongslD + sub_Renamed.LjslD[sub_Renamed.JsslD];
							sub_Renamed.JsslD++;
							if (sub_Renamed.JsslD == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslD / 3, "0.00"); // 大流量
								sub_Renamed.JsslD = (short) 0;
								sub_Renamed.ZongslD = 0;
							}
						}
						else if (Llxuanze == 2 | Llxuanze == 3 | Llxuanze == 4)
						{
							sub_Renamed.LjslZ[sub_Renamed.JsslZ] = (s[6] * 256 + s[7] - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Qmax2 / (4095 - (3 * 256 + sub_Renamed.Ld2)) * sub_Renamed.Vk2;
							sub_Renamed.ZongslZ = sub_Renamed.ZongslZ + sub_Renamed.LjslZ[sub_Renamed.JsslZ];
							sub_Renamed.JsslZ++;
							if (sub_Renamed.JsslZ == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslZ / 3, "0.00"); // 中流量
								sub_Renamed.JsslZ = (short) 0;
								sub_Renamed.ZongslZ = 0;
							}
						}
						else if (Llxuanze == 1)
						{
							sub_Renamed.LjslX[sub_Renamed.JsslX] = (s[4] * 256 + s[5] - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Qmax1 / (4095 - (3 * 256 + sub_Renamed.Ld1)) * sub_Renamed.Vk1;
							sub_Renamed.ZongslX = sub_Renamed.ZongslX + sub_Renamed.LjslX[sub_Renamed.JsslX];
							sub_Renamed.JsslX++;
							if (sub_Renamed.JsslX == 3)
							{
								Text3[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZongslX / 3, "0.000"); // 小流量
								sub_Renamed.JsslX = (short) 0;
								sub_Renamed.ZongslX = 0;
							}
						}
					} //管路选择
				} //标准表数量选择
				
				
			} //If ss(2) = 245 Then
			
			Timer15.Enabled = true;
		}
		
		public void Timer16_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			byte[] fs = new byte[4];
			Text15.Visible = false;
			MSComm1.Output = "FETC? (@1)";
			fs[0] = (byte) 13;
			fs[1] = (byte) 10;
			MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(fs);
			Text15.Text = System.Convert.ToString(MSComm1.Input);
			if (Text15.Text == "")
			{
				Text12.Text = Text12.Text;
			}
			else
			{
				Text12.Text = Text12.Text(Conversion.Val(Text15.Text), "0.000");
			}
		}
		
		public void Timer17_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.Nwdjs++;
			if (sub_Renamed.Nwdjs > 190000)
			{
				sub_Renamed.Nwdjs = 10;
			}
			sub_Renamed.Nwdcz[sub_Renamed.Nwdjs] = (float) (Conversion.Val(Text14.Text));
			sub_Renamed.Nwdzz[sub_Renamed.Nwdjs] = (float) (Conversion.Val(Text12.Text));
			
			sub_Renamed.Njkwd = sub_Renamed.Njkwd + sub_Renamed.Nwdcz[sub_Renamed.Nwdjs];
			sub_Renamed.Nckwd = sub_Renamed.Nckwd + sub_Renamed.Nwdzz[sub_Renamed.Nwdjs];
			
			sub_Renamed.Ninlet = float.Parse(((sub_Renamed.Njkwd) / sub_Renamed.Nwdjs), "0.000");
			sub_Renamed.Noutlet = float.Parse(((sub_Renamed.Nckwd) / sub_Renamed.Nwdjs), "0.000");
		}
		
		public void Timer18_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object Wendu_js1 = null;
			object Data_in1 = null;
			object Kk1 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			
			MSComm1.PortOpen = false;
			MSComm1.PortOpen = true;
			MSComm1.Output = "S";
			MSComm1.PortOpen = false;
			MSComm1.PortOpen = true;
			
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Kk1 = System.Convert.ToInt32(Kk1) + 1;
				delay_times((0.5));F;);
				//UPGRADE_WARNING: 未能解析对象 Kk1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(MSComm1.InBufferCount >= 9 | Kk1 > 9));
			
			//UPGRADE_WARNING: 未能解析对象 MSComm1.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Data_in1 = MSComm1.Input;
			//
			//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Text16.Text = System.Convert.ToString(Data_in1);
			
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Wendu_js1 = System.Convert.ToInt32(Wendu_js1) + 1;
			//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Wendu_js1 < 15)
			{
				//   Text5.Text = Data_in1
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 >= 15 & Wendu_js1 <= 30)
			{
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) Wendu_js1 == 15)
				{
					MessageBox.Show("请在十秒钟内将出口铂电阻接入测试仪！");
				}
				//UPGRADE_WARNING: 未能解析对象 Data_in1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Text15.Text = System.Convert.ToString(Data_in1);
				
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			}
			else if (Wendu_js1 > 30)
			{
				Timer18.Enabled = false;
				//UPGRADE_WARNING: 未能解析对象 Wendu_js1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Wendu_js1 = 0;
			}
		}
		
		public void Timer21_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			object jj = null;
			object t = null;
			object p = null;
			object arg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object indata = null;
			short n = 0;
			object data = null;
			string s;
			object c;
			object xiang = null;
			object changdu = null;
			object qian = null;
			object hou = null;
			object x = null;
			Timer21.Enabled = false;
			if (DanJian == true)
			{
				goto bb;
			}
			
			for ( = ;Biao_Xuhao; i <= sub_Renamed.Stueck); i++;);
			{
				
				if (Text19[sub_Renamed.i + 1].Text != "通讯口不正常!")
				{
					break;
				}
				Biao_Xuhao++;
				if (Biao_Xuhao >= sub_Renamed.Stueck + 1)
				{
					Biao_Xuhao = (short) 0;
				}
				return;
				
				
			}
bb:
			if (Gaibiaohao == false) //读表数据
			{
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				data = sub_Renamed.tx.send_cmd((short) Metertype.SelectedIndex, sub_Renamed.cmd_type, Strings.Trim(System.Convert.ToString(Text11[Biao_Xuhao].Text)), Text21.Text.Trim() + ";;;;;;;;");
			}
			else //改表号
			{
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				data = sub_Renamed.tx.send_cmd((short) Metertype.SelectedIndex, sub_Renamed.cmd_type, Strings.Trim(System.Convert.ToString(Text11[Biao_Xuhao].Text)), sub_Renamed.addr_meter + Strings.Trim(System.Convert.ToString(Text1[Biao_Xuhao].Text)) + ";;;;;;;;");
			}
			//UPGRADE_WARNING: 未能解析对象 arg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Gaicanshu == true)
			{
				data = sub_Renamed.tx.send_cmd((short) Metertype.SelectedIndex, sub_Renamed.cmd_type, Strings.Trim(System.Convert.ToString(Text11[Biao_Xuhao].Text)), System.Convert.ToString(arg));
			}
			
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = Strings.Mid(System.Convert.ToString(data), 3);
			
			
			object cc = null;
			byte[] buf = null;
			//    Dim n As Integer
			
			n = (short) (Strings.Len(data) / 2);
			buf = new byte[n + 3 + 1];
			
			if (Metertype.SelectedIndex == 5 | Metertype.SelectedIndex == 8) //汇中和光大
			{
				buf = new byte[n - 1 + 1];
				//UPGRADE_WARNING: 未能解析对象 cc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cc = 0;
				for ( = ;0; i <= n - 1); i++;);
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					buf[sub_Renamed.i] = byte.Parse("&H" + Strings.Mid(System.Convert.ToString(data), sub_Renamed.i * 2 + 1, 2));
				}
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				sub_Renamed.Txd = System.Convert.ToString(data);
				
			}
			else //其它表
			{
				for ( = ;0; i <= 3); i++;);
				{
					buf[sub_Renamed.i] = (byte) (0xFE);
				}
				
				//UPGRADE_WARNING: 未能解析对象 cc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				cc = 0;
				for ( = ;0; i <= n - 1); i++;);
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					buf[sub_Renamed.i + 4] = byte.Parse("&H" + Strings.Mid(System.Convert.ToString(data), sub_Renamed.i * 2 + 1, 2));
					//UPGRADE_WARNING: 未能解析对象 cc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					cc = System.Convert.ToInt32(cc + buf[sub_Renamed.i + 4]) % 0x100;
				}
				
				sub_Renamed.Txd = "";
				for (p = 4; (int) p <= n + 3; p = (int) p + 1)
				{
					//UPGRADE_WARNING: 未能解析对象 p 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					t = Conversion.Hex(buf[(int) p]);
					for (jj = Strings.Len(t); jj <= 1; System.Convert.ToInt32(jj++))
					{
						//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						t = "0" + t;
					}
					//UPGRADE_WARNING: 未能解析对象 t 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.Txd = sub_Renamed.Txd + t;
				}
			} //汇中
			//
			if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7)
			{
				
				if (MSComm6[Biao_Xuhao].PortOpen == true)
				{
					MSComm6[Biao_Xuhao].PortOpen = false;
				}
				MSComm6[Biao_Xuhao].Settings = "9600,e,8,1";
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					MSComm6[Biao_Xuhao].PortOpen = true;
				}
				
				tstart = (float) VB.DateAndTime.Timer;
				while (VB.DateAndTime.Timer- tstart < 0.3)
				{
					System.Windows.Forms.Application.DoEvents();
				}
				
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					Text19[Biao_Xuhao + 1].Visible = true;
					if (sub_Renamed.Chinese == true)
					{
						Text19[Biao_Xuhao + 1].Text = "通讯口不正常!";
					}
					else
					{
						Text19[Biao_Xuhao + 1].Text = "Comport false!";
					}
					goto aa;
				}
				else
				{
					tstart = (float) VB.DateAndTime.Timer;
					aa1[0] = (byte) (0xFE);
					Text19[Biao_Xuhao + 1].Visible = false;
					while ((VB.DateAndTime.Timer- tstart) < 2.2)
					{
						MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(aa1);
						System.Windows.Forms.Application.DoEvents();
					}
					
					if (MSComm6[Biao_Xuhao].PortOpen == true)
					{
						MSComm6[Biao_Xuhao].PortOpen = false;
					}
					MSComm6[Biao_Xuhao].Settings = "2400,e,8,1";
					if (MSComm6[Biao_Xuhao].PortOpen == false)
					{
						MSComm6[Biao_Xuhao].PortOpen = true;
					}
					
					tstart = (float) VB.DateAndTime.Timer;
					while (VB.DateAndTime.Timer- tstart < 0.5)
					{
						System.Windows.Forms.Application.DoEvents();
					}
					MSComm6[Biao_Xuhao].OutBufferCount = 0;
					MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(buf);
				}
				
			}
			else if (Metertype.SelectedIndex == 8) //光大表
			{
				if (MSComm6[Biao_Xuhao].PortOpen == true)
				{
					MSComm6[Biao_Xuhao].PortOpen = false;
				}
				MSComm6[Biao_Xuhao].PortOpen = true;
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					Text19[Biao_Xuhao + 1].Visible = true;
					if (sub_Renamed.Chinese == true)
					{
						Text19[Biao_Xuhao].Text = "通讯口不正常!";
					}
					else
					{
						Text19[Biao_Xuhao].Text = "Comport false!";
					}
					goto aa;
				}
				else
				{
					tstart = (float) VB.DateAndTime.Timer;
					aa1[0] = (byte) (0xFE);
					aa1[1] = (byte) (0xFE);
					Text19[Biao_Xuhao + 1].Visible = false;
					while ((VB.DateAndTime.Timer- tstart) < 1)
					{
						MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(aa1);
						System.Windows.Forms.Application.DoEvents();
					}
					
					//       tstart = Timer
					//       Do While Timer - tstart < 0.3
					//       DoEvents
					//       Loop
					MSComm6[Biao_Xuhao].OutBufferCount = 0;
					MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(buf);
				}
				
			}
			else //其它表
			{
				if (MSComm6[Biao_Xuhao].PortOpen == true)
				{
					MSComm6[Biao_Xuhao].PortOpen = false;
				}
				MSComm6[Biao_Xuhao].PortOpen = true;
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					Text19[Biao_Xuhao + 1].Visible = true;
					if (sub_Renamed.Chinese == true)
					{
						Text19[Biao_Xuhao + 1].Text = "通讯口不正常!";
					}
					else
					{
						Text19[Biao_Xuhao + 1].Text = "Comport false!";
					}
					goto aa;
				}
				else
				{
					Text19[Biao_Xuhao + 1].Visible = false;
					MSComm6[Biao_Xuhao].OutBufferCount = 0;
					MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(buf);
				}
			}
			
			Gaibiaohao = false;
			Gaicanshu = false;
			
			if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7)
			{
				tstart = (float) VB.DateAndTime.Timer;
				while (VB.DateAndTime.Timer- tstart < 0.5)
				{
					System.Windows.Forms.Application.DoEvents();
				}
			}
			else
			{
				tstart = (float) VB.DateAndTime.Timer;
				while (VB.DateAndTime.Timer- tstart < 1)
				{
					System.Windows.Forms.Application.DoEvents();
				}
			}
			
			n = System.Convert.ToInt16(MSComm6[Biao_Xuhao].InBufferCount);
			//UPGRADE_WARNING: 未能解析对象 MSComm6().Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 indata 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			indata = MSComm6[Biao_Xuhao].Input;
			//             n = LenB(indata)
			MSComm6[Biao_Xuhao].InBufferCount = 0;
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = getstr(indata, n);
			
			
			//从接收数据中挑出有效数据
			
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 xiang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			xiang = sub_Renamed.tx.standarddata(System.Convert.ToString(data), sub_Renamed.Txd);
			
			//UPGRADE_WARNING: 未能解析对象 xiang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = Strings.Mid(System.Convert.ToString(xiang), 3);
			
			//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			data = sub_Renamed.tx.getdata((short) Metertype.SelectedIndex, System.Convert.ToString(data), sub_Renamed.cmd_type);
			switch (sub_Renamed.cmd_type)
			{
				
			case "RD_NUM": //读表号
				//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (double.Parse(Strings.Mid(System.Convert.ToString(data), 1, 1)) == 0)
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text1[Biao_Xuhao].Text = Strings.Mid(System.Convert.ToString(data), 18);
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text11[Biao_Xuhao].Text = Strings.Mid(System.Convert.ToString(data), 3, 14);
					//UPGRADE_WARNING: 未能解析对象 changdu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					changdu = Strings.Trim(System.Convert.ToString(Text1[Biao_Xuhao].Text)).Length;
					//UPGRADE_WARNING: 未能解析对象 changdu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.addr_meter = Strings.Mid(System.Convert.ToString(data), 3, System.Convert.ToInt32(14 - System.Convert.ToInt32(changdu)));
					if (Biao_Xuhao == 0)
					{
						读表号一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 1)
					{
						读表号二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 2)
					{
						读表号三.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 3)
					{
						读表号四.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 4)
					{
						读表号五.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 5)
					{
						读表号六.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 6)
					{
						读表号七.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 7)
					{
						读表号八.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 8)
					{
						读表号九.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 9)
					{
						读表号十.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 10)
					{
						读表号十一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 11)
					{
						读表号十二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					
					
				}
				else
				{
					if (Text19[Biao_Xuhao + 1].Text != "通讯口不正常!")
					{
						Text1[Biao_Xuhao].Text = "读取错误";
					}
					if (Metertype.SelectedIndex == 8)
					{
						Text1[Biao_Xuhao].Text = "无此功能";
					}
				}
				break;
				
				
			case "WR_NUM": //写表号
				if (Biao_Xuhao == 0)
				{
					读表号一.Text = "已改表号";
				}
				读表号一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 1)
				{
					读表号二.Text = "已改表号";
				}
				读表号二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 2)
				{
					读表号三.Text = "已改表号";
				}
				读表号三.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 3)
				{
					读表号四.Text = "已改表号";
				}
				读表号四.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 4)
				{
					读表号五.Text = "已改表号";
				}
				读表号五.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 5)
				{
					读表号六.Text = "已改表号";
				}
				读表号六.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 6)
				{
					读表号七.Text = "已改表号";
				}
				读表号七.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 7)
				{
					读表号八.Text = "已改表号";
				}
				读表号八.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 8)
				{
					读表号九.Text = "已改表号";
				}
				读表号九.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 9)
				{
					读表号十.Text = "已改表号";
				}
				读表号十.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 10)
				{
					读表号十一.Text = "已改表号";
				}
				读表号十一.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				if (Biao_Xuhao == 11)
				{
					读表号十二.Text = "已改表号";
				}
				读表号十二.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
				break;
				
				
				
			case "RD_DATA": //读数据
			case "RD_HIGH_DATA":
				
				//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				qian = 0;
				for ( = ;0; i <= 4); i++;);
				{
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 hou 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					hou = (System.Convert.ToInt32(qian) + 1).ToString().IndexOf(Strings.Mid(System.Convert.ToString(data), 3)) + 1;
					//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 hou 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 data 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					x = Strings.Mid(System.Convert.ToString(data), 3).Substring(System.Convert.ToInt32(qian) + 1 - 1, System.Convert.ToDouble(System.Convert.ToInt32(hou) - System.Convert.ToDouble(qian)) - 1);
					//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Text20[sub_Renamed.i].Text = () );x;
					//UPGRADE_WARNING: 未能解析对象 hou 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 qian 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					qian = hou;
				}
				Text33[Biao_Xuhao].Text = Text20[2].Text;
				Text22[Biao_Xuhao].Text = Text20[0].Text;
				
				if (Strings.Len(Text33[Biao_Xuhao].Text) > 0 || Strings.Len(Text22[Biao_Xuhao].Text) > 0)
				{
					
					if (Biao_Xuhao == 0)
					{
						读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 1)
					{
						读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 2)
					{
						读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 3)
					{
						读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 4)
					{
						读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 5)
					{
						读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 6)
					{
						读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 7)
					{
						读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 8)
					{
						读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 9)
					{
						读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 10)
					{
						读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					if (Biao_Xuhao == 11)
					{
						读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xFF0000);
					}
					//            If Erstpunkt = True Then Text2(Biao_Xuhao).Text = Format((Val(Text33(Biao_Xuhao).Text) * 1000), "0.000")
					//            If Rechen = True And RechenLC = False Then Text4(Biao_Xuhao).Text = Format((Val(Text33(Biao_Xuhao).Text) * 1000), "0.000")
					//            If frmcanshushezhi1.Option11.value = True Then
					if (sub_Renamed.Erstpunkt == true)
					{
						Text6[Biao_Xuhao].Text = Text6(Conversion.Val(Text22[Biao_Xuhao].Text), "0.0000");
					}
					if (sub_Renamed.Rechen == true && sub_Renamed.RechenLC == false)
					{
						Text8[Biao_Xuhao].Text = Text8(Conversion.Val(Text22[Biao_Xuhao].Text), "0.0000");
					}
					if (sub_Renamed.Readone == false)
					{
						Text10[2 * Biao_Xuhao].Text = Text10(Conversion.Val(Text20[3].Text), "0.00");
						Text10[2 * Biao_Xuhao + 1].Text = Text10(Conversion.Val(Text20[4].Text), "0.00");
						Text10[2 * Biao_Xuhao].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * Biao_Xuhao].Font, 14);
						Text10[2 * Biao_Xuhao + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * Biao_Xuhao + 1].Font, 14);
						if (sub_Renamed.Tem == true)
						{
							if (sub_Renamed.Chinese == true)
							{
								if (Conversion.Val((System.Convert.ToDouble(Text10[2 * Biao_Xuhao + 1].Text)) - System.Convert.ToDouble(Text10[2 * Biao_Xuhao].Text).ToString()) > 0)
								{
									MessageBox.Show("请查看" + Conversion.Str(Biao_Xuhao + 1) + "号表温度传感器是否放反或焊反！");
								}
							}
							else
							{
								if (Conversion.Val((System.Convert.ToDouble(Text10[2 * Biao_Xuhao + 1].Text)) - System.Convert.ToDouble(Text10[2 * Biao_Xuhao].Text).ToString()) > 0)
								{
									MessageBox.Show("Please view the temperature sensor pair of meter No." + Conversion.Str(Biao_Xuhao + 1) + "  is placed or welded reversely!");
								}
							}
						}
					}
					//            End If
				}
				break;
			case "RD_FLOW_ARG": //读流量参数
				break;
				//'            Command13.BackColor = &HC00000
				//                    qian = 0
				//
				//                    Dim shu(7) As String
				//                    For i = 0 To 7
				//                        hou = InStr(qian + 1, Mid(data, 3), ";")
				//                        x = Mid(Mid(data, 3), qian + 1, hou - qian - 1)
				//                        shu(i) = x
				//                        qian = hou
				//                    Next i
				//
				//                    Select Case Metertype.ListIndex
				//                    Case 0
				//                    Text44(Biao_Xuhao).Text = shu(0)
				//                        For i = 0 To 2
				//'                            Text28(6 - i).Text = shu(i * 2 + 2)
				//                            Text23(i).Text = shu(i * 2 + 3)
				//                        Next i
				//
				//                    Case 1, 2
				//                        For i = 0 To 3
				//                            Text23(i).Text = shu(i)
				//                        Next i
				//
				//                    Case 3
				//                        For i = 0 To 2
				//                            shu(i) = shu(i) / 10000
				//                            shu(i) = ((1 - shu(i)) / shu(i)) * 100
				//                        Next i
				//                        For i = 0 To 2
				//                            Text23(i).Text = Round(shu(i), 1)
				//                        Next i
				//                    Case 4
				//                        Text23(0).Text = shu(0)
				//                        Text23(1).Text = shu(1)
				//                        Text23(2).Text = shu(3)
				//
				//                    Case Else
				//                     MsgBox "暂不具备此功能！"
				//                     exit sub
				//                    End Select
				//
				//'                    Text4.Text = Mid(data, 3)
				//'                    txtMsg.Text = data
				//            Case "WR_FLOW_ARG" '写流量参数
				//
				//                  If Biao_Xuhao = 0 Then 调一.BackColor = &HFF0000
				//                  If Biao_Xuhao = 1 Then 调二.BackColor = &HFF0000
				//                  If Biao_Xuhao = 2 Then 调三.BackColor = &HFF0000
				//                  If Biao_Xuhao = 3 Then 调四.BackColor = &HFF0000
				//                  If Biao_Xuhao = 4 Then 调五.BackColor = &HFF0000
				//                  If Biao_Xuhao = 5 Then 调六.BackColor = &HFF0000
				//                  If Biao_Xuhao = 6 Then 调七.BackColor = &HFF0000
				//                  If Biao_Xuhao = 7 Then 调八.BackColor = &HFF0000
				//                  If Biao_Xuhao = 8 Then 调九.BackColor = &HFF0000
				//                  If Biao_Xuhao = 9 Then 调十.BackColor = &HFF0000
				//                  If Biao_Xuhao = 10 Then 调十一.BackColor = &HFF0000
				//                  If Biao_Xuhao = 11 Then 调十二.BackColor = &HFF0000
				//
				//
				//
				//
				//                  If Zhijie = True Then
				//                    Command15.BackColor = &HC00000
				//                  ElseIf Huiling = True Then
				//                    Command14.BackColor = &HC00000
				//                  ElseIf Erci = True Then
				//                    Command12.BackColor = &HC00000
				//                  ElseIf Pingjun = True Then
				//                    Command13.BackColor = &HC00000
				//                  End If
				//            Case "WR_SETUP"
				//'                    txtMsg.Text = Mid(data, 3)
				//            Case "WR_CANCEL"
				//'                    txtMsg.Text = Mid(data, 3)
				
		}
aa:
		if (DanJian == true)
		{
			DanJian = false;
		}
		return;
		
//		Biao_Xuhao++;
//		if (Biao_Xuhao >= sub_Renamed.Stueck + 1)
//		{
//			Biao_Xuhao = (short) 0;
//			}
//			return;
			
			
//			Timer21.Enabled = true;
			//                      delay_times (0.5)
			
		}
		
		public void Timer23_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			object indata;
			short n;
			object data;
			string s;
			object c;
			object xiang;
			object changdu;
			object qian;
			object hou;
			object x;
			
			Timer23.Enabled = false;
			
			for ( = ;Biao_Xuhao; i <= sub_Renamed.Stueck); i++;);
			{
				
				if (Text19[sub_Renamed.i + 1].Text != "通讯口不正常!")
				{
					break;
				}
				Biao_Xuhao++;
				if (Biao_Xuhao >= sub_Renamed.Stueck + 1)
				{
					Biao_Xuhao = (short) 0;
				}
				return;
				
			}
			
			
			if (MSComm6[Biao_Xuhao].PortOpen == true)
			{
				MSComm6[Biao_Xuhao].PortOpen = false;
			}
			MSComm6[Biao_Xuhao].Settings = "9600,e,8,1";
			if (MSComm6[Biao_Xuhao].PortOpen == false)
			{
				MSComm6[Biao_Xuhao].PortOpen = true;
			}
			
			tstart = (float) VB.DateAndTime.Timer;
			while (VB.DateAndTime.Timer- tstart < 0.2)
			{
				System.Windows.Forms.Application.DoEvents();
			}
			
			byte[] jiance = new byte[18];
			if (MSComm6[Biao_Xuhao].PortOpen == false)
			{
				Text19[Biao_Xuhao + 1].Visible = true;
				if (sub_Renamed.Chinese == true)
				{
					Text19[Biao_Xuhao + 1].Text = "通讯口不正常!";
				}
				else
				{
					Text19[Biao_Xuhao + 1].Text = "Comport false!";
				}
				goto aa;
			}
			else
			{
				tstart = (float) VB.DateAndTime.Timer;
				aa1[0] = (byte) (0xFE);
				Text19[Biao_Xuhao + 1].Visible = false;
				
				while ((VB.DateAndTime.Timer- tstart) < 2)
				{
					MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(aa1);
					System.Windows.Forms.Application.DoEvents();
				}
				
				if (MSComm6[Biao_Xuhao].PortOpen == true)
				{
					MSComm6[Biao_Xuhao].PortOpen = false;
				}
				MSComm6[Biao_Xuhao].Settings = "2400,e,8,1";
				if (MSComm6[Biao_Xuhao].PortOpen == false)
				{
					MSComm6[Biao_Xuhao].PortOpen = true;
				}
				
				tstart = (float) VB.DateAndTime.Timer;
				while (VB.DateAndTime.Timer- tstart < 0.2)
				{
					System.Windows.Forms.Application.DoEvents();
				}
				
				
				
				//进入检定状态
				jiance[0] = 0xFE;
				jiance[1] = 0xFE;
				jiance[2] = 0xFE;
				jiance[3] = 0xFE;
				jiance[4] = 0xFE;
				jiance[5] = 0x68;
				jiance[6] = 0x20;
				jiance[7] = 0xAA;
				jiance[8] = 0xAA;
				jiance[9] = 0xAA;
				jiance[10] = 0xAA;
				jiance[11] = 0xAA;
				jiance[12] = 0xAA;
				jiance[13] = 0xAA;
				jiance[14] = 0x33;
				jiance[15] = 0x0;
				jiance[16] = 0x61;
				jiance[17] = 0x16;
				
				MSComm6[Biao_Xuhao].Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(jiance);
				
			}
			
			
			
aa:
			
			Biao_Xuhao++;
			if (Biao_Xuhao >= sub_Renamed.Stueck + 1)
			{
				Biao_Xuhao = (short) 0;
			}
			return;
			
//			Timer23.Enabled = true;
			//                      delay_times (0.5)
			
		}
		
		public void Timer7_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
			if (Llds <= 0.01)
			{
				Llds = sub_Renamed.Jd_flow[xx - 1]; //确保流量不为零
			}
			if (double.Parse(sub_Renamed.YouXiaoQi) == 1)
			{
				sub_Renamed.JsyqV[xx - 1] = (float) (1 + 0.01 * Mdlguanfa.Qp / Llds); //误差限Eq
				if (sub_Renamed.JsyqV[xx - 1] > 3.5)
				{
					sub_Renamed.JsyqV[xx - 1] = 3.5F;
				}
			}
			else if (double.Parse(sub_Renamed.YouXiaoQi) == 2)
			{
				sub_Renamed.JsyqV[xx - 1] = (float) (2 + 0.02 * Mdlguanfa.Qp / Llds);
				if (sub_Renamed.JsyqV[xx - 1] > 5)
				{
					sub_Renamed.JsyqV[xx - 1] = 5;
				}
			}
			else if (double.Parse(sub_Renamed.YouXiaoQi) == 3)
			{
				sub_Renamed.JsyqV[xx - 1] = (float) (3 + 0.05 * Mdlguanfa.Qp / Llds);
				if (sub_Renamed.JsyqV[xx - 1] > 5)
				{
					sub_Renamed.JsyqV[xx - 1] = 5;
				}
			}
			//                            Jsz = 0
			Timer7.Enabled = false;
		}
		
		public void Timer8_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Js++;
			if (Js == 3)
			{
				Js = (short) 1;
			}
			//Js = 2
			sub_Renamed.m_lngAddress = Js;
			
			
			//   Else
			//    m_lngAddress = 2
			//    Flagbzwd = False
			//   End If
			if (MSComm5.PortOpen == false)
			{
				MSComm5.PortOpen = true;
			}
			
			Mdlguanfa.abytOrder[0] = (byte) (sub_Renamed.m_lngAddress | 0x80);
			Mdlguanfa.abytOrder[1] = (byte) (sub_Renamed.m_lngAddress | 0x80);
			Mdlguanfa.abytOrder[2] = (byte) (0x52);
			Mdlguanfa.abytOrder[3] = (byte) 0; // Val(txtPara(0).Text)
			Mdlguanfa.abytOrder[4] = (byte) 0;
			Mdlguanfa.abytOrder[5] = (byte) 0;
			
			//*  增加校验
			sub_Renamed.AddSum(ref Mdlguanfa.abytOrder, 0);
			//   labCommFlag = ""
			
			//*  发送命令
			MSComm5.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Mdlguanfa.abytOrder);
			//   delay_times (0.09)
aa:
			1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
		}
		public void Timer9_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Tianping2++;
			if (Tianping2 > 6)
			{
				
				sub_Renamed.jsjs++;
				if (sub_Renamed.jsjs > 190000)
				{
					sub_Renamed.jsjs = 10;
				}
				sub_Renamed.zl[sub_Renamed.jsjs] = (float) (Conversion.Val(Text3[0].Text));
				if (sub_Renamed.jsjs >= 2)
				{
					sub_Renamed.Leiji = sub_Renamed.Leiji + sub_Renamed.zl[sub_Renamed.jsjs] - sub_Renamed.zl[sub_Renamed.jsjs - 1];
					Text3[1].Text = Text3((sub_Renamed.Leiji) / (sub_Renamed.jsjs - 1) * 3.6 * 1.0056, "0.000");
					if (Conversion.Val(Text3[1].Text) < 0.01)
					{
						Text3[1].Text = (0).ToString();
					}
				}
			}
		}
		public void TimerEne_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			
		}
		
		public void Timerpq_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			t6++;
			
			Label2[0].Visible = true;
			Text13.Visible = false;
			Text13.Text = (Pqtime - t6).ToString();
			Label2[0].Text = (Conversion.Val(Text13.Text)).ToString();
			if (double.Parse(Text13.Text) == 0)
			{
				//UPGRADE_ISSUE: TextBox 属性 Text13.Appearance 未升级。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"”
				Text13.Appearance = 1;
				Text13.BackColor = System.Drawing.ColorTranslator.FromOle(0x80000005);
				Label2[0].Visible = false;
				Timerpq.Enabled = false;
			}
		}
		
		private void TPcom()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,e,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,e,6,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,O,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,O,6,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,8,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,8,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,7,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,7,2";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "2400,n,6,1";
			}
			if (sub_Renamed.TPBand == 2400 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "2400,n,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,e,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,e,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,O,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,O,6,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,8,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,8,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,7,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,7,2";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "600,n,6,1";
			}
			if (sub_Renamed.TPBand == 600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "600,n,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,e,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,e,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,O,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,O,6,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,8,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,8,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,7,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,7,2";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "1200,n,6,1";
			}
			if (sub_Renamed.TPBand == 1200 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "1200,n,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,e,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,e,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,O,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,O,6,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,8,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,8,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,7,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,7,2";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "4800,n,6,1";
			}
			if (sub_Renamed.TPBand == 4800 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "4800,n,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,e,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Even(偶)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,e,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,O,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "Odd(奇)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,O,6,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,8,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 8 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,8,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,7,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 7 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,7,2";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 1)
			{
				MSComm2.Settings = "9600,n,6,1";
			}
			if (sub_Renamed.TPBand == 9600 && sub_Renamed.TPVerify == "None(无)" && sub_Renamed.TPData == 6 & sub_Renamed.TPStop == 2)
			{
				MSComm2.Settings = "9600,n,6,2";
			}
			
			
			
		}
		
		
		public void tz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next
			//
			///dim fs(5) As Byte
			//   fs(0) = 255
			//    fs(1) = 250
			//    fs(2) = 0
			//    fs(3) = 0
			//    fs(4) = 254
			//
			//If comm.MSComm1.PortOpen = False Then comm.MSComm1.PortOpen = True
			//'    Fd(0) = &HF9
			//  comm.MSComm1.Output = fs
			// delay_times (0.5)
			Mdlguanfa.Send_Data((short) 250); //关闭水泵
			delay_times(1);
			
		}
		
		public void MSComm5_OnComm(System.Object eventSender, System.EventArgs eventArgs)
		{
			try
			{
				byte[] abytReturnData = null;
				string strValue;
				int lngIndex;
				float sngValue = 0;
				switch (MSComm5.CommEvent)
				{
					case (short) 2:
						//         '*  仪表有数据返回
						//UPGRADE_WARNING: 未能解析对象 MSComm5.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						abytReturnData = () );MSComm5.Input;
						
						sngValue = System.Convert.ToSingle(abytReturnData[1] * 256 + abytReturnData[0]);
						if (sngValue >= 32768)
						{
							sngValue = sngValue - 65536;
						}
						if (Js == 1)
						{
							Text3[4].Text = ((double.Parse((sngValue).ToString())) / 10).ToString();
						}
						if (Js == 2)
						{
							Text3[5].Text = ((double.Parse((sngValue).ToString())) / 10).ToString();
						}
						break;
						//            If Js = 3 Then Text3(2).Text = Format(0.0272 * (Val(sngValue) / 10) - 0.068, "0.00")
						//            If Js = 4 Then Text4.Text = Format(0.0272 * (Val(sngValue) / 10) - 0.068, "0.00")
						//             Text3(4).Text = (sngValue) / 10
						//            If Js = 2 Then Text2.Text = (sngValue) / 10 - 0.9
						//            If Js = 5 Then Text3(2).Text = Format(Val(sngValue / 100), "0.00")
						//            If Js = 4 Then Text3(2).Text = Format(Val(sngValue / 10), "0.00")  '压损
						
					default:
						break;
				}
			}
			catch
			{
				goto aa;
			}
aa:
			1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
		}
		
		// VBConversions Note: Former VB static variables moved to class level because they aren't supported in C#.
		private int MSComm2_OnComm_xian;
		
		public void MSComm2_OnComm(System.Object eventSender, System.EventArgs eventArgs)
		{
			object danwei;
			object mtype;
			object quality = null;
			object mass = null;
			object arg;
			object dot = null;
			object statusC;
			object Statusb = null;
			object Statusa = null;
			object fuhao;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			object guo = null;
			object foot1;
			object head1;
			object head2;
			object foot2;
			// static int xian; VBConversions Note: Static variable moved to class level and renamed MSComm2_OnComm_xian. Local static variables are not supported in C#.
			if (sub_Renamed.Satorius == true)
			{
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s2 = Strings.Trim(System.Convert.ToString(MSComm2.Input));
						sub_Renamed.Tpcj1++;
						if (sub_Renamed.Tpcj1 > 3000)
						{
							sub_Renamed.Tpcj1 = (short) 5;
						}
						if (sub_Renamed.Tpcj1 > 2)
						{
							for ( = ;1; i <= 30); i++;);
							{
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s6 = Strings.Mid(System.Convert.ToString(s2), sub_Renamed.i, 1);
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s3 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s3 = Strings.Mid(System.Convert.ToString(s2), sub_Renamed.i + 13, 1);
								//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								//UPGRADE_WARNING: 未能解析对象 s5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								s5 = Strings.Mid(System.Convert.ToString(s2), sub_Renamed.i, 5);
								//UPGRADE_WARNING: 未能解析对象 s5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if (Strings.StrComp(System.Convert.ToString(s5), "0.000", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									Text3[0].Text = (0).ToString();
									return;
								}
								//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if (Strings.StrComp(System.Convert.ToString(s6), "+", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									Text3[0].Text = Strings.Mid(System.Convert.ToString(s2), sub_Renamed.i + 1, 9).Trim();
									break;
									//UPGRADE_WARNING: 未能解析对象 s6 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								}
								else if (Strings.StrComp(System.Convert.ToString(s6), "-", (Microsoft.VisualBasic.CompareMethod) 1) == 0)
								{
									//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									Text3[0].Text = "-" + Strings.Mid(System.Convert.ToString(s2), sub_Renamed.i + 1, 9).Trim();
									break;
								}
							}
						}
						break;
						
					default:
						break;
				}
				
			}
			else if (sub_Renamed.Bizerba == true)
			{
				
				
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s2 = MSComm2.Input;
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						for ( = ;1; i <= LenB(s2)); i++;);
						{
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 head1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							head1 = Strings.Chr(System.Convert.ToInt32((MidB(s2, sub_Renamed.i, 1))));
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 head2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							head2 = Strings.Chr(System.Convert.ToInt32((MidB(s2, sub_Renamed.i + 1, 1))));
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 foot1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							foot1 = Conversion.Hex((MidB(s2, sub_Renamed.i + 13, 1)));
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_WARNING: 未能解析对象 foot2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							foot2 = Conversion.Hex((MidB(s2, sub_Renamed.i + 14, 1)));
							//UPGRADE_WARNING: 未能解析对象 foot2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 foot1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 head2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							//UPGRADE_WARNING: 未能解析对象 head1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							if (((string) head1 == "S" && (string) head2 == "T" && (string) foot1 == "D" && (string) foot2 == "A") || ((string) head1 == "U" && (string) head2 == "S" && (string) foot1 == "D" && (string) foot2 == "A"))
							{
								for (j = () (sub_Renamed.i + 3)); j <= sub_Renamed.i + 10; j++) //LenB(s2)
								{
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = "";
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 1, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 2, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 3, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 4, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 5, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 6, 1))));
									//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
									//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									guo = guo + Strings.Chr(System.Convert.ToInt32((MidB(s2, j + 7, 1))));
									break;
								}
								//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								guo = Strings.Trim(System.Convert.ToString(guo));
								//                        If IsNumeric(guo) = False Then GoTo err
								break;
							}
						}
						//UPGRADE_WARNING: 未能解析对象 guo 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Text3[0].Text = () );guo;
						break;
						
					default:
						break;
				}
				
				
			}
			else if (sub_Renamed.Mettler == true)
			{
				
				switch (MSComm2.CommEvent)
				{
					case (short) 2:
						//UPGRADE_WARNING: 未能解析对象 s1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						s1 = MSComm2.Input;
						//            Text5.Text = ""
						//            Text6.Text = ""
						//            For i = 1 To LenB(s1)
						//                    Text6.Text = Text6.Text + Hex(AscB(MidB(s1, i, 1)))
						//            Next i
						//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						fuhao = "";
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						if ((s1) < 17)
						{
							return; //没有校验和
						}
						//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
						for ( = ;1; i <= LenB(s1)); i++;);
						{
							//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
							if ((MidB(s1, sub_Renamed.i, 1)) == 2 && AscB(MidB(s1, sub_Renamed.i + 16, 1)) == 0xD)
							{
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 Statusa 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Statusa = (MidB(s1, sub_Renamed.i + 1, 1));
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 Statusb 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Statusb = (MidB(s1, sub_Renamed.i + 2, 1));
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 statusC 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								statusC = (MidB(s1, sub_Renamed.i + 3, 1));
								//UPGRADE_WARNING: 未能解析对象 dot 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								dot = Statusa & 7;
								//UPGRADE_WARNING: 未能解析对象 arg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								arg = Statusa & 0x18;
								// mass = Val(Chr(AscB(MidB(s1, i + 4, 1)))) * 100000
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 5, 1))))) * 10000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 6, 1))))) * 1000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 7, 1))))) * 100;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 8, 1))))) * 10;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mass = System.Convert.ToInt32(mass) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 9, 1)))));
								//quality = Val(Chr(AscB(MidB(s1, i + 10, 1)))) * 100000
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 11, 1))))) * 10000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 12, 1))))) * 1000;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 13, 1))))) * 100;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 14, 1))))) * 10;
								//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
								//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								quality = System.Convert.ToInt32(quality) + Conversion.Val(Strings.Chr(System.Convert.ToInt32((MidB(s1, sub_Renamed.i + 15, 1)))));
								
								if ((int) dot == 1)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToInt32(mass) * 10 - 1000000;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToInt32(quality) * 10 - 1000000;
								}
								else if ((int) dot == 2)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = mass;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = quality;
								}
								else if ((int) dot == 3)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.1;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.1;
								}
								else if ((int) dot == 4)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.01;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.01;
								}
								else if ((int) dot == 5)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToDouble(mass) * 0.001;
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToDouble(quality) * 0.001;
								}
								//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								mtype = Statusb & 1;
								//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								fuhao = Statusb & 2;
								//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								danwei = Statusb & 0x10;
								//UPGRADE_WARNING: 未能解析对象 fuhao 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) fuhao == 2)
								{
									//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mass = System.Convert.ToInt32(- mass);
									//UPGRADE_WARNING: 未能解析对象 quality 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									quality = System.Convert.ToInt32(- quality);
								}
								//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) danwei == 0)
								{
									danwei = "磅";
								}
								else
								{
									//UPGRADE_WARNING: 未能解析对象 danwei 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									danwei = "千克";
								}
								//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								if ((int) mtype == 0)
								{
									mtype = "毛重";
								}
								else
								{
									//UPGRADE_WARNING: 未能解析对象 mtype 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
									mtype = "净重";
								}
								///'''''''''''''''显示毛重和皮重或者显示净重和皮重,毛重=净重+皮重
								//UPGRADE_WARNING: 未能解析对象 mass 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								Text3[0].Text = Conversion.Str(mass); //+ danwei '+ ",皮重" + Str(quality) + danwei
								break;
							}
						}
						break;
						
					default:
						break;
				}
				
				
			}
			
			
		}
		
		public void wiederpruf_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object 调十二 = null;
			object 调十一 = null;
			object 调十 = null;
			object 调九 = null;
			object 调八 = null;
			object 调七 = null;
			object 调六 = null;
			object 调五 = null;
			object 调四 = null;
			object 调三 = null;
			object 调二 = null;
			object 调一 = null;
			object Jiandingliang = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			sub_Renamed.Rechen = false; //用于超声表读表号不返回检定数据
			sub_Renamed.Readone = true; //用于超声表读表号不返回检定数据
			sub_Renamed.Jdks1 = true;
			//If Jdks1 = False Then
			// MsgBox "请首先进行参数设置！"
			//
			//Exit Sub
			//End If
			
			
			for (i = 0; i <= 11; i++)
			{
				Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i].Font, 9); //温度显示大小。
				Text10[2 * sub_Renamed.i].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i].Font, false);
				Text10[2 * sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
				Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeSize(Text10[2 * sub_Renamed.i + 1].Font, 9);
				Text10[2 * sub_Renamed.i + 1].Font = Microsoft.VisualBasic.Compatibility.VB6.Support.FontChangeItalic(Text10[2 * sub_Renamed.i + 1].Font, false);
				Text10[2 * sub_Renamed.i + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
				if (sub_Renamed.Chinese == true)
				{
					Text10[2 * sub_Renamed.i].Text = "进口温度";
					Text10[2 * sub_Renamed.i + 1].Text = "出口温度";
				}
				else
				{
					Text10[2 * sub_Renamed.i].Text = "In.Temp.";
					Text10[2 * sub_Renamed.i + 1].Text = "Ou.Temp";
				}
			}
			
			
			
			
			wiederpruf.Enabled = false;
			
			
			for (i = 0; i <= 11; i++)
			{
				Text1[sub_Renamed.i].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0); //将需进行流量参数修正标识的红色返回到黑色。
			}
			
			//调一.Enabled = False
			//调二.Enabled = False
			//调三.Enabled = False
			//调四.Enabled = False
			//调五.Enabled = False
			//调六.Enabled = False
			//调七.Enabled = False
			//调八.Enabled = False
			//调九.Enabled = False
			//调十.Enabled = False
			//调十一.Enabled = False
			//调十二.Enabled = False
			//调一.BackColor = &HC000&
			//调二.BackColor = &HC000&
			//调三.BackColor = &HC000&
			//调四.BackColor = &HC000&
			//调五.BackColor = &HC000&
			//调六.BackColor = &HC000&
			//调七.BackColor = &HC000&
			//调八.BackColor = &HC000&
			//调九.BackColor = &HC000&
			//调十.BackColor = &HC000&
			//调十一.BackColor = &HC000&
			//调十二.BackColor = &HC000&
			
			
			if (frmzjsz.Default.Option1.Checked == true)
			{
				
				读表号一.Enabled = true;
				读表号二.Enabled = true;
				读表号三.Enabled = true;
				读表号四.Enabled = true;
				读表号五.Enabled = true;
				读表号六.Enabled = true;
				读表号七.Enabled = true;
				读表号八.Enabled = true;
				读表号九.Enabled = true;
				读表号十.Enabled = true;
				读表号十一.Enabled = true;
				读表号十二.Enabled = true;
				
				switch (Metertype.SelectedIndex)
				{
					case 1:
					case 2:
					case 7:
						Chu1.Enabled = true;
						Chu2.Enabled = true;
						Chu3.Enabled = true;
						Chu4.Enabled = true;
						Chu5.Enabled = true;
						Chu6.Enabled = true;
						Chu7.Enabled = true;
						Chu8.Enabled = true;
						Chu9.Enabled = true;
						Chu10.Enabled = true;
						Chu11.Enabled = true;
						Chu12.Enabled = true;
						
						状态一.Enabled = true;
						状态二.Enabled = true;
						状态三.Enabled = true;
						状态四.Enabled = true;
						状态五.Enabled = true;
						状态六.Enabled = true;
						状态七.Enabled = true;
						状态八.Enabled = true;
						状态九.Enabled = true;
						状态十.Enabled = true;
						状态十一.Enabled = true;
						状态十二.Enabled = true;
						break;
					case 5:
						状态一.Enabled = true;
						状态二.Enabled = true;
						状态三.Enabled = true;
						状态四.Enabled = true;
						状态五.Enabled = true;
						状态六.Enabled = true;
						状态七.Enabled = true;
						状态八.Enabled = true;
						状态九.Enabled = true;
						状态十.Enabled = true;
						状态十一.Enabled = true;
						状态十二.Enabled = true;
						break;
				}
			}
			
			Llxuanze = (short) 0;
			if (sub_Renamed.MID1 == 2 | sub_Renamed.MID1 == 3) //带二个以上标准表采瞬流
			{
				Timer15.Enabled = true;
			}
			
			if (frmzjsz.Default.Option13.Checked == true) //重新排气时
			{
				if (Conversion.Val(Text3[0].Text) > 5)
				{
					if (sub_Renamed.Chinese == true)
					{
						Labt.Text = "天平正在放水，请等候...";
					}
					else
					{
						Labt.Text = "The weighing container are drainage, please wait ...";
					}
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.2));F;);
					} while (!(Conversion.Val(Text3[0].Text) <= 2));
					Labt.Text = "";
				}
				
				
				Text13.Visible = true;
				Text13.Text = (45).ToString();
				
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "正在排气..约需    秒";
				}
				else
				{
					Labt.Text = "Exhaust now,wait    s";
				}
				
				System.Int32 temp_i = 8;
				Mdlguanfa.Zhu_Guan(ref temp_i); //关打压阀
				delay_times(1);
				System.Int32 temp_i2 = 1;
				Mdlguanfa.Zhu_Kai(ref temp_i2); //进水开
				delay_times(1);
				System.Int32 temp_i3 = 2;
				Mdlguanfa.Zhu_Kai(ref temp_i3); //小流量开
				delay_times(1);
				System.Int32 temp_i4 = 3;
				Mdlguanfa.Zhu_Kai(ref temp_i4); //中流量开1
				delay_times(1);
				if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
				{
					System.Int32 temp_i5 = 4;
					Mdlguanfa.Zhu_Kai(ref temp_i5); //中流量开2
					delay_times(1);
				}
				if (sub_Renamed.Ld4 == 5)
				{
					System.Int32 temp_i6 = 5;
					Mdlguanfa.Zhu_Kai(ref temp_i6); //大流量开
					delay_times(1);
				}
				System.Int32 temp_i7 = 6;
				Mdlguanfa.Zhu_Kai(ref temp_i7); //大流量开
				delay_times(1);
				//       Zhu_Kai (7) '称放水开
				//       delay_times (1)
				Mdlguanfa.Send_Data((short) 249); //启动水泵
				delay_times(1);
				
				t6 = (short) 0;
				Timerpq.Enabled = true;
				Pqtime = (short) (Conversion.Val(Text13.Text));
				
				for (i = 0; i <= 11; i++)
				{
					Text1[sub_Renamed.i].Text = "";
					
					
					
					Text6[sub_Renamed.i].Text = "";
					Text8[sub_Renamed.i].Text = "";
					Text9[sub_Renamed.i].Text = "";
					Text11[sub_Renamed.i].Text = "";
					Text22[sub_Renamed.i].Text = "";
					Text33[sub_Renamed.i].Text = "";
					Text44[sub_Renamed.i].Text = "";
					sub_Renamed.TemVor[sub_Renamed.i] = 0;
					sub_Renamed.TemRuc[sub_Renamed.i] = 0;
				}
				
				//读表号过程
				for (i = 0; i <= 11; i++)
				{
					Text1[sub_Renamed.i].Text = "";
					Text11[sub_Renamed.i].Text = "";
				}
				if (sub_Renamed.Comopen == true)
				{
					//读表号过程
					
					sub_Renamed.cmd_type = "RD_NUM";
					Biao_Xuhao = (short) 0;
					Timer21.Enabled = true;
					Wancheng = false;
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
						if (Conversion.Val(Text13.Text) == 0)
						{
							if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xC000)
							{
								System.Int32 temp_i8 = 6;
								Mdlguanfa.Zhu_Guan(ref temp_i8); //当大阀开时
							}
							Labt.Text = "正在读取表号，请稍候...";
						}
					} while (!(Timer21.Enabled == false));
					
					if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7) //天罡超声表进入检定状态
					{
						
						delay_times(1);
						//        cmd_type = "WR_INPUT_JIANDING" '检定状态
						Biao_Xuhao = (short) 0;
						Timer23.Enabled = true;
						Wancheng = false;
						
						do
						{
							System.Windows.Forms.Application.DoEvents();
							if (Conversion.Val(Text13.Text) == 0)
							{
								if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xC000)
								{
									System.Int32 temp_i9 = 6;
									Mdlguanfa.Zhu_Guan(ref temp_i9); //当大阀开时
								}
								Labt.Text = "正在进入检定状态，请稍候...";
							}
						} while (!(Timer23.Enabled == false));
						
					}
					else if (Metertype.SelectedIndex == 5) //超声表进入检定状态
					{
						delay_times(1);
						sub_Renamed.cmd_type = "WR_INPUT_JIANDING"; //检定状态
						
						Biao_Xuhao = (short) 0;
						Timer21.Enabled = true;
						Wancheng = false;
						
						do
						{
							System.Windows.Forms.Application.DoEvents();
							if (Conversion.Val(Text13.Text) == 0)
							{
								if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xC000)
								{
									System.Int32 temp_i10 = 6;
									Mdlguanfa.Zhu_Guan(ref temp_i10); //当大阀开时
								}
								Labt.Text = "正在进入检定状态，请稍候...";
							}
						} while (!(Timer21.Enabled == false));
					}
					
					
				}
				do
				{
					System.Windows.Forms.Application.DoEvents();
				} while (!(Timerpq.Enabled == false));
				//       delay_times (Val(Text13.Text))
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "判断天平是否满足检定用量";
				}
				else
				{
					Labt.Text = "Judge balance meets test volume";
				}
				
				
				if (System.Drawing.ColorTranslator.ToOle(this.Shapzsd[6].BackColor) == 0xFF)
				{
					System.Int32 temp_i11 = 6;
					Mdlguanfa.Zhu_Kai(ref temp_i11);
				}
				TPVorbereitung();
				
				if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7) //天罡延时归零
				{
					//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Chuzhijs = 0;
					Timer13.Enabled = true;
				}
				
			}
			else //不重新排气
			{
				
				for (i = 0; i <= 11; i++)
				{
					Text6[sub_Renamed.i].Text = "";
					Text8[sub_Renamed.i].Text = "";
					Text9[sub_Renamed.i].Text = "";
					//    Text11(i).Text = ""
					Text22[sub_Renamed.i].Text = "";
					Text33[sub_Renamed.i].Text = "";
					Text44[sub_Renamed.i].Text = "";
					sub_Renamed.TemVor[sub_Renamed.i] = 0;
					sub_Renamed.TemRuc[sub_Renamed.i] = 0;
				}
				
				if (frmzjsz.Default.Option15.Checked == true) //连续检定
				{
					//UPGRADE_WARNING: 未能解析对象 Jiandingliang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Jiandingliang = 0;
					for (i = 1; i <= sub_Renamed.Jd_point; i++)
					{
						//UPGRADE_WARNING: 未能解析对象 Jiandingliang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						Jiandingliang = Jiandingliang + sub_Renamed.Jd_liang[sub_Renamed.i - 1];
					}
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 Jiandingliang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Jiandingliang = sub_Renamed.Jd_liang[0];
				}
				
				//UPGRADE_WARNING: 未能解析对象 Jiandingliang 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((Conversion.Val(Text3[0].Text) + Jiandingliang) >= 95)
				{
					
					if (sub_Renamed.Chinese == true)
					{
						Labt.Text = "天平正在放水，请等候...";
					}
					else
					{
						Labt.Text = "The weighing container are drainage, please wait ...";
					}
					
					//              Zhu_Kai (7) '放水开
					//              delay_times (1)
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.2));F;);
					} while (!(Conversion.Val(Text3[0].Text) < 2));
					System.Int32 temp_i12 = 7;
					Mdlguanfa.Zhu_Guan(ref temp_i12); //放水关
					delay_times(1);
					
					
					if (sub_Renamed.Chinese == true)
					{
						Labt.Text = "正在准备天平，请等候...";
					}
					else
					{
						Labt.Text = "Preparing balance, please wait ... ";
					}
					
					//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Dtpc = Conversion.Val(Text3[0].Text);
					System.Int32 temp_i13 = 6;
					Mdlguanfa.Zhu_Kai(ref temp_i13); //大水开
					delay_times(1);
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.2));F;);
						Dtpm = (float) (Conversion.Val(Text3[0].Text));
						//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					} while (!(Dtpm >= System.Convert.ToInt32(Dtpc) + 3));
					System.Int32 temp_i14 = 6;
					Mdlguanfa.Zhu_Guan(ref temp_i14); //关大水
					
					
				}
				else
				{
					
					System.Int32 temp_i15 = 7;
					Mdlguanfa.Zhu_Guan(ref temp_i15); //放水关
					delay_times(1);
					
					if (sub_Renamed.Chinese == true)
					{
						Labt.Text = "正在准备天平，请等候...";
					}
					else
					{
						Labt.Text = "Preparing balance, please wait ... ";
					}
					//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Dtpc = Conversion.Val(Text3[0].Text);
					System.Int32 temp_i16 = 6;
					Mdlguanfa.Zhu_Kai(ref temp_i16); //大水开
					delay_times(1);
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.2));F;);
						Dtpm = (float) (Conversion.Val(Text3[0].Text));
						//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					} while (!(Dtpm >= System.Convert.ToInt32(Dtpc) + 3));
					System.Int32 temp_i17 = 6;
					Mdlguanfa.Zhu_Guan(ref temp_i17); //关大水
					
					
				}
				
			} //排气结束
			
			short h = 0;
			
			h = (short) 0;
			bool bHao;
			if (sub_Renamed.Comopen == true) //自动采集时,
			{
				if (frmzjsz.Default.Option13.Checked == true) //重新排气时
				{
					
					Biao_Xuhao = (short) 0;
					
					if (Metertype.SelectedIndex != 8) //光大表无表号
					{
						bHao = false;
						for (i = 0; i <= sub_Renamed.Stueck; i++)
						{
							if (Text19[sub_Renamed.i + 1].Text != "通讯口不正常!")
							{
								if (Strings.Len(Text11[sub_Renamed.i].Text) != 14)
								{
									if (sub_Renamed.Chinese == true)
									{
										Labt.Text = "排气结束，请读出表号后点击《下一步》开始进行检测";
									}
									else
									{
										Labt.Text = "Exhaust end, please read out the meter number before the <<next>> to begin testing ";
									}
									bHao = true;
								}
							}
						}
						
						if (bHao == true)
						{
							sub_Renamed.Pqschutz = true;
							sub_Renamed.Flagnext = false;
							Command5.Visible = true;
							Command5.Focus();
							do
							{
								System.Windows.Forms.Application.DoEvents();
								delay_times((0.5));F;);
							} while (!(sub_Renamed.Flagnext == true));
						}
					}
					
				}
				
				//  '清数据
				//  If frmzjsz.Option8.value = True Then
				//   DataClear
				//  End If
				
				
				读表号一.Enabled = false;
				读表号二.Enabled = false;
				读表号三.Enabled = false;
				读表号四.Enabled = false;
				读表号五.Enabled = false;
				读表号六.Enabled = false;
				读表号七.Enabled = false;
				读表号八.Enabled = false;
				读表号九.Enabled = false;
				读表号十.Enabled = false;
				读表号十一.Enabled = false;
				读表号十二.Enabled = false;
				
				状态一.Enabled = false;
				状态二.Enabled = false;
				状态三.Enabled = false;
				状态四.Enabled = false;
				状态五.Enabled = false;
				状态六.Enabled = false;
				状态七.Enabled = false;
				状态八.Enabled = false;
				状态九.Enabled = false;
				状态十.Enabled = false;
				状态十一.Enabled = false;
				状态十二.Enabled = false;
				
				//UPGRADE_WARNING: 未能解析对象 调一.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调一.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调二.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调二.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调三.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调三.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调四.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调四.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调五.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调五.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调六.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调六.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调七.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调七.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调八.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调八.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调九.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调九.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调十.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调十.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调十一.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调十一.BackColor = 0xC000;
				//UPGRADE_WARNING: 未能解析对象 调十二.BackColor 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				调十二.BackColor = 0xC000;
				
				
				读数1.Enabled = true;
				读数2.Enabled = true;
				读数3.Enabled = true;
				读数4.Enabled = true;
				读数5.Enabled = true;
				读数6.Enabled = true;
				读数7.Enabled = true;
				读数8.Enabled = true;
				读数9.Enabled = true;
				读数10.Enabled = true;
				读数11.Enabled = true;
				读数12.Enabled = true;
				
			}
			else //不自动采集时
			{
				if (frmzjsz.Default.Option13.Checked == true)
				{
					for (i = 0; i <= sub_Renamed.Stueck; i++)
					{
						if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
						{
							h++;
						}
					}
					
					if (h != sub_Renamed.Stueck + 1)
					{
						
						if (sub_Renamed.Chinese == true)
						{
							Labt.Text = "排气结束，请输入表号后点击《下一步》开始进行检测";
						}
						else
						{
							Labt.Text = "Exhaust end, please enter the meter number before the 《next》 to begin testing ";
						}
						sub_Renamed.Pqschutz = true;
						sub_Renamed.Flagnext = false;
						
						Text1[0].Focus();
						Command5.Visible = true;
						do
						{
							System.Windows.Forms.Application.DoEvents();
							delay_times((0.5));F;);
						} while (!(sub_Renamed.Flagnext == true));
					}
				}
			}
			
			
			
			// listvol
			xx = (short) 1;
			
			sub_Renamed.End_biaowei = (short) 0;
			sub_Renamed.Jd_number = (short) 0;
			for (i = 0; i <= 11; i++)
			{
				sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 0;
				if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
				{
					sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 1;
					sub_Renamed.End_biaowei = sub_Renamed.i;
				}
				sub_Renamed.Jd_number = sub_Renamed.Jd_number + sub_Renamed.Jd_biaowei[sub_Renamed.i];
			}
			sub_Renamed.Jd_meter = sub_Renamed.Jd_number;
			Labt.Text = "";
			
			short k = 0;
			for (xx = 1; xx <= sub_Renamed.Jd_point; xx++) //流程： 逐个流量点进行
			{
				
				读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				
				sub_Renamed.RechenLC = false;
				
				
				Label10.Visible = true;
				Label7[0].Visible = true;
				Label7[2].Visible = true;
				Label7[2].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Jd_flow[xx - 1], "0.0##");
				
				Label18.Visible = true;
				Label7[1].Visible = true;
				Label7[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format((double.Parse(Text14.Text)) - double.Parse(Text12.Text), "0.00");
				
				if (xx == 1)
				{
					
					if (frmzjsz.Default.Option1.Checked == true) //自动采集时,
					{
						if (Option3.Checked == true) //如果初值回零
						{
							for (i = 0; i <= sub_Renamed.End_biaowei; i++)
							{
								if (Strings.Len(Text11[sub_Renamed.i].Text) == 14) //对无表号表位不赋0值
								{
									sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
									Text6[sub_Renamed.i].Text = (0).ToString();
								}
								else
								{
									Text6[sub_Renamed.i].Text = "";
								}
							}
						}
						else //如果初值不回零
						{
							Labt.Text = "正在采集被检表初值，请稍候...";
							sub_Renamed.Readone = true; //不读温度值
							sub_Renamed.Rechen = false; //采集数据不计算误差
							sub_Renamed.Erstpunkt = true;
							switch (Metertype.SelectedIndex)
							{
								case 0:
								case 3:
								case 4:
								case 5:
								case 6:
								case 8:
									sub_Renamed.cmd_type = "RD_HIGH_DATA";
									break;
							}
							Biao_Xuhao = (short) 0;
							Timer21.Enabled = true;
							Wancheng = false;
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
							} while (!(Timer21.Enabled == false));
							Readingonerror();
							delay_times(1);
							sub_Renamed.Erstpunkt = false;
							
						} //初值回零结束
						
					}
					else //不自动采集时,
					{
						if (Option3.Checked == true) //如果初值回零
						{
							for (i = 0; i <= sub_Renamed.End_biaowei; i++)
							{
								if (Strings.Len(Text1[sub_Renamed.i].Text) > 0) //对无表号表位不赋0值
								{
									sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
									Text6[sub_Renamed.i].Text = (0).ToString();
								}
								else
								{
									Text6[sub_Renamed.i].Text = "";
								}
							}
							
						}
						else //如果初值不回零
						{
							sub_Renamed.Flagnext = false;
							Command5.Visible = true;
							
							if (sub_Renamed.Chinese == true)
							{
								if (Option6.Checked == true)
								{
									Labt.Text = "请填写被检表热量初值（kWh）,并点击《下一步》确认";
								}
								else
								{
									Labt.Text = "请填写被检表热量初值（MJ）,并点击《下一步》确认";
								}
							}
							else
							{
								if (Option6.Checked == true)
								{
									Labt.Text = "Please enter Eo(kWh) of meters, and then click on 《next》 to continue ";
								}
								else
								{
									Labt.Text = "Please enter Eo(MJ) of meters, and then click on 《next》 to continue ";
								}
							}
							
							
							for (i = 0; i <= 11; i++)
							{
								sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
								Text6[sub_Renamed.i].Text = "";
							}
							// 找第一个装表的表位
							for (i = 0; i <= sub_Renamed.End_biaowei; i++)
							{
								if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
								{
									goto ss;
								}
							}
ss:
							Text6[sub_Renamed.i].Focus();
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
								delay_times((0.5));F;);
							} while (!(sub_Renamed.Flagnext == true));
						} //回零结束
						
					} //'自动采集结束,
				}
				else //如果不是第一遍
				{
					if (frmzjsz.Default.Option16.Checked == true) //如果不是连续检定
					{
						if ((Conversion.Val(Text3[0].Text) + sub_Renamed.Jd_liang[xx - 1]) >= 100)
						{
							System.Int32 temp_i18 = 7;
							Mdlguanfa.Zhu_Kai(ref temp_i18); //量器放水
							delay_times(1);
							
							Labt.Text = "天平正在放水，请等候...";
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
								delay_times(1);
							} while (!(Conversion.Val(Text3[0].Text) + sub_Renamed.Jd_liang[xx - 1] < 95));
							
							System.Int32 temp_i19 = 7;
							Mdlguanfa.Zhu_Guan(ref temp_i19); //放水关
							delay_times(3);
						}
					}
					if (Option3.Checked == true) //如果初值回零
					{
						
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							if (Strings.Len(Text1[sub_Renamed.i].Text) > 0) //对无表号表位不赋0值
							{
								sub_Renamed.lLChuzhi[sub_Renamed.i] = 0;
								Text6[sub_Renamed.i].Text = (0).ToString();
							}
							else
							{
								Text6[sub_Renamed.i].Text = "";
							}
							//                               Text8(i).Text = ""
						}
						
					}
					else //如果初值不回零
					{
						//
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							Text6[sub_Renamed.i].Text = Text8[sub_Renamed.i].Text;
							sub_Renamed.lLChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text8[sub_Renamed.i].Text));
							sub_Renamed.llZhongzhi[sub_Renamed.i] = 0;
							//                        Text4(i).Text = ""
						}
						
						
					} //回零结束
					
				} //第一遍结束
				
				
				sub_Renamed.Zlm0 = (float) (Conversion.Val(Text3[0].Text));
				
				if (Timer13.Enabled == true)
				{
					Labt.Text = "正在等待自动回零时间...";
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.5));F;);
					} while (!(Timer13.Enabled == false)); //等待10秒钟，初值自动回零。
				}
				
				if (sub_Renamed.Ld4 == 3)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i20 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i20); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i21 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i21); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i22 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i22); //
					}
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i23 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i23); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i24 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i24); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i25 = 4;
						Mdlguanfa.Zhu_Kai(ref temp_i25); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[2] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[3])
					{
						Llxuanze = (short) 4;
						System.Int32 temp_i26 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i26); //
					}
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i27 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i27); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i28 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i28); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i29 = 4;
						Mdlguanfa.Zhu_Kai(ref temp_i29); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[2] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[3])
					{
						Llxuanze = (short) 4;
						System.Int32 temp_i30 = 5;
						Mdlguanfa.Zhu_Kai(ref temp_i30); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[3] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[4])
					{
						Llxuanze = (short) 5;
						System.Int32 temp_i31 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i31); //
					}
				}
				delay_times(1);
				
				读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				
				sub_Renamed.zeit = 0;
				Text7.Text = (0).ToString();
				//               Textjs.Text = 0
				Timer10.Enabled = true;
				
				
				
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "正在通水检测，请等待约     秒";
				}
				else
				{
					Labt.Text = "Testing now, wait about     seconds ";
				}
				
				
				//采温度
				sub_Renamed.jkwd = 0;
				sub_Renamed.ckwd = 0;
				sub_Renamed.wdjs = 0;
				Timer11.Enabled = true;
				
				sub_Renamed.Njkwd = 0;
				sub_Renamed.Nckwd = 0;
				sub_Renamed.Nwdjs = 0;
				Timer17.Enabled = true;
				
				if (sub_Renamed.MID1 == 0 | sub_Renamed.MID1 == 1)
				{
					sub_Renamed.jsjs = 0;
					sub_Renamed.Leiji = 0;
					Tianping2 = (short) 0;
					Timer9.Enabled = true; //开始计算瞬流
				}
				
				Jsz = (short) 0;
				llJs = 0;
				ssLL = 0;
				Timer12.Enabled = true; //计六秒后开始采集平均瞬流
				
				Dtianping = 0;
				Caiji();
				
				Timer11.Enabled = false; //温度采集结束
				Timer12.Enabled = false; //流量采集结束
				Timer17.Enabled = true;
				
				for (j = 0; j <= sub_Renamed.End_biaowei; j++) //计算每个表温度及密度
				{
					sub_Renamed.Zlwendu[j] = (float) (System.Math.Round(sub_Renamed.inlet - (sub_Renamed.inlet - sub_Renamed.outlet) / (sub_Renamed.Stueck + 2) * (j + 1), 2));
					//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.ZlMiDu[j] = float.Parse(Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(mdlyingpanxuliehao.MiDu(Conversion.Str(sub_Renamed.Zlwendu[j])), "0.0000"));
				}
				
				Text14.Text = (sub_Renamed.Ninlet).ToString();
				Text12.Text = (sub_Renamed.Noutlet).ToString();
				
				if (sub_Renamed.Ld4 == 3) //三管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i32 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i32); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i33 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i33); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i34 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i34); //
						delay_times(1);
					}
				}
				else if (sub_Renamed.Ld4 == 4) //四管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i35 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i35); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i36 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i36); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i37 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i37); //
						delay_times(1);
					}
					else if (Llxuanze == 4)
					{
						System.Int32 temp_i38 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i38); //
						delay_times(1);
					}
				}
				else if (sub_Renamed.Ld4 == 5) //五管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i39 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i39); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i40 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i40); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i41 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i41); //
						delay_times(1);
					}
					else if (Llxuanze == 4)
					{
						System.Int32 temp_i42 = 5;
						Mdlguanfa.Zhu_Guan(ref temp_i42); //
						delay_times(1);
					}
					else if (Llxuanze == 5)
					{
						System.Int32 temp_i43 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i43); //
						delay_times(1);
					}
				}
				
				
				Label12.Visible = false;
				Timer10.Enabled = false;
				
				Timer9.Enabled = false;
				Text3[1].Text = (0).ToString();
				Timer7.Enabled = true; //计算流量误差限
				
				if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7) //天罡延时归零
				{
					//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Chuzhijs = 0;
					Timer13.Enabled = true;
				}
				
				if (sub_Renamed.Comopen == true) //如果自动采集
				{
					if (sub_Renamed.Chinese == true)
					{
						Labt.Text = "通水检测结束，正在读取被检表终值，请稍候...";
					}
					else
					{
						Labt.Text = "Testing is over, the test values are read now, please wait ... ";
					}
				}
				else
				{
					if (sub_Renamed.Chinese == true)
					{
						Labt.Text = "通水检测结束，正等待稳定时间...";
					}
					else
					{
						Labt.Text = "Testing is over, waiting for the stable time of balance ...";
					}
					
				}
				
				delay_times(5);
				
				sub_Renamed.Zlm1 = (float) (Conversion.Val(Text3[0].Text));
				
				if (sub_Renamed.Comopen == true) //如果自动采集
				{
					
					for (i = 0; i <= sub_Renamed.End_biaowei; i++)
					{
						Text44[sub_Renamed.i].Text = "";
						Text33[sub_Renamed.i].Text = "";
						Text22[sub_Renamed.i].Text = "";
						Text8[sub_Renamed.i].Text = "";
						Text9[sub_Renamed.i].Text = "";
					}
					
					//记录体积数
					sub_Renamed.Tem = true;
					
					if (Metertype.SelectedIndex == 0) //需第一次读数为了表示值结束，
					{
						sub_Renamed.Readone = true; //不读温度值
						sub_Renamed.Rechen = false; //采集数据不计算误差
						sub_Renamed.cmd_type = "RD_HIGH_DATA";
						Biao_Xuhao = (short) 0;
						Timer21.Enabled = true;
						Wancheng = false;
						
						do
						{
							System.Windows.Forms.Application.DoEvents();
						} while (!(Timer21.Enabled == false));
					}
					//读终值
					sub_Renamed.Erstpunkt = false;
					sub_Renamed.Rechen = true; //用于采集数据计算误差
					
					switch (Metertype.SelectedIndex)
					{
						case 3:
						case 4:
						case 5:
							sub_Renamed.Readone = true; //不读温度值
							break;
						default:
							sub_Renamed.Readone = false; //读温度值
							break;
					}
					
					sub_Renamed.RechenLC = false;
					sub_Renamed.cmd_type = "RD_HIGH_DATA";
					Biao_Xuhao = (short) 0;
					Timer21.Enabled = true;
					Wancheng = false;
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
					} while (!(Timer21.Enabled == false));
					Readingonerror();
					delay_times(1);
					switch (Metertype.SelectedIndex)
					{
						case 3:
						case 4:
						case 5:
							
							读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
							
							
							sub_Renamed.Erstpunkt = false;
							sub_Renamed.Readone = false; //读温度值
							sub_Renamed.RechenLC = true; //采集数据不计算误差
							sub_Renamed.cmd_type = "RD_DATA"; //读温度值
							Biao_Xuhao = (short) 0;
							Timer21.Enabled = true;
							Wancheng = false;
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
							} while (!(Timer21.Enabled == false));
							Readingonerror();
							delay_times(1);
							break;
					}
					
					sub_Renamed.Tem = false;
					
					
				}
				else //如果不是自动采集
				{
					
					if (sub_Renamed.Chinese == true)
					{
						if (Option6.Checked == true)
						{
							Labt.Text = "通水检测结束，请输入被检表热量终值（kWh）";
						}
						else
						{
							Labt.Text = "通水检测结束，请输入被检表热量终值（MJ）";
						}
					}
					else
					{
						if (Option6.Checked == true)
						{
							Labt.Text = "Testing is over, Please enter E1（kWh） of meters";
						}
						else
						{
							Labt.Text = "Testing is over, Please enter E1（MJ） of meters";
						}
					}
					
					
					for (i = 0; i <= sub_Renamed.End_biaowei; i++)
					{
						sub_Renamed.ZlZhongzhi[sub_Renamed.i] = 0;
						Text8[sub_Renamed.i].Text = "";
					}
					// 找第一个装表的表位
					for (i = 0; i <= sub_Renamed.End_biaowei; i++)
					{
						if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
						{
							goto UM;
						}
					}
UM:
					Text8[sub_Renamed.i].Focus();
					
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.5));F;);
					} while (!(sub_Renamed.ZlZhongzhi[sub_Renamed.End_biaowei] > 0));
					
					
				} // 结束自动采集判断
				
				
				
				
				k = (short) 0;
				for (j = 0; j <= sub_Renamed.End_biaowei; j++)
				{
					
					if (Strings.Len(Text1[j].Text) > 0)
					{
						if (j == 0)
						{
							k = (short) 1;
						}
						else if (j == 1)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
						}
						else if (j == 2)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
						}
						else if (j == 3)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
						}
						else if (j == 4)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
						}
						else if (j == 5)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
						}
						else if (j == 6)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
						}
						else if (j == 7)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
						}
						else if (j == 8)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
						}
						else if (j == 9)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
						}
						else if (j == 10)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
						}
						else if (j == 11)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
						}
						
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 1) = "q:" + "" + System.Convert.ToString(Llds) + "" + "、" + "Δθ:" + "" + System.Convert.ToString(Text14.Text) - double.Parse(Text12.Text);); //平均流量点
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 2) = Text1[j].Text; //表号
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 3) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlChuzhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 4) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlZhongzhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 5) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlShizhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 6) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm0, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 7) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm1, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 8) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm1 - sub_Renamed.Zlm0, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 9) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlwendu[j], "###0.##");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 10) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlMiDu[j], "###0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 11) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.BiaozhunzhiE[j], "###0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 12) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Text9[j].Text, "0.0");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 13) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE, "0.00");
						
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(zz + 1, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 17)).Font.Size = 10;
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(zz + 1, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 17)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(zz + 1, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 17)).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
						
						
						
						if (System.Math.Abs(System.Convert.ToDouble(Text9[j].Text)) > sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE)
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 14) = "不合格";
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 14).Font.Color = 0xFF;
						}
						else
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 14) = "合格";
						}
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 15) = j + 1;
						
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 14).Font.Color == 0xFF)
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 15).Font.Color = 0xFF;
						}
						
						
						if (sub_Renamed.Comopen == true) //自动采集时
						{
							
							sub_Renamed.Teminlet[xx, j] = (float) (Conversion.Val(Text10[2 * j].Text));
							sub_Renamed.Temoutlet[xx, j] = (float) (Conversion.Val(Text10[2 * j + 1].Text));
							//                Dim xy As Integer
							//
							//                If xx > 2 Then
							//                xy = 2
							//                Else
							//                xy = xx
							//                End If
							sub_Renamed.TemVor[j] = (float) (Conversion.Val(Text10[2 * j].Text));
							sub_Renamed.TemRuc[j] = (float) (Conversion.Val(Text10[2 * j + 1].Text));
							
							//计算温度示值误差
							
							if (System.Math.Abs(sub_Renamed.TemVor[j] - double.Parse(Text14.Text)) > 0.3 + 0.005 * Conversion.Val(Text14.Text))
							{
								Text10[2 * j].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
							}
							else
							{
								Text10[2 * j].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
							}
							if (System.Math.Abs(sub_Renamed.TemRuc[j] - double.Parse(Text12.Text)) > 0.3 + 0.005 * Conversion.Val(Text12.Text))
							{
								Text10[2 * j + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
							}
							else
							{
								Text10[2 * j + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
							}
							
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 16) = System.Math.Round(sub_Renamed.TemVor[j], 2);
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 17) = System.Math.Round(sub_Renamed.TemRuc[j], 2);
							if (System.Math.Abs(sub_Renamed.TemVor[j] - double.Parse(Text14.Text)) > 0.3 + 0.005 * Conversion.Val(Text14.Text))
							{
								//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 16).Font.Color = 0xFF;
							}
							if (System.Math.Abs(sub_Renamed.TemRuc[j] - double.Parse(Text12.Text)) > 0.3 + 0.005 * Conversion.Val(Text12.Text))
							{
								//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
								sub_Renamed.objExcel.ActiveSheet.Cells(zz + k, 17).Font.Color = 0xFF;
							}
							
							
						} //自动采集结束
						
					} //If Len(Text1(j).Text) > 0
					
				}
				zz = zz + k;
				if (xx != sub_Renamed.Jd_point)
				{
					MessageBox.Show("请将恒温浴槽调到第" + "" + System.Convert.ToString(xx + 1) + "" + "检定点的" + "" + System.Convert.ToString(sub_Renamed.Jd_wc[xx]) + "" + "K 温差点!  点击《确定》将开始下一点检定!");
				}
				
			}
			
			//'全部结束处理
			
			Protokol2();
			delay_times(1);
			读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			
			读数1.Enabled = false;
			读数2.Enabled = false;
			读数3.Enabled = false;
			读数4.Enabled = false;
			读数5.Enabled = false;
			读数6.Enabled = false;
			读数7.Enabled = false;
			读数8.Enabled = false;
			读数9.Enabled = false;
			读数10.Enabled = false;
			读数11.Enabled = false;
			读数12.Enabled = false;
			
			
			if (frmzjsz.Default.Frame9.Enabled == true) //重复检测时
			{
				if (frmzjsz.Default.Option13.Checked == true) //重新排气时
				{
					Mdlguanfa.Send_Data((short) 250);
					delay_times(1);
					System.Int32 temp_i44 = 1;
					Mdlguanfa.Zhu_Guan(ref temp_i44); //关进水阀
					delay_times(1);
					System.Int32 temp_i45 = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i45); //称放水开
					delay_times(1);
					System.Int32 temp_i46 = 8;
					Mdlguanfa.Zhu_Kai(ref temp_i46); //开打压阀
				}
				else if (frmzjsz.Default.Option14.Checked == true) //不重新排气时
				{
					System.Int32 temp_i47 = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i47); //称放水开
					delay_times(1);
				}
			}
			else
			{
				Mdlguanfa.Send_Data((short) 250);
				delay_times(1);
				System.Int32 temp_i48 = 1;
				Mdlguanfa.Zhu_Guan(ref temp_i48); //关进水阀
				delay_times(1);
				System.Int32 temp_i49 = 7;
				Mdlguanfa.Zhu_Kai(ref temp_i49); //称放水开
				delay_times(1);
				System.Int32 temp_i50 = 8;
				Mdlguanfa.Zhu_Kai(ref temp_i50); //开打压阀
			}
			
			Timer15.Enabled = false;
			
			Label7[0].Visible = false;
			Label18.Visible = false;
			Label10.Visible = false;
			Label7[1].Visible = false;
			Label7[2].Visible = false;
			
			//Labt.Caption = "检定完毕，如需要调整误差，请点击《调整系数》。完毕后点击《下一步》进行记录整理！"
			
			//                            Flagnext = False
			//                            Command5.Visible = True
			//                            Do
			//                            DoEvents
			//                            Loop Until Flagnext = True
			
			//删除多余不合格空表格
			//   ww = yy - 50 '从表格开始处再倒回有可能不合格所删除的行（50行）
			//   If ww < 6 Then ww = 6
			//    For i = zz To ww Step -1
			//    If objExcel.ActiveSheet.Cells(i, 2) = "" And objExcel.ActiveSheet.Cells(i, 1) = "" Then
			//    objExcel.ActiveSheet.Rows(i).Delete
			//    End If
			//    Next i
			
			//'表格中检表数量
			//    ww = 0
			//    For i = zz To 6 Step -1
			//    If Comopen = True Then
			//      If Len(objExcel.ActiveSheet.Cells(i, 2)) = 8 And objExcel.ActiveSheet.Cells(i, 1) <> "" Then ww = ww + 1
			//    Else
			//      If Len(objExcel.ActiveSheet.Cells(i, 2)) > 0 And objExcel.ActiveSheet.Cells(i, 1) <> "" Then ww = ww + 1
			//    End If
			//    Next i
			//
			//    If frmzjsz.Option11.value = True Then
			//          If Jd_point = 4 Then ww = Int(ww / 5)
			//          If Jd_point = 3 Then ww = Int(ww / 4)
			//          If Jd_point = 2 Then ww = Int(ww / 3)
			//          If Jd_point = 1 Then ww = Int(ww / 2)
			//    Else
			//          If Jd_point = 4 Then ww = Int(ww / 4)
			//          If Jd_point = 3 Then ww = Int(ww / 3)
			//          If Jd_point = 2 Then ww = Int(ww / 2)
			//          If Jd_point = 1 Then ww = Int(ww / 1)
			//    End If
			//    objExcel.ActiveSheet.Cells(2, 17) = ww
			//
			//    If ww = 50 Then
			//      Title = "重新开始"
			//      msg = MsgBox("检定表记录已到50只表，需重新开始吗？", vbYesNo + vbQuestion + vbApplicationModal, "提示")
			//      Select Case msg
			//      Case vbYes
			//            Labt.Caption = "本次检定结束，请点击《退出》重新开始下次检定！"
			//            yibiao_No = ""
			//            yibiao_No = Trim(Str(yibiaoNo))
			//            Call save_execel
			//            objExcel.Workbooks(1).SaveAs (App.Path & "\report\" & Trim(yibiao_No) & ".xls")
			//             Call PrintllZL
			//             wiederpruf.Enabled = False
			//           Exit Sub
			//
			//          Case vbNo
			//          End Select
			//    End If
			//
			yy = zz; //记录表格末行作为下个表格开始行
			
			sub_Renamed.yibiao_No = int.Parse("");
			sub_Renamed.yibiao_No = int.Parse(Conversion.Str(Mdlguanfa.yibiaoNo).Trim());
			sub_Renamed.save_execel();
			sub_Renamed.objExcel.Workbooks(1).SaveCopyAs((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\report\\" + (sub_Renamed.yibiao_No).ToString().Trim() + ".xls");
			PrintZong();
			
			if (frmzjsz.Default.Frame9.Enabled == true) //如重新排气
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "检定完毕，重复本次检定点击《重复检测》。重新开始下次检定点击《退出》！";
				}
				else
				{
					Labt.Text = "Test is complete,the duplicate test clicks on the《Repeat》. Restart the new test you click on the 《Exit》 ! ";
				}
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "检定完毕，重新开始下次检定点击《退出》！";
				}
				else
				{
					Labt.Text = "Test is complete, Restart the new test you click on the 《Exit》 ! ";
				}
			}
			
			sub_Renamed.Jdks = false;
			
			
			if (frmzjsz.Default.Frame9.Enabled == true)
			{
				wiederpruf.Enabled = true;
			}
			
			
		}
		
		private string getstr(object v, short l)
		{
			string returnValue = "";
			
			//UPGRADE_WARNING: 未能解析对象 s 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			s = "";
			for ( = ;0; i <= l - 1); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 v() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 s1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				s1 = VB.Strings.Right("0" + Conversion.Hex(v(sub_Renamed.i)), 2);
				//UPGRADE_WARNING: 未能解析对象 s1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 s 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				s = s + System.Convert.ToString(s1);
			}
			//UPGRADE_WARNING: 未能解析对象 s 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			returnValue = System.Convert.ToString(s);
			return returnValue;
		}
		
		
		//Private Sub SendData1(data As String)
		// On Error Resume Next
		//
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		//ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(0).PortOpen = True Then MSComm6(0).PortOpen = False
		//  MSComm6(0).Settings = "9600,e,8,1"
		//If MSComm6(0).PortOpen = False Then MSComm6(0).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(0).PortOpen = False Then
		//    Text19(1).Visible = True
		//    If Chinese = True Then
		//    Text19(1).Text = "通讯口不正常!"
		//    Else
		//    Text19(1).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(1).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(0).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(0).PortOpen = True Then MSComm6(0).PortOpen = False
		//    MSComm6(0).Settings = "2400,e,8,1"
		//   If MSComm6(0).PortOpen = False Then MSComm6(0).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(0).Output = buf
		//End If
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg1 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(0).Output = buf
		//
		//Else
		//    If MSComm6(0).PortOpen = True Then MSComm6(0).PortOpen = False
		//    MSComm6(0).PortOpen = True
		//      If MSComm6(0).PortOpen = False Then
		//        Text19(1).Visible = True
		//        If Chinese = True Then
		//           Text19(1).Text = "通讯口不正常!"
		//        Else
		//           Text19(1).Text = "Comport false!"
		//        End If
		//        Exit Sub
		//      Else
		//        Text19(1).Visible = False
		//        MSComm6(0).Output = buf
		//      End If
		//End If
		//Sendend = True
		//
		//End Sub
		//Private Sub SendData2(data As String)
		//On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(1).PortOpen = True Then MSComm6(1).PortOpen = False
		//  MSComm6(1).Settings = "9600,e,8,1"
		//If MSComm6(1).PortOpen = False Then MSComm6(1).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(1).PortOpen = False Then
		//    Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(2).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(1).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(1).PortOpen = True Then MSComm6(1).PortOpen = False
		//    MSComm6(1).Settings = "2400,e,8,1"
		//   If MSComm6(1).PortOpen = False Then MSComm6(1).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(1).Output = buf
		//End If
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg2 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(1).Output = buf
		//Else
		//    If MSComm6(1).PortOpen = True Then MSComm6(1).PortOpen = False
		//    MSComm6(1).PortOpen = True
		//    If MSComm6(1).PortOpen = False Then
		//    Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(2).Visible = False
		//'
		//    MSComm6(1).Output = buf
		//
		//   End If
		//End If
		//Sendend = True
		//
		//End Sub
		//Private Sub SendData3(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(2).PortOpen = True Then MSComm6(2).PortOpen = False
		//  MSComm6(2).Settings = "9600,e,8,1"
		//If MSComm6(2).PortOpen = False Then MSComm6(2).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(2).PortOpen = False Then
		//    Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(3).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(2).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(2).PortOpen = True Then MSComm6(2).PortOpen = False
		//    MSComm6(2).Settings = "2400,e,8,1"
		//   If MSComm6(2).PortOpen = False Then MSComm6(2).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(2).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg3 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(2).Output = buf
		//Else
		//    If MSComm6(2).PortOpen = True Then MSComm6(2).PortOpen = False
		//    MSComm6(2).PortOpen = True
		//    If MSComm6(2).PortOpen = False Then
		//    Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(3).Visible = False
		//'
		//    MSComm6(2).Output = buf
		//
		//   End If
		//   End If
		//Sendend = True
		//    End Sub
		//Private Sub SendData4(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(3).PortOpen = True Then MSComm6(3).PortOpen = False
		//  MSComm6(3).Settings = "9600,e,8,1"
		//If MSComm6(3).PortOpen = False Then MSComm6(3).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(3).PortOpen = False Then
		//    Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(4).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(3).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(3).PortOpen = True Then MSComm6(3).PortOpen = False
		//    MSComm6(3).Settings = "2400,e,8,1"
		//   If MSComm6(3).PortOpen = False Then MSComm6(3).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(3).Output = buf
		//End If
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg4 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(3).Output = buf
		//Else
		//    If MSComm6(3).PortOpen = True Then MSComm6(3).PortOpen = False
		//    MSComm6(3).PortOpen = True
		//    If MSComm6(3).PortOpen = False Then
		//    Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(4).Visible = False
		//'
		//    MSComm6(3).Output = buf
		//
		//   End If
		//End If
		//  Sendend = True
		//    End Sub
		//Private Sub SendData5(data As String)
		// On Error Resume Next
		//
		//
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(4).PortOpen = True Then MSComm6(4).PortOpen = False
		//  MSComm6(4).Settings = "9600,e,8,1"
		//If MSComm6(4).PortOpen = False Then MSComm6(4).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(4).PortOpen = False Then
		//    Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(5).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(4).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(4).PortOpen = True Then MSComm6(4).PortOpen = False
		//    MSComm6(4).Settings = "2400,e,8,1"
		//   If MSComm6(4).PortOpen = False Then MSComm6(4).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(4).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg5 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(4).Output = buf
		//Else
		//    If MSComm6(4).PortOpen = True Then MSComm6(4).PortOpen = False
		//    MSComm6(4).PortOpen = True
		//    If MSComm6(4).PortOpen = False Then
		//    Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(5).Visible = False
		//'
		//    MSComm6(4).Output = buf
		//
		//   End If
		//
		//End If
		//Sendend = True
		//
		//    End Sub
		//
		//Private Sub SendData6(data As String)
		//On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(5).PortOpen = True Then MSComm6(5).PortOpen = False
		//  MSComm6(5).Settings = "9600,e,8,1"
		//If MSComm6(5).PortOpen = False Then MSComm6(5).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(5).PortOpen = False Then
		//    Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(6).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(5).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(5).PortOpen = True Then MSComm6(5).PortOpen = False
		//    MSComm6(5).Settings = "2400,e,8,1"
		//   If MSComm6(5).PortOpen = False Then MSComm6(5).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(5).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg6 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(5).Output = buf
		//Else
		//    If MSComm6(5).PortOpen = True Then MSComm6(5).PortOpen = False
		//    MSComm6(5).PortOpen = True
		//    If MSComm6(5).PortOpen = False Then
		//    Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(6).Visible = False
		//'
		//    MSComm6(5).Output = buf
		//
		//   End If
		// End If
		// Sendend = True
		//    End Sub
		//Private Sub SendData7(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(6).PortOpen = True Then MSComm6(6).PortOpen = False
		//  MSComm6(6).Settings = "9600,e,8,1"
		//If MSComm6(6).PortOpen = False Then MSComm6(6).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(6).PortOpen = False Then
		//    Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(7).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(6).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(6).PortOpen = True Then MSComm6(6).PortOpen = False
		//    MSComm6(6).Settings = "2400,e,8,1"
		//   If MSComm6(6).PortOpen = False Then MSComm6(6).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(6).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg7 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(6).Output = buf
		//Else
		//    If MSComm6(6).PortOpen = True Then MSComm6(6).PortOpen = False
		//    MSComm6(6).PortOpen = True
		//    If MSComm6(6).PortOpen = False Then
		//    Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(7).Visible = False
		//'
		//
		//    MSComm6(6).Output = buf
		// End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData8(data As String)
		//On Error Resume Next
		//      Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(7).PortOpen = True Then MSComm6(7).PortOpen = False
		//  MSComm6(7).Settings = "9600,e,8,1"
		//If MSComm6(7).PortOpen = False Then MSComm6(7).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(7).PortOpen = False Then
		//    Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(8).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(7).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(7).PortOpen = True Then MSComm6(7).PortOpen = False
		//    MSComm6(7).Settings = "2400,e,8,1"
		//   If MSComm6(7).PortOpen = False Then MSComm6(7).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(7).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg8 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(7).Output = buf
		//Else
		//    If MSComm6(7).PortOpen = True Then MSComm6(7).PortOpen = False
		//    MSComm6(7).PortOpen = True
		//    If MSComm6(7).PortOpen = False Then
		//    Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(8).Visible = False
		//'
		//
		//    MSComm6(7).Output = buf
		//End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData9(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(8).PortOpen = True Then MSComm6(8).PortOpen = False
		//  MSComm6(8).Settings = "9600,e,8,1"
		//If MSComm6(8).PortOpen = False Then MSComm6(8).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(8).PortOpen = False Then
		//    Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(9).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(8).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(8).PortOpen = True Then MSComm6(8).PortOpen = False
		//    MSComm6(8).Settings = "2400,e,8,1"
		//   If MSComm6(8).PortOpen = False Then MSComm6(8).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(8).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg9 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(8).Output = buf
		//Else
		//    If MSComm6(8).PortOpen = True Then MSComm6(8).PortOpen = False
		//    MSComm6(8).PortOpen = True
		//    If MSComm6(8).PortOpen = False Then
		//    Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(9).Visible = False
		//'
		//
		//    MSComm6(8).Output = buf
		// End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData10(data As String)
		//On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(9).PortOpen = True Then MSComm6(9).PortOpen = False
		//  MSComm6(9).Settings = "9600,e,8,1"
		//If MSComm6(9).PortOpen = False Then MSComm6(9).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(9).PortOpen = False Then
		//    Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(10).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(9).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(9).PortOpen = True Then MSComm6(9).PortOpen = False
		//    MSComm6(9).Settings = "2400,e,8,1"
		//   If MSComm6(9).PortOpen = False Then MSComm6(9).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(9).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg10 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(9).Output = buf
		//Else
		//    If MSComm6(9).PortOpen = True Then MSComm6(9).PortOpen = False
		//    MSComm6(9).PortOpen = True
		//    If MSComm6(9).PortOpen = False Then
		//    Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(10).Visible = False
		//'
		//    MSComm6(9).Output = buf
		//End If
		//   End If
		//   Sendend = True
		//    End Sub
		//Private Sub SendData11(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(10).PortOpen = True Then MSComm6(10).PortOpen = False
		//  MSComm6(10).Settings = "9600,e,8,1"
		//If MSComm6(10).PortOpen = False Then MSComm6(10).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(10).PortOpen = False Then
		//    Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(11).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(10).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(10).PortOpen = True Then MSComm6(10).PortOpen = False
		//    MSComm6(10).Settings = "2400,e,8,1"
		//   If MSComm6(10).PortOpen = False Then MSComm6(10).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(10).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg11 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(10).Output = buf
		//Else
		//    If MSComm6(10).PortOpen = True Then MSComm6(10).PortOpen = False
		//    MSComm6(10).PortOpen = True
		//    If MSComm6(10).PortOpen = False Then
		//    Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(11).Visible = False
		//'
		//
		//    MSComm6(10).Output = buf
		//End If
		//End If
		//Sendend = True
		//    End Sub
		//Private Sub SendData12(data As String)
		// On Error Resume Next
		//    Dim c, buf() As Byte
		//    Dim n As Integer
		//
		//    n = Len(data) / 2
		//    ReDim buf(n + 3)
		//
		//If Metertype.ListIndex = 5 Then '汇中
		// ReDim buf(n - 1)
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i) = "&H" & Mid(data, i * 2 + 1, 2)
		//    Next i
		//    Txd = data
		//Else
		//    For i = 0 To 3
		//        buf(i) = &HFE
		//    Next i
		//
		//    c = 0
		//    For i = 0 To n - 1
		//        buf(i + 4) = "&H" & Mid(data, i * 2 + 1, 2)
		//        c = (c + buf(i + 4)) Mod &H100
		//    Next i
		//'    buf(i + 4) = c
		//'    buf(i + 1 + 4) = &H16
		//
		//    Txd = ""
		//For p = 4 To n + 3
		//    t = Hex(buf(p))
		//    For jj = Len(t) To 1
		//        t = "0" + t
		//    Next jj
		//    Txd = Txd + t
		//Next p
		//End If '汇中
		//'
		//If Metertype.ListIndex = 1 Or Metertype.ListIndex = 2 Or Metertype.ListIndex = 7 Then
		//
		//If MSComm6(11).PortOpen = True Then MSComm6(11).PortOpen = False
		//  MSComm6(11).Settings = "9600,e,8,1"
		//If MSComm6(11).PortOpen = False Then MSComm6(11).PortOpen = True
		//
		//  tstart = Timer
		//  Do While Timer - tstart < 0.3
		//    DoEvents
		//  Loop
		//
		//If MSComm6(11).PortOpen = False Then
		//    Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//Else
		//   tstart = Timer
		//   aa1(0) = &HFE
		//   Text19(12).Visible = False
		//   Do While (Timer - tstart) < 2.2
		//     MSComm6(11).Output = aa1
		//   DoEvents
		//   Loop
		//
		//   If MSComm6(11).PortOpen = True Then MSComm6(11).PortOpen = False
		//    MSComm6(11).Settings = "2400,e,8,1"
		//   If MSComm6(11).PortOpen = False Then MSComm6(11).PortOpen = True
		//
		//   tstart = Timer
		//   Do While Timer - tstart < 0.5
		//    DoEvents
		//   Loop
		//
		//   MSComm6(11).Output = buf
		//End If
		//
		//
		//ElseIf Metertype.ListIndex = 8 Then
		//    Yanshi = False
		//    delayg12 (1000)
		//    Do
		//    DoEvents
		//    Loop Until Yanshi = True
		//    MSComm6(11).Output = buf
		//Else
		//    If MSComm6(11).PortOpen = True Then MSComm6(11).PortOpen = False
		//    MSComm6(11).PortOpen = True
		//    If MSComm6(11).PortOpen = False Then
		//    Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//    Exit Sub
		//    Else
		//    Text19(12).Visible = False
		//'
		//    MSComm6(11).Output = buf
		//
		//   End If
		//End If
		//    Sendend = True
		//    End Sub
		//    Private Sub delay(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm1.PortOpen = False
		//MSComm1.Settings = "9600,e,8,1"
		//MSComm1.PortOpen = True
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//MSComm1.Output = aa1
		//'DoEvents
		//Wend
		//MSComm1.PortOpen = False
		//MSComm1.Settings = "2400,e,8,1"
		//MSComm1.PortOpen = True
		//
		//Exit Sub
		//End Sub
		//Private Sub delayg1(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(0).PortOpen = False Then
		//    Text19(1).Visible = True
		//    If Chinese = True Then
		//    Text19(1).Text = "通讯口不正常!"
		//    Else
		//    Text19(1).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(1).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(0).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg2(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(1).PortOpen = False Then
		//    Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(2).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(1).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg3(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(2).PortOpen = False Then
		//    Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(3).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(2).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg4(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(3).PortOpen = False Then
		//    Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(4).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(3).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg5(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(4).PortOpen = False Then
		//    Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(5).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(4).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg6(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(5).PortOpen = False Then
		//    Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(6).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(5).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg7(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(6).PortOpen = False Then
		//    Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(7).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(6).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg8(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(7).PortOpen = False Then
		//    Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(8).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(7).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg9(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(8).PortOpen = False Then
		//    Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(9).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(8).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg10(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(9).PortOpen = False Then
		//    Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(10).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(9).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg11(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(10).PortOpen = False Then
		//    Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(11).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(10).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delayg12(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//
		//If MSComm6(11).PortOpen = False Then
		//    Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(12).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 1
		//         aa1(i) = &HFE
		//     Next i
		//     MSComm6(11).Output = aa1
		//   Wend
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay1(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(0).PortOpen = False
		//MSComm6(0).Settings = "9600,e,8,1"
		//MSComm6(0).PortOpen = True
		//delay_times (0.1)
		//
		//If MSComm6(0).PortOpen = False Then
		//    Text19(1).Visible = True
		//    If Chinese = True Then
		//    Text19(1).Text = "通讯口不正常!"
		//    Else
		//    Text19(1).Text = "Comport false!"
		//    End If
		//Else
		//   Text19(1).Visible = False
		//   While (Timer - tstart) < (msec / 1000)
		//     For i = 0 To 0
		//         aa1(i) = aa0(i)
		//     Next i
		//     MSComm6(0).Output = aa1
		//   Wend
		//   MSComm6(0).PortOpen = False
		//   MSComm6(0).Settings = "2400,e,8,1"
		//   MSComm6(0).PortOpen = True
		//   delay_times (0.1)
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay2(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(1).PortOpen = False
		//MSComm6(1).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(1).PortOpen = True
		//If MSComm6(1).PortOpen = False Then
		//Text19(2).Visible = True
		//    If Chinese = True Then
		//    Text19(2).Text = "通讯口不正常!"
		//    Else
		//    Text19(2).Text = "Comport false!"
		//    End If
		//Else
		//Text19(2).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(1).Output = aa1
		//
		//Wend
		//
		//MSComm6(1).PortOpen = False
		//MSComm6(1).Settings = "2400,e,8,1"
		//MSComm6(1).PortOpen = True
		//delay_times (0.1)
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay3(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(2).PortOpen = False
		//MSComm6(2).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(2).PortOpen = True
		//If MSComm6(2).PortOpen = False Then
		//Text19(3).Visible = True
		//    If Chinese = True Then
		//    Text19(3).Text = "通讯口不正常!"
		//    Else
		//    Text19(3).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(3).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(2).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(2).PortOpen = False
		//MSComm6(2).Settings = "2400,e,8,1"
		//MSComm6(2).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay4(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(3).PortOpen = False
		//MSComm6(3).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(3).PortOpen = True
		//If MSComm6(3).PortOpen = False Then
		//Text19(4).Visible = True
		//    If Chinese = True Then
		//    Text19(4).Text = "通讯口不正常!"
		//    Else
		//    Text19(4).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(4).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(3).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(3).PortOpen = False
		//MSComm6(3).Settings = "2400,e,8,1"
		//MSComm6(3).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay5(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(4).PortOpen = False
		//MSComm6(4).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(4).PortOpen = True
		//If MSComm6(4).PortOpen = False Then
		//Text19(5).Visible = True
		//    If Chinese = True Then
		//    Text19(5).Text = "通讯口不正常!"
		//    Else
		//    Text19(5).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(5).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(4).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(4).PortOpen = False
		//MSComm6(4).Settings = "2400,e,8,1"
		//MSComm6(4).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay6(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(5).PortOpen = False
		//MSComm6(5).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(5).PortOpen = True
		//If MSComm6(5).PortOpen = False Then
		//Text19(6).Visible = True
		//    If Chinese = True Then
		//    Text19(6).Text = "通讯口不正常!"
		//    Else
		//    Text19(6).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(6).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(5).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(5).PortOpen = False
		//MSComm6(5).Settings = "2400,e,8,1"
		//MSComm6(5).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay7(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(6).PortOpen = False
		//MSComm6(6).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(6).PortOpen = True
		//If MSComm6(6).PortOpen = False Then
		//Text19(7).Visible = True
		//    If Chinese = True Then
		//    Text19(7).Text = "通讯口不正常!"
		//    Else
		//    Text19(7).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(7).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(6).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(6).PortOpen = False
		//MSComm6(6).Settings = "2400,e,8,1"
		//MSComm6(6).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay8(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(7).PortOpen = False
		//MSComm6(7).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(7).PortOpen = True
		//If MSComm6(7).PortOpen = False Then
		//Text19(8).Visible = True
		//    If Chinese = True Then
		//    Text19(8).Text = "通讯口不正常!"
		//    Else
		//    Text19(8).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(8).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(7).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(7).PortOpen = False
		//MSComm6(7).Settings = "2400,e,8,1"
		//MSComm6(7).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay9(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(8).PortOpen = False
		//MSComm6(8).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(8).PortOpen = True
		//If MSComm6(8).PortOpen = False Then
		//Text19(9).Visible = True
		//    If Chinese = True Then
		//    Text19(9).Text = "通讯口不正常!"
		//    Else
		//    Text19(9).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(9).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(8).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(8).PortOpen = False
		//MSComm6(8).Settings = "2400,e,8,1"
		//MSComm6(8).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay10(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(9).PortOpen = False
		//MSComm6(9).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(9).PortOpen = True
		//If MSComm6(9).PortOpen = False Then
		//Text19(10).Visible = True
		//    If Chinese = True Then
		//    Text19(10).Text = "通讯口不正常!"
		//    Else
		//    Text19(10).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(10).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(9).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(9).PortOpen = False
		//MSComm6(9).Settings = "2400,e,8,1"
		//MSComm6(9).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay11(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(10).PortOpen = False
		//MSComm6(10).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(10).PortOpen = True
		//If MSComm6(10).PortOpen = False Then
		//Text19(11).Visible = True
		//    If Chinese = True Then
		//    Text19(11).Text = "通讯口不正常!"
		//    Else
		//    Text19(11).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(11).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(10).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(10).PortOpen = False
		//MSComm6(10).Settings = "2400,e,8,1"
		//MSComm6(10).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		//Private Sub delay12(msec As Long)
		//On Error Resume Next
		//tstart = Timer
		//
		//MSComm6(11).PortOpen = False
		//MSComm6(11).Settings = "9600,e,8,1"
		//delay_times (0.1)
		//MSComm6(11).PortOpen = True
		//If MSComm6(11).PortOpen = False Then
		//Text19(12).Visible = True
		//    If Chinese = True Then
		//    Text19(12).Text = "通讯口不正常!"
		//    Else
		//    Text19(12).Text = "Comport false!"
		//    End If
		//
		//
		//Else
		//Text19(1).Visible = False
		//While (Timer - tstart) < (msec / 1000)
		//For i = 0 To 0
		//aa1(i) = aa0(i)
		//Next i
		//
		//MSComm6(11).Output = aa1
		//'DoEvents
		//Wend
		//MSComm6(11).PortOpen = False
		//MSComm6(11).Settings = "2400,e,8,1"
		//MSComm6(11).PortOpen = True
		//delay_times (0.1)
		//
		//End If
		//Yanshi = True
		//End Sub
		public object ComputerSum(double[] Arry, short nStart, short count)
		{
			object returnValue = null;
			double num = 0;
			double num1 = 0;
			short i = 0;
			num = 0;
			for (i = nStart; i <= count + nStart - 1; i++)
			{
				num = Arry[i] + num;
			}
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			num1 = num % 0x100;
			//UPGRADE_WARNING: 未能解析对象 ComputerSum 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			returnValue = num1;
			return returnValue;
		}
		
		private void DataClear()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//                        iTimeOut = 500
			//
			//                         If Len(Text11(0).Text) = 14 Then
			//                         data = "6820" & Text11(0).Text & "2403A00E01"
			//                         SendData1 (data)
			//                          Sleep 500
			//                         End If
			//                         If Len(Text11(1).Text) = 14 Then
			//                         data = "6820" & Text11(1).Text & "2403A00E01"
			//                         SendData2 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(2).Text) = 14 Then
			//                         data = "6820" & Text11(2).Text & "2403A00E01"
			//                         SendData3 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(3).Text) = 14 Then
			//                         data = "6820" & Text11(3).Text & "2403A00E01"
			//                         SendData4 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(4).Text) = 14 Then
			//                         data = "6820" & Text11(4).Text & "2403A00E01"
			//                         SendData5 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(5).Text) = 14 Then
			//                         data = "6820" & Text11(5).Text & "2403A00E01"
			//                         SendData6 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(6).Text) = 14 Then
			//                         data = "6820" & Text11(6).Text & "2403A00E01"
			//                         SendData7 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(7).Text) = 14 Then
			//                         data = "6820" & Text11(7).Text & "2403A00E01"
			//                         SendData8 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(8).Text) = 14 Then
			//                          data = "6820" & Text11(8).Text & "2403A00E01"
			//                         SendData9 (data)
			//                          Sleep 500
			//                          End If
			//                         If Len(Text11(9).Text) = 14 Then
			//                         data = "6820" & Text11(9).Text & "2403A00E01"
			//                         SendData10 (data)
			//                         Sleep 500
			//                         End If
			//                         If Len(Text11(10).Text) = 14 Then
			//                         data = "6820" & Text11(10).Text & "2403A00E01"
			//                         SendData11 (data)
			//                         Sleep 500
			//                         End If
			//                         If MID2 = 0 Then
			//                         If Len(Text11(11).Text) = 14 Then
			//                         data = "6820" & Text11(11).Text & "2403A00E01"
			//                         SendData12 (data)
			//                         Sleep 500
			//                         End If
			//                         End If
			
		}
		private string GetUnit(string data)
		{
			string returnValue = "";
			if (data == "02")
			{
				returnValue = "Wh";
			}
			if (data == "05")
			{
				returnValue = "kWh";
			}
			if (data == "08")
			{
				returnValue = "MWh";
			}
			if (data == "0A")
			{
				returnValue = "MWh×100";
			}
			if (data == "01")
			{
				returnValue = "J";
			}
			if (data == "0B")
			{
				returnValue = "kJ";
			}
			if (data == "0E")
			{
				returnValue = "MJ";
			}
			if (data == "11")
			{
				returnValue = "GJ";
			}
			if (data == "13")
			{
				returnValue = "GJ×100";
			}
			if (data == "14")
			{
				returnValue = "W";
			}
			if (data == "17")
			{
				returnValue = "kW";
			}
			if (data == "1A")
			{
				returnValue = "MW";
			}
			if (data == "29")
			{
				returnValue = "L";
			}
			if (data == "2C")
			{
				returnValue = "m3";
			}
			if (data == "32")
			{
				returnValue = "L/h";
			}
			if (data == "35")
			{
				returnValue = "m3/h";
			}
			return returnValue;
		}
		
		
		public void 读表号一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[0].Text = "";
				Text11[0].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				//    iTimeOut = 1000
				DanJian = true;
				Biao_Xuhao = (short) 0;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[1].Text = "";
				Text11[1].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 1;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号三_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[2].Text = "";
				Text11[2].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 2;
				Timer21.Enabled = true;
				
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号四_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[3].Text = "";
				Text11[3].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 3;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号五_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[4].Text = "";
				Text11[4].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 4;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号六_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[5].Text = "";
				Text11[5].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 5;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号七_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[6].Text = "";
				Text11[6].Text = "";
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 6;
				Timer21.Enabled = true;
				
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号八_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[7].Text = "";
				Text11[7].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 7;
				Timer21.Enabled = true;
				
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读表号九_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[8].Text = "";
				Text11[8].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 8;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号十_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[9].Text = "";
				Text11[9].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 9;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号十一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[10].Text = "";
				Text11[10].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//    data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 10;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		public void 读表号十二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				Text1[11].Text = "";
				Text11[11].Text = "";
				
				sub_Renamed.cmd_type = "RD_NUM";
				//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
				//     data = Mid(data, 3)
				DanJian = true;
				Biao_Xuhao = (short) 11;
				Timer21.Enabled = true;
				
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		private void 读出_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			if (sub_Renamed.Comopen == true)
			{
				
				for ( = ;0; i <= 11); i++;);
				{
					Text1[sub_Renamed.i].Text = "";
					Text11[sub_Renamed.i].Text = "";
				}
				
				//    data = "6820AAAAAAAAAAAAAA0303810A05"
				//    SendData (data)
				Mdlguanfa.Sleep(500);
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					MessageBox.Show("请先进行参数设置并开启自动采集功能！");
				}
				else
				{
					MessageBox.Show("Click on <<Setup>> first and enable automatic acquisition function ！");
				}
				return;
			}
		}
		
		public void 读数1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(0).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 0;
			Timer21.Enabled = true;
			
		}
		
		public void 读数10_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(9).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 9;
			Timer21.Enabled = true;
			
		}
		
		public void 读数11_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(10).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 10;
			Timer21.Enabled = true;
			
		}
		
		public void 读数12_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(11).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 11;
			Timer21.Enabled = true;
			
		}
		
		public void 读数2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(1).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 1;
			Timer21.Enabled = true;
			
		}
		
		public void 读数3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(2).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 2;
			Timer21.Enabled = true;
			
		}
		
		public void 读数4_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(3).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 3;
			Timer21.Enabled = true;
			
		}
		
		public void 读数5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(4).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 4;
			Timer21.Enabled = true;
			
		}
		
		public void 读数6_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(5).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 5;
			Timer21.Enabled = true;
			
		}
		
		public void 读数7_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(6).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 6;
			Timer21.Enabled = true;
			
		}
		
		public void 读数8_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(7).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 7;
			Timer21.Enabled = true;
			
		}
		
		public void 读数9_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Erstpunkt == false && sub_Renamed.Readone == false && sub_Renamed.RechenLC == true) //读温度值
			{
				sub_Renamed.cmd_type = "RD_DATA"; //读温度值
			}
			else
			{
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
			}
			//data = tx.send_cmd(Metertype.ListIndex, cmd_type, Trim(Text11(8).Text), Trim(Text21.Text) + ";;;;;;;;")
			//data = Mid(data, 3)
			
			DanJian = true;
			Biao_Xuhao = (short) 8;
			Timer21.Enabled = true;
			
		}
		public void 时间_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			double temp;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			//MeterTime(0) = CDbl(&HFE)
			//MeterTime(1) = CDbl(&HFE)
			//MeterTime(2) = CDbl(&HFE)
			//MeterTime(3) = CDbl(&HFE)
			//MeterTime(4) = CDbl(&HFE)
			//MeterTime(5) = CDbl(&HFE)
			//MeterTime(6) = CDbl(&HFE)
			//MeterTime(7) = CDbl(&HFE)
			//MeterTime(8) = CDbl(&HFE)
			//MeterTime(9) = CDbl(&HFE)
			//MeterTime(10) = CDbl(&H68)
			//MeterTime(11) = CDbl(&H20)
			//MeterTime(12) = CDbl(&HAA)
			//MeterTime(13) = CDbl(&HAA)
			//MeterTime(14) = CDbl(&HAA)
			//MeterTime(15) = CDbl(&HAA)
			//MeterTime(16) = CDbl(&HAA)
			//MeterTime(17) = CDbl(&H11)
			//MeterTime(18) = CDbl(&H11)
			//MeterTime(19) = CDbl(&H4)
			//MeterTime(20) = CDbl(&HA)
			//MeterTime(21) = CDbl(&H15)
			//MeterTime(22) = CDbl(&HA0)
			//MeterTime(23) = CDbl(&H12)
			//MeterTime(24) = CDbl(&H0)
			//MeterTime(25) = CDbl(&H0)
			//MeterTime(26) = CDbl(&H12)
			//MeterTime(27) = CDbl(&H1)
			//MeterTime(28) = CDbl(&H8)
			//MeterTime(29) = CDbl(&H7)
			//MeterTime(30) = CDbl(&H20)
			//MeterTime(31) = CDbl(&H0)
			//MeterTime(32) = CDbl(&H16)
			//
			//temp = Second(DateTime.Now) Mod 256
			//MeterTime(24) = CDbl(temp Mod 10 + Int(temp / 10) * 16)
			//temp = Minute(DateTime.Now) Mod 256
			//MeterTime(25) = CDbl(temp Mod 10 + Int(temp / 10) * 16)
			//temp = Hour(DateTime.Now) Mod 256
			//MeterTime(26) = CDbl(temp Mod 10 + Int(temp / 10) * 16)
			//temp = Day(DateTime.Now) Mod 256
			//MeterTime(27) = CDbl(temp Mod 10 + Int(temp / 10) * 16)
			//temp = Month(DateTime.Now) Mod 256
			//MeterTime(28) = CDbl(temp Mod 10 + Int(temp / 10) * 16)
			//temp = Year(DateTime.Now) Mod 100
			//MeterTime(29) = CDbl(temp Mod 10 + Int(temp / 10) * 16)
			//temp = Year(DateTime.Now) / 100
			//MeterTime(30) = CDbl(temp Mod 10 + Int(temp / 10) * 16)
			//MeterTime(31) = CDbl(ComputerSum(MeterTime, 10, 21) Mod 256)
			//
			//
			//For i = 0 To 32
			//MeterTime1(i) = MeterTime(i)
			//Next i
			//
			//
			//If Comopen = False Then '如果手动
			//    MSComm1.Settings = "2400,E,8,1"
			//    MSComm1.InputLen = 0
			//    MSComm1.DTREnable = True
			//    MSComm1.RTSEnable = True
			//    MSComm1.RThreshold = 1
			//    MSComm1.InputMode = comInputModeBinary
			//    MSComm1.CommPort = Com4
			//    If MSComm1.PortOpen = True Then MSComm1.PortOpen = False
			//    MSComm1.PortOpen = True
			//
			//    MSComm1.Output = MeterTime1
			//Else '如果自动
			//
			//
			//'delay1 (1200)
			//'    MSComm6.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay2 (1200)
			//'    MSComm7.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay3 (1200)
			//'    MSComm8.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay4 (1200)
			//'    MSComm9.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay5 (1200)
			//'    MSComm10.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay6 (1200)
			//'    MSComm11.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay7 (1200)
			//'    MSComm12.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay8 (1200)
			//'    MSComm13.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay9 (1200)
			//'    MSComm14.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay10 (1200)
			//'    MSComm15.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay11 (1200)
			//'    MSComm16.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//'delay12 (1200)
			//'    MSComm17.Output = MeterTime1
			//'Sleep 1500
			//'delay_times (0.1)
			//End If
			//
		}
		
		
		
		public float standom_t(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[2] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[3] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[1];
			returnValue = (float) (System.Math.Round((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa), 4));
			return returnValue;
		}
		public float standom_t1(float Fenzi) //由标准电阻值计算 标准温度
		{
			float returnValue = 0;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//        t1 = T
			//        T = Round(T, 4)
			
			Mdlguanfa.Xb = (float) (mi[5] / Math.Pow(10, 3)); //铂电阻的一次项
			Mdlguanfa.Xa = (float) (mi[6] / Math.Pow(10, 7)); //铂电阻的二次顶
			Mdlguanfa.Xc = Fenzi / mi[4];
			returnValue = (float) (System.Math.Round(System.Convert.ToDouble((-1 * Mdlguanfa.Xb + System.Math.Sqrt(Math.Pow(Mdlguanfa.Xb, 2) - 4 * Mdlguanfa.Xa * (1 - Mdlguanfa.Xc))) / (2 * Mdlguanfa.Xa)), 4));
			return returnValue;
		}
		private void pt_centgrade()
		{
			//以下是铂电阻计算程序：
			double[] d = new double[10];
			double wt = 0;
			double deltaW = 0;
			double wrt = 0;
			double pt;
			double r = 0;
			double t = 0;
			double a;
			double b;
			double a8 = 0;
			double b8 = 0;
			double rpt = 0;
			
			float t1;
			float t2;
			float t3;
			
			float[] pt1000 = new float[101];
			short i = 0;
			
			d[0] = 439.932854;
			d[1] = 472.41802;
			d[2] = 37.684494;
			d[3] = 7.472018;
			d[4] = 2.920828;
			d[5] = 0.005184;
			d[6] = -0.963864;
			d[7] = -0.188732;
			d[8] = 0.191203;
			d[9] = 0.049025;
			
			//UPGRADE_WARNING: 未能解析对象 pt_om 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			r = System.Convert.ToDouble(sub_Renamed.pt_om);
			//UPGRADE_WARNING: 未能解析对象 pt_a8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			a8 = System.Convert.ToDouble(sub_Renamed.pt_a8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_b8 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b8 = System.Convert.ToDouble(sub_Renamed.pt_b8) * Math.Pow(10, -5);
			//UPGRADE_WARNING: 未能解析对象 pt_Rpt 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			rpt = System.Convert.ToDouble(sub_Renamed.pt_Rpt);
			
			wt = r / rpt;
			deltaW = a8 * (wt - 1) + b8 * Math.Pow((wt - 1), 2);
			wrt = wt - deltaW;
			t = 0;
			for (i = 0; i <= 9; i++)
			{
				t = t + d[i] * Math.Pow(((wrt - 2.64) / 1.64), i); //t=d0*sum[di(Wr(t)-2.64)/1.64]^I;I:1 to 9
			}
			t1 = (float) t;
			sub_Renamed.centgrade = System.Math.Round(t, 4);
			
		}
		
		private void stb()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			short st;
			short pp = 0;
			double cl = 0;
			double tt = 0;
			double t = 0;
			object p5 = null;
			double v1;
			double ab = 0;
			double h1 = 0;
			double volume;
			double w3 = 0;
			double w1 = 0;
			double Gf = 0;
			double z = 0;
			double y = 0;
			double o = 0;
			double b = 0;
			double y1 = 0;
			double gg = 0;
			double w = 0;
			double w2 = 0;
			double v = 0;
			double AAA = 0;
			double h6 = 0;
			double aa = 0;
			double h2 = 0;
			double kr = 0;
			double vr = 0;
			double tf = 0;
			double hf = 0;
			double g7;
			double g5 = 0;
			double g3 = 0;
			double g1 = 0;
			double g2 = 0;
			double g4 = 0;
			double g6 = 0;
			double h = 0;
			double vf = 0;
			double hr = 0;
			double tR = 0;
			double kf = 0;
			st = (short) 0;
			if (st == 0)
			{
				tt = sub_Renamed.Ninlet; //进口温度输入
			}
AAAA:
			if (st == 1)
			{
				tt = sub_Renamed.Noutlet; //出口温度输入
			}
			cl = tt;
			t = tt + 273.15;
			pp = (short) 6;
			
			//pp = Val(Text10.Text)
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			p5 = pp * 100000;
			o = t / Module1.tc;
			//UPGRADE_WARNING: 未能解析对象 p5 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			b = System.Convert.ToDouble(System.Convert.ToDouble(p5) / Module1.pc);
			y = 1 - Module1.d1 * Math.Pow(o, 2) - Module1.d2 * Math.Pow(o, -6);
			y1 = -2 * Module1.d1 * o + 6 * Module1.d2 * Math.Pow(o, -7);
			z = y + System.Math.Sqrt(System.Math.Abs(Module1.d3 * Math.Pow(y, 2) - 2 * Module1.d4 * o + 2 * Module1.d5 * b));
			gg = Module1.d6 - o;
			if (System.Math.Abs(gg) < 0.000158)
			{
				gg = 0;
			}
			Gf = Module1.d6 - o;
			if (System.Math.Abs(Gf) < 0.0000596)
			{
				Gf = 0;
			}
			w = Module1.B1 * Module1.d5 * Math.Pow(z, (-5 / 17));
			w1 = w + (Module1.B2 + Module1.B3 * o + Module1.b4 * Math.Pow(o, 2) + Module1.b5 * Math.Pow(gg, 10) + Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -1)) - Math.Pow((Module1.d8 + Math.Pow(o, 11)), -1) * (Module1.b7 + 2 * Module1.b8 * b + 3 * Module1.b9 * Math.Pow(b, 2));
			w2 = w1 - Module1.c0 * Math.Pow(o, 18) * (Module1.d9 + Math.Pow(o, 2)) * (-3 * Math.Pow((Module1.e0 + b), -4) + Module1.e1);
			w3 = w2 + 3 * Module1.c1 * (Module1.e2 - o) * Math.Pow(b, 2) + 4 * Module1.c2 * Math.Pow(o, -20) * Math.Pow(b, 3);
			v = 1000 * w3 * Module1.vc;
			volume = 1 / v;
			
			AAA = Module1.a1 + Module1.a2 * o + Module1.a3 * Math.Pow(o, 2) + Module1.a4 * Math.Pow(o, 3) + Module1.a5 * Math.Pow(o, 4) + Module1.a6 * Math.Pow(o, 5) + Module1.a7 * Math.Pow(o, 6) + Module1.a8 * Math.Pow(o, 7) + Module1.a9 * Math.Pow(o, 8) + Module1.b0 * Math.Pow(o, 9);
			h1 = Module1.a0 * o * (1 - System.Math.Log(o)) + AAA + Module1.B1 * ((17 / 29) * z - (17 / 12) * y) * Math.Pow(z, (12 / 17)) + (Module1.B2 + Module1.B3 * o + Module1.b4 * Math.Pow(o, 2) + Module1.b5 * Math.Pow(gg, 10) + Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -1)) * b;
			h2 = h1 - Math.Pow((Module1.d8 + Math.Pow(o, 11)), -1) * (Module1.b7 * b + Module1.b8 * Math.Pow(b, 2) + Module1.b9 * Math.Pow(b, 3)) - Module1.c0 * Math.Pow(o, 18) * (Module1.d9 + Math.Pow(o, 2)) * (Math.Pow((Module1.e0 + b), -3) + Module1.e1 * b);
			h6 = h2 + Module1.c1 * (Module1.e2 - o) * Math.Pow(b, 3) + Module1.c2 * Math.Pow(o, -20) * Math.Pow(b, 4);
			//Text2.Text = Left$(CStr(h6#), 6)
			ab = Module1.a2 + 2 * Module1.a3 * o;
			aa = ab + 3 * Module1.a4 * Math.Pow(o, 2) + 4 * Module1.a5 * Math.Pow(o, 3) + 5 * Module1.a6 * Math.Pow(o, 4) + 6 * Module1.a7 * Math.Pow(o, 5) + 7 * Module1.a8 * Math.Pow(o, 6) + 8 * Module1.a9 * Math.Pow(o, 7) + 9 * Module1.b0 * Math.Pow(o, 8);
			g1 = Module1.a0 * System.Math.Log(o) - aa + Module1.B1 * ((((5 * z) / 12) - (Module1.d3 - 1) * y) * y1 + Module1.d4) * Math.Pow(z, (-5 / 17));
			g2 = (- Module1.B3 - 2 * Module1.b4 * o + 10 * Module1.b5 * Math.Pow(Gf, 9) + 19 * Module1.b6 * Math.Pow((Module1.d7 + Math.Pow(o, 19)), -2) * Math.Pow(o, 18)) * b;
			g3 = 11 * Math.Pow((Module1.d8 + Math.Pow(o, 11)), -2) * Math.Pow(o, 10) * (Module1.b7 * b + Module1.b8 * Math.Pow(b, 2) + Module1.b9 * Math.Pow(b, 3));
			g4 = Module1.c0 * Math.Pow(o, 17) * (18 * Module1.d9 + 20 * Math.Pow(o, 2)) * (Math.Pow((Module1.e0 + b), -3) + Module1.e1 * b);
			g5 = Module1.c1 * Math.Pow(b, 3) + 20 * Module1.c2 * Math.Pow(o, -21) * Math.Pow(b, 4);
			g6 = g1 + g2 - g3 + g4 + g5;
			//Text3.Text = Left$(CStr(g6#), 6)
			h = (Module1.pc * Module1.vc) * (o * g6 + h6);
			h = h / 1000;
			
			if (st == 1)
			{
				goto XXX;
			}
			hf = h;
			vf = v;
			tf = cl;
			st = (short) 1;
			goto AAAA;
			
XXX:
			hr = h;
			vr = v;
			tR = cl;
			
			kr = (hf - hr) / ((tf - tR) * vr);
			kf = (hf - hr) / ((tf - tR) * vf);
			
			if (Option1.Checked == true)
			{
				if (Option5.Checked == true)
				{
					Kxishu = float.Parse(VB.Strings.Left((kf).ToString(), 7)); //进口K系数 MJ
				}
				else
				{
					Kxishu = float.Parse(VB.Strings.Left((kf / 3.6).ToString(), 7)); //进口K系数 kWh
				}
			}
			else
			{
				if (Option5.Checked == true)
				{
					Kxishu = float.Parse(VB.Strings.Left((kr).ToString(), 7)); //出口K系数 MJ
				}
				else
				{
					Kxishu = float.Parse(VB.Strings.Left((kr / 3.6).ToString(), 7)); //出口K系数 kWh
				}
			}
			
			Kxs = (float) (System.Math.Round(System.Convert.ToDouble((Conversion.Val(Text14.Text) - Conversion.Val(Text12.Text)) * Kxishu / 1000), 4)); //理论热量
		}
		
		
		public void 状态一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 0;
			Timer21.Enabled = true;
			
		}
		public void 状态二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 1;
			Timer21.Enabled = true;
			
		}
		public void 状态三_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 2;
			Timer21.Enabled = true;
			
		}
		public void 状态四_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 3;
			Timer21.Enabled = true;
			
		}
		
		public void 状态五_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 4;
			Timer21.Enabled = true;
			
		}
		public void 状态六_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 5;
			Timer21.Enabled = true;
			
		}
		
		public void 状态七_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 6;
			Timer21.Enabled = true;
			
		}
		public void 状态八_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 7;
			Timer21.Enabled = true;
			
		}
		public void 状态九_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 8;
			Timer21.Enabled = true;
			
		}
		public void 状态十_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 9;
			Timer21.Enabled = true;
			
		}
		public void 状态十一_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 10;
			Timer21.Enabled = true;
			
		}
		public void 状态十二_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.cmd_type = "WR_INPUT_JIANDING";
			//    data = tx.send_cmd(Metertype.ListIndex, cmd_type, "", "")
			//
			//    data = Mid(data, 3)
			DanJian = true;
			Biao_Xuhao = (short) 11;
			Timer21.Enabled = true;
			
		}
		
		private void Readingonerror()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (Strings.Len(Text11[0].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数1.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第1块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 1. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[1].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数2.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第2块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 2. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[2].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数3.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第3块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 3. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[3].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数4.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第4块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 4. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[4].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数5.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第5块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 5. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[5].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数6.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第6块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 6. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[6].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数7.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第7块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 7. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[7].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数8.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第8块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 8. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[8].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数9.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第9块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 9. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[9].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数10.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第10块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 10. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[10].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数11.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第11块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 11. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			if (Strings.Len(Text11[11].Text) == 14 && System.Drawing.ColorTranslator.ToOle(读数12.BackColor) == 0xC000)
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "点击第12块表《读表数据》后,点《下一步》继续！  ";
				}
				else
				{
					Labt.Text = "Click on the <<Read>> on meter 12. then <<next>> to continue!   ";
				}
				sub_Renamed.Flagnext = false;
				Command5.Visible = true;
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.5));F;);
				} while (!(sub_Renamed.Flagnext == true));
			}
			
		}
		
		private void Autoeich()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Fsbz = true;
			
			bool bHao;
			if (Metertype.SelectedIndex != 8) //光大表无表号
			{
				bHao = false;
				for (i = 0; i <= sub_Renamed.Stueck; i++)
				{
					if (Text19[sub_Renamed.i + 1].Text != "通讯口不正常!")
					{
						if (Strings.Len(Text11[sub_Renamed.i].Text) != 14)
						{
							if (sub_Renamed.Chinese == true)
							{
								Labt.Text = "排气结束，请读出表号后点击《下一步》开始进行检测";
							}
							else
							{
								Labt.Text = "Exhaust end, please read out the meter number before the <<next>> to begin testing ";
							}
							bHao = true;
						}
					}
				}
				
				if (bHao == true)
				{
					sub_Renamed.Pqschutz = true;
					sub_Renamed.Flagnext = false;
					Command5.Visible = true;
					Command5.Focus();
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.5));F;);
					} while (!(sub_Renamed.Flagnext == true));
				}
			}
			
			
			
			读表号一.Enabled = false;
			读表号二.Enabled = false;
			读表号三.Enabled = false;
			读表号四.Enabled = false;
			读表号五.Enabled = false;
			读表号六.Enabled = false;
			读表号七.Enabled = false;
			读表号八.Enabled = false;
			读表号九.Enabled = false;
			读表号十.Enabled = false;
			读表号十一.Enabled = false;
			读表号十二.Enabled = false;
			
			状态一.Enabled = false;
			状态二.Enabled = false;
			状态三.Enabled = false;
			状态四.Enabled = false;
			状态五.Enabled = false;
			状态六.Enabled = false;
			状态七.Enabled = false;
			状态八.Enabled = false;
			状态九.Enabled = false;
			状态十.Enabled = false;
			状态十一.Enabled = false;
			状态十二.Enabled = false;
			
			读数1.Enabled = true;
			读数2.Enabled = true;
			读数3.Enabled = true;
			读数4.Enabled = true;
			读数5.Enabled = true;
			读数6.Enabled = true;
			读数7.Enabled = true;
			读数8.Enabled = true;
			读数9.Enabled = true;
			读数10.Enabled = true;
			读数11.Enabled = true;
			读数12.Enabled = true;
			
			if (sub_Renamed.Chinese == true)
			{
				Labt.Text = "正在打开检定记录表格，请稍候...";
			}
			else
			{
				Labt.Text = "Opening test record form, please wait ... ";
			}
			//计算每个表位上的检表数量
			
			sub_Renamed.End_biaowei = (short) 0;
			sub_Renamed.Jd_number = (short) 0;
			for (i = 0; i <= 11; i++)
			{
				sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 0;
				if (Strings.Len(Text1[sub_Renamed.i].Text) > 0)
				{
					sub_Renamed.Jd_biaowei[sub_Renamed.i] = (short) 1;
					sub_Renamed.End_biaowei = sub_Renamed.i;
				}
				sub_Renamed.Jd_number = sub_Renamed.Jd_number + sub_Renamed.Jd_biaowei[sub_Renamed.i];
			}
			
			sub_Renamed.Jd_meter = sub_Renamed.Jd_number;
			
			
			//UPGRADE_NOTE: 在对对象 objExcel 进行垃圾回收前，不可以将其销毁。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"”
			sub_Renamed.objExcel = null;
			sub_Renamed.gain_fileNO();
			sub_Renamed.objExcel = new Microsoft.Office.Interop.Excel.Application();
			sub_Renamed.objExcel.SheetsInNewWorkbook = 1;
			sub_Renamed.objExcel.Workbooks.Add();
			//objExcel.Sheets.Application.DisplayFullScreen = True
			sub_Renamed.objExcel.Application.WindowState = Microsoft.Office.Interop.Excel.XlWindowState.xlMinimized;
			sub_Renamed.objExcel.Application.Visible = true;
			
			yy = (short) 0;
			zz = (short) 0;
			
			
			listene();
			
			xx = (short) 1;
			
			short k = 0;
			for (xx = 1; xx <= sub_Renamed.Jd_point; xx++) //流程： 逐个流量点进行
			{
				
				Label10.Visible = true;
				Label7[0].Visible = true;
				Label7[2].Visible = true;
				Label7[2].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Jd_flow[xx - 1], "0.0##");
				Label18.Visible = true;
				Label7[1].Visible = true;
				Label7[1].Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format((double.Parse(Text14.Text)) - double.Parse(Text12.Text), "0.00");
				
				sub_Renamed.RechenLC = false;
				
				读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				
				
				if (xx == 1)
				{
					
					
					if (Option3.Checked == true) //如果初值回零
					{
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							if (Strings.Len(Text11[sub_Renamed.i].Text) == 14) //对无表号表位不赋0值
							{
								sub_Renamed.ZlChuzhi[sub_Renamed.i] = 0;
								Text6[sub_Renamed.i].Text = (0).ToString();
							}
							else
							{
								Text6[sub_Renamed.i].Text = "";
							}
						}
					}
					else //如果初值不回零.自动采集初值
					{
						Labt.Text = "正在采集被检表初值，请稍候...";
						sub_Renamed.Readone = true; //不读温度值
						sub_Renamed.Rechen = false; //采集数据不计算误差
						sub_Renamed.Erstpunkt = true;
						switch (Metertype.SelectedIndex)
						{
							case 0:
							case 3:
							case 4:
							case 5:
							case 6:
							case 8:
								sub_Renamed.cmd_type = "RD_HIGH_DATA";
								break;
						}
						Biao_Xuhao = (short) 0;
						
						Timer21.Enabled = true;
						delay_times(1);
						do
						{
							System.Windows.Forms.Application.DoEvents();
						} while (!(Timer21.Enabled == false));
						Readingonerror();
						delay_times(1);
						sub_Renamed.Erstpunkt = false;
						
					} //初值回零结束
				}
				else //如果不是第一遍
				{
					if (frmzjsz.Default.Option16.Checked == true) //如果不是连续检定
					{
						if ((Conversion.Val(Text3[0].Text) + sub_Renamed.Jd_liang[xx - 1]) >= 100)
						{
							System.Int32 temp_i = 7;
							Mdlguanfa.Zhu_Kai(ref temp_i); //量器放水
							delay_times(1);
							
							Labt.Text = "天平正在放水，请等候...";
							
							do
							{
								System.Windows.Forms.Application.DoEvents();
								delay_times(1);
							} while (!(Conversion.Val(Text3[0].Text) + sub_Renamed.Jd_liang[xx - 1] < 95));
							
							System.Int32 temp_i2 = 7;
							Mdlguanfa.Zhu_Guan(ref temp_i2); //放水关
							delay_times(3);
						}
					}
					
					if (Option3.Checked == true) //如果初值回零
					{
						
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							if (Strings.Len(Text11[sub_Renamed.i].Text) == 14) //对无表号表位不赋0值
							{
								sub_Renamed.lLChuzhi[sub_Renamed.i] = 0;
								Text6[sub_Renamed.i].Text = (0).ToString();
							}
							else
							{
								Text6[sub_Renamed.i].Text = "";
							}
							//                               Text8(i).Text = ""
						}
						
					}
					else //如果初值不回零
					{
						//
						for (i = 0; i <= sub_Renamed.End_biaowei; i++)
						{
							Text6[sub_Renamed.i].Text = Text8[sub_Renamed.i].Text;
							sub_Renamed.lLChuzhi[sub_Renamed.i] = (float) (Conversion.Val(Text8[sub_Renamed.i].Text));
							sub_Renamed.llZhongzhi[sub_Renamed.i] = 0;
							//                        Text4(i).Text = ""
						}
						
						
					} //回零结束
					
				} //第一遍判断结束
				
				sub_Renamed.Zlm0 = (float) (Conversion.Val(Text3[0].Text));
				
				if (Timer13.Enabled == true)
				{
					Labt.Text = "正在等待自动回零时间...";
					do
					{
						System.Windows.Forms.Application.DoEvents();
						delay_times((0.5));F;);
					} while (!(Timer13.Enabled == false)); //等待10秒钟，初值自动回零。
				}
				
				if (sub_Renamed.Ld4 == 3)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i3 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i3); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i4 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i4); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i5 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i5); //
					}
				}
				else if (sub_Renamed.Ld4 == 4)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i6 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i6); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i7 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i7); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i8 = 4;
						Mdlguanfa.Zhu_Kai(ref temp_i8); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[2] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[3])
					{
						Llxuanze = (short) 4;
						System.Int32 temp_i9 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i9); //
					}
				}
				else if (sub_Renamed.Ld4 == 5)
				{
					if (sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[0])
					{
						Llxuanze = (short) 1;
						System.Int32 temp_i10 = 2;
						Mdlguanfa.Zhu_Kai(ref temp_i10); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[0] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[1])
					{
						Llxuanze = (short) 2;
						System.Int32 temp_i11 = 3;
						Mdlguanfa.Zhu_Kai(ref temp_i11); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[1] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[2])
					{
						Llxuanze = (short) 3;
						System.Int32 temp_i12 = 4;
						Mdlguanfa.Zhu_Kai(ref temp_i12); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[2] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[3])
					{
						Llxuanze = (short) 4;
						System.Int32 temp_i13 = 5;
						Mdlguanfa.Zhu_Kai(ref temp_i13); //
					}
					else if (sub_Renamed.Jd_flow[xx - 1] > sub_Renamed.LLQmax[3] && sub_Renamed.Jd_flow[xx - 1] <= sub_Renamed.LLQmax[4])
					{
						Llxuanze = (short) 5;
						System.Int32 temp_i14 = 6;
						Mdlguanfa.Zhu_Kai(ref temp_i14); //
					}
				}
				读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
				delay_times(1);
				sub_Renamed.zeit = 0;
				Text7.Text = (0).ToString();
				//               Textjs.Text = 0
				Timer10.Enabled = true;
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "正在通水检测，请等待约     秒";
				}
				else
				{
					Labt.Text = "Testing now, wait about     seconds ";
				}
				
				
				//采温度
				sub_Renamed.jkwd = 0;
				sub_Renamed.ckwd = 0;
				sub_Renamed.wdjs = 0;
				Timer11.Enabled = true;
				
				//采标准温度平均
				sub_Renamed.Njkwd = 0;
				sub_Renamed.Nckwd = 0;
				sub_Renamed.Nwdjs = 0;
				Timer17.Enabled = true;
				
				if (sub_Renamed.MID1 == 0 | sub_Renamed.MID1 == 1)
				{
					sub_Renamed.jsjs = 0;
					sub_Renamed.Leiji = 0;
					Tianping2 = (short) 0;
					Timer9.Enabled = true; //开始计算瞬流
				}
				
				Jsz = (short) 0;
				llJs = 0;
				ssLL = 0;
				Timer12.Enabled = true; //计六秒后开始采集平均瞬流
				
				Dtianping = 0;
				Caiji();
				
				Timer11.Enabled = false; //温度采集结束
				Timer12.Enabled = false; //流量采集结束
				Timer17.Enabled = false; //温度采集平均结束
				
				for (j = 0; j <= sub_Renamed.End_biaowei; j++) //计算每个表温度及密度
				{
					sub_Renamed.Zlwendu[j] = (float) (System.Math.Round(sub_Renamed.inlet - (sub_Renamed.inlet - sub_Renamed.outlet) / (sub_Renamed.Stueck + 2) * (j + 1), 2));
					//UPGRADE_WARNING: 未能解析对象 MiDu() 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.ZlMiDu[j] = float.Parse(Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(mdlyingpanxuliehao.MiDu(Conversion.Str(sub_Renamed.Zlwendu[j])), "0.0000"));
				}
				
				Text14.Text = (sub_Renamed.Ninlet).ToString();
				Text12.Text = (sub_Renamed.Noutlet).ToString();
				
				if (sub_Renamed.Ld4 == 3) //三管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i15 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i15); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i16 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i16); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i17 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i17); //
						delay_times(1);
					}
				}
				else if (sub_Renamed.Ld4 == 4) //四管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i18 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i18); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i19 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i19); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i20 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i20); //
						delay_times(1);
					}
					else if (Llxuanze == 4)
					{
						System.Int32 temp_i21 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i21); //
						delay_times(1);
					}
				}
				else if (sub_Renamed.Ld4 == 5) //五管路
				{
					if (Llxuanze == 1)
					{
						System.Int32 temp_i22 = 2;
						Mdlguanfa.Zhu_Guan(ref temp_i22); //
						delay_times(1);
					}
					else if (Llxuanze == 2)
					{
						System.Int32 temp_i23 = 3;
						Mdlguanfa.Zhu_Guan(ref temp_i23); //
						delay_times(1);
					}
					else if (Llxuanze == 3)
					{
						System.Int32 temp_i24 = 4;
						Mdlguanfa.Zhu_Guan(ref temp_i24); //
						delay_times(1);
					}
					else if (Llxuanze == 4)
					{
						System.Int32 temp_i25 = 5;
						Mdlguanfa.Zhu_Guan(ref temp_i25); //
						delay_times(1);
					}
					else if (Llxuanze == 5)
					{
						System.Int32 temp_i26 = 6;
						Mdlguanfa.Zhu_Guan(ref temp_i26); //
						delay_times(1);
					}
				}
				
				Label12.Visible = false;
				Timer10.Enabled = false;
				
				Timer9.Enabled = false;
				Text3[1].Text = (0).ToString();
				Timer7.Enabled = true; //计算流量误差限
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "通水检测结束，正在读取被检表终值，请稍候...";
				}
				else
				{
					Labt.Text = "Testing is over, the test values are read now, please wait ... ";
				}
				
				delay_times(5);
				
				sub_Renamed.Zlm1 = (float) (Conversion.Val(Text3[0].Text));
				
				if (Metertype.SelectedIndex == 1 | Metertype.SelectedIndex == 2 | Metertype.SelectedIndex == 7)
				{
					//UPGRADE_WARNING: 未能解析对象 Chuzhijs 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					Chuzhijs = 0;
					Timer13.Enabled = true;
				}
				
				for (i = 0; i <= sub_Renamed.End_biaowei; i++)
				{
					Text44[sub_Renamed.i].Text = "";
					Text33[sub_Renamed.i].Text = "";
					Text22[sub_Renamed.i].Text = "";
					Text8[sub_Renamed.i].Text = "";
					Text9[sub_Renamed.i].Text = "";
				}
				
				
				//记录体积数
				sub_Renamed.Tem = true;
				
				if (Metertype.SelectedIndex == 0) //需第一次读数为了表示值结束，
				{
					sub_Renamed.Readone = true; //不读温度值
					sub_Renamed.Rechen = false; //采集数据不计算误差
					sub_Renamed.cmd_type = "RD_HIGH_DATA";
					Biao_Xuhao = (short) 0;
					Timer21.Enabled = true;
					delay_times(1);
					do
					{
						System.Windows.Forms.Application.DoEvents();
					} while (!(Timer21.Enabled == false));
					delay_times(1);
				}
				//读终值
				sub_Renamed.Erstpunkt = false;
				sub_Renamed.Rechen = true; //用于采集数据计算误差
				
				
				switch (Metertype.SelectedIndex)
				{
					case 3: //力创汇中读数温度
					case 4:
					case 5:
						sub_Renamed.Readone = true; //不读温度值
						break;
					default:
						sub_Renamed.Readone = false; //读温度值
						break;
				}
				
				sub_Renamed.RechenLC = false;
				sub_Renamed.cmd_type = "RD_HIGH_DATA";
				Biao_Xuhao = (short) 0;
				
				Timer21.Enabled = true;
				Wancheng = false;
				
				do
				{
					System.Windows.Forms.Application.DoEvents();
				} while (!(Timer21.Enabled == false));
				Readingonerror();
				delay_times(1);
				
				switch (Metertype.SelectedIndex)
				{
					case 3: //力创汇中读数温度
					case 4:
					case 5:
						读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
						
						sub_Renamed.Erstpunkt = false;
						sub_Renamed.Readone = false; //读温度值
						sub_Renamed.RechenLC = true; //采集数据不计算误差
						sub_Renamed.cmd_type = "RD_DATA"; //读温度值
						Biao_Xuhao = (short) 0;
						Timer21.Enabled = true;
						Wancheng = false;
						
						do
						{
							System.Windows.Forms.Application.DoEvents();
						} while (!(Timer21.Enabled == false));
						Readingonerror();
						delay_times(1);
						break;
				}
				
				
				sub_Renamed.Tem = false;
				
				
				
				k = (short) 0;
				for (j = 0; j <= sub_Renamed.End_biaowei; j++)
				{
					
					if (Strings.Len(Text1[j].Text) == 8)
					{
						if (j == 0)
						{
							k = (short) 1;
						}
						else if (j == 1)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
						}
						else if (j == 2)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
						}
						else if (j == 3)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
						}
						else if (j == 4)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
						}
						else if (j == 5)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
						}
						else if (j == 6)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
						}
						else if (j == 7)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
						}
						else if (j == 8)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
						}
						else if (j == 9)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
						}
						else if (j == 10)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
						}
						else if (j == 11)
						{
							if (k == 0)
							{
								k = (short) 1;
							}
							else if (k == 1)
							{
								k = (short) 2;
							}
							else if (k == 2)
							{
								k = (short) 3;
							}
							else if (k == 3)
							{
								k = (short) 4;
							}
							else if (k == 4)
							{
								k = (short) 5;
							}
							else if (k == 5)
							{
								k = (short) 6;
							}
							else if (k == 6)
							{
								k = (short) 7;
							}
							else if (k == 7)
							{
								k = (short) 8;
							}
							else if (k == 8)
							{
								k = (short) 9;
							}
							else if (k == 9)
							{
								k = (short) 10;
							}
							else if (k == 10)
							{
								k = (short) 11;
							}
							else if (k == 11)
							{
								k = (short) 12;
							}
						}
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 1) = "q:" + "" + System.Convert.ToString(Llds) + "" + "、" + "Δθ:" + "" + System.Convert.ToString(Text14.Text) - double.Parse(Text12.Text);); //平均流量点
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 2) = Text1[j].Text; //表号
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 3) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlChuzhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 4) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlZhongzhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 5) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlShizhi[j], "##0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 6) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm0, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 7) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm1, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 8) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlm1 - sub_Renamed.Zlm0, "##0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 9) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.Zlwendu[j], "###0.##");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 10) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.ZlMiDu[j], "###0.####");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 11) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.BiaozhunzhiE[j], "###0.###");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 12) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Text9[j].Text, "0.0");
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 13) = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE, "0.00");
						
						
						if (System.Math.Abs(System.Convert.ToDouble(Text9[j].Text)) > sub_Renamed.JsyqE[xx - 1] * sub_Renamed.SicherE)
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14) = "不合格";
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14).Font.Color = 0xFF;
						}
						else
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14) = "合格";
						}
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 15) = j + 1;
						
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 14).Font.Color == 0xFF)
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 15).Font.Color = 0xFF;
						}
						
						
						
						sub_Renamed.Teminlet[xx, j] = (float) (Conversion.Val(Text10[2 * j].Text));
						sub_Renamed.Temoutlet[xx, j] = (float) (Conversion.Val(Text10[2 * j + 1].Text));
						//                Dim xy As Integer
						
						//                If xx > 2 Then
						//                xy = 2
						//                Else
						//                xy = xx
						//                End If
						sub_Renamed.TemVor[j] = (float) (Conversion.Val(Text10[2 * j].Text));
						sub_Renamed.TemRuc[j] = (float) (Conversion.Val(Text10[2 * j + 1].Text));
						
						//计算温度示值误差
						
						
						if (System.Math.Abs(sub_Renamed.TemVor[j] - double.Parse(Text14.Text)) > 0.3 + 0.005 * Conversion.Val(Text14.Text))
						{
							Text10[2 * j].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
						}
						else
						{
							Text10[2 * j].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
						}
						if (System.Math.Abs(sub_Renamed.TemRuc[j] - double.Parse(Text12.Text)) > 0.3 + 0.005 * Conversion.Val(Text12.Text))
						{
							Text10[2 * j + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0xFF);
						}
						else
						{
							Text10[2 * j + 1].ForeColor = System.Drawing.ColorTranslator.FromOle(0x0);
						}
						
						
						
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 16) = System.Math.Round(sub_Renamed.TemVor[j], 2);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 17) = System.Math.Round(sub_Renamed.TemRuc[j], 2);
						if (System.Math.Abs(sub_Renamed.TemVor[j] - double.Parse(Text14.Text)) > 0.3 + 0.005 * Conversion.Val(Text14.Text))
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 16).Font.Color = 0xFF;
						}
						if (System.Math.Abs(sub_Renamed.TemRuc[j] - double.Parse(Text12.Text)) > 0.3 + 0.005 * Conversion.Val(Text12.Text))
						{
							//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
							sub_Renamed.objExcel.ActiveSheet.Cells(5 + sub_Renamed.Jd_number * (xx - 1) + k, 17).Font.Color = 0xFF;
						}
						
					} //If Len(Text1(j).Text) > 0
					
					zz = 5 + sub_Renamed.Jd_number * (xx - 1) + k;
				}
				
				if (xx != sub_Renamed.Jd_point)
				{
					MessageBox.Show("请将恒温浴槽调到第" + "" + System.Convert.ToString(xx + 1) + "" + "检定点的" + "" + System.Convert.ToString(sub_Renamed.Jd_wc[xx]) + "" + "K 温差点!  点击《确定》将开始下一点检定!");
				}
				
			}
			yy = zz;
			
			Protokol1();
			
			
			if (frmzjsz.Default.Frame9.Enabled == true) //重复检测时
			{
				if (frmzjsz.Default.Option13.Checked == true) //重新排气时
				{
					Mdlguanfa.Send_Data((short) 250);
					delay_times(1);
					System.Int32 temp_i27 = 1;
					Mdlguanfa.Zhu_Guan(ref temp_i27); //关进水阀
					delay_times(1);
					System.Int32 temp_i28 = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i28); //称放水开
					delay_times(1);
					System.Int32 temp_i29 = 8;
					Mdlguanfa.Zhu_Kai(ref temp_i29); //开打压阀
				}
				else if (frmzjsz.Default.Option14.Checked == true) //不重新排气时
				{
					System.Int32 temp_i30 = 7;
					Mdlguanfa.Zhu_Kai(ref temp_i30); //称放水开
					delay_times(1);
				}
			}
			else
			{
				Mdlguanfa.Send_Data((short) 250);
				delay_times(1);
				System.Int32 temp_i31 = 1;
				Mdlguanfa.Zhu_Guan(ref temp_i31); //关进水阀
				delay_times(1);
				System.Int32 temp_i32 = 7;
				Mdlguanfa.Zhu_Kai(ref temp_i32); //称放水开
				delay_times(1);
				System.Int32 temp_i33 = 8;
				Mdlguanfa.Zhu_Kai(ref temp_i33); //开打压阀
			}
			
			Timer15.Enabled = false;
			
			
			
			//全部结束处理
			
			读数1.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数2.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数3.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数4.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数5.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数6.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数7.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数8.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数9.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数10.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数11.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			读数12.BackColor = System.Drawing.ColorTranslator.FromOle(0xC000);
			
			读数1.Enabled = false;
			读数2.Enabled = false;
			读数3.Enabled = false;
			读数4.Enabled = false;
			读数5.Enabled = false;
			读数6.Enabled = false;
			读数7.Enabled = false;
			读数8.Enabled = false;
			读数9.Enabled = false;
			读数10.Enabled = false;
			读数11.Enabled = false;
			读数12.Enabled = false;
			
			
			
			sub_Renamed.yibiao_No = int.Parse("");
			sub_Renamed.yibiao_No = int.Parse(Conversion.Str(Mdlguanfa.yibiaoNo).Trim());
			sub_Renamed.save_execel();
			sub_Renamed.objExcel.Workbooks(1).SaveAs((new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\report\\" + (sub_Renamed.yibiao_No).ToString().Trim() + ".xls");
			PrintZong();
			
			
			if (frmzjsz.Default.Frame9.Enabled == true) //如重新排气
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "检定完毕，重复本次检定点击《重复检测》。重新开始下次检定点击《退出》！";
				}
				else
				{
					Labt.Text = "Test is complete,the duplicate test clicks on the《Repeat》. Restart the new test you click on the 《Exit》 ! ";
				}
			}
			else
			{
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "检定完毕，重新开始下次检定点击《退出》！";
				}
				else
				{
					Labt.Text = "Test is complete, Restart the new test you click on the 《Exit》 ! ";
				}
			}
			
			//Set objExcel = Nothing
			//Me.Command2.Enabled = True
			sub_Renamed.Jdks = false;
			
			Label7[0].Visible = false;
			Label10.Visible = false;
			Label18.Visible = false;
			Label7[1].Visible = false;
			Label7[2].Visible = false;
			
			if (frmzjsz.Default.Frame9.Enabled == true)
			{
				wiederpruf.Enabled = true;
			}
			
			
			
		}
		private void PrintZong()
		{
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			short jd = 0;
			if (sub_Renamed.Comopen == false)
			{
				sub_Renamed.Title = "保存数据";
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("请你确认输入项是否正确？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
				if (msg == MsgBoxResult.Yes)
				{
					sub_Renamed.StrSql = "select * from zjjc ";
					sub_Renamed.RsZbs = new ADODB.Recordset();
					sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
					for (jd = 0; jd <= 11; jd++)
					{
						if (Strings.Len(Text1[jd].Text) > 0)
						{
							sub_Renamed.RsZbs.AddNew(null, null);
							sub_Renamed.RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
							sub_Renamed.RsZbs.Fields[1].Value = Text1[jd].Text;
							sub_Renamed.RsZbs.Fields[2].Value = DateAndTime.Today;
							sub_Renamed.RsZbs.Fields[3].Value = sub_Renamed.SongjianDanwei;
							sub_Renamed.RsZbs.Update(null, null);
						}
					}
					sub_Renamed.RsZbs.Close();
					
					//            MsgBox "保存完毕！保存路径\lib\jiliang.mdb jcjg", vbInformation, "保存完毕"
					//            MsgBox App.Path & "\report\" & Trim(yibiao_No) & ".xls"
					return;
				}
				else if (msg == MsgBoxResult.No)
				{
					
					return;
				}
			}
			else
			{
				sub_Renamed.StrSql = "select * from zjjc ";
				sub_Renamed.RsZbs = new ADODB.Recordset();
				sub_Renamed.RsZbs.Open(sub_Renamed.StrSql, sub_Renamed.db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, -1);
				for (jd = 0; jd <= 11; jd++)
				{
					if (Strings.Len(Text1[jd].Text) > 0)
					{
						sub_Renamed.RsZbs.AddNew(null, null);
						sub_Renamed.RsZbs.Fields[0].Value = Mdlguanfa.yibiaoNo; //jcbh ccbh rq sjdw1
						sub_Renamed.RsZbs.Fields[1].Value = Text1[jd].Text;
						sub_Renamed.RsZbs.Fields[2].Value = DateAndTime.Today;
						sub_Renamed.RsZbs.Fields[3].Value = sub_Renamed.SongjianDanwei;
						sub_Renamed.RsZbs.Update(null, null);
					}
				}
				sub_Renamed.RsZbs.Close();
			}
		}
		
		private void TPVorbereitung()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			float Jiandingliang = 0;
			
			if (frmzjsz.Default.Option15.Checked == true) //连续检定
			{
				Jiandingliang = 0;
				for (i = 1; i <= sub_Renamed.Jd_point; i++)
				{
					Jiandingliang = Jiandingliang + sub_Renamed.Jd_liang[sub_Renamed.i - 1];
				}
			}
			else
			{
				Jiandingliang = sub_Renamed.Jd_liang[0];
			}
			
			if ((Conversion.Val(Text3[0].Text) + Jiandingliang) >= 95)
			{
				
				System.Int32 temp_i = 6;
				Mdlguanfa.Zhu_Guan(ref temp_i); //大阀关
				delay_times(1);
				if (sub_Renamed.Ld4 == 5)
				{
					System.Int32 temp_i2 = 5;
					Mdlguanfa.Zhu_Guan(ref temp_i2); //中3水关
					delay_times(1);
				}
				if (sub_Renamed.Ld4 == 5 | sub_Renamed.Ld4 == 4)
				{
					delay_times(1);
					System.Int32 temp_i3 = 4;
					Mdlguanfa.Zhu_Guan(ref temp_i3); //中2关
				}
				delay_times(1);
				System.Int32 temp_i4 = 3;
				Mdlguanfa.Zhu_Guan(ref temp_i4); //中1水关
				delay_times(1);
				System.Int32 temp_i5 = 2;
				Mdlguanfa.Zhu_Guan(ref temp_i5); //小水关
				delay_times(1);
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "天平正在放水，请等候...";
				}
				else
				{
					Labt.Text = "The weighing container are drainage, please wait ...";
				}
				
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.2));F;);
				} while (!(Conversion.Val(Text3[0].Text) < 2));
				
				System.Int32 temp_i6 = 7;
				Mdlguanfa.Zhu_Guan(ref temp_i6); //放水关
				delay_times(1);
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "正在准备天平，请等候...";
				}
				else
				{
					Labt.Text = "Preparing balance, please wait ... ";
				}
				
				//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Dtpc = Conversion.Val(Text3[0].Text);
				System.Int32 temp_i7 = 6;
				Mdlguanfa.Zhu_Kai(ref temp_i7); //大水开
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.2));F;);
					Dtpm = (float) (Conversion.Val(Text3[0].Text));
					//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				} while (!(Dtpm >= System.Convert.ToInt32(Dtpc) + 3));
				System.Int32 temp_i8 = 6;
				Mdlguanfa.Zhu_Guan(ref temp_i8); //关大水
			}
			else
			{
				
				System.Int32 temp_i9 = 2;
				Mdlguanfa.Zhu_Guan(ref temp_i9); //中水1关
				delay_times(1);
				System.Int32 temp_i10 = 3;
				Mdlguanfa.Zhu_Guan(ref temp_i10); //中水2关
				delay_times(1);
				if (sub_Renamed.Ld4 == 4 | sub_Renamed.Ld4 == 5)
				{
					System.Int32 temp_i11 = 4;
					Mdlguanfa.Zhu_Guan(ref temp_i11); //小水关
					delay_times(1);
				}
				if (sub_Renamed.Ld4 == 5)
				{
					System.Int32 temp_i12 = 5;
					Mdlguanfa.Zhu_Guan(ref temp_i12); //中水2关
					delay_times(1);
				}
				System.Int32 temp_i13 = 7;
				Mdlguanfa.Zhu_Guan(ref temp_i13); //放水关
				delay_times(1);
				
				if (sub_Renamed.Chinese == true)
				{
					Labt.Text = "正在准备天平，请等候...";
				}
				else
				{
					Labt.Text = "Preparing balance, please wait ... ";
				}
				
				//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Dtpc = Conversion.Val(Text3[0].Text);
				do
				{
					System.Windows.Forms.Application.DoEvents();
					delay_times((0.2));F;);
					Dtpm = (float) (Conversion.Val(Text3[0].Text));
					//UPGRADE_WARNING: 未能解析对象 Dtpc 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				} while (!(Dtpm >= System.Convert.ToInt32(Dtpc) + 3));
				System.Int32 temp_i14 = 6;
				Mdlguanfa.Zhu_Guan(ref temp_i14); //关大水
				
			}
			
		}
		private void Protokol1()
		{
			object uu1 = null;
			object uu2 = null;
			object uu = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //
			
			//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu = zz + 1; //从表格最后一行的下行开始
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 1)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 2)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 3)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 4)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 5)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 6)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 7)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 8)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 9)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 10)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 11)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 12)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			//删除原记录表格
			for ( = ;zz; i >= 6); i--;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Rows 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				objExcel.ActiveSheet.Rows(i).Delete();
			}
			
			//For i = zz + 1 + uu To zz + 1 Step -1
			// objExcel.ActiveSheet.Rows(i).Delete
			//Next i
			
			
			
			
			
			//处理表格
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 1)
				{
					
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
				
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
				
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
				
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 3)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 4)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 5)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 6)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 7)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 8)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 9)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 10)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 11)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;6; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 12)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//划线工具
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(6, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Font.Size = 10;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(6, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(6, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
			
			
		}
		
		private void Protokol2()
		{
			object uu1 = null;
			object uu2 = null;
			object uu = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //
			
			//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu = zz + 1;
			
			for ( = ;yy + 1; i <= zz); i++;); //从上次表格结束处开始至最后一行。
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 1)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 2)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 3)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 4)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 5)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 6)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 7)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 8)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 9)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 10)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 11)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 12)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			//删除原记录表格
			for ( = ;zz; i >= yy + 1); i--;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Rows 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				objExcel.ActiveSheet.Rows(i).Delete();
			}
			
			//For i = zz + 1 + uu To zz + 1 Step -1
			// objExcel.ActiveSheet.Rows(i).Delete
			//Next i
			
			
			
			
			
			//处理表格
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 1)
				{
					
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
				
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
				
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
				
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 3)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 4)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 5)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 6)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 7)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 8)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 9)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 10)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 11)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;yy + 1; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 12)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//划线工具
			//If frmzjsz.Option11.value = False Then
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(yy + 1, 1), objExcel.ActiveSheet.Cells(zz, 15)).Font.Size = 10
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(yy + 1, 1), objExcel.ActiveSheet.Cells(zz, 15)).Borders.LineStyle = xlContinuous
			//     objExcel.ActiveSheet.Range(objExcel.ActiveSheet.Cells(yy + 1, 1), objExcel.ActiveSheet.Cells(zz, 15)).Borders.Weight = xlThin
			//Else
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(yy + 1, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Font.Size = 10;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(yy + 1, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(yy + 1, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
			//End If
			
		}
		private void Protokol3()
		{
			object uu1 = null;
			object uu2 = null;
			object uu = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C# //
			
			//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu = zz + 1; //从表格最后一行的下行开始
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 1)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 2)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 3)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 4)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 5)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 6)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 7)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 8)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 9)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 10)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 11)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 12)
				{
					for (j = 1; j <= 17; j++)
					{
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						sub_Renamed.objExcel.ActiveSheet.cells(uu, j) = sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j);
						//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
						if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, j).Font.Color == 0xFF)
						{
							sub_Renamed.objExcel.ActiveSheet.cells(uu, j).Font.Color = 0xFF;
						}
					}
					//UPGRADE_WARNING: 未能解析对象 uu 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu = System.Convert.ToInt32(uu) + 1;
				}
			}
			
			//删除原记录表格
			for ( = ;zz; i >= 7 + sub_Renamed.Jd_meter); i--;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Rows 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				objExcel.ActiveSheet.Rows(i).Delete();
			}
			
			//For i = zz + 1 + uu To zz + 1 Step -1
			// objExcel.ActiveSheet.Rows(i).Delete
			//Next i
			
			
			
			
			
			//处理表格
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 1)
				{
					
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
				
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
				
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
				
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 3)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 4)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 5)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 6)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 7)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 8)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 9)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (Sub_Renamed.objExcel.ActiveSheet.Cells(sub_Renamed.i, 15) == 10)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 11)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			uu2 = 0;
			for ( = ;7 + sub_Renamed.Jd_meter; i <= zz); i++;);
			{
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if (sub_Renamed.objExcel.ActiveSheet.cells(sub_Renamed.i, 15) == 12)
				{
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu1 = sub_Renamed.i;
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					uu2 = System.Convert.ToInt32(uu2) + 1;
				}
			}
			//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (uu2 != 1 & uu2 != 0)
			{
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				if ((int) uu2 == 2)
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					objExcel.ActiveSheet.Cells(uu1, 2).Clear();
				}
				else
				{
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
					sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 2, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Clear();
				}
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu2 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 uu1 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(System.Convert.ToDouble(System.Convert.ToInt32(uu1) - System.Convert.ToDouble(uu2)) + 1, 2), sub_Renamed.objExcel.ActiveSheet.Cells(uu1, 2)).Merge();
			}
			
			//划线工具
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(6, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Font.Size = 10;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			sub_Renamed.objExcel.ActiveSheet.range(sub_Renamed.objExcel.ActiveSheet.Cells(6, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Borders.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous;
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Cells 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: 未能解析对象 objExcel.ActiveSheet.Range 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Sub_Renamed.objExcel.ActiveSheet.Range(sub_Renamed.objExcel.ActiveSheet.Cells(6, 1), sub_Renamed.objExcel.ActiveSheet.Cells(zz, 17)).Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
			
			
		}
		private void delay_times(float pause)
		{
			object x = null;
			//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			x = VB.DateAndTime.Timer;
			do
			{
				System.Windows.Forms.Application.DoEvents();
				//UPGRADE_WARNING: 未能解析对象 x 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			} while (!(VB.DateAndTime.Timer- x > pause));
		}
	}
}
