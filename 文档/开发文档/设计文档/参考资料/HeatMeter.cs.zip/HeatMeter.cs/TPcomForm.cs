// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class TPcomForm : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static TPcomForm defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static TPcomForm Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new TPcomForm();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		public void btnCancel_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		public void btnOK_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			object msg = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Chinese == true)
			{
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("请您确认输入项是否正确，并保存？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "提示");
			}
			else
			{
				//UPGRADE_WARNING: 未能解析对象 msg 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				msg = Interaction.MsgBox("Please confirm the saved data are correct？", (int) MsgBoxStyle.YesNo + MsgBoxStyle.Question + MsgBoxStyle.ApplicationModal, "Note");
			}
			
			if (msg == MsgBoxResult.Yes)
			{
				sub_Renamed.TPBand = short.Parse(comboTPBand.Text);
				sub_Renamed.TPVerify = comboTPVerify.Text;
				sub_Renamed.TPData = short.Parse(comboTPData.Text);
				sub_Renamed.TPStop = short.Parse(comboTPStop.Text);
				
				if (Option2.Checked == true)
				{
					sub_Renamed.Bizerba = true;
					sub_Renamed.Satorius = false;
					sub_Renamed.Mettler = false;
					sub_Renamed.TP = "Bizerba";
				}
				else if (Option1.Checked == true)
				{
					sub_Renamed.Bizerba = false;
					sub_Renamed.Mettler = false;
					sub_Renamed.Satorius = true;
					sub_Renamed.TP = "Satorius";
				}
				else if (Option3.Checked == true)
				{
					sub_Renamed.Bizerba = false;
					sub_Renamed.Mettler = true;
					sub_Renamed.Satorius = false;
					sub_Renamed.TP = "Mettler";
				}
				
				FileSystem.FileClose(3);
				
				FileSystem.FileOpen(3, (new Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase()).Info.DirectoryPath + "\\tpcom.dll", OpenMode.Output, (Microsoft.VisualBasic.OpenAccess) (-1), (Microsoft.VisualBasic.OpenShare) (-1), -1);
				FileSystem.WriteLine(3, sub_Renamed.TPBand);
				FileSystem.WriteLine(3, sub_Renamed.TPVerify);
				FileSystem.WriteLine(3, sub_Renamed.TPData);
				FileSystem.WriteLine(3, sub_Renamed.TPStop);
				FileSystem.WriteLine(3, sub_Renamed.TP);
				FileSystem.FileClose(3);
				
				
			}
			else if (msg == MsgBoxResult.No)
			{
				return;
			}
			
			
			
			
			
			this.Close();
		}
		
		public void TPcomForm_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (sub_Renamed.Chinese == true)
			{
				this.Text = "天平串口设置";
				Label1.Text = "串口";
				Label2.Text = "波特率";
				Label3.Text = "校验位";
				Label4.Text = "数据位";
				Label5.Text = "停止位";
				btnOK.Text = "确定";
				btnCancel.Text = "取消";
			}
			else
			{
				this.Text = "Balance port";
				Label1.Text = "COM";
				Label2.Text = "Baut";
				Label3.Text = "Parity";
				Label4.Text = "Data";
				Label5.Text = "Stop";
				btnOK.Text = "Ok";
				btnCancel.Text = "Cancel";
			}
			
			comboTPPort.Items.Clear();
			comboTPBand.Items.Clear();
			comboTPVerify.Items.Clear();
			comboTPData.Items.Clear();
			comboTPStop.Items.Clear();
			
			
			//comboTPBand.AddItem "300"
			comboTPBand.Items.Add("600");
			comboTPBand.Items.Add("1200");
			comboTPBand.Items.Add("2400");
			comboTPBand.Items.Add("4800");
			comboTPBand.Items.Add("9600");
			//comboTPBand.AddItem "19200"
			//comboTPBand.AddItem "38400"
			
			comboTPVerify.Items.Add("None(无)");
			comboTPVerify.Items.Add("Odd(奇)");
			comboTPVerify.Items.Add("Even(偶)");
			
			comboTPData.Items.Add("8");
			comboTPData.Items.Add("7");
			comboTPData.Items.Add("6");
			
			comboTPStop.Items.Add("1");
			comboTPStop.Items.Add("2");
			
			comboTPPort.Text = (Conversion.Val((sub_Renamed.Com2).ToString())).ToString();
			comboTPBand.Text = (sub_Renamed.TPBand).ToString();
			comboTPVerify.Text = sub_Renamed.TPVerify;
			comboTPData.Text = (sub_Renamed.TPData).ToString();
			comboTPStop.Text = (sub_Renamed.TPStop).ToString();
			
			if (sub_Renamed.Satorius == true)
			{
				Option1.Checked = true;
			}
			if (sub_Renamed.Bizerba == true)
			{
				Option2.Checked = true;
			}
			if (sub_Renamed.Mettler == true)
			{
				Option3.Checked = true;
			}
		}
	}
}
