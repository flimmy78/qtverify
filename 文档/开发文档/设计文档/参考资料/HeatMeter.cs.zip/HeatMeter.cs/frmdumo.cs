// VBConversions Note: VB project level imports
using System.Collections;
using System.Windows.Forms;
using AxSIATOGGLELib;
using AxComctlLib;
using System.Data;
using AxMSDataGridLib;
using AxSIASLIDERLib;
using System.Diagnostics;
using AxMSComCtl2;
using System;
using Microsoft.VisualBasic;
using System.Drawing;
using AxMSHierarchicalFlexGridLib;
using AxMCI;
using AxMSCommLib;
using Microsoft.VisualBasic.Compatibility;
using AxComCtl2;
using AxThreed;
// End of VB project level imports


namespace 热量表
{
	partial class frmdumo : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmdumo defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static frmdumo Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmdumo();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		float jk;
		float jk1;
		short j;
		
		object s2;
		object i1;
		float ll;
		object s3;
		object s4;
		object s5;
		short[] s = new short[10];
		object s6;
		short[] M = new short[10];
		short Recount;
		string Rxd;
		short i;
		
		short malP;
		short malDP;
		float[] Lpres = new float[11];
		float[] Ldpre = new float[11];
		float Ppres;
		float DPpre;
		
		public void Cmdexit_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			this.Close();
		}
		
		
		
		private void Cmdkaishi_Click()
		{
			object Lab2 = null;
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Mdlguanfa.Send_Data((short) 233);
			Timer8.Enabled = true;
			
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Lab2.Caption = "请启动水泵";
			sub_Renamed.delay_times(3);
			// Lab2.Caption = "将大调节阀打开，设置后等30秒"
			//delay_times (30)
			
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Lab2.Caption = "打开中流量阀门";
			
			//    Send_Data (225)  'kai出水阀门
			sub_Renamed.delay_times(3);
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			lab2.Caption = "打开进水阀门";
			
			//
			sub_Renamed.delay_times(3);
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Lab2.Caption = "打开放水阀门";
			sub_Renamed.delay_times(3);
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			lab2.Caption = "请等待50秒......";
			sub_Renamed.delay_times(50);
			
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Lab2.Caption = "停止水泵";
			sub_Renamed.delay_times(3);
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			lab2.Caption = "关中流量阀门";
			sub_Renamed.delay_times(3);
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			lab2.Caption = "关进水阀门";
			sub_Renamed.delay_times(3);
			//Lab2.Caption = "点‘采压’将电压转换开关到采压状态"
			//delay_times (3)
			
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Lab2.Caption = "打开打压阀门";
			sub_Renamed.delay_times(3);
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Lab2.Caption = "启动电动打压泵,观察压力,到达一定压力后";
			sub_Renamed.delay_times(30);
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			lab2.Caption = "关闭打压阀门";
			sub_Renamed.delay_times(3);
			
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			lab2.Caption = "停止电动打压泵";
			sub_Renamed.delay_times(3);
			
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			= "保持压力，请稍候...";
			sub_Renamed.delay_times(120);
			
			//Lab2.Caption = "点‘变频’将电压转换开关到变频状态"
			//delay_times (3)
			
			
			//UPGRADE_WARNING: 未能解析对象 Lab2.Caption 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			lab2.Caption = "耐压实验结束，请打开中流量阀门泄压";
			sub_Renamed.delay_times(3);
			
			
		}
		
		public void Command1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			Text1.Text = (1).ToString();
			System.Int32 temp_i = 8;
			Mdlguanfa.Zhu_Kai(ref temp_i);
			sub_Renamed.delay_times(1);
			
		}
		
		private void Command10_Click()
		{
			//Send_Data (233)
			//delay_times (1)
		}
		
		private void Command11_Click()
		{
			//Send_Data (232)
			//delay_times (1)
		}
		
		public void Command2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			System.Int32 temp_i = 8;
			Mdlguanfa.Zhu_Guan(ref temp_i);
			sub_Renamed.delay_times(1);
			
			//    On Error Resume Next
			//    Timer8.Enabled = True
			//    j = 0
			//    Call qd
			//    Lab2.Caption = "启动水泵"
			//    Tiaojiexiao (80)
			//    delay_times (1)
			//    TiaojieDa (0)
			//
			//    Send_Data (225)  'kai出水阀门
			//    delay_times (1)
			//    Send_Data (227)  'kai进水阀门
			//
			//     delay_times (1)
			//    Send_Data (231)  'fang shui kai
			//    If Val(Text1.Text) > 200 Or Val(Text1.Text) < 20 Then Text1.Text = 30
			//    Lab2.Caption = "请稍候......"
			//    delay_times (Val(Text1.Text))
			//    Call tz
			//    Lab2.Caption = "停水泵"
			//    Send_Data (226)  '关出水阀门
			//    delay_times (1)   '‘
			//    Send_Data (224)  '关进口阀门
			//    delay_times (2)
			//
			//    Send_Data (233) ' 电压转换开关  采压
			//    delay_times (2)
			//
			//    Send_Data (239)  '打开电动阀阀门气动
			//    delay_times (1)
			//
			//    Lab2.Caption = "启动电泵"
			//    Send_Data (239)
			//    delay_times (1)
			//
			//    delay_times (1)
			//
			//    Do
			//       j = j + 1
			//       DoEvents
			//       delay_times (1)
			//       jk = Val(Text3.Text)
			//       jk1 = Val(Text4.Text)
			//    Loop Until jk >= jk1 Or j > 25
			//
			//        Lab2.Caption = "停电动泵"
			//
			//        Send_Data (238)  '关电动阀阀门气动
			//
			//        delay_times (1)
			//        Send_Data (238)
			//        delay_times (1)
			//
			//    Lab2.Caption = "保持压力，请等待。。。"
			//    delay_times (Val(Text2.Text))
			//
			//    Lab2.Caption = "耐压实验结束！"
			//    Send_Data (232) ' 电压转换开关 到变频
			//    delay_times (1)
			//    Send_Data (239) ' 写压
			//    delay_times (1)
			//    Send_Data (225) ' 写压
			//    delay_times (1)
			
		}
		
		public void Command3_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Mdlguanfa.Send_Data((short) 251);
			sub_Renamed.delay_times(1);
		}
		
		public void Command5_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 252);
			sub_Renamed.delay_times(1);
		}
		
		private void Command6_Click()
		{
			object Text11 = null;
			float Fdizhi;
			float Fzhi = 0;
			float Fzhi1 = 0;
			float Fzhi2;
			byte[] Fd = new byte[7];
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Text11.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Conversion.Val((text11.Text > 100).ToString()) || Conversion.Val(Text11.Text) < 0)
			{
				Text11.text = 50;
			}
			
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			
			
			
			//On Error Resume Next
			
			//If Option1.Enabled = True Then
			//  Fzhi = Val(Text11.Text) / 100 * 4095
			//  Fzhi1 = Fzhi / 256
			//  Fzhi2 = Fzhi Mod 256
			
			//  Fzhi = Int(Val(Text11.Text) * 4095 / 100 / 256)
			//  Fzhi1 = (Val(Text11.Text) * 4095 / 100) Mod 256
			//  Fzhi = Int(Val(Text11.Text) * 4095 / 100 / 256)
			//  Fzhi1 = (Val(Text11.Text) * 4095 / 100) Mod 256
			//UPGRADE_WARNING: 未能解析对象 Text11.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Fzhi = System.Convert.ToSingle(Conversion.Int(Conversion.Val(text11.Text) * 16 / 100));
			//UPGRADE_WARNING: 未能解析对象 Text11.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			Fzhi1 = System.Convert.ToSingle((Conversion.Val(Text11.text) * 40.96) % 256);
			// If Commini_1() = -1 Then GoTo 10004
			// 'dim fs(5) As Byte
			Fd[0] = (byte) 255;
			Fd[1] = (byte) 242;
			Fd[2] = () );Fzhi;
			Fd[3] = () );Fzhi1;
			Fd[4] = (byte) 254;
			
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Fd);
			return;
_10004:
			1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
		}
		
		public void Command7_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			System.Int32 temp_i = 7;
			Mdlguanfa.Zhu_Kai(ref temp_i);
			sub_Renamed.delay_times(1);
		}
		
		private void Command8_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 230);
			sub_Renamed.delay_times(1);
		}
		
		public void CommandX_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			System.Int32 temp_i = 3;
			Mdlguanfa.Zhu_Kai(ref temp_i);
			sub_Renamed.delay_times(1);
		}
		
		public void Commandxg_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			System.Int32 temp_i = 3;
			Mdlguanfa.Zhu_Guan(ref temp_i);
			sub_Renamed.delay_times(1);
		}
		
		public void CommandZ_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			System.Int32 temp_i = 1;
			Mdlguanfa.Zhu_Kai(ref temp_i);
			sub_Renamed.delay_times(1);
			
		}
		
		private void CommandZ1_Click()
		{
			//dim fs(5) As Byte
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			Mdlguanfa.fs[0] = (byte) 255;
			Mdlguanfa.fs[1] = (byte) 225;
			Mdlguanfa.fs[2] = (byte) 0;
			Mdlguanfa.fs[3] = (byte) 0;
			Mdlguanfa.fs[4] = (byte) 254;
			//    Send_Data = -1
			//    comm.MSComm1.InBufferCount = 0
			//      comm.MSComm1.OutBufferCount = 0
			//发送
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Mdlguanfa.fs);
			Module1.delay();
		}
		
		public void CommandZ2_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Text1.Text = (2).ToString();
			System.Int32 temp_i = 8;
			Mdlguanfa.Zhu_Kai(ref temp_i);
			sub_Renamed.delay_times(1);
			//Send_Data (232)
			//delay_times (1)
		}
		
		private void CommandZ3_Click()
		{
			Mdlguanfa.Send_Data((short) 225);
			sub_Renamed.delay_times(1);
		}
		
		private void CommandZ4_Click()
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			
			Mdlguanfa.Send_Data((short) 230);
			sub_Renamed.delay_times(1);
		}
		
		public void CommandZg_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			System.Int32 temp_i = 1;
			Mdlguanfa.Zhu_Guan(ref temp_i);
			sub_Renamed.delay_times(1);
		}
		
		public void frmdumo_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			sub_Renamed.Frmdumoactive = true;
			comm.Default.MSComm1.CommPort = sub_Renamed.Com1;
			Timer8.Enabled = true;
			
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			
		}
		
		private void fs_Click()
		{
			object Text11 = null;
			float Fdizhi;
			float Fzhi = 0;
			float Fzhi1 = 0;
			float Fzhi2;
			byte[] Fd = new byte[7];
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			//UPGRADE_WARNING: 未能解析对象 Text11.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Conversion.Val((text11.Text > 100).ToString()) || Conversion.Val(Text11.Text) < 0)
			{
				Text11.text = 50;
			}
			
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			
			//UPGRADE_WARNING: 未能解析对象 Text11.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Fzhi = (float) (Conversion.Int(Conversion.Val(Text11.text) * 16 / 100));
			//UPGRADE_WARNING: 未能解析对象 Text11.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			//UPGRADE_WARNING: Mod 有新行为。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"”
			Fzhi1 = System.Convert.ToSingle((Conversion.Val(Text11.text) * 40.96) % 256);
			
			// If Commini_1() = -1 Then GoTo 10004
			// 'dim fs(5) As Byte
			Fd[0] = (byte) 255;
			Fd[1] = (byte) 243;
			Fd[2] = () );Fzhi;
			Fd[3] = () );Fzhi1;
			Fd[4] = (byte) 254;
			
			comm.Default.MSComm1.Output = Microsoft.VisualBasic.Compatibility.VB6.Support.CopyArray(Fd);
			return;
_10004:
			1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
			
		}
		
		public void frmdumo_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			Timer8.Enabled = false;
			sub_Renamed.Frmdumoactive = false;
			if (comm.Default.MSComm1.PortOpen == true)
			{
				comm.Default.MSComm1.PortOpen = false;
			}
		}
		
		public void qd_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			if (comm.Default.MSComm1.PortOpen == false)
			{
				comm.Default.MSComm1.PortOpen = true;
			}
			
			
			Mdlguanfa.Send_Data((short) 249);
			sub_Renamed.delay_times(1);
		}
		
		//UPGRADE_WARNING: 初始化窗体时可能激发事件 Text1.TextChanged。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"”
		public void Text1_TextChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (Conversion.Val(Text1.Text) > 200)
			{
				MessageBox.Show("时间太长，请修改");
				Text1.Text = (100).ToString();
			}
			
		}
		
		private void Text4_Change()
		{
			object Text4 = null;
			//UPGRADE_WARNING: 未能解析对象 Text4.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			if (Conversion.Val() > 2.6)
			{
				MessageBox.Show("设定压力太大，请修改！");
				//UPGRADE_WARNING: 未能解析对象 Text4.Text 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
				= ;2;
				return;
			}
			
		}
		
		public void Timer8_Tick(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Mdlguanfa.Send_DataSl((short) 245); //liusu
			sub_Renamed.delay_times((0.4));F;);
			//UPGRADE_WARNING: 未能解析对象 comm.MSComm1.Input 的默认属性。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"”
			Rxd = System.Convert.ToString(comm.Default.MSComm1.Input);
			//UPGRADE_ISSUE: 不支持 LenB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
			Recount = System.Convert.ToInt16(LenB(Rxd));
			for (i = 1; i <= Recount; i++)
			{
				//UPGRADE_ISSUE: 不支持 MidB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				//UPGRADE_ISSUE: 不支持 AscB 函数。 单击以获得更多信息:“ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"”
				s[i] = System.Convert.ToInt16(AscB(MidB(Rxd, i, 1)));
			}
			if (s[2] == 245)
			{
				Lpres[malP] = (float) ((s[4] * 256 + s[5] - 883) * 0.0007783); //2.5MPa
				Ppres = Ppres + Lpres[malP];
				malP++;
				if (malP == 3)
				{
					Text3.Text = Microsoft.VisualBasic.Compatibility.VB6.Strings.Format(Ppres / 3, "0.00"); // 压力
					//                       If Val(Text4.Text) < 0.01 Then Text4.Text = "0.00"
					malP = (short) 0;
					Ppres = 0;
				}
				
				//                    Ldpre(malDP) = (s(6) * 256 + s(7) - 883) * 0.0467  '150kPa
				//                    DPpre = DPpre + Ldpre(malDP)
				//                    malDP = malDP + 1
				//                    If malDP = 3 Then
				//                       Text5.Text = Format(DPpre / 3, "0.0") ' 差压
				//                       If Val(Text5.Text) < 0.1 Then Text5.Text = "0.0"
				//                        malDP = 0
				//                        DPpre = 0
				//                    End If
				
			}
		}
		public void MSComm5_OnComm(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error GoTo aa
			//
			//   Dim abytReturnData() As Byte
			//   Dim strValue         As String
			//   Dim lngIndex         As Long
			//   Dim sngValue         As Single
			//   Select Case MSComm5.CommEvent
			//      Case 2
			//'         '*  仪表有数据返回
			//         abytReturnData = MSComm5.Input
			//
			//         sngValue = abytReturnData(1) * 256 + abytReturnData(0)
			//         If sngValue >= 32768 Then
			//            sngValue = sngValue - 65536
			//         End If
			//            Text3.Text = (sngValue) / 100
			//      Case Else
			//   End Select
			//aa:
		}
		
		public void tz_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
			Mdlguanfa.Send_Data((short) 250);
			sub_Renamed.delay_times(1);
			
		}
	}
}
